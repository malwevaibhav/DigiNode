module.exports = {
  encryption: {
    hash: 'projecthash',
    iv: 'projectiv',
  },
  secret: 'encryptionsecret'
};
