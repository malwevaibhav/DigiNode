// import mongoose from 'mongoose';
// const connection = require('./PatientSchema');

// //Create Schema
// const PatientSchema = new mongoose.Schema({


// }, { _id: false });

// //Note here we are using the secondary conn object to model this schema
// //module.exports = connection.model('loans', PatientSchema);
// export default mongoose.model<mongoose.Document>('loans', PatientSchema);