import mongoose from 'mongoose';

const EmployeeSchema = new mongoose.Schema(
    {
        LiquiStatus: {
            type: String
        },
        qube_ref_id: {
            type: String,
            unique: true,
        },
        organization_name: {
            type: String
        },
        occupation: {
            type: String
        },
        gender: {
            type: String,
            enum: ['M', 'F', 'T', 'O'],
        },
        applicant_id: {
            type: Number,
            // unique: true,
            required: false,
        },
        applicant_id_updated: {
            type: Boolean,
            default: false
        },
        qube_limit_updated: {
            type: Boolean,
            default: false
        },
        digiComment: {
            type: String
        },
        LLapproved: {
            type: Boolean
        },
        ////
        Employee_name: {
            type: String,
        },
        Mobile_no: {
            type: String,
        },
        EmailId: {
            type: String,
        },
        Joining_date: {
            type: Date,
        },
        Date_of_birth: {
            type: Date,
        },
        Pan_no: {
            type: String,
        },
        Aadhaar_no: {
            type: String,
        },
        Address: {
            type: String,
        },
        state: {
            type: String,
        },
        City: {
            type: String,
        },
        PinCode: {
            type: Number,
        },
        //monthly
        salary: {
            type: Number,
        },
        // address
        area: {
            type: String,
        },
        address_line_1: {
            type: String,
        },
        address_line_2: {
            type: String,
        },
        address_type: {
            type: String,
            enum: ['Current', 'Permanent', 'AlternateAddress', 'Office']
        },
        address_ownership_type: {
            type: String,
            enum: ['Owned', 'Rented', 'FamilyOwned']
        },

        // Limits

        Loan_limit: {
            type: Number,
            default: 0,
        },
        upper_limit: String,
        available_limit: String,
        block_limit: Number,

        credit_line_schemes: {
            type: Array
        },
        tenure: {
            type: Number,
        },

        //// bank details
        account_type: {
            type: String,
            enum: ["Saving", "Current"],
        },

        bank_name: {
            type: String,
        },

        ifsc: {
            type: String,
        },

        account_number: {
            type: String,
        },

        account_holder_name: {
            Types: String,
        },

        //documents
        aadhaarImageURL: {
            type: String
        },
        PANImageURL: {
            type: String
        },
        kycXmlURL: {
            type: String
        },
        agreementLetterURL: {
            type: String
        },
        agreement_doc_id: {
            type: String
        },
        agreement_pdf: {
            type: String
        },

        // flags
        bank_details_submitted: {
            type: Boolean,
            default: false
        },
        address_submitted: {
            type: Boolean,
            default: false
        },
        pan_uploaded: {
            type: Boolean,
            default: false
        },
        aadhaar_uploaded: {
            type: Boolean,
            default: false
        },
        agreement_uploaded: {
            type: Boolean,
            default: false
        },
        agreement_generated: {
            type: Boolean,
            default: false
        },
        isDeleted: {
            type: Boolean,
            default: false
        },
        isActive: {
            type: Boolean,
            default: true
        },
        updatedBy: {
            type: mongoose.Schema.Types.ObjectId,
            default: null,
            require: false,
        },
        EmpSOA: {
            type: String
        }
    },
    {
        timestamps: true,
    }
);

export default mongoose.model<mongoose.Document>('Employee', EmployeeSchema);

export interface EmployeeDoc extends mongoose.Document {
    address_submitted: Boolean,
    bank_details_submitted: Boolean,
    pan_uploaded: Boolean,
    aadhaar_uploaded: Boolean,
    Address: string,
    state: string,
    City: string,
    PinCode: number,
    address_line_1: string,
    address_line_2: string,
    address_type: string,
    area: string,
    account_holder_name: string,
    account_number: string,
    account_type: string,
    bank_name: string,
    ifsc: string,
    PANImageURL: string,
    aadhaarImageURL: string,
    Employee_name: string,
    Date_of_birth: Date,
    Mobile_no: string,
    Pan_no: string,
    Aadhaar_no: string,
    Joining_date: Date,
    salary: number,
    organization_name: string,
    EmailId: string
}
