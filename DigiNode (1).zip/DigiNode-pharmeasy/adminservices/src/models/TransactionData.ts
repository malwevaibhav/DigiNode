import mongoose from 'mongoose';


const TransactionDataSchema = new mongoose.Schema({
    invoiceId: {
        type: mongoose.Schema.Types.ObjectId
    },
    LoanID: {
        type: Number
    },
    hospialId: {
        type: mongoose.Schema.Types.ObjectId
    },
    aggregatorId: {
        type: mongoose.Schema.Types.ObjectId
    },
    lenderId: {
        type: mongoose.Schema.Types.ObjectId
    },
    vendorId: {
        type: mongoose.Schema.Types.ObjectId
    },
    InvoiceNumber: {
        type: String
    },
    claimId: {
        type: String
    },
    AmountDisbursed: {
        type: Number
    },
    transactionDate: {
        type: Date
    },
    AmountToBePaid: {
        type: Number
    },
    Interest: {
        type: Number
    },
    SettleStatus: {
        type: String
    },
    AdditionalDays: {
        type: Number
    },
    AdditionalInterest: {
        type: Number
    },
    RemainingAmount: {
        type: Number
    },
    AmountReceived: {
        type: Number
    },
    NEFT_RTG: {
        type: String
    },
    createdBy: {
        type: mongoose.Schema.Types.ObjectId
    },
}, { timestamps: true });

export default mongoose.model<mongoose.Document>('TransactionData', TransactionDataSchema);
