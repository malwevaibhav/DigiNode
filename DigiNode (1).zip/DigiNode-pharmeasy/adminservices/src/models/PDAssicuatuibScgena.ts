
import mongoose from 'mongoose';

const HVAssociationSchema = new mongoose.Schema({

    DistibuterId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Users'
    },
    DistibuterName: {
        type: String
    },
    PvendorId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Users'
    },
    PvendorName: {
        type: String
    },
    isDeleted: {
        type: Boolean,
        default: false
    },
    AvailableLimit: {
        type: Number
    },
    UtilizedAmount: {
        type: Number
    },
    Repayment: {
        type: Number
    },
    creditLimit:{
        type: Number
    }
}, { timestamps: true });


export default mongoose.model<mongoose.Document>('HVAssociation', HVAssociationSchema);

export interface HVAssociationDoc extends mongoose.Document {
    DistibuterName: string,
    DistibuterId: string,
    PvendorId: string,
    PvendorName: string,
    AvailableLimit: number,
    Repayment: number,
    UtilizedAmount: number,
    creditLimit: Number
}

