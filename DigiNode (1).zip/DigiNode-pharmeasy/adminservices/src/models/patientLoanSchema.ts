import { ObjectID, ObjectId } from 'mongodb';
import mongoose from 'mongoose';
const AutoIncrement = require('mongoose-sequence')(mongoose);

const loansSchema = new mongoose.Schema(
  {
    //org
    organizationId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'organizationschemas',
    },
    organizationName: {
      type: String
    },
    uploadedViaExcel: {
      type: Boolean
    },
    //invoice Type/Status
    isInsured: {
      type: Boolean,
    },
    invoiceStatus: {
      type: String,
      enum: ['Pending', 'Ops Pending', 'Ops Verification', 'Ops Hold', 'Ops TBD', 'InProcess', 'Approved', 'Soft Approved', 'Approved_level_1', 'Disbursed', 'Partially Repaid', 'Closed', 'Rejected', 'Withdraw'],
      default: 'Pending',
    },
    invoiceSubStatus: {
      type: String,
      enum: ['Pending at DSPL',
        'Pending at Claim Processing Team',
        'Pending for Final Approval Amount',
        'Pending at Lender',
        'Pending Agreement Signing',
        'Pending E-Nach',
        'Upload Final Bill',
        'Pending Disbursement',
        'Rejected by DSPL',
        'Rejected by Under-Writing Partner',
        'Rejected by Lender',
        'Additional Information requested by Lender',
        'Additional Information requested by Under-Writing Partner',
        'Awaiting Agreement Signing',
        'Awaiting Bank Verification',
        'Bank Verified',
        'Pending Bank Verification',
        'Agreement Signing Failed',
        'Mandate Authentication Successful',
        'Mandate Authentication Failed',
        'Mandate Accepted by Destination Bank',
        'Mandate Rejected by Destination Bank'
      ],
    },
    digiComment: {
      type: String,
    },
    // patient
    patientName: {
      type: String,
    },
    //borrower
    borrowerName: {
      type: String,
    },
    relation: {
      type: String,
    },
    dateOfBirth: {
      type: Date,
    },
    emailId: {
      type: String,
    },
    contactNumber: {
      type: Number,
    },
    PANNumber: {
      type: String
    },
    currentAddress: {
      type: String,
    },
    permanentAddress: {
      type: String,
    },
    //occupaption details
    occupation: {
      type: String,
    },
    companyName: {
      type: String,
    },
    totalIncome: {
      type: Number,
    },
    //loan details
    loanAmount: {
      type: Number,
    },
    scheme: {
      type: Number,
    },
    interest: {
      type: Number,
    },
    processingFees: {
      type: Number,
    },
    //borrower's bank details
    accountNumber: {
      type: String,
    },
    accountHolderName: {
      type: String
    },
    bankAssociated: {
      type: String,
    },
    branch: {
      type: String,
    },
    IFSCCode: {
      type: String,
    },
    //reference person
    referenceName: {
      type: String,
    },
    contactNoRefPerson: {
      type: Number,
    },
    relationship: {
      type: String,
    },
    emailIdRefPerson: {
      type: String,
    },
    // hospital
    hospitalName: {
      type: String,
    },
    // upload documents
    uploadAadharFront: {
      type: String,
    },
    uploadAadharBack: {
      type: String,
    },
    uploadPAN: {
      type: String,
    },
    uploadHospitalBill: {
      type: String,
    },
    uploadCancelledCheque: {
      type: String,
    },
    //relationship proof
    uploadProof: {
      type: String,
    },
    uploadIncomeProof: {
      type: String,
    },
    uploadBankStatement: {
      type: String,
    },
    uploadInsurancePolicy: {
      type: String,
    },
    uploadOtherDoc: {
      type: String,
    },
    NTCDoc: {
      type: String,
    },
    createdAt: {
      type: Date,
    },
    updatedAt: {
      type: Date,
    },
    isDeleted: {
      type: Boolean,
      default: false
    },
    isActive: {
      type: Boolean,
    },
    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'users',
    },

    // Disbursement data
    lenderStatus: {
      type: String,
    },
    Down_Payment_Amount: {
      type: Number,
    },
    Subvention_Amount: {
      type: Number,
    },
    PF_Amount: {
      type: Number,
    },
    Franking_Amount: {
      type: Number,
    },
    interest_Amount: {
      type: Number,
    },
    GST_Amount: {
      type: Number,
    },
    deduction_Amount: {
      type: Number,
    },
    EMI_Tenure: {
      type: Number,
    },
    EMI_Amount: {
      type: Number,
    },
    Approval_Date: {
      type: Date,
    },
    Disbursed_Amount: {
      type: Number,
    },
    Disbursement_Date: {
      type: Date,
    },
    Unique_Ref_No: {
      type: String,
    },
    Cash_Out_Flow_Amount: {
      type: Number,
    },
    invoiceId: {
      type: Number,
      index: { unique: true },
    },
    permanentPinCode: {
      type: Number,
    },
    permanentCity: {
      type: String,
    },
    permanentState: {
      type: String,
    },
    currentPinCode: {
      type: Number,
    },
    currentCity: {
      type: String,
    },
    currentState: {
      type: String,
    },
    permanentDistrict: {
      type: String,
    },
    currentDistrict: {
      type: String,
    },
    aadhaarNumber: {
      type: String,
    },
    UWPartnerApproved: {
      type: Boolean,
    },
    caseId: {
      type: String
    },
    UWApprovedAmount: {
      type: Number
    },
    UWName: {
      type: String
    },
    UTR: {
      type: String
    },
    Application_Date: {
      type: Date
    },
    loan_id: {
      type: String,
      // unique: true,
      // sparse:true

    },
    treatmentDetails: {
      type: String
    },
    DSPLAssignee: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'users'
    },
    lenderApprovedAmount: {
      type: Number
    },
    lenderComment: {
      type: String
    },
    finalApprovedAmount: {
      type: Number
    },
    UWComment: {
      type: String
    },
    agreementDocUrl: {
      type: String
    },
    agreementDocId: {
      type: String
    },
    agreementESignedOn: {
      type: Date
    },
    KYCRequestId: {
      type: String
    },
    KYCActionId: {
      type: String
    },
    mandate_id: {
      type: String
    },
    failureReason: {
      type: String
    },
    mandateUMRN: {
      type: String
    },
    // Settlement
    settlementDate: {
      type: Date
    },
    settlementAmount: {
      type: Number
    },
    settlementLetter: {
      type: String,
    },
    approvalLetter: {
      type: String
    },
    LenderId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'organizationschemas',
    },
    lineOfCredit: {
      type: Number
    },
    recommendedAmount: {
      type: Number
    },
    TotalDisbursementAmount: {
      type: Number
    },
    UTRNumber: {
      type: String
    },
    altContactNumber: {
      type: String
    },
    gender: {
      type: String
    },
    templateId: {
      type: String
    },
    agreementTemplateId: {
      type: String
    },
    uploadFinalBill: {
      type: String
    },
    uploadCibil: {
      type: String
    },
    cibil_score: {
      type: String
    }
  },
  {
    timestamps: true,
  },
);
loansSchema.plugin(AutoIncrement, {
  inc_field: 'invoiceId',
  start_seq: 303001,
});

export default mongoose.model<mongoose.Document>('patientloans', loansSchema);

export interface patientLoanDoc extends mongoose.Document {
  invoiceStatus: string,
  loanAmount: number,
  lenderApprovedAmount: number,
  accountNumber: string,
  contactNumber: string,
  emailId: any,
  patientName: string,
  invoiceId: any,
  mandate_id: string,
  mandateDetailsId:ObjectID,
  bankAssociated: string,
  IFSCCode: string,
  accountType: string,
  agreementDocUrl: string,
  invoiceSubStatus: string,
  agreementDocId: string,
  agreementESignedOn: Date,
  accountHolderName: string,
  finalApprovedAmount: number,
  KYCRequestId: string,
  KYCActionId: string,
  uploadHospitalBill: string,
  mandateUMRN: string,
  UWApprovedAmount: number,
  borrowerName: string,
  currentAddress: string,
  currentCity: string,
  currentState: string,
  dateOfBirth: Date,
  PANNumber: string,
  LenderId: ObjectId,
  lineOfCredit: number,
  recommendedAmount: number,
  NTCDoc: string,
  UTRNumber: string,
  altContactNumber: string,
  permanentPinCode: number;
  permanentCity: string;
  permanentState: string;
  permanentDistrict: string;
  currentDistrict: string;
  currentPinCode: number;
  permanentAddress: string;
  gender: string;
  agreementTemplateId: string;
  Tenure: number;
  loan_id: any;
  interest: number;
  processingFees: number;
  TotalDisbursementAmount: number;
  scheme: number;
  uploadFinalBill: String;
  approvalLetter: String;
  uploadPAN: String;
  uploadAadharFront : String; 
  uploadAadharBack : String;
  uploadCibil : String;
  cibil_score : String;
}
