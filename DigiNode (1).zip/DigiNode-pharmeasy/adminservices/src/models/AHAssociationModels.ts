import mongoose from 'mongoose';

const AHAssociationSchema = new mongoose.Schema({

    hospitalId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Users'
    },
    hospitalName: {
        type: String
    },
    vendorId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Users'
    },
    vendorName: {
        type: String
    },
    isDeleted: {
        type: Boolean,
        default: false
    },
    AvailableLimit: {
        type: Number
    },
    UtilizedAmount: {
        type: Number
    },
    Repayment: {
        type: Number
    },
    creditLimit: {
        type: Number
    },

    Hospital: {
        type: String,
    },
    Aggregator: {
        type: String,
    },


}, { timestamps: true });


export default mongoose.model<mongoose.Document>('AHAssociation', AHAssociationSchema);

export interface AHAssociationDoc extends mongoose.Document {
    hospitalName: string,
    hospitalId: string,
    vendorId: string,
    vendorName: string,
    AvailableLimit: number,
    Repayment: number,
    UtilizedAmount: number,
    creditLimit: Number,
    Hospital: Array<string>,
    Aggregator: any
}
