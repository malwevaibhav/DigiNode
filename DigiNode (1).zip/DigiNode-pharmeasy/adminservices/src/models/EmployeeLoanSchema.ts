import mongoose from 'mongoose';

const EmployeeLoanSchema = new mongoose.Schema(
    {
        qube_ref_id: {
            type: String,
            required: true,
        },
        Employee_id: {
            type: String,
            required: true,
        },

        qube_loan_id: {
            type: String,
            required: true,
            unique: true,
        },
        LL_loan_id: {
            type: Number,
        },

        product_id: {
            type: mongoose.Schema.Types.ObjectId,
            require: false,
        },

        status: {
            type: String,
            // required: true,
            enum: ["disbursed", "cancelled", "repaid"],

        },

        loanAmount: {
            type: Number,
            required: true,
        },

        loanTenure: {
            //in months 1-12
            type: Number,
            enum: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
            required: true,
        },

        hospitalName: {
            type: String,
            // required: true,
        },

        ROI: {
            type: Number,
        },

        totalInterest: {
            type: Number,
        },

        EMI: {
            type: Number,
        },

        DisbursementDate: {
            type: Date,
            // required: true,
        },

        qubeComment: {
            type: String,
        },

        isActive: {
            type: Boolean,
            default: true,
        },

        isDeleted: {
            type: Boolean,
            default: false,
        },

        updatedBy: {
            type: mongoose.Schema.Types.ObjectId,
            default: null,
            require: false,
        },
    },
    {
        timestamps: true,
    }
);

export default mongoose.model<mongoose.Document>('EmployeeLoan', EmployeeLoanSchema);

