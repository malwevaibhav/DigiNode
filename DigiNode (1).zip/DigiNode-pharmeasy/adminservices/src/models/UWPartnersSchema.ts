import mongoose from 'mongoose';

const UWPartner = new mongoose.Schema({
    partnerName: {
        type: String,
    },
    isDeleted: {
        type: Boolean,
        default: false
    },
}, { timestamps: true });

export default mongoose.model<mongoose.Document>('UWPartner', UWPartner);

export interface UWPartnerDoc extends mongoose.Document {
    partnerName: string
}