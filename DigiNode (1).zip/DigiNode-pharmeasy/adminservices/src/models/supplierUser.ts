// import mongoose from 'mongoose';
// // const connection = require('./Supplier.schema');

// const Schema = mongoose.Schema;

// //Create Schema
// const SupplierSchema = new Schema({


// }, { _id: false });

// //Note here we are using the secondary conn object to model this schema
// // module.exports = connection.model('supplier_user', SupplierSchema);