import { Container } from 'typedi';
import { Logger } from 'winston';
import claimInvoices from '../models/claimInvoiceSchema';
import userModel from '../models/user';
import orgModel from '../models/organizationSchema';
import businessLogicsModel from '../models/businessLogicSchema'
import TransactionData from '../models/TransactionData';

export default class claimDueDateJob {
    public async handler(job, done): Promise<void> {
        const Logger: Logger = Container.get('logger');
        try {
            Logger.debug('running claimDueDateJob job');
            const invoices = await claimInvoices.find({ $or: [{ Status: "Disbursed" }, { Status: "Partially Repaid" }], DueDate: { $lte: new Date() } })
            async function updateInterest() {
                try {
                    loop1: for (var i = 0; i < invoices.length; i++) {
                        var invoice = invoices[i];
                        var anchorDetails: any = {};
                        var hosDetail: any = await orgModel.findOne({ _id: invoice.hospitalId })
                        const businessLogicsData: any = await businessLogicsModel.findOne({ hospitalId: invoice.hospitalId });

                        var AmountToBePaid = invoice.RemainingAmount ? invoice.RemainingAmount : invoice.LenderApprovalAmount;
                        var ROI = 0;
                        if (hosDetail && hosDetail.AdditionalInterest) { ROI = hosDetail.AdditionalInterest } else { console.log('Hospital Additional Interest not found') }

                        var date2 = new Date(invoice.DueDate);
                        var date1 = new Date();

                        var AdditionalDays;
                        AdditionalDays = Math.floor(
                            (date1.getTime() - date2.getTime()) / (1000 * 60 * 60 * 24)
                        );
                        var AdditionalInterest = 0;
                        if (AdditionalDays == 1) {
                            AdditionalInterest = Math.round((AmountToBePaid * ROI) / 100);
                            anchorDetails.AdditionalDays = AdditionalDays;
                        }
                        else if (AdditionalDays == 31) {
                            AdditionalInterest = Math.round((AmountToBePaid * ROI) / 100);
                            anchorDetails.AdditionalDays = AdditionalDays;
                        }
                        else { continue }

                        var RemainingAmount = 0;
                        var RemainingAmount = Math.round(AmountToBePaid + AdditionalInterest);

                        var usrObj: any = {};
                        usrObj.AvailableLimit = hosDetail.AvailableLimit - AdditionalInterest;
                        usrObj.UtilizedAmount = hosDetail.UtilizedAmount + AdditionalInterest;

                        anchorDetails.AdditionalInterest = AdditionalInterest;
                        anchorDetails.RemainingAmount = RemainingAmount;

                        /// transaction log

                        const transaction = await TransactionData.create({
                            invoiceId: invoice._id,
                            LoanID: invoice.LoanID,
                            hospialId: invoice.hospitalId,
                            aggregatorId: invoice.aggregatorId,
                            lenderId: invoice.LenderId,
                            claimId: invoice.claimId,
                            AmountDisbursed: invoice.AmountDisbursed,
                            AmountToBePaid: invoice.AmountToBePaid,
                            Interest: invoice.Interest,
                            SettleStatus: "Overdue",
                            RemainingAmount: RemainingAmount,
                            AdditionalInterest: AdditionalInterest,
                            transactionDate: new Date()
                        });
                        ///

                        var updateInvoice = await claimInvoices.findOneAndUpdate(
                            { _id: invoice._id },
                            { $set: anchorDetails },
                            { useFindAndModify: false }
                        );
                        var updateHos = await orgModel.findOneAndUpdate(
                            { _id: hosDetail._id },
                            { $set: usrObj },
                            { useFindAndModify: false }
                        );
                        Logger.debug(`${invoice.LoanID} past due date, updated`);
                    };
                } catch (e) { Logger.error(`🔥 Error updating case id : ${invoices[i].LoanID}` + '-' + `${e}`) }

            }
            updateInterest();
            Logger.debug('claimDueDateJob finished');
            done();
        } catch (e) {
            Logger.error('🔥 Error with claimDueDateJob Job: %o', e);
            done(e);
        }
    }
}
