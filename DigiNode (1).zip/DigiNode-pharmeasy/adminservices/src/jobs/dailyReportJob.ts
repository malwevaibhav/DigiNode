import { Container } from 'typedi';
import { Logger } from 'winston';
import moment from 'moment';
import claimInvoices from '../models/claimInvoiceSchema';
import SupplierInvoice from '../models/SupplierInvoiceSchema';
import patientLoans from '../models/patientLoanSchema';
import merchantLoans from '../models/loans';
import ApprovedLoans from '../models/ApprovedLoans';
import axios, { AxiosRequestConfig, AxiosResponse } from 'axios';

export default class dailyReportJob {
    public async handler(job, done): Promise<void> {
        const Logger: Logger = Container.get('logger');
        try {
            Logger.debug('running dailyReportJob');
            var date = moment.utc();
            var currentDate = date.date();
            var currentMonth = date.month() + 1;
            var currentMonthYear = date.year();

            const claimData = await claimInvoices.aggregate([
                {
                    $facet: {
                        claimMTDAmount: [
                            { $project: { Status: 1, LenderApprovalAmount: 1, month: { $month: '$FundedDate' }, year: { $year: '$FundedDate' } } },
                            {
                                $match: {
                                    $and: [
                                        { month: currentMonth, year: currentMonthYear },
                                        { $or: [{ Status: "Disbursed" }, { Status: "Partially Repaid" }, { Status: "Fully Repaid" }, { Status: "RepaymentConfirmed" }] },
                                    ],
                                },
                            },
                            { $group: { _id: "$_v", total: { $sum: "$LenderApprovalAmount" } } },
                        ],
                        claimMTDCount: [
                            { $project: { Status: 1, month: { $month: '$FundedDate' }, year: { $year: '$FundedDate' } } },
                            {
                                $match: {
                                    $and: [
                                        { month: currentMonth, year: currentMonthYear },
                                        { $or: [{ Status: "Disbursed" }, { Status: "Partially Repaid" }, { Status: "Fully Repaid" }, { Status: "RepaymentConfirmed" }] },
                                    ],
                                },
                            },
                            { $count: "total" },
                        ],
                        claimFTDAmount: [
                            { $project: { Status: 1, LenderApprovalAmount: 1, dayOfMonth: { $dayOfMonth: '$FundedDate' }, month: { $month: '$FundedDate' }, year: { $year: '$FundedDate' } } },
                            {
                                $match: {
                                    $and: [
                                        { dayOfMonth: currentDate, month: currentMonth, year: currentMonthYear },
                                        { $or: [{ Status: "Disbursed" }, { Status: "Partially Repaid" }, { Status: "Fully Repaid" }, { Status: "RepaymentConfirmed" }] },
                                    ],
                                },
                            },
                            { $group: { _id: "$_v", total: { $sum: "$LenderApprovalAmount" } } },
                        ],
                        claimFTDCount: [
                            { $project: { Status: 1, dayOfMonth: { $dayOfMonth: '$FundedDate' }, month: { $month: '$FundedDate' }, year: { $year: '$FundedDate' } } },
                            {
                                $match: {
                                    $and: [
                                        { dayOfMonth: currentDate, month: currentMonth, year: currentMonthYear },
                                        { $or: [{ Status: "Disbursed" }, { Status: "Partially Repaid" }, { Status: "Fully Repaid" }, { Status: "RepaymentConfirmed" }] },
                                    ],
                                },
                            },
                            { $count: "total" },
                        ],
                    }
                }
            ]
            )
            var claimMTDAmount = 0;
            var claimMTDCount = 0;
            var claimFTDAmount = 0;
            var claimFTDCount = 0;
            if (claimData[0].claimMTDAmount[0] != undefined) { claimMTDAmount = claimData[0].claimMTDAmount[0].total }
            if (claimData[0].claimMTDCount[0] != undefined) { claimMTDCount = claimData[0].claimMTDCount[0].total }
            if (claimData[0].claimFTDAmount[0] != undefined) { claimFTDAmount = claimData[0].claimFTDAmount[0].total }
            if (claimData[0].claimFTDCount[0] != undefined) { claimFTDCount = claimData[0].claimFTDCount[0].total }

            const supplierData = await SupplierInvoice.aggregate([
                {
                    $facet: {
                        supplierMTDAmount: [
                            { $project: { Status: 1, LTVAmount: 1, month: { $month: '$PaymentDate' }, year: { $year: '$PaymentDate' } } },
                            {
                                $match: {
                                    $and: [
                                        { month: currentMonth, year: currentMonthYear },
                                        { $or: [{ Status: "Disbursed" }, { Status: "Partially Repaid" }, { Status: "Fully Repaid" }, { Status: "Hospital Repaid" }] },
                                    ],
                                },
                            },
                            { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } },
                        ],
                        supplierMTDCount: [
                            { $project: { Status: 1, month: { $month: '$PaymentDate' }, year: { $year: '$PaymentDate' } } },
                            {
                                $match: {
                                    $and: [
                                        { month: currentMonth, year: currentMonthYear },
                                        { $or: [{ Status: "Disbursed" }, { Status: "Partially Repaid" }, { Status: "Fully Repaid" }, { Status: "Hospital Repaid" }] },
                                    ],
                                },
                            },
                            { $count: "total" },
                        ],
                        supplierFTDAmount: [
                            { $project: { Status: 1, LTVAmount: 1, dayOfMonth: { $dayOfMonth: '$PaymentDate' }, month: { $month: '$PaymentDate' }, year: { $year: '$PaymentDate' } } },
                            {
                                $match: {
                                    $and: [
                                        { dayOfMonth: currentDate, month: currentMonth, year: currentMonthYear },
                                        { $or: [{ Status: "Disbursed" }, { Status: "Partially Repaid" }, { Status: "Fully Repaid" }, { Status: "Hospital Repaid" }] },
                                    ],
                                },
                            },
                            { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } },
                        ],
                        supplierFTDCount: [
                            { $project: { Status: 1, dayOfMonth: { $dayOfMonth: '$PaymentDate' }, month: { $month: '$PaymentDate' }, year: { $year: '$PaymentDate' } } },
                            {
                                $match: {
                                    $and: [
                                        { dayOfMonth: currentDate, month: currentMonth, year: currentMonthYear },
                                        { $or: [{ Status: "Disbursed" }, { Status: "Partially Repaid" }, { Status: "Fully Repaid" }, { Status: "Hospital Repaid" }] },
                                    ],
                                },
                            },
                            { $count: "total" },
                        ],
                    }
                }
            ]
            )
            var supplierMTDAmount = 0;
            var supplierMTDCount = 0;
            var supplierFTDAmount = 0;
            var supplierFTDCount = 0;
            if (supplierData[0].supplierMTDAmount[0] != undefined) { supplierMTDAmount = supplierData[0].supplierMTDAmount[0].total }
            if (supplierData[0].supplierMTDCount[0] != undefined) { supplierMTDCount = supplierData[0].supplierMTDCount[0].total }
            if (supplierData[0].supplierFTDAmount[0] != undefined) { supplierFTDAmount = supplierData[0].supplierFTDAmount[0].total }
            if (supplierData[0].supplierFTDCount[0] != undefined) { supplierFTDCount = supplierData[0].supplierFTDCount[0].total }

            const patientData = await patientLoans.aggregate([
                {
                    $facet: {
                        reimbursementMTDAmount: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$Disbursement_Date' },
                                    year: { $year: '$Disbursement_Date' }
                                },
                            },
                            {
                                $match: {
                                    month: currentMonth,
                                    year: currentMonthYear,
                                    isInsured: true,
                                    invoiceStatus: 'Disbursed',
                                },
                            },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],
                        reimbursementMTDCount: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$Disbursement_Date' },
                                    year: { $year: '$Disbursement_Date' }
                                },
                            },
                            {
                                $match: {
                                    month: currentMonth,
                                    year: currentMonthYear,
                                    isInsured: true,
                                    invoiceStatus: 'Disbursed',
                                },
                            },
                            { $count: "total" },
                        ],
                        uninsuredMTDAmount: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$Disbursement_Date' },
                                    year: { $year: '$Disbursement_Date' }
                                },
                            },
                            {
                                $match: {
                                    month: currentMonth,
                                    year: currentMonthYear,
                                    isInsured: false,
                                    invoiceStatus: 'Disbursed',
                                },
                            },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],
                        uninsuredMTDCount: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$Disbursement_Date' },
                                    year: { $year: '$Disbursement_Date' }
                                },
                            },
                            {
                                $match: {
                                    month: currentMonth,
                                    year: currentMonthYear,
                                    isInsured: false,
                                    invoiceStatus: 'Disbursed',
                                },
                            },
                            { $count: "total" },
                        ],
                        reimbursementFTDAmount: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    dayOfMonth: { $dayOfMonth: '$Disbursement_Date' },
                                    month: { $month: '$Disbursement_Date' },
                                    year: { $year: '$Disbursement_Date' }
                                },
                            },
                            {
                                $match: {
                                    dayOfMonth: currentDate,
                                    month: currentMonth,
                                    year: currentMonthYear,
                                    isInsured: true,
                                    invoiceStatus: 'Disbursed',
                                },
                            },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],
                        reimbursementFTDCount: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    dayOfMonth: { $dayOfMonth: '$Disbursement_Date' },
                                    month: { $month: '$Disbursement_Date' },
                                    year: { $year: '$Disbursement_Date' }
                                },
                            },
                            {
                                $match: {
                                    dayOfMonth: currentDate,
                                    month: currentMonth,
                                    year: currentMonthYear,
                                    isInsured: true,
                                    invoiceStatus: 'Disbursed',
                                },
                            },
                            { $count: "total" },
                        ],
                        uninsuredFTDAmount: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    dayOfMonth: { $dayOfMonth: '$Disbursement_Date' },
                                    month: { $month: '$Disbursement_Date' },
                                    year: { $year: '$Disbursement_Date' }
                                },
                            },
                            {
                                $match: {
                                    dayOfMonth: currentDate,
                                    month: currentMonth,
                                    year: currentMonthYear,
                                    isInsured: false,
                                    invoiceStatus: 'Disbursed',
                                },
                            },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],
                        uninsuredFTDCount: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    dayOfMonth: { $dayOfMonth: '$Disbursement_Date' },
                                    month: { $month: '$Disbursement_Date' },
                                    year: { $year: '$Disbursement_Date' }
                                },
                            },
                            {
                                $match: {
                                    dayOfMonth: currentDate,
                                    month: currentMonth,
                                    year: currentMonthYear,
                                    isInsured: false,
                                    invoiceStatus: 'Disbursed',
                                },
                            },
                            { $count: "total" },
                        ],
                    }
                }
            ]
            )
            var reimbursementMTDAmount = 0;
            var reimbursementMTDCount = 0;
            var uninsuredMTDAmount = 0;
            var uninsuredMTDCount = 0;

            var reimbursementFTDAmount = 0;
            var reimbursementFTDCount = 0;
            var uninsuredFTDAmount = 0;
            var uninsuredFTDCount = 0;

            if (patientData[0].reimbursementMTDAmount[0] != undefined) { reimbursementMTDAmount = patientData[0].reimbursementMTDAmount[0].total }
            if (patientData[0].reimbursementMTDCount[0] != undefined) { reimbursementMTDCount = patientData[0].reimbursementMTDCount[0].total }
            if (patientData[0].uninsuredMTDAmount[0] != undefined) { uninsuredMTDAmount = patientData[0].uninsuredMTDAmount[0].total }
            if (patientData[0].uninsuredMTDCount[0] != undefined) { uninsuredMTDCount = patientData[0].uninsuredMTDCount[0].total }

            if (patientData[0].reimbursementFTDAmount[0] != undefined) { reimbursementFTDAmount = patientData[0].reimbursementFTDAmount[0].total }
            if (patientData[0].reimbursementFTDCount[0] != undefined) { reimbursementFTDCount = patientData[0].reimbursementFTDCount[0].total }
            if (patientData[0].uninsuredFTDAmount[0] != undefined) { uninsuredFTDAmount = patientData[0].uninsuredFTDAmount[0].total }
            if (patientData[0].uninsuredFTDCount[0] != undefined) { uninsuredFTDCount = patientData[0].uninsuredFTDCount[0].total }

            const merchantData = await ApprovedLoans.aggregate([
                {
                    $facet: {
                        merchantMTDAmount: [
                            { $project: { Status: 1, LoanAmount: 1, month: { $month: '$DisbursementDate' }, year: { $year: '$DisbursementDate' } } },
                            {
                                $match: {
                                    $and: [
                                        { month: currentMonth, year: currentMonthYear },
                                        { $or: [{ Status: "Disbursed" }, { Status: "Loan closed" }] },
                                    ],
                                },
                            },
                            { $group: { _id: "$_v", total: { $sum: "$LoanAmount" } } },
                        ],
                        merchantMTDCount: [
                            { $project: { Status: 1, month: { $month: '$DisbursementDate' }, year: { $year: '$DisbursementDate' } } },
                            {
                                $match: {
                                    $and: [
                                        { month: currentMonth, year: currentMonthYear },
                                        { $or: [{ Status: "Disbursed" }, { Status: "Loan closed" }] },
                                    ],
                                },
                            },
                            { $count: "total" },
                        ],
                        merchantFTDAmount: [
                            { $project: { Status: 1, LoanAmount: 1, dayOfMonth: { $dayOfMonth: '$DisbursementDate' }, month: { $month: '$DisbursementDate' }, year: { $year: '$DisbursementDate' } } },
                            {
                                $match: {
                                    $and: [
                                        { dayOfMonth: currentDate, month: currentMonth, year: currentMonthYear },
                                        { $or: [{ Status: "Disbursed" }, { Status: "Loan closed" }] },
                                    ],
                                },
                            },
                            { $group: { _id: "$_v", total: { $sum: "$LoanAmount" } } },
                        ],
                        merchantFTDCount: [
                            { $project: { Status: 1, dayOfMonth: { $dayOfMonth: '$DisbursementDate' }, month: { $month: '$DisbursementDate' }, year: { $year: '$DisbursementDate' } } },
                            {
                                $match: {
                                    $and: [
                                        { dayOfMonth: currentDate, month: currentMonth, year: currentMonthYear },
                                        { $or: [{ Status: "Disbursed" }, { Status: "Loan closed" }] },
                                    ],
                                },
                            },
                            { $count: "total" },
                        ],
                    }
                }
            ]
            )
            var merchantMTDAmount = 0;
            var merchantMTDCount = 0;
            var merchantFTDAmount = 0;
            var merchantFTDCount = 0;
            if (merchantData[0].merchantMTDAmount[0] != undefined) { merchantMTDAmount = merchantData[0].merchantMTDAmount[0].total }
            if (merchantData[0].merchantMTDCount[0] != undefined) { merchantMTDCount = merchantData[0].merchantMTDCount[0].total }

            if (merchantData[0].merchantFTDAmount[0] != undefined) { merchantFTDAmount = merchantData[0].merchantFTDAmount[0].total }
            if (merchantData[0].merchantFTDCount[0] != undefined) { merchantFTDCount = merchantData[0].merchantFTDCount[0].total }

            // daily 

            const config: AxiosRequestConfig = {
                method: 'POST',
                url: `http://localhost:3061/api/auth/whatsappClient`,
                data: {
                    text: `Month Till Date- \n` +
                        `Claim Financing: ${claimMTDCount} cases - Rs.${claimMTDAmount}\n` +
                        `Supplier Financing: ${supplierMTDCount} cases - Rs.${supplierMTDAmount}\n` +
                        `Patient Financing(Reimbursement): ${reimbursementMTDCount} cases - Rs.${reimbursementMTDAmount}\n` +
                        `Patient Financing(Uninsured): ${uninsuredMTDCount} cases - Rs.${uninsuredMTDAmount}\n` +
                        `NICT: ${merchantMTDCount} cases - Rs.${merchantMTDAmount}\n\n`+
                        `For The Date- \n` +
                        `Claim Financing: ${claimFTDCount} cases - Rs.${claimFTDAmount}\n` +
                        `Supplier Financing: ${supplierFTDCount} cases - Rs.${supplierFTDAmount}\n` +
                        `Patient Financing(Reimbursement): ${reimbursementFTDCount} cases - Rs.${reimbursementFTDAmount}\n` +
                        `Patient Financing(Uninsured): ${uninsuredFTDCount} cases - Rs.${uninsuredFTDAmount}\n` +
                        `NICT: ${merchantFTDCount} cases - Rs.${merchantFTDAmount}`,
                    notificationId: null,
                    organization: "DSPL"
                },
                headers: {
                    'Content-Type': 'application/json',
                }
            };
            const response: AxiosResponse = await axios(config);

            Logger.debug('dailyReportJob finished');
            done();
        } catch (e) {
            Logger.error('🔥 Error with dailyReportJob: %o', e);
            done(e);
        }
    }
}
