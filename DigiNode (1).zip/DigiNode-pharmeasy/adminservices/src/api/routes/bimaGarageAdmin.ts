import { Router, Request, Response, NextFunction } from 'express';
import { Container } from 'typedi';
import adminService from '../../services/adminService';
import {

  IUserInputDTO,
  IAggregatorDTO,
  IVendorDTO,
  ILenderDTO,
  IHospitalDTO,
  IPatientLoanDTO,
  IUser,
  IFilterDTO,
  IClaimInvoiceDTO
} from '../../interfaces/IUser';
import { Logger, loggers } from 'winston';
import { celebrate, Joi, errors } from 'celebrate';
import getDashboardForBimaGarage from '../../services/bimaGarageService';
import DateExtension from '@joi/date';
const JoiDate = Joi.extend(DateExtension);
import middlewares from '../middlewares';
import excel from 'exceljs';


const route = Router();

export default (app: Router) => {
  app.use('/bimaGarage', route);

  route.get('/getDashboardForBimaGarage',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Digisparsh'),
    middlewares.requiredAccess(0),
    // celebrate({
    //   query: {
    //     pageNumber: Joi.number().positive(),
    //     pageSize: Joi.number().positive(),
    //     filters: Joi.array(),
    //   },
    // }),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');

      try {
        const bimagagareServiceInstance = Container.get(getDashboardForBimaGarage);
        const { BemagarageLocalDash } = await bimagagareServiceInstance.getDashboardForBimaGarage(req.query as unknown as IFilterDTO);
        return res.status(201).json({ BemagarageLocalDash });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    }
  );
  route.get('/getDashofBG',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Digisparsh'),
    middlewares.requiredAccess(0),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      // logger.debug('Calling Sign-Up endpoint with body: %o', req.query);
      try {

        const bimagagareServiceInstance = Container.get(getDashboardForBimaGarage);
        const data = await bimagagareServiceInstance.getDashofBG();
        return res.status(201).json(data);
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
}




