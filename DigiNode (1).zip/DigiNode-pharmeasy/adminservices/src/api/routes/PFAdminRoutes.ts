import { Router, Request, Response, NextFunction } from 'express';
import { Container } from 'typedi';
import PFAdminService from '../../services/PFAdminService';
// import supplierAdminService2 from '../../services/PFAdminService';
import { IFilterDTO, IUserInputDTO, ISupplierInvoiceDTO } from '../../interfaces/IUser';
import middlewares from '../middlewares';
import { celebrate, errors, Joi } from 'celebrate';
import { Logger, loggers } from 'winston';

const route = Router();

export default (app: Router) => {
  app.use('/PF', route);

  route.get(
    '/getsdash',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Digisparsh'),
    middlewares.requiredAccess(0),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('get sdash: %o', req.body);
      try {
        const supplierAdminServiceInstance = Container.get(PFAdminService);
        const { data } = await supplierAdminServiceInstance.getSDash(req);
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  )
  route.get(
    '/supplierDashboardJob',
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('get supplierDashboardJob: %o', req.body);
      try {
        const supplierAdminServiceInstance = Container.get(PFAdminService);
        const { dashboardData } = await supplierAdminServiceInstance.supplierDashboardJob(req);
        return res.status(201).json({ dashboardData });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    }
  )
  route.get(
    '/getAllHospital',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Digisparsh'),
    middlewares.requiredAccess(0),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('sdash/getAllHospital: %o', req.body);
      try {
        const supplierAdminServiceInstance = Container.get(PFAdminService);
        const { data } = await supplierAdminServiceInstance.getAllHospital(req);
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    }
  )
  route.get(
    '/getAllLenderToAdmin',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Digisparsh'),
    middlewares.requiredAccess(0),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('get getAllLenderToAdmin: %o', req.body);
      try {
        const supplierAdminServiceInstance = Container.get(PFAdminService);
        const { data } = await supplierAdminServiceInstance.getAllLenderToAdmin(req);
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    }
  )
  route.get(
    '/getAllVendorToAdmin',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Digisparsh'),
    middlewares.requiredAccess(0),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('get getAllVendorToAdmin: %o', req.body);
      try {
        const supplierAdminServiceInstance = Container.get(PFAdminService);
        const { data } = await supplierAdminServiceInstance.getAllVendorToAdmin(req);
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    }
  )
  route.get(
    '/getUserByIdToAdmin',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Digisparsh'),
    middlewares.requiredAccess(3),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('get getUserByIdToAdmin: %o', req.body);
      try {
        const supplierAdminServiceInstance = Container.get(PFAdminService);
        const { data } = await supplierAdminServiceInstance.getUserByIdToAdmin(req);
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    }
  )
  route.get('/getPFInvoiceToAdmin',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Digisparsh'),
    middlewares.requiredAccess(0),
    celebrate({
      query: {
        pageNumber: Joi.number().positive().allow(null),
        pageSize: Joi.number().positive().allow(null),
        Status: Joi.string().allow(null),
        searchTerm: Joi.string()
      },
    }),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('getPFInvoiceToAdmin: %o', req.query);
      try {
        const supplierAdminServiceInstance = Container.get(PFAdminService);
        const { data } = await supplierAdminServiceInstance.getPFInvoiceToAdmin(req.query as unknown as IFilterDTO);
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
  route.get('/getPFInvoiceByIdToAdmin',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Digisparsh'),
    middlewares.requiredAccess(0),
    celebrate({
      query: {
        _id: Joi.string()
      }
    }),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('getSupplierInvoiceByIdToAdmin: %o', req.query);
      try {
        const supplierAdminServiceInstance = Container.get(PFAdminService);
        const { data } = await supplierAdminServiceInstance.getPFInvoiceByIdToAdmin(req.query as unknown as IFilterDTO);
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
  route.post('/editPFInvoiceByAdmin',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Digisparsh'),
    middlewares.requiredAccess(1),
    celebrate({
      query: {
        _id: Joi.string().required()
      },
      body: Joi.object({
        Status: Joi.boolean().required()
      }),
    }),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('editPFInvoiceByAdmin: %o', req.body);
      try {
        const supplierAdminServiceInstance = Container.get(PFAdminService);
        const { data } = await supplierAdminServiceInstance.editPFInvoiceByAdmin(
          req.query as unknown as IFilterDTO,
          req.body as ISupplierInvoiceDTO,
        );
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
  route.use(errors());
}