import { Router, Request, Response, NextFunction } from 'express';
import { Container } from 'typedi';

import { AHAssociationDTO, IFilterDTO } from '../../interfaces/IUser';
import { Logger } from 'winston';
import { celebrate, Joi, errors } from 'celebrate';
import middlewares from '../middlewares';
import excel from 'exceljs';
import multer from 'multer';
import excelToJson from 'convert-excel-to-json';
import moment from 'moment';
import decompress from 'decompress';
import path from 'path';
import fs from 'fs';
// import AHAssociationService from '@/services/AHAssociationService';
import AHAssociationService from '../../services/AHAssociationService';


const route = Router();
const storage = multer.diskStorage({
    destination: './upload/',
    filename: function (req, file, cb) {
      cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
    },
  });
const uploaders = multer({
    storage: storage,
    limits: { fieldSize: 10 * 1024 * 1024 }
  });

export default (app: Router) => {
  
    app.use('/AHAssociation', route);
    route.post('/updateAHAssociation',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Digisparsh'),
        middlewares.requiredAccess(3),
        celebrate({
            body: Joi.object({
              hospitals: Joi.array().items(
                    Joi.object().keys({
                        hospitalId: Joi.string(),
                        hospitalName: Joi.string(),
                        _id: Joi.string(),
                        Hospital: Joi.string(),

                    })
                ),
                aggregatorId: Joi.string(),
            })
        }),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('updateAHAssociation: %o', req.body);
            try {
                const AHAssociationServiceInstance = Container.get(AHAssociationService);
                const { data } = await AHAssociationServiceInstance.updateAHAssociation(req.body as AHAssociationDTO);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        }
    )

    route.post('/uploadHospitals',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Digisparsh'),
    middlewares.requiredAccess(0),
    async (req: any, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('uploadbanks: %o', req.body);
      try {
        var dirPath;
        var destPath;
        var numFiles;
        var filesarr;
        var filepaths;
        var fileWithExt = [];

        uploaders.fields([{ name: 'uploadfile' }, { name: 'uploadzip' }])(req, res, err => {
          dirPath = './upload/' + req.files['uploadfile'][0].filename;
          var ran = Math.floor(Math.random() * 90000) + 10000;

          const excelData = excelToJson({
            sourceFile: './upload/' + req.files['uploadfile'][0].filename,
            sheets: [
              {
                // Excel Sheet Name
                name: 'Sheet1',
                // Header Row -> be skipped and will not be present at our result object.
                header: {
                  rows: 1,
                },
                // Mapping columns to keys
                columnToKey: {
                  '*': '{{columnHeader}}',
                },
              },
            ],
          });

          if (!excelData.Sheet1.length) {
            return res.status(400).json({
              success: false,
              error: 'Blank sheet not uploaded',
            });
          }

          var arr = [];

          async function invoicer() {
            try {
              var bankstoadd = []
              for (var i = 0; i < excelData.Sheet1.length; i++) {
                if (
                  excelData.Sheet1[i].Hospital &&
                  excelData.Sheet1[i].Aggregator
                 
                ) {
                  let Hospital = excelData.Sheet1[i].Hospital;
                 let Aggregator = excelData.Sheet1[i].Aggregator;
                  var count = 0;
                  count++;
                  var ranDate = new Date();
                  let randate = ('0' + ranDate.getDate()).slice(-2);
                  let ranmonth = ('0' + (ranDate.getMonth() + 1)).slice(-2);
                  let ranyear = ranDate.getFullYear();
                  let ranhours = ranDate.getHours();
                  let ranminutes = ranDate.getMinutes();
                  let ranseconds = ranDate.getSeconds();

                  var finalRanDate =
                    ranyear + '-' + ranmonth + '-' + randate + '-' + ranhours + '-' + ranminutes + '-' + ranseconds;

                  destPath = `./upload/${finalRanDate}-${ran}`;

                  arr[i] = Hospital;

                  const files = await decompress(dirPath, destPath);
                  numFiles = files.length;
                  filesarr = [];
                  filepaths = [];
                  var obj = {
                    Hospital: Hospital,
                    Aggregator: Aggregator
                  }
                  bankstoadd.push(obj)

                } else {
                  return res.status(400).json({
                    success: false,
                    message: 'Please fill all the fields in excel, missing fields',
                  });
                }
              }
              if (bankstoadd != null) {
                const AHAssociationServiceInstance = Container.get(AHAssociationService);
                const { companyConstantBankdata } = await AHAssociationServiceInstance.addHospital(bankstoadd)


              }
              fs.unlinkSync('./upload/' + req.files['uploadfile'][0].filename);
              return res.status(200).json({ success: true, message: 'uploaded and updated' });
            } catch (error) {
              return res.status(400).send({
                success: false,
                error,
              });
            }
          }
          invoicer();
        });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    }
  );

  route.get('/getAllHospitals',
  middlewares.isAuth,
  middlewares.attachCurrentUser,
  middlewares.requiredOrg('Digisparsh'),
  middlewares.requiredAccess(0),
  async (req: any, res: any, next: NextFunction) => {
    const logger: Logger = Container.get('logger');
    logger.debug('getAllHospitals: %o', req.body);
    try {
      const AHAssociationServiceInstance = Container.get(AHAssociationService);
      const data = await AHAssociationServiceInstance.getAllHospitals();
      return res.status(201).json({ data });
    } catch (e) {
      logger.error('🔥 error: %o', e);
      return next(e);
    }
  })

  route.get('/downloadTemplateForHospital',
  // middlewares.isAuth,
  // middlewares.attachCurrentUser,
  // middlewares.requiredOrg('Digisparsh'),
  // middlewares.requiredAccess(0),
  async (req: Request, res: Response, next: NextFunction) => {
    const logger: Logger = Container.get('logger');
    logger.debug('downloadTemplateForHospital: %o', req.body);
    try {
      let workbook = new excel.Workbook();
      let worksheet = workbook.addWorksheet('Sheet1');
      let Sheet1 = [];
      worksheet.columns = [
        { header: 'Aggregator', key: 'Aggregator', width: 25 }, 
        { header: 'Hospital', key: 'Hospital', width: 25 },
   
      ];
      // Add Array Rows
      worksheet.addRows(Sheet1);
      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition', 'attachment; filename=' + 'sample_repayment.xlsx');

      return workbook.xlsx.write(res).then(function () {
        res.status(200).end();
      });
    } catch (e) {
      logger.error('🔥 error: %o', e);
      return next(e);
    }
  });  
    route.use(errors());
}