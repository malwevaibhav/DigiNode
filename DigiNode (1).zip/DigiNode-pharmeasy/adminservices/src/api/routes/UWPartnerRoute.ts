import { Router, Request, Response, NextFunction } from 'express';
import { Container } from 'typedi';
import UWPartnerService from '../../services/UWPartnerService';
import { IOrgInputDTO, IFilterDTO, IPartnerDTO, IUser, IPatientLoanDTO } from '../../interfaces/IUser';
import { Logger } from 'winston';
import { celebrate, Joi, errors } from 'celebrate';
import DateExtension from '@joi/date';
const JoiDate = Joi.extend(DateExtension);
import middlewares from '../middlewares';

import util from 'util'
// const util = require('util')
const gc = require('../GCP/gcp')
const bucket = gc.bucket('digisparsh_images')


var multer = require('multer');
var path = require('path')
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'upload/')
    },
    filename: function (req, file, cb) {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9)
        cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname))
    }
})

const storage_V2 = multer.memoryStorage()
const uploadBuffer = multer({
    storage: storage_V2,
    limits: { fieldSize: 10 * 1024 * 1024 },
},

)
const upload = multer({
    storage: storage,
    limits: { fieldSize: 10 * 1024 * 1024 }
})
var fs = require('fs');

const { BlobServiceClient } = require("@azure/storage-blob");
const containerName = "uatcontainer";
const sasToken = "sv=2021-06-08&ss=bfqt&srt=sco&sp=rwdlacupiytfx&se=2024-02-20T16:47:15Z&st=2023-02-20T08:47:15Z&spr=https&sig=BDmeVstReLGKpmVAufC%2FKQd2afDfAPdO4LzQgdB1SXo%3D";
const storageAccountName = "uatresource";
const key = "uaEjdcwzjVO7U7qv/JFnOnsEXUxQHQ46zI4x+onZBXL9UPCLEfEk+xd0sMB0ZWmZGuRLXdxjDzBIUba3A5CUrw==";

const createBlobInContainer = async (containerClient, filename, mimetype) => {
    const blobClient = containerClient.getBlockBlobClient(filename);
    const options = { blobHTTPHeaders: { blobContentType: mimetype } };
    var a = await blobClient.uploadData(
        fs.readFileSync("upload/" + filename),
        options
    );
    return blobClient.url;
};

const uploadFileToBlob = async (filename, mimetype) => {
    if (!filename || !mimetype) return [];
    const blobService = new BlobServiceClient(
        `https://${storageAccountName}.blob.core.windows.net/?${sasToken}`
    );
    const containerClient = blobService.getContainerClient(containerName);
    var response = await createBlobInContainer(containerClient, filename, mimetype);
    return response;
};
const uploadImage = (file) => new Promise((resolve, reject) => {
    const { originalname, buffer } = file
    const date1 = Date.now().toString()

    const blob = bucket.file(originalname.replace(/ /g, "_"))
    const blobStream = blob.createWriteStream({
        resumable: false
    })
    let tempName = blob.name.split('.')
    if (tempName && tempName?.length) {

        blob.name = tempName[0] + date1 + '.' + tempName[tempName?.length - 1]
    }

    var blobb = blobStream.on('finish', () => {
        const publicUrl = util.format(
            `https://storage.googleapis.com/${bucket.name}/${blob.name}`
        )
        console.log(publicUrl)
        resolve(publicUrl)

    })
        .on('error', (err) => {
            reject(`Unable to upload image, something went wrong=>${err}`)
        })
        .end(buffer)

})


const route = Router();

export default (app: Router) => {
    app.use('/UWPartner', route);
    // route.get('/getPartnersToAdmin',
    //     middlewares.isAuth,
    //     middlewares.attachCurrentUser,
    //     middlewares.requiredOrg('Digisparsh'),
    //     middlewares.requiredAccess(3),
    //     celebrate({
    //         query: {
    //             pageNumber: Joi.number().positive(),
    //             pageSize: Joi.number().positive(),
    //         },
    //     }),
    //     async (req: Request, res: Response, next: NextFunction) => {
    //         const logger: Logger = Container.get('logger');
    //         logger.debug('getPartnersToAdmin: %o');
    //         try {
    //             const UWPartnerServiceInstance = Container.get(UWPartnerService);
    //             const { data } = await UWPartnerServiceInstance.getPartnersToAdmin(req.query as unknown as IFilterDTO);
    //             return res.status(201).json({ data });
    //         } catch (e) {
    //             logger.error('🔥 error: %o', e);
    //             return next(e);
    //         }
    //     },
    // )
    route.post('/addPartnerAssociation',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Digisparsh'),
        middlewares.requiredAccess(3),
        celebrate({
            body: Joi.object({
                organizationId: Joi.string(),
                UWPartners: Joi.array().items(
                    Joi.object().keys({
                        partnerId: Joi.string(),
                        partnerName: Joi.string()
                    }),
                ),
            })
        }),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('addPartnerAssociation: %o', req.body);
            try {
                const UWPartnerServiceInstance = Container.get(UWPartnerService);
                const { data } = await UWPartnerServiceInstance.addPartnerAssociation(req.body as IOrgInputDTO);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        }
    )
    // route.post('/addPartnerByAdmin',
    //     middlewares.isAuth,
    //     middlewares.attachCurrentUser,
    //     middlewares.requiredOrg('Digisparsh'),
    //     middlewares.requiredAccess(3),
    //     celebrate({
    //         body: Joi.object({
    //             partnerName: Joi.string()
    //         })
    //     }),
    //     async (req: Request, res: Response, next: NextFunction) => {
    //         const logger: Logger = Container.get('logger');
    //         logger.debug('addPartnerByAdmin: %o', req.body);
    //         try {
    //             const UWPartnerServiceInstance = Container.get(UWPartnerService);
    //             const { data } = await UWPartnerServiceInstance.addPartnerByAdmin(req.body as IPartnerDTO);
    //             return res.status(201).json({ data });
    //         } catch (e) {
    //             logger.error('🔥 error: %o', e);
    //             return next(e);
    //         }
    //     }
    // )
    // route.put('/editPartnerByAdmin',
    //     middlewares.isAuth,
    //     middlewares.attachCurrentUser,
    //     middlewares.requiredOrg('Digisparsh'),
    //     middlewares.requiredAccess(3),
    //     celebrate({
    //         body: Joi.object({
    //             _id: Joi.string(),
    //             partnerName: Joi.string()
    //         })
    //     }),
    //     async (req: Request, res: Response, next: NextFunction) => {
    //         const logger: Logger = Container.get('logger');
    //         logger.debug('editPartnerByAdmin: %o', req.body);
    //         try {
    //             const UWPartnerServiceInstance = Container.get(UWPartnerService);
    //             const { data } = await UWPartnerServiceInstance.editPartnerByAdmin(req.body as IPartnerDTO);
    //             return res.status(201).json({ data });
    //         } catch (e) {
    //             logger.error('🔥 error: %o', e);
    //             return next(e);
    //         }
    //     }
    // )
    // route.put('/deletePartnerByAdmin',
    //     middlewares.isAuth,
    //     middlewares.attachCurrentUser,
    //     middlewares.requiredOrg('Digisparsh'),
    //     middlewares.requiredAccess(4),
    //     celebrate({
    //         body: Joi.object({
    //             _id: Joi.string()
    //         })
    //     }),
    //     async (req: Request, res: Response, next: NextFunction) => {
    //         const logger: Logger = Container.get('logger');
    //         logger.debug('deletePartnerByAdmin: %o', req.body);
    //         try {
    //             const UWPartnerServiceInstance = Container.get(UWPartnerService);
    //             const { data } = await UWPartnerServiceInstance.deletePartnerByAdmin(req.body as IPartnerDTO);
    //             return res.status(201).json({ data });
    //         } catch (e) {
    //             logger.error('🔥 error: %o', e);
    //             return next(e);
    //         }
    //     }
    // )
    route.get('/partnerDashboard',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        // middlewares.requiredOrg('Digisparsh'),
        // middlewares.requiredAccess(0),
        celebrate({
            query: {
                dateFrom: JoiDate.date().allow(null),
                dateTo: JoiDate.date().allow(null),
            },
        }),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('partnerDashboard: %o', req.query);
            try {
                const UWPartnerServiceInstance = Container.get(UWPartnerService);
                const { data } = await UWPartnerServiceInstance.partnerDashboard(req.currentUser as IUser, req.query as unknown as IFilterDTO);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.get('/getAllInvoices',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        // middlewares.requiredOrg('Digisparsh'),
        // middlewares.requiredAccess(0),
        celebrate({
            query: {
                pageNumber: Joi.number().positive(),
                pageSize: Joi.number().positive(),
                filters: Joi.array(),
                isInsured: Joi.boolean(),
                Status: Joi.string(),
                dateFrom: JoiDate.date().format('YYYY-MM-DD'),
                dateTo: JoiDate.date().format('YYYY-MM-DD'),
                searchTerm: Joi.string(),
                organizationId: Joi.string()
            },
        }),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('getAllInvoices: %o', req.query);
            try {
                const UWPartnerServiceInstance = Container.get(UWPartnerService);
                const { data } = await UWPartnerServiceInstance.getAllInvoices(req.query as unknown as IFilterDTO, req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.get('/getInvoiceById',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('getInvoiceById: %o', req.query);
            try {
                const UWPartnerServiceInstance = Container.get(UWPartnerService);
                const { data } = await UWPartnerServiceInstance.getInvoiceById(req, res);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.get('/getAllClaimInvoices',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        celebrate({
            query: {
                pageNumber: Joi.number().positive(),
                pageSize: Joi.number().positive(),
                Status: Joi.string(),
                dateFrom: JoiDate.date().format('YYYY-MM-DD'),
                dateTo: JoiDate.date().format('YYYY-MM-DD'),
                searchTerm: Joi.string()
            },
        }),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('getAllClaimInvoices: %o', req.query);
            try {
                const UWPartnerServiceInstance = Container.get(UWPartnerService);
                const { data } = await UWPartnerServiceInstance.getAllClaimInvoices(req.query as unknown as IFilterDTO, req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.get('/getClaimInvoiceById',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('getClaimInvoiceById: %o', req.query);
            try {
                const UWPartnerServiceInstance = Container.get(UWPartnerService);
                const { data, repaymentData } = await UWPartnerServiceInstance.getClaimInvoiceById(req, res);
                return res.status(201).json({ data, repaymentData });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.get('/getAllOrg',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        // middlewares.requiredOrg('Digisparsh'),
        // middlewares.requiredAccess(0),
        celebrate({
            query: {
                pageNumber: Joi.number().positive(),
                pageSize: Joi.number().positive(),
                typeOfOrganization: Joi.string(),
                searchTerm: Joi.string()
            },
        }),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('UWPartner/getAllOrg: %o', req.query);
            try {
                const UWPartnerServiceInstance = Container.get(UWPartnerService);
                const { data } = await UWPartnerServiceInstance.getAllOrg(req.query as unknown as IFilterDTO, req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.put('/updatePatientInvoice',

        uploadBuffer.fields([{ name: "approvalLetter" }]),
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        async (req: Request, res: Response, next: NextFunction) => {
            let files = req['files'] as { [fieldname: string]: Express.Multer.File[] };
            const logger: Logger = Container.get('logger');
            logger.debug('updatePatientInvoice: %o', req.body);
            try {

                if (files.approvalLetter) {
                    req.body.approvalLetter = await uploadImage(files.approvalLetter[0])
                    req.body.approvalLetter = req.body.approvalLetter.split('?')[0];
                }
                // if (req.file) {
                //     req.body.approvalLetter = await uploadFileToBlob(req.file.filename, req.file.mimetype)
                //     req.body.approvalLetter = req.body.approvalLetter.split('?')[0]
                // }
                const UWPartnerServiceInstance = Container.get(UWPartnerService);
                const { data } = await UWPartnerServiceInstance.updatePatientInvoice(
                    req.currentUser as IUser,
                    req.body as IPatientLoanDTO,
                    req.body.approvalLetter
                );
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.post('/updateSettlement',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        uploadBuffer.fields([
            { name: "settlementLetter" }
        ]),
        async (req: Request, res: Response, next: NextFunction) => {
            let files = req['files'] as { [fieldname: string]: Express.Multer.File[] };

            const logger: Logger = Container.get('logger')
            logger.debug('UWPartner/updateSettlement: %o', req.body);
            try {
                const UWPartnerServiceInstance = Container.get(UWPartnerService);

                if (files?.settlementLetter) {
                    req.body.settlementLetter = await uploadImage(files.settlementLetter[0])
                    req.body.settlementLetter = req.body.settlementLetter.split('?')[0];
                }
                // req.body.settlementLetter = await uploadFileToBlob(req.file.filename, req.file.mimetype)
                // req.body.settlementLetter = req.body.settlementLetter.split('?')[0]

                const { success, message } = await UWPartnerServiceInstance.updateSettlement(req.body as IPatientLoanDTO);
                return res.status(201).json({ success, message });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        }
    );
    route.use(errors());
}