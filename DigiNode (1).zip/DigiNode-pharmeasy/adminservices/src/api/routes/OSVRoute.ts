import { Router, Request, Response, NextFunction } from 'express';
import { Container } from 'typedi';
import OSVService from '../../services/OSVService';
import { IUser, IOSVDTO } from '../../interfaces/IUser';
import { Logger, loggers } from 'winston';
import { celebrate, Joi, errors } from 'celebrate';
import middlewares from '../middlewares';

const route = Router();

export default (app: Router) => {
    app.use('/admin/osv', route);

    route.get('/getOSVDetails',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        // middlewares.requiredAccess(3),
        middlewares.requiredOrg('Digisparsh'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('getOSVDetails: %o');
            try {
                const OSVServiceInstance = Container.get(OSVService);
                const { data } = await OSVServiceInstance.getOSVDetails();
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );

    route.put('/updateOSVDetails',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        // middlewares.requiredAccess(3),
        middlewares.requiredOrg('Digisparsh'),
        celebrate({
            body: Joi.object({
                _id: Joi.string(),
                osvEmpName: Joi.string(),
                osvEmpId: Joi.string(),
                osvEmpOrg: Joi.string(),
            }),
        }),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('get updateOSVDetails: %o', req.body);
            try {
                const OSVServiceInstance = Container.get(OSVService);
                const { data } = await OSVServiceInstance.updateOSVDetails(req.body as IOSVDTO, req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.use(errors());
};
