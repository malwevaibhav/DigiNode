import { Router, Request, Response, NextFunction } from 'express';
import { Container } from 'typedi';
import newLeadService from '../../services/newLeadService';
import { IFilterDTO } from '../../interfaces/IUser';
import { Logger } from 'winston';
import { celebrate, Joi, errors } from 'celebrate';
import DateExtension from '@joi/date';
const JoiDate = Joi.extend(DateExtension);
import middlewares from '../middlewares';

const route = Router();

export default (app: Router) => {
    app.use('/newLead', route);
    route.get('/getNewLeads',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Digisparsh'),
        middlewares.requiredAccess(3),
        celebrate({
            query: {
                pageNumber: Joi.number().positive(),
                pageSize: Joi.number().positive(),
                searchTerm: Joi.string(),
                leadType: Joi.string().valid('Patient', 'Hospital', 'Partner', 'Contact'),
                isInsured: Joi.boolean(),
                product: Joi.string().valid('Invoice Claim Financing', 'Supplier Financing')
            },
        }),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('getNewLeads: %o', req.query);
            try {
                const newLeadServiceInstance = Container.get(newLeadService);
                const { leads, numberOfPages } = await newLeadServiceInstance.getNewLeads(req.query as unknown as IFilterDTO);
                return res.status(201).json({ leads, numberOfPages });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    )
    route.get('/newLeadDashboard',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Digisparsh'),
        middlewares.requiredAccess(3),
        celebrate({
            query: {
                dateFrom: JoiDate.date().allow(null),
                dateTo: JoiDate.date().allow(null),
            },
        }),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('newLeadDashboard: %o', req.query);
            try {
                const newLeadServiceInstance = Container.get(newLeadService);
                const { totalPatient, totalHospital, totalPartner, totalContact, leadCountGraph } = await newLeadServiceInstance.newLeadDashboard(req.query as unknown as IFilterDTO);
                return res.status(201).json({ totalPatient, totalHospital, totalPartner, totalContact, leadCountGraph });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    )
    route.post('/updateLead',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Digisparsh'),
        middlewares.requiredAccess(3),
        celebrate({
            body: Joi.object({
                _id: JoiDate.string().required(),
                leadStatus: Joi.string().required().valid('Open', 'On Boarded', 'Not Converted')
            }),
        }),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('updateLead: %o', req.body);
            try {
                const newLeadServiceInstance = Container.get(newLeadService);
                const { success, message } = await newLeadServiceInstance.updateLead(req.body as IFilterDTO);
                return res.status(201).json({ success, message });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.use(errors())
};