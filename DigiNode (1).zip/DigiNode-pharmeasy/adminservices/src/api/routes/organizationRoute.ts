import { Router, Request, Response, NextFunction } from 'express';
import { Container } from 'typedi';
import OrgService from '../../services/organizationService';
import { IOrgInputDTO, IFilterDTO } from '../../interfaces/IUser';
import { Logger, loggers } from 'winston';
import { celebrate, Joi, errors } from 'celebrate';
import middlewares from '../middlewares';
import DateExtension from '@joi/date'
const JoiDate = Joi.extend(DateExtension)

const route = Router();

export default (app: Router) => {
  app.use('/org', route);

  route.get('/getAllOrg',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Digisparsh'),
    middlewares.requiredAccess(0),
    celebrate({
      query: {
        pageNumber: Joi.number().positive(),
        pageSize: Joi.number().positive(),
        filters: Joi.array(),
        searchTerm: Joi.string(),
        claimFinancing: Joi.boolean(),
        supplierFinancing: Joi.boolean(),
        patientFinancing: Joi.boolean(),
        merchantFinancing: Joi.boolean(),
        employeeManagement: Joi.boolean(),
        purchaseFinancing: Joi.boolean(),
        typeOfOrganization: Joi.string().valid('Digisparsh', 'Hospital', 'Aggregator', 'Lender', 'Vendor', 'Business Partner', 'Processing Partner',"Distributor","Pmanufacture"),
        forAssociation: Joi.boolean()
      }
    }),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('org/getAllOrg: %o', req.query);
      try {
        const OrgServiceInstance = Container.get(OrgService);
        const { data } = await OrgServiceInstance.getAllOrg(req.query as unknown as IFilterDTO);
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  )
  route.get('/getOrgByIdToAdmin',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Digisparsh'),
    middlewares.requiredAccess(3),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('getOrgByIdToAdmin: %o', req.query);
      try {
        const OrgServiceInstance = Container.get(OrgService);
        const { data } = await OrgServiceInstance.getOrgByIdToAdmin(req, res);
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  )
  route.post('/addOrgByAdmin',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Digisparsh'),
    middlewares.requiredAccess(3),
    celebrate({
      body: Joi.object({
        nameOfOrganization: Joi.string().required(),
        typeOfOrganization: Joi.string().required(),
        dateOfRegistration: JoiDate.date().format('DD-MM-YYYY'),
        contactNumber: Joi.number().required(),
        email: Joi.string(),
        primaryDSPLAssignee: Joi.string(),
        // Joi.when('patientFinancing', { is: true, then: Joi.string().required(), otherwise: Joi.forbidden() }),
        secondaryDSPLAssignee: Joi.string(),
        // Joi.when('patientFinancing', { is: true, then: Joi.string().required(), otherwise: Joi.forbidden() }),
        claimFinancing: Joi.boolean().required(),
        supplierFinancing: Joi.boolean().required(),
        patientFinancing: Joi.boolean().required(),
        merchantFinancing: Joi.boolean().required(),
        employeeManagement: Joi.boolean().required(),
        purchaseFinancing: Joi.boolean().required(),
        PFFees: Joi.when('typeOfOrganization', [{ is: 'Distributor', then: Joi.number().required() },{ is: 'Hospital', then: Joi.number().required(), otherwise: Joi.forbidden() }]),
        // PFFees: Joi.when('typeOfOrganization', { is: 'Hospital', then: Joi.number().required(), otherwise: Joi.forbidden() }),
        
        LenderId: Joi.string(),
        // Joi.when('typeOfOrganization', { is: 'Hospital', then: Joi.string().required() })
        //   .concat(Joi.when('typeOfOrganization', { is: 'Aggregator', then: Joi.when('patientFinancing', { is: true, then: Joi.string().required() }) })),
        LTV:  Joi.when('typeOfOrganization', [{ is: 'Distributor', then: Joi.number().required() },{ is: 'Hospital', then: Joi.number().required(), otherwise: Joi.forbidden() }]),
        lenderType: Joi.string().when('typeOfOrganization', { is: 'Lender', then: Joi.when('patientFinancing', { is: true, then: Joi.string().required() }) }).valid('Offline', 'Online-A', 'Online-B'),
        agreementTemplateId: Joi.string(),
        schemas:Joi.any(),
        templateData:Joi.any(),
        digiPercentage:Joi.any(),
        hospitalPercentage:Joi.any(),
        lenderPercentage:Joi.any()
        //Joi.when('typeOfOrganization',{is:'Hospital', then:Joi.object().required()}).concat(Joi.when('typeOfOrganization',{is:'Aggregator',then: Joi.object().required(), otherwise: Joi.forbidden()}))
      })
    }),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('addOrgByAdmin: %o', req.body);
      try {
        const OrgServiceInstance = Container.get(OrgService);
        const { responseCode, data } = await OrgServiceInstance.addOrgByAdmin(req.body as IOrgInputDTO);
        return res.status(responseCode).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    }
  )
  route.post('/editOrgByAdmin',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Digisparsh'),
    middlewares.requiredAccess(3),
    celebrate({
      body: Joi.object({
        nameOfOrganization: Joi.string().required(),
        typeOfOrganization: Joi.string().required(),
        dateOfRegistration: JoiDate.date().format('DD-MM-YYYY'),
        contactNumber: Joi.number().required(),
        email: Joi.string(),
        primaryDSPLAssignee: Joi.string(),
        // Joi.when('patientFinancing', { is: true, then: Joi.string().required(), otherwise: Joi.forbidden() }),
        secondaryDSPLAssignee: Joi.string(),
        // Joi.when('patientFinancing', { is: true, then: Joi.string().required(), otherwise: Joi.forbidden() }),
        claimFinancing: Joi.boolean().required(),
        supplierFinancing: Joi.boolean().required(),
        patientFinancing: Joi.boolean().required(),
        merchantFinancing: Joi.boolean().required(),
        employeeManagement: Joi.boolean().required(),
        purchaseFinancing: Joi.boolean().required(),
        PFFees: Joi.when('typeOfOrganization', [{ is: 'Distributor', then: Joi.number().required() },{ is: 'Hospital', then: Joi.number().required(), otherwise: Joi.forbidden() }]),
        LenderId: Joi.string().allow(null),
        // Joi.when('typeOfOrganization', { is: 'Hospital', then: Joi.string().required() })
        //   .concat(Joi.when('typeOfOrganization', { is: 'Aggregator', then: Joi.when('patientFinancing', { is: true, then: Joi.string().required() }) })),
        LTV:  Joi.when('typeOfOrganization', [{ is: 'Distributor', then: Joi.number().required() },{ is: 'Hospital', then: Joi.number().required(), otherwise: Joi.forbidden() }]),
        lenderType: Joi.string().when('typeOfOrganization', { is: 'Lender', then: Joi.when('patientFinancing', { is: true, then: Joi.string().required() }) }).valid('Offline', 'Online-A', 'Online-B'),
        agreementTemplateId: Joi.string(),
        schemas:Joi.any(),
        templateData:Joi.any(),
        digiPercentage:Joi.any(),
        lenderPercentage:Joi.any(),
        hospitalPercentage:Joi.any()
      })
    }),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('editOrgByAdmin: %o', req.body);
      try {
        const OrgServiceInstance = Container.get(OrgService);
        const { data } = await OrgServiceInstance.editOrgByAdmin(req, req.body as IOrgInputDTO);
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  )
  route.delete('/deleteOrgByAdmin',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Digisparsh'),
    middlewares.requiredAccess(4),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('deleteOrgByAdmin: %o', req.body);
      try {
        const OrgServiceInstance = Container.get(OrgService);
        const { data } = await OrgServiceInstance.deleteOrgByAdmin(req, res);
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    }
  )
  route.use(errors());
}