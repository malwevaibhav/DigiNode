import { Router, Request, Response, NextFunction } from 'express';
import { Container } from 'typedi';
import DPAssociationService from '../../services/DPAssociationService';
import { HVAssociationDTO, IFilterDTO, DPAssociationDTO, IUser } from '../../interfaces/IUser';
import { Logger } from 'winston';
import { celebrate, Joi, errors } from 'celebrate';
import middlewares from '../middlewares';

const route = Router();

export default (app: Router) => {
  app.use('/DPAssociation', route);
  route.get(
    '/getAssociations',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Digisparsh'),
    middlewares.requiredAccess(3),
    celebrate({
      query: {
        pageNumber: Joi.number().positive(),
        pageSize: Joi.number().positive(),
        searchTerm: Joi.string(),
      },
    }),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('getAssociations: %o');
      try {
        const DPAssociationServiceInstance = Container.get(DPAssociationService);
        const { data } = await DPAssociationServiceInstance.getAssociations(req.query as unknown as IFilterDTO);

        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
  route.post(
    '/addDistToVendor',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Digisparsh'),
    middlewares.requiredAccess(3),
    celebrate({
      body: Joi.object({
        PmanufactureId: Joi.string(), 
        PmanufactureName: Joi.string(),
            distributorId: Joi.string(),
            distributorName: Joi.string(),
            AvailableLimit: Joi.number(),
      }),
    }),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('addPartnerAssociation: %o', req.body);
      try {
        const UWPartnerServiceInstance = Container.get(DPAssociationService);

        const { data } = await UWPartnerServiceInstance.addDistributor(req.body as DPAssociationDTO);
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
  //   route.post('/updateAssociation',
  //       middlewares.isAuth,
  //       middlewares.attachCurrentUser,
  //       middlewares.requiredOrg('Digisparsh'),
  //       middlewares.requiredAccess(3),
  //       celebrate({
  //           body: Joi.object({
  //               distributorId: Joi.string(),
  //               distributorName: Joi.string(),
  //               PmanufactureId: Joi.string(),
  //               PmanufactureName: Joi.string()
  //           })
  //       }),
  //       async (req: Request, res: Response, next: NextFunction) => {
  //           const logger: Logger = Container.get('logger');
  //           logger.debug('updateAssociation: %o', req.body);
  //           try {
  //               const DPAssociationServiceInstance = Container.get(DPAssociationService);
  //               const { data } = await DPAssociationServiceInstance.updateAssociation(req.body as DPAssociationDTO);
  //               return res.status(201).json({ data });
  //           } catch (e) {
  //               logger.error('🔥 error: %o', e);
  //               return next(e);
  //           }
  //       }
  //   )
  route.put(
    '/deleteAssociation',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Digisparsh'),
    middlewares.requiredAccess(4),
    celebrate({
      query: Joi.object({
        _id: Joi.string(),
      }),
    }),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('deleteAssociation: %o', req.query);
      try {
        const HVAssociationServiceInstance = Container.get(DPAssociationService);
        const { data } = await HVAssociationServiceInstance.deleteAssociation(req.query as unknown as IFilterDTO);
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
  // route.put('/postDistLimitFromDSPL',
  //   middlewares.isAuth,
  //   middlewares.attachCurrentUser,
  //   // middlewares.requiredOrg('Lender'),
  //   // middlewares.requiredProduct('purchaseFinancing'),
  //   async (req: Request, res: Response, next: NextFunction) => {
  //     const logger: Logger = Container.get('logger');
  //     // logger.debug('supplier/supplier/postCreditLimitFromLender: %o', req.body, req.query);
  //     try {
  //       const lenderServiceInstance = Container.get(DPAssociationService);
  //       const { data } = await lenderServiceInstance.postDistLimitFromDSPL(req);
  //       return res.status(201).json({ data });
  //     } catch (e) {
  //       logger.error('🔥 error: %o', e);
  //       return next(e);
  //     }
  //   }
  // )
  route.put('/distLimitByAdmin',
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('distLimitByAdmin: %o', req.query);
      try {
        const HVAssociationServiceInstance = Container.get(DPAssociationService);
        const { data } = await HVAssociationServiceInstance.distLimitByAdmin(req.body as DPAssociationDTO, req.body as IUser);
        return res.status(201).json(data);
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  )
  route.use(errors());
};
