/* eslint-disable no-var */
import { Router, Request, Response, NextFunction } from 'express';
import { Container } from 'typedi';
import adminService from '../../services/adminService';
import {
  IUserInputDTO,
  IAggregatorDTO,
  IVendorDTO,
  ILenderDTO,
  IHospitalDTO,
  IPatientLoanDTO,
  IUser,
  IFilterDTO,
  IClaimInvoiceDTO,
  IOrgInputDTO
} from '../../interfaces/IUser';
import { Logger, loggers } from 'winston';
import { celebrate, Joi, errors } from 'celebrate';
import DateExtension from '@joi/date';
const JoiDate = Joi.extend(DateExtension);
import middlewares from '../middlewares';
import excel from 'exceljs';
import multer from 'multer';
import path from 'path';
import excelToJson from 'convert-excel-to-json';
import fs from 'fs';
import { ObjectId } from 'mongodb';
import { PDFDocument, rgb, StandardFonts } from 'pdf-lib';

import util from 'util'
// const util = require('util')
const gc = require('../GCP/gcp')
const bucket = gc.bucket('digisparsh_images')


const storage = multer.diskStorage({
  destination: './uploads/',
  filename: function (req, file, cb) {
    cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
  },
});

const uploaders = multer({
  storage: storage,
  limits: { fieldSize: 10 * 1024 * 1024 }
});
const storage_V2 = multer.memoryStorage()
const uploadBuffer = multer({
  storage: storage_V2,
  limits: { fieldSize: 10 * 1024 * 1024 },
},

)

const upload = multer({
  storage: storage,
  limits: { fieldSize: 10 * 1024 * 1024 }
})
// This is for google cloud platform!!
// const storage_V2 = multer.memoryStorage()
// const uploadBuffer = multer({ storage: storage_V2 },
//   // limits, { fieldSize: 10 * 1024 * 1024 }
// )
const { BlobServiceClient } = require("@azure/storage-blob");
const containerName = "uatcontainer";
const sasToken = "sv=2021-06-08&ss=bfqt&srt=sco&sp=rwdlacupiytfx&se=2024-02-20T16:47:15Z&st=2023-02-20T08:47:15Z&spr=https&sig=BDmeVstReLGKpmVAufC%2FKQd2afDfAPdO4LzQgdB1SXo%3D";
const storageAccountName = "uatresource";
const key = "uaEjdcwzjVO7U7qv/JFnOnsEXUxQHQ46zI4x+onZBXL9UPCLEfEk+xd0sMB0ZWmZGuRLXdxjDzBIUba3A5CUrw==";
// const storage = multer.diskStorage({
//   destination: './upload/',
//   filename: function (req, file, cb) {
//     cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
//   },
// });

const uploadImage = (file) => new Promise((resolve, reject) => {
  const { originalname, buffer } = file
  const date1 = Date.now().toString()

  const blob = bucket.file(originalname.replace(/ /g, "_"))
  const blobStream = blob.createWriteStream({
    resumable: false
  })
  let tempName = blob.name.split('.')
  if (tempName && tempName?.length) {

    blob.name = tempName[0] + date1 + '.' + tempName[tempName?.length - 1]
  }

  var blobb = blobStream.on('finish', () => {
    const publicUrl = util.format(
      `https://storage.googleapis.com/${bucket.name}/${blob.name}`
    )
    console.log(publicUrl)
    resolve(publicUrl)

  })
    .on('error', (err) => {
      reject(`Unable to upload image, something went wrong=>${err}`)
    })
    .end(buffer)

})



const createBlobInContainer = async (containerClient, filename, mimetype) => {
  const blobClient = containerClient.getBlockBlobClient(filename);
  const options = { blobHTTPHeaders: { blobContentType: mimetype } };
  var a = await blobClient.uploadData(
    fs.readFileSync("uploads/" + filename),
    options
  );
  return blobClient.url;
};

const uploadFileToBlob = async (filename, mimetype) => {
  if (!filename || !mimetype) return [];
  const blobService = new BlobServiceClient(
    `https://${storageAccountName}.blob.core.windows.net/?${sasToken}`
  );
  const containerClient = blobService.getContainerClient(containerName);
  var response = await createBlobInContainer(containerClient, filename, mimetype);
  return response;
};

const imageToPDF = async (imageFile) => {
  const imageBytes = fs.readFileSync(imageFile.buffer)
  const pdfDoc = await PDFDocument.create()
  var image
  if (path.extname(imageFile.path) == '.png') {
    image = await pdfDoc.embedPng(imageBytes)
  }
  else {
    image = await pdfDoc.embedJpg(imageBytes)
  }

  const page = pdfDoc.addPage();
  var scale = page.getWidth() * 0.8 / image.width
  const jpgDims = image.scale(scale)

  page.drawImage(image, {
    x: page.getWidth() / 2 - jpgDims.width / 2,
    y: page.getHeight() / 2 - jpgDims.height / 2,
    width: jpgDims.width,
    height: jpgDims.height,
  })

  const pdfBytes = await pdfDoc.save()
  var pdfFilePath = imageFile.path.split('.')[0]
  var pdfFileName = imageFile.filename.split('.')[0] + 'PDF.pdf'
  fs.writeFileSync(pdfFilePath + 'PDF.pdf', pdfBytes)
  pdfFilePath = pdfFilePath + 'PDF.pdf'
  var pdfFile = { pdfFilePath, pdfFileName }
  return pdfFile
}

const addWatermarkPDF = async (pdfFilePath, osvDetails) => {
  const existingPdfBytes = fs.readFileSync(pdfFilePath)
  const pdfDoc = await PDFDocument.load(existingPdfBytes)
  const helveticaFont = await pdfDoc.embedFont(StandardFonts.Helvetica)

  const pages = pdfDoc.getPages()
  const firstPage = pages[0]
  const { width, height } = firstPage.getSize()

  firstPage.drawText(`Employee Name: ${osvDetails.osvEmpName}, Employee Id: ${osvDetails.osvEmpId} \n${new Date().toString().split('GMT')[0]} \n${osvDetails.osvEmpOrg}`, {
    x: 10,
    y: 60,
    size: 12,
    font: helveticaFont,
    color: rgb(0, 0, 0),
  })

  const pdfBytes = await pdfDoc.save()
  fs.writeFileSync(pdfFilePath, pdfBytes)
  return pdfFilePath;
}

const route = Router();

export default (app: Router) => {
  app.use('/admin', route);

  //get All users to admin/ user master/ with pagination/search
  route.get('/getAllUsers',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Digisparsh'),
    middlewares.requiredAccess(3),
    celebrate({
      query: {
        pageNumber: Joi.number().positive(),
        pageSize: Joi.number().positive(),
        filters: Joi.array(),
        searchTerm: Joi.string(),
        organizationId: Joi.string()
      },
    }),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('getAllUsers: %o', req.query);
      try {
        const adminServiceInstance = Container.get(adminService);
        const { data } = await adminServiceInstance.getAllUsers(req.query as unknown as IFilterDTO);
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
  route.get('/getAllLenderToAdmin',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Digisparsh'),
    middlewares.requiredAccess(0),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('get getAllLenderToAdmin: %o');
      try {
        const adminServiceInstance = Container.get(adminService);
        const { data } = await adminServiceInstance.getAllLenderToAdmin(req, res);
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
  // get user by ID
  route.get('/getUserByIdToAdmin',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Digisparsh'),
    middlewares.requiredAccess(3),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('get getUserByIdToAdmin: %o', req.body);
      try {
        const adminServiceInstance = Container.get(adminService);
        const { data } = await adminServiceInstance.getUserByIdToAdmin(req, res);
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
  //sign up user by admin with common user info
  route.post('/addUserByAdmin',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Digisparsh'),
    middlewares.requiredAccess(3),
    celebrate({
      body: Joi.object({
        email: Joi.string().required(),
        password: Joi.string().required(),
        organizationId: Joi.string().required(),
        name: Joi.string().required(),
        address: Joi.array().items(
          Joi.object().keys({
            street: Joi.string(),
            state: Joi.string(),
            city: Joi.string(),
            pinCode: Joi.number().positive(),
            country: Joi.string(),
          }),
        ),
        mobileNumber: Joi.number().required(),
        accessControl: Joi.number().valid(0, 1, 2, 3, 4),
        PFFees: Joi.number(),
        claimFinancing: Joi.boolean().required(),
        supplierFinancing: Joi.boolean().required(),
        patientFinancing: Joi.boolean().required(),
        merchantFinancing: Joi.boolean().required(),
        employeeManagement: Joi.boolean().required(),
        purchaseFinancing: Joi.boolean().required()
      }),
    }),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('get addUserByAdmin: %o', req.body);
      try {
        const adminServiceInstance = Container.get(adminService);
        const { responseCode, data } = await adminServiceInstance.addUserByAdmin(
          req.body as IUserInputDTO,
          req.currentUser as IUser,
        );
        return res.status(responseCode).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
  route.put('/updatePassword',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Digisparsh'),
    middlewares.requiredAccess(4),
    celebrate({
      body: Joi.object({
        password: Joi.string().required(),
      }),
    }),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('get updatePassword: %o', req.body, req.query);
      try {
        const adminServiceInstance = Container.get(adminService);
        const { data } = await adminServiceInstance.updatePassword(
          req,
          req.body as IUserInputDTO,
          req.currentUser as IUser,
        );
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
  // update additional aggregator details
  route.post('/updateAggregator',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Digisparsh'),
    middlewares.requiredAccess(0),
    celebrate({
      body: Joi.object({
        CINNumber: Joi.string(),
        TotalNoOfHospital: Joi.number().positive().allow(0),
        NoOfTPAsAssociated: Joi.number().positive().allow(0),
        noOfICompAsd: Joi.number().positive().allow(0),
        ROIForAggregator: Joi.number().positive(),
      }),
    }),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('get updateAggregator: %o', req.body);
      try {
        const adminServiceInstance = Container.get(adminService);
        const { responseCode, data } = await adminServiceInstance.updateAggregator(req,
          req.body as IAggregatorDTO,
          req.currentUser as IUser,
        );
        return res.status(responseCode).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
  // update additional vendor details
  route.post('/updateVendor',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Digisparsh'),
    middlewares.requiredAccess(0),
    // celebrate({
    //   body: Joi.object({
    //     userId: Joi.string().required(),
    //     VednorType: Joi.string(),
    //     GSTNumber: Joi.string(),
    //     PANNumber: Joi.string(),
    //     bankName: Joi.string(),
    //     accountNumber: Joi.string(),
    //     IFSCCode: Joi.string(),
    //     authorisedPersonName: Joi.string(),
    //     contactDetailsForAuthPerson: Joi.number(),
    //     PANNumberForAuthPerson: Joi.string(),
    //     relationShip: Joi.string(),
    //     RateOfDeduction: Joi.number(),
    //     NoOfDaysCreditPeriod: Joi.number(),
    //     SanctionLimit: Joi.number(),
    //     HospitalName: Joi.string(),
    //     HospitalId: Joi.string(),
    //     LTV: Joi.number(),
    //     KycDocument: Joi.string(),
    //     Other: Joi.string(),
    //     ParriPassu: Joi.string(),
    //     LastTwoYrBank: Joi.string(),
    //     LastAudFin: Joi.string(),
    //     LastTwoFin: Joi.string(),
    //     RegCert: Joi.string(),
    //     GstCert: Joi.string(),
    //     AddrProof: Joi.string(),
    //   }),
    // }),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('updateVendor: %o', req.body, req.query);
      try {
        const adminServiceInstance = Container.get(adminService);
        if (req.query._id) {
          req.body.userId = req.query._id
        }
        const { responseCode, data } = await adminServiceInstance.updateVendor(
          req.body as IVendorDTO,
          req.currentUser as IUser,
        );
        return res.status(responseCode).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
  // update additional lender details
  route.post('/updateLender',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Digisparsh'),
    middlewares.requiredAccess(0),
    celebrate({
      body: Joi.object({
        userId: Joi.string().required(),
        LenderType: Joi.string(),
        GSTNumber: Joi.string(),
        PANNumber: Joi.string(),
        bankNameDisb: Joi.string(),
        accountNumberDisb: Joi.string(),
        IFSCCodeDisb: Joi.string(),
        authorisedPersonName: Joi.string(),
        contactDetailsForAuthPerson: Joi.number(),
        bankNameCollection: Joi.string(),
        accountNumberCollection: Joi.string(),
        IFSCCodeCollection: Joi.string(),
        PANNumberForAuthPerson: Joi.string(),
        relationShip: Joi.string(),
      }),
    }),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('updateLender: %o', req.body);
      try {
        const adminServiceInstance = Container.get(adminService);
        const { responseCode, data } = await adminServiceInstance.updateLender(
          req.body as ILenderDTO,
          req.currentUser as IUser,
        );
        return res.status(responseCode).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
  // update additional hospital details
  route.post('/updateHospital',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Digisparsh'),
    middlewares.requiredAccess(0),
    celebrate({
      body: Joi.object({
        LTV: Joi.number(),
        HospitalType: Joi.string(),
        GSTNumber: Joi.string(),
        PANNumber: Joi.string(),
        bankName: Joi.string(),
        accountNumber: Joi.string(),
        IFSCCode: Joi.string(),
        authorisedPersonName: Joi.string(),
        contactDetailsForAuthPerson: Joi.number(),
        PANNumberForAuthPerson: Joi.string(),
        relationShip: Joi.string(),
        LenderId: Joi.string(),
        LenderName: Joi.string(),
        Visibility: Joi.string(),
        CINNumber: Joi.number(),
        GSTcertificate: Joi.string(),
        DateOfRegistration: JoiDate.date().format('YYYY-MM-DD'),
        HospitalRegistrationCertificate: Joi.string(),
      }),
    }),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('updateHospital: %o', req.body);
      try {
        const adminServiceInstance = Container.get(adminService);
        const { responseCode, data } = await adminServiceInstance.updateHospital(req,
          req.body as IHospitalDTO,
          req.currentUser as IUser,
        );
        return res.status(responseCode).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
  route.post('/editUserByAdmin',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Digisparsh'),
    middlewares.requiredAccess(3),
    celebrate({
      body: Joi.object({
        email: Joi.string().required(),
        organizationId: Joi.string().required(),
        name: Joi.string().required(),
        address: Joi.array().items(
          Joi.object().keys({
            street: Joi.string(),
            state: Joi.string(),
            city: Joi.string(),
            pinCode: Joi.number().positive(),
            country: Joi.string(),
          }),
        ),
        mobileNumber: Joi.number().required(),
        accessControl: Joi.number().valid(0, 1, 2, 3, 4),
        claimFinancing: Joi.boolean().required(),
        supplierFinancing: Joi.boolean().required(),
        patientFinancing: Joi.boolean().required(),
        merchantFinancing: Joi.boolean().required(),
        employeeManagement: Joi.boolean().required(),
        purchaseFinancing: Joi.boolean().required()
      }),
    }),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('editUserByAdmin: %o', req.body);
      try {
        const adminServiceInstance = Container.get(adminService);
        const { data } = await adminServiceInstance.editUserByAdmin(
          req.body as IUserInputDTO,
          req.currentUser as IUser,
          req,
        );
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
  route.delete('/deleteUserByAdmin',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Digisparsh'),
    middlewares.requiredAccess(4),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('deleteUserByAdmin: %o', req.body);
      try {
        const adminServiceInstance = Container.get(adminService);
        const { data } = await adminServiceInstance.deleteUserByAdmin(req, res);
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
  route.get('/getAllInvoicesToAdmin',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Digisparsh'),
    middlewares.requiredAccess(0),
    celebrate({
      query: {
        pageNumber: Joi.number().positive().allow(null),
        pageSize: Joi.number().positive().allow(null),
        filters: Joi.array().allow(null),
        isInsured: Joi.boolean().allow(null),
        invoiceStatus: Joi.string().allow(null),
        invoiceSubStatus: Joi.string().allow(null),
        dateFrom: JoiDate.date().allow(null),
        dateTo: JoiDate.date().allow(null),
        organizationId: Joi.string().allow(null),
        searchTerm: Joi.string()
      },
    }),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('getAllInvoicesToAdmin: %o', req.query);
      try {
        const adminServiceInstance = Container.get(adminService);
        const { data } = await adminServiceInstance.getAllInvoicesToAdmin(req.currentUser as IUser, req.query as unknown as IFilterDTO);
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );

  route.put('/deleteInvoiceToAdmin',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Digisparsh'),
    middlewares.requiredAccess(0),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('deleteInvoiceToAdmin: %o', req.query);
      try {
        const adminServiceInstance = Container.get(adminService);
        const { data } = await adminServiceInstance.deleteInvoiceToAdmin(
          req.currentUser as unknown as IUser,
          req.query as unknown as IPatientLoanDTO
        );
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );

  route.get('/getClaimInvoicesToAdmin',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Digisparsh'),
    middlewares.requiredAccess(0),
    celebrate({
      query: {
        pageNumber: Joi.number().positive().allow(null),
        pageSize: Joi.number().positive().allow(null),
        filters: Joi.array().allow(null),
        Status: Joi.string().allow(null),
        organizationId: Joi.string().allow(null),
        searchTerm: Joi.string()
      },
    }),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('getClaimInvoicesToAdmin: %o', req.query);
      try {
        const adminServiceInstance = Container.get(adminService);
        const { data } = await adminServiceInstance.getClaimInvoicesToAdmin(req.query as unknown as IFilterDTO);
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );

  route.put('/deleteClaimInvoicesToAdmin',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Digisparsh'),
    middlewares.requiredAccess(0),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('deleteClaimInvoicesToAdmin: %o', req.query);
      try {
        const adminServiceInstance = Container.get(adminService);
        const { data } = await adminServiceInstance.deleteClaimInvoicesToAdmin(req.currentUser as unknown as IUser, req.query as unknown as IClaimInvoiceDTO);
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );

  route.get('/getClaimInvoiceByIdToAdmin',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Digisparsh'),
    middlewares.requiredAccess(0),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('getClaimInvoiceByIdToAdmin: %o', req.query);
      try {
        const adminServiceInstance = Container.get(adminService);
        const { data, repaymentData } = await adminServiceInstance.getClaimInvoiceByIdToAdmin(req, res);
        return res.status(201).json({ data, repaymentData });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
  route.get('/getInvoiceByIdToAdmin',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Digisparsh'),
    middlewares.requiredAccess(0),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('getInvoiceByIdToAdmin: %o', req.query);
      try {
        const adminServiceInstance = Container.get(adminService);
        const { data } = await adminServiceInstance.getInvoiceByIdToAdmin(req, res);
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
  route.post('/editInvoiceByAdmin',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Digisparsh'),
    middlewares.requiredAccess(0),
    uploadBuffer.fields([
      { name: 'uploadAadharFront' },
      { name: 'uploadAadharBack' },
      { name: 'uploadPAN' },
      { name: 'uploadCancelledCheque' },
      { name: 'uploadInsurancePolicy' },
      { name: 'uploadHospitalBill' },
      { name: 'uploadProof' },
      { name: 'uploadIncomeProof' },
      { name: 'uploadBankStatement' },
      { name: 'uploadOtherDoc' },
      { name: 'uploadConsentDoc' },
      { name: 'recommendationLetter' },
      { name: 'NTCDoc' },
      { name: 'uploadCibil' },
      { name: 'approvalLetter' }
    ]),
    // celebrate({
    //   body: Joi.object({
    //     invoiceStatus: Joi.string(),
    //     digiComment: Joi.string().allow(''),
    //     loan_id: Joi.when('invoiceStatus', { not: 'Withdraw', then: Joi.string().required(), otherwise: Joi.string().allow('') }),
    //   }),
    // }),
    async (req: Request, res: Response, next: NextFunction) => {
      let files = req['files'] as { [fieldname: string]: Express.Multer.File[] };
      const logger: Logger = Container.get('logger');
      if (!files) {
        files = {}
      }
      logger.debug('editInvoiceByAdmin: %o', req.body);

      try {
        const adminServiceInstance = Container.get(adminService);
        const osvDetails = await adminServiceInstance.getOSVDetails()

        if (files?.uploadAadharFront) {
          var filePath = files.uploadAadharFront[0].path
          if (files?.uploadAadharFront[0].mimetype == 'application/pdf', 'image/png', 'image/jpeg', 'application/pdf', 'application/octet-stream') {
            // const blob=await addWatermarkPDF(files?.uploadAadharFront[0], osvDetails)
            // req.body.uploadAadharFront = await uploadFileToBlob(files?.uploadAadharFront[0].filename, 'application/pdf')
            req.body.uploadAadharFront = await uploadImage(files?.uploadAadharFront[0])
          }
          else {
            var pdfFile = await imageToPDF(files.uploadAadharFront[0].mimetype == 'application/pdf')
            await addWatermarkPDF(pdfFile.pdfFilePath, osvDetails);
            req.body.uploadAadharFront = await uploadFileToBlob(pdfFile.pdfFileName, 'application/pdf')
          }
          req.body.uploadAadharFront = req.body.uploadAadharFront.split('?')[0];
        }
        // if (files?.uploadAadharFront) {
        //   if (files?.uploadAadharFront[0].mimetype == 'application/pdf', 'image/png', 'image/jpeg', 'application/pdf', 'application/octet-stream') {
        //     // const blob=await addWatermarkPDF(files?.uploadAadharFront[0], osvDetails)
        //     // req.body.uploadAadharFront = await uploadFileToBlob(files?.uploadAadharFront[0].filename, 'application/pdf')
        //     req.body.uploadAadharFront = await uploadImage(files?.uploadAadharFront[0])
        //   }
        //   else {
        //     var pdfFile = await imageToPDF(files?.uploadAadharFront[0])
        //     // await addWatermarkPDF(pdfFile.pdfFilePath, osvDetails);
        //     req.body.uploadAadharFront = await uploadFileToBlob(pdfFile.pdfFileName, 'application/pdf')
        //   }
        //   req.body.uploadAadharFront = req.body.uploadAadharFront.split('?')[0];
        // }
        if (files.uploadAadharBack) {
          var filePath = files.uploadAadharBack[0].path
          if (files?.uploadAadharBack[0].mimetype == 'application/pdf', 'image/png', 'image/jpeg', 'application/pdf', 'application/octet-stream') {
            // await addWatermarkPDF(files.uploadAadharBack[0].path, osvDetails)
            // req.body.uploadAadharBack = await uploadFileToBlob(files.uploadAadharBack[0].filename, 'application/pdf')
            req.body.uploadAadharBack = await uploadImage(files?.uploadAadharBack[0])

          }
          else {
            var pdfFile = await imageToPDF(files.uploadAadharBack[0])
            await addWatermarkPDF(pdfFile.pdfFilePath, osvDetails);
            req.body.uploadAadharBack = await uploadFileToBlob(pdfFile.pdfFileName, 'application/pdf')
          }
          req.body.uploadAadharBack = req.body.uploadAadharBack.split('?')[0];
        }
        if (files.uploadPAN) {
          var filePath = files.uploadPAN[0].path
          if (files?.uploadPAN[0].mimetype == 'application/pdf', 'image/png', 'image/jpeg', 'application/pdf', 'application/octet-stream') {
            // await addWatermarkPDF(files.uploadPAN[0].path, osvDetails)
            // req.body.uploadPAN = await uploadFileToBlob(files.uploadPAN[0].filename, 'application/pdf')
            req.body.uploadPAN = await uploadImage(files?.uploadPAN[0])

          }
          else {
            var pdfFile = await imageToPDF(files.uploadPAN[0])
            await addWatermarkPDF(pdfFile.pdfFilePath, osvDetails);
            req.body.uploadPAN = await uploadFileToBlob(pdfFile.pdfFileName, 'application/pdf')
          }
          req.body.uploadPAN = req.body.uploadPAN.split('?')[0];
        }
        if (files.uploadProof) {
          req.body.uploadProof = await uploadImage(files.uploadProof[0])
          req.body.uploadProof = req.body.uploadProof.split('?')[0];
        }
        if (files.recommendationLetter) {
          req.body.recommendationLetter = await uploadImage(files.recommendationLetter[0])
          req.body.recommendationLetter = req.body.recommendationLetter.split('?')[0];
        }
        if (files.uploadCancelledCheque) {
          req.body.uploadCancelledCheque = await uploadImage(files.uploadCancelledCheque[0])
          req.body.uploadCancelledCheque = req.body.uploadCancelledCheque.split('?')[0];
        }
        if (files.uploadIncomeProof) {
          req.body.uploadIncomeProof = await uploadImage(files.uploadIncomeProof[0])
          req.body.uploadIncomeProof = req.body.uploadIncomeProof.split('?')[0];
        }
        if (files.uploadHospitalBill) {
          req.body.uploadHospitalBill = await uploadImage(files.uploadHospitalBill[0])
          req.body.uploadHospitalBill = req.body.uploadHospitalBill.split('?')[0];
        }
        if (files.uploadBankStatement) {
          req.body.uploadBankStatement = await uploadImage(files.uploadBankStatement[0])
          req.body.uploadBankStatement = req.body.uploadBankStatement.split('?')[0];
        }
        if (files.uploadInsurancePolicy) {
          req.body.uploadInsurancePolicy = await uploadImage(files.uploadInsurancePolicy[0])
          req.body.uploadInsurancePolicy = req.body.uploadInsurancePolicy.split('?')[0];
        }
        if (files.uploadOtherDoc) {
          req.body.uploadOtherDoc = await uploadImage(files.uploadOtherDoc[0])
          req.body.uploadOtherDoc = req.body.uploadOtherDoc.split('?')[0];
        }
        if (files.uploadConsentDoc) {
          req.body.uploadConsentDoc = await uploadImage(files.uploadConsentDoc[0])
          req.body.uploadConsentDoc = req.body.uploadConsentDoc.split('?')[0];
        }
        if (files.NTCDoc) {
          req.body.NTCDoc = await uploadImage(files.NTCDoc[0])
          req.body.NTCDoc = req.body.NTCDoc.split('?')[0];
        }
        if (files.approvalLetter) {
          req.body.approvalLetter = await uploadImage(files.approvalLetter[0])
          req.body.approvalLetter = req.body.approvalLetter.split('?')[0];
        }
        if (files.uploadCibil) {
          req.body.uploadCibil = await uploadImage(files.uploadCibil[0])
          req.body.uploadCibil = req.body.uploadCibil.split('?')[0];
        }

        const { data } = await adminServiceInstance.editInvoiceByAdmin(
          req,
          req.currentUser as IUser,
          req.body as IPatientLoanDTO,
          req.body as IOrgInputDTO
        );
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
  route.post('/editClaimInvoiceByAdmin',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Digisparsh'),
    middlewares.requiredAccess(1),
    celebrate({
      body: Joi.object({
        Status: Joi.boolean().allow(null),
        DigiSparshComment: Joi.string().allow('')
      }),
    }),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('editClaimInvoiceByAdmin: %o', req.body);
      try {
        const adminServiceInstance = Container.get(adminService);
        const { data } = await adminServiceInstance.editClaimInvoiceByAdmin(
          req,
          req.currentUser as IUser,
          req.body as IClaimInvoiceDTO,
        );
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
  route.post('/updateAssignee',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Digisparsh'),
    middlewares.requiredAccess(1),
    celebrate({
      body: Joi.object({
        invoiceIds: Joi.array().required(),
        assigneeId: Joi.string()
      }),
    }),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('updateAssignee: %o', req.body);
      try {
        const adminServiceInstance = Container.get(adminService);
        const { data } = await adminServiceInstance.updateAssignee(req.currentUser as IUser, req.body as IPatientLoanDTO);
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );

  // get merchant list in NICT
  route.get('/getMerchantList',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Digisparsh'),
    middlewares.requiredAccess(0),
    celebrate({
      query: {
        pageNumber: Joi.number().positive(),
        pageSize: Joi.number().positive(),
        dateFrom: JoiDate.date(),
        dateTo: JoiDate.date(),
        searchTerm: Joi.string()
      },
    }),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('merchant list : %o', req.query);
      try {
        const adminServiceInstance = Container.get(adminService);
        const { data } = await adminServiceInstance.getMerchantList(req.query as unknown as IFilterDTO);
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );

  // get merchant by Id in NICT
  route.get('/getMerchantById',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Digisparsh'),
    middlewares.requiredAccess(0),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('merchant by Id : %o', req.body);
      try {
        const adminServiceInstance = Container.get(adminService);
        const { data } = await adminServiceInstance.getMerchantById(req);
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    });

  // NICT api to update loans to Admin
  route.put('/updateLoansToAdmin',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Digisparsh'),
    middlewares.requiredAccess(0),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('update loan to Admin : %o', req.body);
      try {
        const adminServiceInstance = Container.get(adminService);
        const { updatedData } = await adminServiceInstance.updateLoansToAdmin(req);
        return res.status(201).json({ updatedData });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    });

  route.get('/downloadTemplate',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Digisparsh'),
    middlewares.requiredAccess(0),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('downloadTemplate: %o');
      try {
        let workbook = new excel.Workbook();
        let worksheet = workbook.addWorksheet('Sheet1');
        let Sheet1 = [];
        worksheet.columns = [
          { header: 'KOCode', key: 'KOCode', width: 25 },
          { header: 'BankAssociated', key: 'BankAssociated', width: 25 },
          { header: 'OfficeName', key: 'OfficeName', width: 25 },
          { header: 'Branch', key: 'Branch', width: 25 },
          { header: 'FullName', key: 'FullName', width: 25 },
          { header: 'MobileNumber', key: 'MobileNumber', width: 25 },
          {
            header: 'AlternateContactNumber',
            key: 'AlternateContactNumber',
            width: 25,
          },
          { header: 'EmailId', key: 'EmailId', width: 25 },
          { header: 'ApplicantsPanNo', key: 'ApplicantsPanNo', width: 25 },
          {
            header: 'ApplicantsAadhaarNo',
            key: 'ApplicantsAadhaarNo',
            width: 25,
          },
          { header: 'DateOfBirth', key: 'DateOfBirth', width: 25 },
          { header: 'District', key: 'District', width: 25 },
          { header: 'City', key: 'City', width: 25 },
          { header: 'CurrentAddress', key: 'CurrentAddress', width: 25 },
          { header: 'State', key: 'State', width: 25 },
          { header: 'Pincode', key: 'Pincode', width: 25 },
          { header: 'AccountNumber', key: 'AccountNumber', width: 25 },
          { header: 'IFSCCode', key: 'IFSCCode', width: 25 },
          { header: 'AccountHolderName', key: 'AccountHolderName', width: 25 },
          { header: 'LoanAmount', key: 'LoanAmount', width: 25 },
          { header: 'EMIAmount', key: 'EMIAmount', width: 25 },
          { header: 'Scheme', key: 'Scheme', width: 25 },
          { header: 'ProcessingFees', key: 'ProcessingFees', width: 25 },
          { header: 'Interest', key: 'Interest', width: 25 },
          { header: 'Lender', key: 'Lender', width: 25 },
        ];
        // Add Array Rows
        worksheet.addRows(Sheet1);
        res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        res.setHeader('Content-Disposition', 'attachment; filename=' + 'new_data_template.xlsx');

        return workbook.xlsx.write(res).then(function () {
          res.status(200).end();
        });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    });
  // offline cases patient loan
  route.post('/dataUploadByExcelPatient',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Digisparsh'),
    middlewares.requiredAccess(0),
    async (req: any, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('dataUploadByExcelPatient: %o', req.body);
      try {
        var dirPath;
        var destPath;
        var numFiles;
        var filesarr;
        var filepaths;
        var fileWithExt = [];

        uploaders.fields([{ name: 'uploadfile' }, { name: 'uploadzip' }])(req, res, err => {
          dirPath = './upload/' + req.files['uploadfile'][0].filename;
          var ran = Math.floor(Math.random() * 90000) + 10000;

          const excelData = excelToJson({
            sourceFile: './upload/' + req.files['uploadfile'][0].filename,
            sheets: [
              {
                // Excel Sheet Name
                name: 'Reimbursement',
                // Header Row -> be skipped and will not be present at our result object.
                header: {
                  rows: 1,
                },
                // Mapping columns to keys
                columnToKey: {
                  '*': '{{columnHeader}}',
                },
              },
              {
                name: 'Uninsured',
                header: {
                  rows: 1,
                },
                columnToKey: {
                  '*': '{{columnHeader}}',
                },
              },
            ],
          });

          if (!(excelData.Reimbursement.length || excelData.Uninsured.length)) {
            return res.status(400).json({
              success: false,
              error: 'Blank sheet not uploaded',
            });
          }

          var arr = [];
          async function invoicer() {
            var reimbursementInvoiceCount = excelData.Reimbursement.length;
            var uninsuredInvoiceCount = excelData.Uninsured.length;
            var updateCount = 0;
            var addCount = 0;
            var failData = [];
            console.log("reimbursementInvoiceCount : ", reimbursementInvoiceCount);
            console.log("uninsuredInvoiceCount: ", uninsuredInvoiceCount);

            for (var i = 0; i < excelData.Reimbursement.length; i++) {
              if (!(excelData.Reimbursement[i].Status &&
                excelData.Reimbursement[i].Code &&
                excelData.Reimbursement[i].Applicant &&
                // excelData.Reimbursement[i].Contact_No &&
                excelData.Reimbursement[i].EMI_Tenure &&
                excelData.Reimbursement[i].Application_Date &&
                excelData.Reimbursement[i].Disbursement_Date &&
                excelData.Reimbursement[i].Store &&
                (excelData.Reimbursement[i].Loan_Amount !== null) &&
                (excelData.Reimbursement[i].PF_Amount !== null) &&
                (excelData.Reimbursement[i].GST_Amount !== null) &&
                (excelData.Reimbursement[i].Disbursed_Amount !== null)
              )) {
                var statusIssue: any = {};
                statusIssue.Code = excelData.Reimbursement[i].Code;
                statusIssue.Reason = 'Incomplete data';
                failData.push(statusIssue);
                continue;
              }
              var invoiceData = {
                uploadedViaExcel: true,
                isInsured: true,
                Unique_Ref_No: excelData.Reimbursement[i].Code,
                invoiceStatus: excelData.Reimbursement[i].Status,
                // patientName: excelData.Reimbursement[i].patientName,
                borrowerName: excelData.Reimbursement[i].Applicant,
                emailId: excelData.Reimbursement[i].Email_Id,
                contactNumber: excelData.Reimbursement[i].Contact_No,
                loanAmount: excelData.Reimbursement[i].Loan_Amount,
                Down_Payment_Amount: excelData.Reimbursement[i].Down_Payment_Amount,
                Subvention_Amount: excelData.Reimbursement[i].Subvention_Amount,
                PF_Amount: excelData.Reimbursement[i].PF_Amount,
                Franking_Amount: excelData.Reimbursement[i].Franking_Amount,
                GST_Amount: excelData.Reimbursement[i].GST_Amount,
                EMI_Tenure: excelData.Reimbursement[i].EMI_Tenure,
                EMI_Amount: excelData.Reimbursement[i].EMI_Amount,
                Application_Date: excelData.Reimbursement[i].Application_Date,
                Approval_Date: excelData.Reimbursement[i].Approval_Date,
                Disbursed_Amount: excelData.Reimbursement[i].Disbursed_Amount,
                Disbursement_Date: excelData.Reimbursement[i].Disbursement_Date,
                IFSCCode: excelData.Reimbursement[i].Ifsc,
                accountNumber: excelData.Reimbursement[i].Account_No,
                UTR: excelData.Reimbursement[i].UTR,
                organizationName: excelData.Reimbursement[i].Store,
                organizationId: ObjectId
              }
              // status check
              if (!(
                invoiceData.invoiceStatus == 'Pending' ||
                invoiceData.invoiceStatus == 'InProcess' ||
                invoiceData.invoiceStatus == 'Approved' ||
                invoiceData.invoiceStatus == 'Disbursed' ||
                invoiceData.invoiceStatus == 'Partially Repaid' ||
                invoiceData.invoiceStatus == 'Closed' ||
                invoiceData.invoiceStatus == 'Rejected' ||
                invoiceData.invoiceStatus == 'Withdraw'
              )) {
                var statusIssue: any = {};
                statusIssue.Code = invoiceData.Unique_Ref_No;
                statusIssue.Reason = 'not a valid status';
                failData.push(statusIssue);
                continue;
              }
              // org name check
              const adminServiceInstance = Container.get(adminService);
              const data = await adminServiceInstance.getOrgByName(invoiceData.organizationName);
              if (data.data) {
                invoiceData.organizationId = data.data._id
              } else {
                var statusIssue: any = {};
                statusIssue.Code = invoiceData.Unique_Ref_No;
                statusIssue.Reason = 'organization Not found';
                failData.push(statusIssue);
                continue;
              }
              const invoice = await adminServiceInstance.getPatientInvoice(invoiceData.Unique_Ref_No);

              if (invoice.invoice !== null) {
                const adminServiceInstance = Container.get(adminService);
                const invoice = await adminServiceInstance.updatePatientInvoice(invoiceData);
                updateCount++;
              } else {
                const adminServiceInstance = Container.get(adminService);
                const invoice = await adminServiceInstance.uploadPatientInvoice(invoiceData);
                addCount++;
              }
            }
            for (var i = 0; i < excelData.Uninsured.length; i++) {
              if (!(excelData.Uninsured[i].Status &&
                excelData.Uninsured[i].Code &&
                excelData.Uninsured[i].Applicant &&
                // excelData.Uninsured[i].Contact_No &&
                excelData.Uninsured[i].EMI_Tenure &&
                excelData.Uninsured[i].Application_Date &&
                excelData.Uninsured[i].Disbursement_Date &&
                excelData.Uninsured[i].Store &&
                (excelData.Uninsured[i].Loan_Amount !== null) &&
                (excelData.Uninsured[i].PF_Amount !== null) &&
                (excelData.Uninsured[i].GST_Amount !== null) &&
                (excelData.Uninsured[i].Disbursed_Amount !== null)
              )) {
                var statusIssue: any = {};
                statusIssue.Code = excelData.Uninsured[i].Code;
                statusIssue.Reason = 'Incomplete data';
                failData.push(statusIssue);
                continue;
              }
              var invoiceData = {
                uploadedViaExcel: true,
                isInsured: false,
                Unique_Ref_No: excelData.Uninsured[i].Code,
                invoiceStatus: excelData.Uninsured[i].Status,
                // patientName: excelData.Uninsured[i].patientName,
                borrowerName: excelData.Uninsured[i].Applicant,
                emailId: excelData.Uninsured[i].Email_Id,
                contactNumber: excelData.Uninsured[i].Contact_No,
                loanAmount: excelData.Uninsured[i].Loan_Amount,
                Down_Payment_Amount: excelData.Uninsured[i].Down_Payment_Amount,
                Subvention_Amount: excelData.Uninsured[i].Subvention_Amount,
                PF_Amount: excelData.Uninsured[i].PF_Amount,
                Franking_Amount: excelData.Uninsured[i].Franking_Amount,
                GST_Amount: excelData.Uninsured[i].GST_Amount,
                EMI_Tenure: excelData.Uninsured[i].EMI_Tenure,
                EMI_Amount: excelData.Uninsured[i].EMI_Amount,
                Application_Date: excelData.Uninsured[i].Application_Date,
                Approval_Date: excelData.Uninsured[i].Approval_Date,
                Disbursed_Amount: excelData.Uninsured[i].Disbursed_Amount,
                Disbursement_Date: excelData.Uninsured[i].Disbursement_Date,
                IFSCCode: excelData.Uninsured[i].Ifsc,
                accountNumber: excelData.Uninsured[i].Account_No,
                UTR: excelData.Uninsured[i].UTR,
                organizationName: excelData.Uninsured[i].Store,
                organizationId: ObjectId
              }
              // status check
              if (!(
                invoiceData.invoiceStatus == 'Pending' ||
                invoiceData.invoiceStatus == 'InProcess' ||
                invoiceData.invoiceStatus == 'Approved' ||
                invoiceData.invoiceStatus == 'Disbursed' ||
                invoiceData.invoiceStatus == 'Partially Repaid' ||
                invoiceData.invoiceStatus == 'Closed' ||
                invoiceData.invoiceStatus == 'Rejected' ||
                invoiceData.invoiceStatus == 'Withdraw'
              )) {
                var statusIssue: any = {};
                statusIssue.Code = invoiceData.Unique_Ref_No;
                statusIssue.Reason = 'not a valid status';
                failData.push(statusIssue);
                continue;
              }
              // org name check
              const adminServiceInstance = Container.get(adminService);
              const data = await adminServiceInstance.getOrgByName(invoiceData.organizationName);
              if (data.data) {
                invoiceData.organizationId = data.data._id
              } else {
                var statusIssue: any = {};
                statusIssue.Code = invoiceData.Unique_Ref_No;
                statusIssue.Reason = 'organization Not found';
                failData.push(statusIssue);
                continue;
              }
              const invoice = await adminServiceInstance.getPatientInvoice(invoiceData.Unique_Ref_No);

              if (invoice.invoice !== null) {
                const adminServiceInstance = Container.get(adminService);
                const invoice = await adminServiceInstance.updatePatientInvoice(invoiceData);
                updateCount++;
              } else {
                const adminServiceInstance = Container.get(adminService);
                const invoice = await adminServiceInstance.uploadPatientInvoice(invoiceData);
                addCount++;
              }
            }
            fs.unlinkSync('./upload/' + req.files['uploadfile'][0].filename);
            return res.status(200).json({
              success: true,
              updateCount,
              addCount,
              failData,
              message: 'uploaded',
            });
          }
          invoicer();
        });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );

  route.get('/getAddressByPIN',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    celebrate({
      query: {
        pincode: Joi.string().required()
      },
    }),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('getAddressByPIN: %o', req.query);
      try {
        const practoServiceInstance = Container.get(adminService);
        const { success, message } = await practoServiceInstance.getAddressByPIN(req);
        return res.status(201).json({ success, message });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );



  route.post('/uploadAadharDoc',
    uploadBuffer.fields([{ name: "uploadAadharDoc" }]),
    async (req: Request, res: Response, next: NextFunction) => {
      let { uploadAadharDoc } = req.body;
      let files = req['files'] as { [fieldname: string]: Express.Multer.File[] };
      const logger: Logger = Container.get('logger');
      logger.debug('claim/invoiceUpload: %o', req.body);


      if (files?.uploadAadharDoc) {
        uploadAadharDoc = await uploadImage(files.uploadAadharDoc[0]);
        console.log("HERE - ", uploadAadharDoc);

        // uploadAadharDoc = uploadAadharDoc.split('?')[0];
      }
      return res.status(200).json({
        status: true,
        data: uploadAadharDoc
      });

    })


  route.post('/uploadAadharDocs',
    uploadBuffer.fields([{ name: "uploadAadharDocs" }]),
    async (req: Request, res: Response, next: NextFunction) => {
      let { uploadAadharDocs } = req.body;
      let files = req['files'] as { [fieldname: string]: Express.Multer.File[] };
      const logger: Logger = Container.get('logger');
      logger.debug('claim/invoiceUpload: %o', req.body);


      if (files?.uploadAadharDocs) {
        uploadAadharDocs = await uploadImage(files.uploadAadharDocs[0]);
        console.log("HERE - ", uploadAadharDocs);

        // uploadAadharDocs = uploadAadharDocs.split('?')[0];
      }
      return res.status(200).json({
        status: true,
        data: uploadAadharDocs
      });

    })


  route.post('/uploadPANDoc',
    uploadBuffer.fields([{ name: "uploadPANDoc" }]),
    async (req: Request, res: Response, next: NextFunction) => {
      let { uploadPANDoc } = req.body;
      let files = req['files'] as { [fieldname: string]: Express.Multer.File[] };
      const logger: Logger = Container.get('logger');
      logger.debug('claim/invoiceUpload: %o', req.body);


      if (files?.uploadPANDoc) {
        uploadPANDoc = await uploadImage(files.uploadPANDoc[0]);
        console.log("HERE - ", uploadPANDoc);

        // uploadPANDoc = uploadPANDoc.split('?')[0];
      }
      return res.status(200).json({
        status: true,
        data: uploadPANDoc
      });

    })



  route.put('/userActivation',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Digisparsh'),
    //middlewares.isActive,
    middlewares.requiredAccess(4),
    celebrate({
      body: Joi.object({
        _id: Joi.string().required(),
        isActive: Joi.boolean().required()
      })
    }),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('userActivation: %o', req.body);
      try {
        const adminServiceInstance = Container.get(adminService);
        const { success, message } = await adminServiceInstance.userActivation(req.body as IUser);
        return res.status(201).json({ success, message });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  )

  route.use(errors());
};
