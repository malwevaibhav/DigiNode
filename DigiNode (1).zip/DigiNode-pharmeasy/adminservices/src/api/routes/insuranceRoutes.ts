import { Router, Request, Response, NextFunction } from 'express';
import { Container } from 'typedi';
import { Logger, loggers } from 'winston';
import { celebrate, errors, Joi } from 'celebrate';
import DateExtension from '@joi/date';
const JoiDate = Joi.extend(DateExtension);
import insuranceService from '../../services/insuranceService';
import middlewares from '../middlewares';

const route = Router();

export default (app: Router) => {
    app.use('/insurance', route);
    route.get('/getInsurance',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Digisparsh'),
        middlewares.requiredAccess(3),
        celebrate({
            query: {
                pageNumber: Joi.number().positive(),
                pageSize: Joi.number().positive()
            },
        }),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('getInsurance: %o', req.query);
            try {
                var body = req.query
                const insuranceServiceInstance = Container.get(insuranceService);
                const { data } = await insuranceServiceInstance.getInsurance(body as any);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );

    route.get('/getInsuranceById',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Digisparsh'),
        middlewares.requiredAccess(3),
        celebrate({
            query: {
                _id: Joi.string().required()
            }
        }),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('getInsuranceById: %o', req.query);
            try {
                let id = req.query._id
                const insuranceServiceInstance = Container.get(insuranceService);
                const { data } = await insuranceServiceInstance.getInsuranceById(id);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.put('/deleteInsurance',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Digisparsh'),
        middlewares.requiredAccess(4),
        celebrate({
            query: {
                _id: Joi.string().required()
            }
        }),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('deleteInsurance: %o', req.query);
            try {
                let id = req.query._id
                const insuranceServiceInstance = Container.get(insuranceService);
                const { data } = await insuranceServiceInstance.deleteInsurance(id);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );

    route.post('/addInsuranceWithTPA',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Digisparsh'),
        middlewares.requiredAccess(3),
        celebrate({
            body: {
                InsuranceCompanyName: Joi.string().required(),
                InsuranceCompanyCode: Joi.string().required(),
                InHouseTPA: Joi.boolean().required(),
                TPAName: Joi.string(),
                TPACode: Joi.number()
            },
        }),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('addInsuranceWithTPA: %o', req.query);
            try {
                //let id = req.query._id
                const insuranceServiceInstance = Container.get(insuranceService);
                const { data } = await insuranceServiceInstance.addInsuranceWithTPA(req, res);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );

    route.put('/updateInsuranceWithTPA',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Digisparsh'),
        middlewares.requiredAccess(3),
        celebrate({
            query: {
                _id: Joi.string()
            },
            body: {
                InsuranceCompanyName: Joi.string(),
                InsuranceCompanyCode: Joi.string(),
                InHouseTPA: Joi.boolean(),
                TPAName: Joi.string(),
                TPACode: Joi.number()
            },
        }),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('updateInsuranceWithTPA: %o', req.query);
            try {
                let id = req.query._id
                const insuranceServiceInstance = Container.get(insuranceService);
                const { data } = await insuranceServiceInstance.updateInsuranceWithTPA(req, res);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );

}