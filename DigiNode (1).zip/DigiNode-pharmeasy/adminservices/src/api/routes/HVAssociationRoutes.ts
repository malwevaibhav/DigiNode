import { Router, Request, Response, NextFunction } from 'express';
import { Container } from 'typedi';
import HVAssociationService from '../../services/HVAssociationService';
import { HVAssociationDTO, IFilterDTO } from '../../interfaces/IUser';
import { Logger } from 'winston';
import { celebrate, Joi, errors } from 'celebrate';
import middlewares from '../middlewares';

const route = Router();

export default (app: Router) => {
    app.use('/HVAssociation', route);
    route.get('/getAssociations',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Digisparsh'),
        middlewares.requiredAccess(3),
        celebrate({
            query: {
                pageNumber: Joi.number().positive(),
                pageSize: Joi.number().positive(),
                searchTerm: Joi.string(),
            },
        }),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('getAssociations: %o');
            try {
                const HVAssociationServiceInstance = Container.get(HVAssociationService);
                const { data } = await HVAssociationServiceInstance.getAssociations(req.query as unknown as IFilterDTO);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    )
    route.post('/updateAssociation',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Digisparsh'),
        middlewares.requiredAccess(3),
        celebrate({
            body: Joi.object({
                hospitalId: Joi.string(),
                hospitalName: Joi.string(),
                vendorId: Joi.string(),
                vendorName: Joi.string()
            })
        }),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('updateAssociation: %o', req.body);
            try {
                const HVAssociationServiceInstance = Container.get(HVAssociationService);
                const { data } = await HVAssociationServiceInstance.updateAssociation(req.body as HVAssociationDTO);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        }
    )
    route.put('/deleteAssociation',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Digisparsh'),
        middlewares.requiredAccess(4),
        celebrate({
            query: Joi.object({
                _id: Joi.string()
            })
        }),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('deleteAssociation: %o', req.query);
            try {
                const HVAssociationServiceInstance = Container.get(HVAssociationService);
                const { data } = await HVAssociationServiceInstance.deleteAssociation(req.query as unknown as IFilterDTO);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        }
    )
    route.use(errors());
}