export default requiredAccess => {
  return (req, res, next) => {
    if (req.currentUser.accessControl < requiredAccess) {
      console.log('Unauthorized');
      return res.status(401).end();
    } else {
      return next();
    }
  };
};
