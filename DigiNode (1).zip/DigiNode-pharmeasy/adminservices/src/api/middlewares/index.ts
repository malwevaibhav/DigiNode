import attachCurrentUser from './attachCurrentUser';
import requiredOrg from './checkOrg';
import isAuth from './isAuth';
import requiredAccess from './checkAccess';

export default {
  attachCurrentUser,
  isAuth,
  requiredOrg,
  requiredAccess,
};
