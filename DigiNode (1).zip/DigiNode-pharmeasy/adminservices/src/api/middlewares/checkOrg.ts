import { Container } from 'typedi';
import mongoose from 'mongoose';
import { Organization } from '@/models/organizationSchema';

/**
 * Attach user to req.currentUser
 * @param {*} req Express req Object
 * @param {*} res  Express res Object
 * @param {*} next  Express next Function
 */

export default requiredOrg =>  {
  return async (req, res, next) =>  {

    const OrganizationModel = Container.get('organizationModel') as mongoose.Model<Organization & mongoose.Document>;
    const OrganizationRecord = await OrganizationModel.findOne({ _id: req.currentUser.organizationId });

    if (OrganizationRecord.typeOfOrganization !== requiredOrg) {
      console.log('Unauthorized');
      return res.status(401).end();
    } else {
      return next();
    }
  };
};
