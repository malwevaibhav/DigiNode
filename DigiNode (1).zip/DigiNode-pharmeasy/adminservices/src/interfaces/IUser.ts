import mongoose from "@/loaders/mongoose";
import { ObjectId } from "mongoose";

export interface IFilterDTO {
  _id: string;
  pageNumber: number;
  pageSize: number;
  filters: Array<Object>;
  Status: string;
  isInsured: boolean;
  invoiceStatus: string;
  invoiceSubStatus: string;
  dateFrom: Date;
  dateTo: Date;
  organizationId: string;
  searchTerm: string;
  typeOfOrganization: string;
  claimFinancing: boolean,
  supplierFinancing: boolean,
  patientFinancing: boolean,
  merchantFinancing: boolean,
  purchaseFinancing: boolean,
  employeeManagement: boolean,
  forAssociation: boolean
  leadType: string,
  leadStatus: string,
  product: string
}

export interface IUser {
  _id: string;
  name: string;
  email: string;
  password: string;
  salt: string;
  organizationId: ObjectId;
  testUser: boolean;
  passwordUpdatedOn: Date;
  CINNumber: string,
  GSTNumber: string,
  PANNumber: string,
  hospitalName: string,
  dateOfRegistration: Date,
  address: string,
  mobileNumber: number
  isSplit: Boolean,
  aggregatorSplit: number,
  hospitalSplit: number,
  aggregatorROI: number,
  hospitalROI: number,
  AvailableLimit: number,
  UtilizedAmount: number,
  Repayment: number,
  ExistingCreditLimit: number,
  PFFees: number,
  PFAmount: number,
  PFRemaining: number,
  PFDeducted: number,
  ROIForAggregator: number,
  AdditionalInterest: number,
  accessControl: number
}

export interface IUserInputDTO {
  name: string;
  email: string;
  password: string;
  address: Array<Object>;
  organizationId: ObjectId;
  testUser: boolean;
  accessControl: number;
  DateOfRegistration: Date,
  PFFees: number,
  claimFinancing: boolean,
  supplierFinancing: boolean,
  patientFinancing: boolean,
  merchantFinancing: boolean,
  employeeManagement: boolean,
  purchaseFinancing: boolean
}

export interface IAggregatorDTO {
  CINNumber: number,
  TotalNoOfHospital: number,
  NoOfTPAsAssociated: number,
  noOfICompAsd: number,
  ROIForAggregator: number,
}
export interface IVendorDTO {
  userId: string,
  VednorType: string,
  GSTNumber: string,
  PANNumber: string,
  bankName: string,
  accountNumber: string,
  IFSCCode: string,
  authorisedPersonName: string,
  contactDetailsForAuthPerson: number,
  PANNumberForAuthPerson: string,
  relationShip: string,
  RateOfDeduction: number,
  NoOfDaysCreditPeriod: number,
  SanctionLimit: number,
  HospitalName: string,
  HospitalId: string,
  LTV: number,
  KycDocument: string,
  Other: string,
  ParriPassu: string,
  LastTwoYrBank: string,
  LastAudFin: string,
  LastTwoFin: string,
  RegCert: string,
  GstCert: string,
  AddrProof: string
}
export interface ILenderDTO {
  userId: string,
  LenderType: string,
  GSTNumber: string,
  PANNumber: string,
  bankNameDisb: string,
  accountNumberDisb: string,
  IFSCCodeDisb: string,
  authorisedPersonName: string,
  contactDetailsForAuthPerson: number,
  bankNameCollection: string,
  accountNumberCollection: string,
  IFSCCodeCollection: string,
  PANNumberForAuthPerson: string,
  relationShip: string
}
export interface IHospitalDTO {
  LTV: number,
  HospitalType: string,
  GSTNumber: string,
  PANNumber: string,
  bankName: string,
  accountNumber: string,
  IFSCCode: string,
  authorisedPersonName: string,
  contactDetailsForAuthPerson: number,
  PANNumberForAuthPerson: string,
  relationShip: string,
  LenderId: string,
  LenderName: string,
  Visibility: string
  CINNumber: number,
  GSTcertificate: string,
  DateOfRegistration: string,
  HospitalRegistrationCertificate: string
}
export interface IOrgInputDTO {
  nameOfOrganization: string,
  typeOfOrganization: string,
  lenderType: string,
  dateOfRegistration: Date,
  contactNumber: number,
  email: string,
  claimFinancing: boolean,
  supplierFinancing: boolean,
  patientFinancing: boolean,
  merchantFinancing: boolean,
  employeeManagement: boolean,
  purchaseFinancing: boolean,
  UWPartners: Array<Object>,
  organizationId: string,
  primaryDSPLAssignee: string,
  secondaryDSPLAssignee: string,
  PFFees: number,
  LenderId: string,
  LenderName: string,
  LTV: number,
  AdditionalInterest: number,
  AvailableLimit: number,
  UtilizedAmount: number,
  agreementTemplateId: string,
  cibil_score: string,
  schemas:Array<Object>,
  templateData:Array<Object>,
}
export interface IPartnerDTO {
  _id: string,
  partnerName: string
}
export interface IProductDTO {
  productCode: string,
  productName: string,
  // tenure: string,
  // hasEMI: Boolean,
  interestMaster: Array<Object>,
  moduleName: string
}
export interface IProductMappingDTO {
  organizationId: ObjectId,
  organizationName: string,
  productId: ObjectId,
  productName: string,
  // ROI: number,
}
export interface IAggrLenAssocDTO {
  aggregatorId: ObjectId,
  lenderId: ObjectId,
}
export interface IPatientLoanDTO {
  invoiceStatus: string,
  digiComment: string,
  _id: string,
  loan_id: string,
  LenderId: any,
  invoiceIds: Array<string>
  assigneeId: string,
  UWApprovedAmount: number,
  finalApprovedAmount: number,
  UWComment: string,
  contactNoRefPerson:number,
  //digio
  digio_doc_id: string,
  txn_id: string,
  message: string,
  error_code: string,
  agreementDocUrl: string,
  invoiceSubStatus: string,
  lenderApprovedAmount: number,
 lenderComment: string;
  settlementLetter: string;
  settlementAmount: number;
  settlementDate: Date;
  approvalLetter: string;
  NTCDoc: string;
  uploadCibil: string;
  lineOfCredit: number;
  organizationId: string;
  bankAssociated: string;
  loanAmount: number;
  permanentPinCode: number;
  permanentCity: string;
  permanentState: string;
  permanentDistrict: string;
  currentDistrict: string;
  currentPinCode: number;
  currentCity: string;
  currentState: string;
  permanentAddress: string;
  currentAddress: string;
  templateId:string;
  agreementTemplateId:string;
  totalIncome: number;
  PF_Amount: number;
  GST_Amount: number;
  Disbursed_Amount: number;
  Disbursement_Date: Date;
  interest_Amount: number;
  deduction_Amount: number;
  EMI_Amount: number;
  EMI_Tenure: number;
  isInsured: Boolean;
  scheme: number;
  interest: number;
  processingFees: number;
  hospitalBeneficiaryName:string;
  hospitalBankBranch:string;
  hospitalBankIfsc:string;
  hospitalAggregatorName:string;
  hospitalAccount:string;
  hospitalBankName:string;
}

export interface IClaimInvoiceDTO {
  Status: boolean
  _id: string,
  DigiSparshComment: string,
}

export interface ISupplierInvoiceDTO {
  Status: boolean
  _id: string
}


export interface TpaInvoiceDTO {
  nameOfInsurer: String,
  InsuranceCompanyId: ObjectId,
  TPAName: string,
  TPACode: string
}

export interface HVAssociationDTO {
  _id: ObjectId,
  hospitalName: string,
  hospitalId: string,
  vendorId: string,
  vendorName: string
}
export interface DPAssociationDTO {
  _id: ObjectId,
  distributorName: string,
  distributorId: ObjectId,
  // DPPartners: Array<Object>,
  PmanufactureId: ObjectId,
  PmanufactureName: string,
  AvailableLimit: number,
  Repayment: number,
  UtilizedAmount: number,
  creditLimit:number
}
export interface IEmpDTO {
  EmpSOA: String
}

export interface ILeadDTO {
  leadType: string
}

export interface IOSVDTO {
  _id: string,
  osvEmpName: string,
  osvEmpId: string,
  osvEmpOrg: string,
}

export interface AHAssociationDTO {
  hospitals: Array<object>
  aggregatorId: string,
  Aggregator: string
}