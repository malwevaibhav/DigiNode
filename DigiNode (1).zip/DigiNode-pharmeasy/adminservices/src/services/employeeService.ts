import { Service, Inject } from 'typedi';
import { Request, Response } from 'express';
import { IFilterDTO, IEmpDTO } from '../interfaces/IUser';
import moment from 'moment';
@Service()
export default class employeeService {
  constructor(
    @Inject('Employess') private EmployeesModel: Models.EmployeesModel,
    @Inject('EmployeeLoan') private EmployeeLoan: Models.EmployeesModel,
    @Inject('logger') private logger,
  ) { }

  public async getEmployees(IFilterDTO: IFilterDTO): Promise<{ getEmployees: any }> {
    try {
      var pageNumber = 1;
      var pageSize = 0;
      if (IFilterDTO.pageNumber) {
        var pageNumber = IFilterDTO.pageNumber;
      }
      if (IFilterDTO.pageSize) {
        var pageSize = IFilterDTO.pageSize;
      }
      //search
      var searchFilters = [];
      searchFilters.push({ isDeleted: false });
      searchFilters.push({ applicant_id_updated: true });
      if (IFilterDTO.Status != undefined) {
        if (IFilterDTO.Status == "Pending") {
          searchFilters.push({ $or: [{ LiquiStatus: "Pending" }, { LiquiStatus: "Created" }] })
        }
        else {
          searchFilters.push({ LiquiStatus: IFilterDTO.Status })
        }
      }
      if (IFilterDTO.searchTerm != undefined) {
        searchFilters.push({
          $or: [
            { qube_ref_id: { $regex: IFilterDTO.searchTerm, $options: 'i' } },
            { Employee_name: { $regex: IFilterDTO.searchTerm, $options: 'i' } },
            {
              "$expr": {
                "$regexMatch": {
                  "input": { "$toString": "$applicant_id" },
                  "regex": IFilterDTO.searchTerm
                }
              }
            }
          ]
        })
      }
      var userCount = await this.EmployeesModel.find({ $and: searchFilters }).countDocuments();
      var numberOfPages = pageSize === 0 ? 1 : Math.ceil(userCount / pageSize);

      var users = await this.EmployeesModel.find({ $and: searchFilters }).sort({ createdAt: -1 }).skip((pageNumber - 1) * pageSize).limit(pageSize);

      var getEmployees = { users, numberOfPages };
      return { getEmployees };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  public async getEmployeeById(qube_ref_id: string): Promise<{ userCount: any }> {
    try {
      var userCount = await this.EmployeesModel.findOne({ qube_ref_id: qube_ref_id });
      return { userCount };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  public async AddEmployee(usrObj: any): Promise<{ UpdatedLoan: any }> {
    try {
      const UpdatedLoan = await this.EmployeesModel.create(usrObj);
      return { UpdatedLoan };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  public async updateEmployeeLimit(Employee_id: string, Loan_limit: Number): Promise<{ userCount: any }> {
    try {
      var userCount: any = {};
      var EmployeeData = await this.EmployeesModel.findOne({ _id: Employee_id });
      if (!EmployeeData) {
        userCount.success = false;
        userCount.message = "Invalid Employee";
        return { userCount }
      }
      let obj = {
        Loan_limit: Number(Loan_limit),
        isActive: true
      }
      const updateEmployee = await this.EmployeesModel.updateOne({ _id: Employee_id }, { $set: obj });
      console.log(updateEmployee)
      if (updateEmployee.ok == 1) {
        userCount.success = true;
        userCount.message = "Employee Updated Successfully";
      } else {
        userCount.success = false;
        userCount.message = "Unable to Update";
        return { userCount }
      }
      return { userCount };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  public async getEmployeeLoans(IFilterDTO: IFilterDTO): Promise<{ getEmployees: any }> {
    try {
      var pageNumber = 1;
      var pageSize = 0;
      if (IFilterDTO.pageNumber) {
        var pageNumber = IFilterDTO.pageNumber;
      }
      if (IFilterDTO.pageSize) {
        var pageSize = IFilterDTO.pageSize;
      }
      //search
      var searchFilters = [];
      searchFilters.push({ isDeleted: false });
      if (IFilterDTO.searchTerm != undefined) {
        searchFilters.push({
          $or: [
            { qube_ref_id: { $regex: IFilterDTO.searchTerm, $options: 'i' } },
            { qube_loan_id: { $regex: IFilterDTO.searchTerm, $options: 'i' } }
          ]
        })
      }
      if (IFilterDTO.dateFrom != undefined || (null && IFilterDTO.dateTo != undefined) || null) {
        searchFilters.push({ createdAt: { $gte: IFilterDTO.dateFrom, $lte: IFilterDTO.dateTo } });
      }
      var userCount = await this.EmployeeLoan.find({ $and: searchFilters }).countDocuments();
      var numberOfPages = pageSize === 0 ? 1 : Math.ceil(userCount / pageSize);

      var loans = await this.EmployeeLoan.aggregate([
        { $match: { $and: searchFilters } },
        { $sort: { createdAt: -1 } },
        { $skip: (pageNumber - 1) * pageSize },
        { $limit: pageSize ? pageSize : Number.MAX_SAFE_INTEGER },
        {
          $lookup: {
            from: 'employees',
            localField: 'Employee_id',
            foreignField: '_id',
            as: 'empData',
          },
        },
        {
          $unwind: {
            path: "$empData",
            preserveNullAndEmptyArrays: true
          }
        },
        {
          $set: { EmpSOA: "$empData.EmpSOA" }
        },
        {
          $project: { empData: 0 }
        },
      ])
      var getEmployees = { loans, numberOfPages };
      return { getEmployees };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  public async getEmployeeLoanById(qube_ref_id: string, qube_loan_id: string): Promise<{ EmployeeLoan: any }> {
    try {
      var EmployeeLoan = await this.EmployeeLoan.findOne({ qube_ref_id: qube_ref_id, qube_loan_id: qube_loan_id });
      return { EmployeeLoan };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  public async updateEmployeeLoan(usrObj: any): Promise<{ EmployeeLoan: any }> {
    try {
      var EmployeeLoan = await this.EmployeeLoan.findOneAndUpdate(
        { qube_ref_id: usrObj.qube_ref_id, qube_loan_id: usrObj.qube_loan_id },
        { $set: usrObj }
      );
      return { EmployeeLoan };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  public async partnerDashboard(IFilterDTO: IFilterDTO): Promise<{ data: any }> {
    try {
      var searchFilters = [];
      searchFilters.push({ applicant_id_updated: true });

      if (IFilterDTO.dateFrom != undefined || null && IFilterDTO.dateTo != undefined || null) {
        searchFilters.push({ createdAt: { $gte: IFilterDTO.dateFrom, $lte: IFilterDTO.dateTo } });
      }

      var dashboardData = await this.EmployeesModel.aggregate([
        {
          $facet: {
            totalEmpCount: [{ $match: { $and: searchFilters } }, { $count: 'total' }],
            pendingCount: [{ $match: { $and: [{ $and: searchFilters }, { $or: [{ LiquiStatus: 'Pending' }, { LiquiStatus: 'Created' }] }] } }, { $count: 'total' }],
            approvedCount: [{ $match: { $and: [{ $and: searchFilters }, { LiquiStatus: 'Approved' }] } }, { $count: 'total' }],
            rejectedCount: [{ $match: { $and: [{ $and: searchFilters }, { LiquiStatus: 'Rejected' }] } }, { $count: 'total' }]
          },
        },
      ]);

      var totalEmpCount: 0; var pendingCount: 0; var approvedCount: 0; var rejectedCount: 0;

      if (dashboardData[0].totalEmpCount[0] != undefined) { totalEmpCount = dashboardData[0].totalEmpCount[0].total } else { totalEmpCount = 0 }
      if (dashboardData[0].pendingCount[0] != undefined) { pendingCount = dashboardData[0].pendingCount[0].total } else { pendingCount = 0 }
      if (dashboardData[0].approvedCount[0] != undefined) { approvedCount = dashboardData[0].approvedCount[0].total } else { approvedCount = 0 }
      if (dashboardData[0].rejectedCount[0] != undefined) { rejectedCount = dashboardData[0].rejectedCount[0].total } else { rejectedCount = 0 }

      //graphs
      var date = moment.utc();
      var currentMonth = date.month() + 1;
      var currentMonthYear = date.year();
      var previousMonth1 = date.subtract(1, 'month').month() + 1;
      var previousMonthYear1 = date.year();
      var previousMonth2 = date.subtract(1, 'months').month() + 1;
      var previousMonthYear2 = date.year();
      var previousMonth3 = date.subtract(1, 'months').month() + 1;
      var previousMonthYear3 = date.year();
      var previousMonth4 = date.subtract(1, 'months').month() + 1;
      var previousMonthYear4 = date.year();
      var previousMonth5 = date.subtract(1, 'months').month() + 1;
      var previousMonthYear5 = date.year();

      //Count of Uploaded Employees(Monthly)

      var pendingEmp1 = 0; var pendingEmp2 = 0; var pendingEmp3 = 0; var pendingEmp4 = 0; var pendingEmp5 = 0; var pendingEmp6 = 0;
      var approvedEmp1 = 0; var approvedEmp2 = 0; var approvedEmp3 = 0; var approvedEmp4 = 0; var approvedEmp5 = 0; var approvedEmp6 = 0;
      var rejectedEmp1 = 0; var rejectedEmp2 = 0; var rejectedEmp3 = 0; var rejectedEmp4 = 0; var rejectedEmp5 = 0; var rejectedEmp6 = 0;
      var totalEmp1 = 0; var totalEmp2 = 0; var totalEmp3 = 0; var totalEmp4 = 0; var totalEmp5 = 0; var totalEmp6 = 0;


      var empData = await this.EmployeesModel.aggregate([
        {
          $facet: {
            totalEmp1: [
              { $project: { applicant_id_updated: 1, month: { $month: '$createdAt' } } },
              { $match: { month: currentMonth, applicant_id_updated: true } },
              { $count: 'total' },
            ],
            totalEmp2: [
              { $project: { applicant_id_updated: 1, month: { $month: '$createdAt' } } },
              { $match: { month: previousMonth1, applicant_id_updated: true } },
              { $count: 'total' }
            ],
            totalEmp3: [
              { $project: { applicant_id_updated: 1, month: { $month: '$createdAt' } } },
              { $match: { month: previousMonth2, applicant_id_updated: true } },
              { $count: 'total' }
            ],
            totalEmp4: [
              { $project: { applicant_id_updated: 1, month: { $month: '$createdAt' } } },
              { $match: { month: previousMonth3, applicant_id_updated: true } },
              { $count: 'total' }
            ],
            totalEmp5: [
              { $project: { applicant_id_updated: 1, month: { $month: '$createdAt' } } },
              { $match: { month: previousMonth4, applicant_id_updated: true } },
              { $count: 'total' }
            ],
            totalEmp6: [
              { $project: { applicant_id_updated: 1, month: { $month: '$createdAt' } } },
              { $match: { month: previousMonth5, applicant_id_updated: true } },
              { $count: 'total' }
            ],


            pendingEmp1: [
              { $project: { applicant_id_updated: 1, LiquiStatus: 1, month: { $month: '$createdAt' } } },
              { $match: { month: currentMonth, applicant_id_updated: true, $or: [{ LiquiStatus: 'Created' }, { LiquiStatus: 'Pending' }] } },
              { $count: 'total' }
            ],
            pendingEmp2: [
              { $project: { applicant_id_updated: 1, LiquiStatus: 1, month: { $month: '$createdAt' } } },
              { $match: { month: previousMonth1, applicant_id_updated: true, $or: [{ LiquiStatus: 'Created' }, { LiquiStatus: 'Pending' }] } },
              { $count: 'total' }
            ],
            pendingEmp3: [
              { $project: { applicant_id_updated: 1, LiquiStatus: 1, month: { $month: '$createdAt' } } },
              { $match: { month: previousMonth2, applicant_id_updated: true, $or: [{ LiquiStatus: 'Created' }, { LiquiStatus: 'Pending' }] } },
              { $count: 'total' }
            ],
            pendingEmp4: [
              { $project: { applicant_id_updated: 1, LiquiStatus: 1, month: { $month: '$createdAt' } } },
              { $match: { month: previousMonth3, applicant_id_updated: true, $or: [{ LiquiStatus: 'Created' }, { LiquiStatus: 'Pending' }] } },
              { $count: 'total' }
            ],
            pendingEmp5: [
              { $project: { applicant_id_updated: 1, LiquiStatus: 1, month: { $month: '$createdAt' } } },
              { $match: { month: previousMonth4, applicant_id_updated: true, $or: [{ LiquiStatus: 'Created' }, { LiquiStatus: 'Pending' }] } },
              { $count: 'total' }
            ],
            pendingEmp6: [
              { $project: { applicant_id_updated: 1, LiquiStatus: 1, month: { $month: '$createdAt' } } },
              { $match: { month: previousMonth5, applicant_id_updated: true, $or: [{ LiquiStatus: 'Created' }, { LiquiStatus: 'Pending' }] } },
              { $count: 'total' }
            ],

            approvedEmp1: [
              { $project: { applicant_id_updated: 1, LiquiStatus: 1, month: { $month: '$createdAt' } } },
              { $match: { month: currentMonth, applicant_id_updated: true, LiquiStatus: "Approved" } },
              { $count: 'total' }
            ],
            approvedEmp2: [
              { $project: { applicant_id_updated: 1, LiquiStatus: 1, month: { $month: '$createdAt' } } },
              { $match: { month: previousMonth1, applicant_id_updated: true, LiquiStatus: "Approved" } },
              { $count: 'total' }
            ],
            approvedEmp3: [
              { $project: { applicant_id_updated: 1, LiquiStatus: 1, month: { $month: '$createdAt' } } },
              { $match: { month: previousMonth2, applicant_id_updated: true, LiquiStatus: "Approved" } },
              { $count: 'total' }
            ],
            approvedEmp4: [
              { $project: { applicant_id_updated: 1, LiquiStatus: 1, month: { $month: '$createdAt' } } },
              { $match: { month: previousMonth3, applicant_id_updated: true, LiquiStatus: "Approved" } },
              { $count: 'total' }
            ],
            approvedEmp5: [
              { $project: { applicant_id_updated: 1, LiquiStatus: 1, month: { $month: '$createdAt' } } },
              { $match: { month: previousMonth4, applicant_id_updated: true, LiquiStatus: "Approved" } },
              { $count: 'total' }
            ],
            approvedEmp6: [
              { $project: { applicant_id_updated: 1, LiquiStatus: 1, month: { $month: '$createdAt' } } },
              { $match: { month: previousMonth5, applicant_id_updated: true, LiquiStatus: "Approved" } },
              { $count: 'total' }
            ],

            rejectedEmp1: [
              { $project: { applicant_id_updated: 1, LiquiStatus: 1, month: { $month: '$createdAt' } } },
              { $match: { month: currentMonth, applicant_id_updated: true, LiquiStatus: "Rejected" } },
              { $count: 'total' }
            ],
            rejectedEmp2: [
              { $project: { applicant_id_updated: 1, LiquiStatus: 1, month: { $month: '$createdAt' } } },
              { $match: { month: previousMonth1, applicant_id_updated: true, LiquiStatus: "Rejected" } },
              { $count: 'total' }
            ],
            rejectedEmp3: [
              { $project: { applicant_id_updated: 1, LiquiStatus: 1, month: { $month: '$createdAt' } } },
              { $match: { month: previousMonth2, applicant_id_updated: true, LiquiStatus: "Rejected" } },
              { $count: 'total' }
            ],
            rejectedEmp4: [
              { $project: { applicant_id_updated: 1, LiquiStatus: 1, month: { $month: '$createdAt' } } },
              { $match: { month: previousMonth3, applicant_id_updated: true, LiquiStatus: "Rejected" } },
              { $count: 'total' }
            ],
            rejectedEmp5: [
              { $project: { applicant_id_updated: 1, LiquiStatus: 1, month: { $month: '$createdAt' } } },
              { $match: { month: previousMonth4, applicant_id_updated: true, LiquiStatus: "Rejected" } },
              { $count: 'total' }
            ],
            rejectedEmp6: [
              { $project: { applicant_id_updated: 1, LiquiStatus: 1, month: { $month: '$createdAt' } } },
              { $match: { month: previousMonth5, applicant_id_updated: true, LiquiStatus: "Rejected" } },
              { $count: 'total' }
            ],

          },
        },
      ]);
      if (empData[0].totalEmp1[0] != undefined) { totalEmp1 = empData[0].totalEmp1[0].total }
      if (empData[0].totalEmp2[0] != undefined) { totalEmp2 = empData[0].totalEmp2[0].total }
      if (empData[0].totalEmp3[0] != undefined) { totalEmp3 = empData[0].totalEmp3[0].total }
      if (empData[0].totalEmp4[0] != undefined) { totalEmp4 = empData[0].totalEmp4[0].total }
      if (empData[0].totalEmp5[0] != undefined) { totalEmp4 = empData[0].totalEmp5[0].total }
      if (empData[0].totalEmp6[0] != undefined) { totalEmp5 = empData[0].totalEmp6[0].total }

      if (empData[0].pendingEmp1[0] != undefined) { pendingEmp1 = empData[0].pendingEmp1[0].total }
      if (empData[0].pendingEmp2[0] != undefined) { pendingEmp2 = empData[0].pendingEmp2[0].total }
      if (empData[0].pendingEmp3[0] != undefined) { pendingEmp3 = empData[0].pendingEmp3[0].total }
      if (empData[0].pendingEmp4[0] != undefined) { pendingEmp4 = empData[0].pendingEmp4[0].total }
      if (empData[0].pendingEmp5[0] != undefined) { pendingEmp4 = empData[0].pendingEmp5[0].total }
      if (empData[0].pendingEmp6[0] != undefined) { pendingEmp5 = empData[0].pendingEmp6[0].total }

      if (empData[0].approvedEmp1[0] != undefined) { approvedEmp1 = empData[0].approvedEmp1[0].total }
      if (empData[0].approvedEmp2[0] != undefined) { approvedEmp2 = empData[0].approvedEmp2[0].total }
      if (empData[0].approvedEmp3[0] != undefined) { approvedEmp3 = empData[0].approvedEmp3[0].total }
      if (empData[0].approvedEmp4[0] != undefined) { approvedEmp4 = empData[0].approvedEmp4[0].total }
      if (empData[0].approvedEmp5[0] != undefined) { approvedEmp4 = empData[0].approvedEmp5[0].total }
      if (empData[0].approvedEmp6[0] != undefined) { approvedEmp5 = empData[0].approvedEmp6[0].total }

      if (empData[0].rejectedEmp1[0] != undefined) { rejectedEmp1 = empData[0].rejectedEmp1[0].total }
      if (empData[0].rejectedEmp2[0] != undefined) { rejectedEmp2 = empData[0].rejectedEmp2[0].total }
      if (empData[0].rejectedEmp3[0] != undefined) { rejectedEmp3 = empData[0].rejectedEmp3[0].total }
      if (empData[0].rejectedEmp4[0] != undefined) { rejectedEmp4 = empData[0].rejectedEmp4[0].total }
      if (empData[0].rejectedEmp5[0] != undefined) { rejectedEmp4 = empData[0].rejectedEmp5[0].total }
      if (empData[0].rejectedEmp6[0] != undefined) { rejectedEmp5 = empData[0].rejectedEmp6[0].total }

      var totalGraph = [
        [totalEmp1, currentMonth, currentMonthYear],
        [totalEmp2, previousMonth1, previousMonthYear1],
        [totalEmp3, previousMonth2, previousMonthYear2],
        [totalEmp4, previousMonth3, previousMonthYear3],
        [totalEmp5, previousMonth4, previousMonthYear4],
        [totalEmp6, previousMonth5, previousMonthYear5],
      ];

      var pendingGraph = [
        [pendingEmp1, currentMonth, currentMonthYear],
        [pendingEmp2, previousMonth1, previousMonthYear1],
        [pendingEmp3, previousMonth2, previousMonthYear2],
        [pendingEmp4, previousMonth3, previousMonthYear3],
        [pendingEmp5, previousMonth4, previousMonthYear4],
        [pendingEmp6, previousMonth5, previousMonthYear5],
      ];
      var approvedGraph = [
        [approvedEmp1, currentMonth, currentMonthYear],
        [approvedEmp2, previousMonth1, previousMonthYear1],
        [approvedEmp3, previousMonth2, previousMonthYear2],
        [approvedEmp4, previousMonth3, previousMonthYear3],
        [approvedEmp5, previousMonth4, previousMonthYear4],
        [approvedEmp6, previousMonth5, previousMonthYear5],
      ];
      var rejectedGraph = [
        [rejectedEmp1, currentMonth, currentMonthYear],
        [rejectedEmp2, previousMonth1, previousMonthYear1],
        [rejectedEmp3, previousMonth2, previousMonthYear2],
        [rejectedEmp4, previousMonth3, previousMonthYear3],
        [rejectedEmp5, previousMonth4, previousMonthYear4],
        [rejectedEmp6, previousMonth5, previousMonthYear5],
      ];


      var data = {
        totalEmpCount: totalEmpCount,
        pendingCount: pendingCount,
        approvedCount: approvedCount,
        rejectedCount: rejectedCount,
        empCountGraph: {
          totalGraph: totalGraph,
          pendingGraph: pendingGraph,
          approvedGraph: approvedGraph,
          rejectedGraph: rejectedGraph
        }
      };
      return { data };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  public async getEmpDetails(IFilterDTO: IFilterDTO): Promise<{ data: any }> {
    try {
      var empData = await this.EmployeesModel.findOne({ _id: IFilterDTO._id })
      var employee: any = {};
      employee._id = empData._id;
      employee.Employee_name = empData.Employee_name;
      employee.Date_of_birth = empData.Date_of_birth;
      employee.Mobile_no = empData.Mobile_no;
      employee.Pan_no = empData.Pan_no;
      employee.Aadhaar_no = empData.Aadhaar_no;
      employee.Joining_date = empData.Joining_date;
      employee.salary = empData.salary;
      employee.organization_name = empData.organization_name;
      employee.EmailId = empData.EmailId;

      if (empData.address_submitted) {
        employee.Address = empData.address_line_1 + empData.address_line_2;
        employee.state = empData.state;
        employee.City = empData.City;
        employee.PinCode = empData.PinCode;
        employee.address_type = empData.address_type;
        employee.area = empData.area;
      }
      if (empData.bank_details_submitted) {
        employee.account_holder_name = empData.account_holder_name;
        employee.account_number = empData.account_number;
        employee.account_type = empData.account_type;
        employee.bank_name = empData.bank_name;
        employee.ifsc = empData.ifsc;
      }
      if (empData.aadhaar_uploaded && empData.pan_uploaded) {
        employee.aadhaarImageURL = empData.aadhaarImageURL;
        employee.PANImageURL = empData.PANImageURL;
      }
      return { data: employee };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  public async uploadEmpSOA(IFilterDTO: IFilterDTO, IEmpDTO: IEmpDTO): Promise<{ data: any }> {
    try {
      var empData = await this.EmployeesModel.findOne({ _id: IFilterDTO._id })
      if (!empData) {
        return { data: { success: false, message: "Employee not found" } };
      }
      var employee = await this.EmployeesModel.findByIdAndUpdate(
        { _id: IFilterDTO._id },
        { $set: { EmpSOA: IEmpDTO.EmpSOA } }
      )

      return { data: { success: true, message: "SOA uploaded successfully" } };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
}