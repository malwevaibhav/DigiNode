import { Service, Inject } from 'typedi';
import { Request, Response } from 'express';
@Service()
export default class InsuranceService {
  constructor(
    @Inject('InsuranceMasterModel') private InsuranceMasterModel: Models.InsuranceMasterModel,
        @Inject('TPAMasterModel') private TPAMasterModel: Models.TPAMasterModel,

    @Inject('userModel') private userModel: Models.UserModel,

    @Inject('logger') private logger,
  ) {}

  public async getInsurance(body: any): Promise<{ data: any }> {
    try {
      var pageNumber = 1;
      var pageSize = 0;
      if (body.pageNumber) {
        var pageNumber = parseInt(body.pageNumber.toString());
      }
      if (body.pageSize) {
        var pageSize = parseInt(body.pageSize.toString());
      }
      var searchFilters = [];
      searchFilters.push({ isDeleted: false });

      var userCount = await this.InsuranceMasterModel.find({ $and: searchFilters}).count();
      var numberOfPages = pageSize === 0 ? 1 : Math.ceil(userCount / pageSize);
      var Insurancelist = await this.InsuranceMasterModel.find({ $and: searchFilters})
        .sort({ createdAt: -1 })
        .skip((pageNumber - 1) * pageSize)
        .limit(pageSize);

      return {
        data: {
          success: true,
          message: Insurancelist,
          numberOfPages,
          userCount
        },
      };
    } catch (error) {
      this.logger.error(error);
      return { data: { success: false, error: error } };
    }
  }
  public async getInsuranceById(id: any): Promise<{ data: any }> {
    try {
    
      var userDetail :any = await this.InsuranceMasterModel.findById({_id:id})
     if(userDetail.isDeleted === true){
       return { data :{success: false, massage : 'Not a valid Insurance id'} }
      }

      return {
        data: {
          success: true,
          message: userDetail,
         
        }
      };
    } catch (error) {
      this.logger.error(error);
      return { data: { success: false, error: error } };
    }
  }
  public async addInsuranceWithTPA(req: Request, res: Response): Promise<{ data: any }> {
    try {
      const { InsuranceCompanyName, InsuranceCompanyCode,TPAName, InHouseTPA, TPACode } = req.body;
      var saveUser;

      if (InHouseTPA) {
        const usrObj = { InsuranceCompanyName, InsuranceCompanyCode, InHouseTPA};
        const newUser = new this.InsuranceMasterModel(usrObj);
        var saveUser1 = await newUser.save();

        var nameOfInsurer = InsuranceCompanyName;
        const usrObject = { nameOfInsurer, InsuranceCompanyId: saveUser1._id, TPAName, TPACode };
        const User = new this.TPAMasterModel(usrObject);
        const saveUser = await User.save();

        var data: any = {};

        data.TPAId = saveUser._id;

        var updateTPA = await this.InsuranceMasterModel.updateOne(
          { _id: saveUser1._id },
          { $set: data },
          { useFindAndModify: false },
        );
        console.log(updateTPA);
      } else {
        const usrObj = { InsuranceCompanyName, InsuranceCompanyCode, InHouseTPA };
        const newUser = new this.InsuranceMasterModel(usrObj);
        saveUser = await newUser.save();
      }

      return {
        data: {
          success: true,
          message: updateTPA,
        },
      };
    } catch (error) {
      this.logger.error(error);
      return { data: { success: false, error: error } };
    }
  }
  public async updateInsuranceWithTPA(req: Request, res: Response): Promise<{ data: any }> {
    try {
      const InsuranceID = req.query._id;
      const { InsuranceCompanyName, InsuranceCompanyCode, InHouseTPA, TPAName, TPACode, TPAId } = req.body;

      if (InHouseTPA) {
        let data: any = {};
        data.InHouseTPA = InHouseTPA;

        if (InsuranceCompanyName) {
          data.InsuranceCompanyName = InsuranceCompanyName;
        }
        if (InsuranceCompanyCode) {
          data.InsuranceCompanyCode = InsuranceCompanyCode;
        }
        const updateTPA = await this.InsuranceMasterModel.updateOne(
          { _id: InsuranceID },
          { $set: data },
          { useFindAndModify: false },
        );

        let dataTPAModel: any = {};
        dataTPAModel = data;

        if (TPAName) {
          dataTPAModel.TPAName = TPAName;
        }
        if (TPACode) {
          dataTPAModel.TPACode = TPACode;
        }

        const updateTPATPAModel = await this.InsuranceMasterModel.updateOne(
          { _id: TPAId },
          { $set: dataTPAModel },
          { useFindAndModify: false },
        );

        return {
          data: {
            success: true,
            message: 'Data Update Succefully',
          },
        };
      } else {
        let dataTPA: any = {};

        dataTPA.InHouseTPA = InHouseTPA;
        if (InsuranceCompanyName) {
          dataTPA.InsuranceCompanyName = InsuranceCompanyName;
        }
        if (InsuranceCompanyCode) {
          dataTPA.InsuranceCompanyCode = InsuranceCompanyCode;
        }

        const updateInsurance = await this.TPAMasterModel.findByIdAndUpdate(
          { _id: InsuranceID },
          { $set: dataTPA },
          { useFindAndModify: false },
        );

        return {
          data: {
            success: true,
            message: 'Data Update Succefully',
          },
        };
      }
    } catch (err) {
      res.send('Error: ' + err);
    }
  }
  public async deleteInsurance(id): Promise<{ data: any }> {
    try {
      const ID = id;
      const deleteUser = await this.InsuranceMasterModel.findByIdAndUpdate({ _id: ID }, {$set:{isDeleted: true}});
      return {
        data: {
          success: true,
          message: 'Delete User Successfully',
        },
      };
    } catch (error) {
      this.logger.error(error);
      return { data: { success: false, error: error } };
    }
  }
}
