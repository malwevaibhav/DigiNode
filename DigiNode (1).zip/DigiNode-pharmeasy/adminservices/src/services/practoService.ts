import { errors } from 'celebrate';
import { Service, Inject } from 'typedi';
import { Request, Response } from 'express';
import { EventDispatcher, EventDispatcherInterface } from '../decorators/eventDispatcher';
import { IPatientLoanDTO, IUser, IFilterDTO } from '@/interfaces/IUser';
import { ObjectId } from 'mongoose';
import { patientLoanRepaymentDC } from '@/models/patientLoanRepayment';
import axios, { AxiosRequestConfig, AxiosResponse } from 'axios';
import { Types } from 'mongoose';
import moment from 'moment';
const BG_URL = process.env.BG_URL;
@Service()
export default class practoService {
  constructor(
    @Inject('patientLoanModel') private patientLoanModel: Models.patientLoanModel,
    @Inject('loans') private loans: Models.loansModel,
    @Inject('ApprovedLoans') private ApprovedLoans: Models.ApprovedLoansModel,

    @Inject('patientLoanRepayment') private patientLoanRepaymentModel: Models.patientLoanRepaymentModel,

    @Inject('logger') private logger,
    @EventDispatcher() private eventDispatcher: EventDispatcherInterface,
  ) {}

  public async updateInvoiceById(invoiceId: ObjectId, usrObj: any): Promise<{ repaymentupdate: any }> {
    try {
      const repaymentupdate = await this.patientLoanModel.updateOne({ invoiceId: invoiceId }, { $set: usrObj });
      return { repaymentupdate };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  public async updateInvoiceById1(invoiceId: ObjectId, repayment: any): Promise<{ repaymentupdate: any }> {
    try {
      const repaymentupdate = await this.patientLoanModel.updateOne({ invoiceId: invoiceId }, { $set: repayment });
      return { repaymentupdate };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  public async updateInvoiceByLoanId(invoiceId: string, usrObj: Object): Promise<{ updateInvoice: any }> {
    try {
      // if(){
      //   delete
      // }
      const usrObj1 = Object.entries(usrObj).filter(([key, value]) => value !== undefined)
      .reduce((obj, [key, value]) => {
        obj[key] = value;
        return obj
      })
      console.log(usrObj1)
      const updateInvoice = await this.patientLoanModel.findOneAndUpdate(
        { invoiceId: invoiceId },
        { $set: usrObj },
        { useFindAndModify: false },
      );
      return { updateInvoice };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  public async updateInvoiceByCaseId(caseId: ObjectId, usrObj: any): Promise<{ disbursementUpdate: any }> {
    try {
      const disbursementUpdate = await this.patientLoanModel.updateOne({ caseId: caseId }, { $set: usrObj });
      return { disbursementUpdate };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  public async UploadLoanByKoCode(KOCode: string, usrObj: any): Promise<{ UpdatedLoan: any }> {
    try {
      const UpdatedLoan = await this.loans.updateOne({ KOCode: KOCode }, { $set: usrObj });
      return { UpdatedLoan };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  public async UpdateAproveLoneByLLCode(KOCode: string, usrObj: any): Promise<{ updateTPA: any }> {
    try {
      const updateTPA = await this.ApprovedLoans.updateOne({ KOCode: KOCode }, { $set: usrObj });
      return { updateTPA };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  public async AddAproveLone(usrObj: any): Promise<{ upl: any }> {
    try {
      const upl = await this.ApprovedLoans.create(usrObj);
      return { upl };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  public async AddLoan(usrObj: any): Promise<{ UpdatedLoan: any }> {
    try {
      const UpdatedLoan = await this.loans.create(usrObj);
      return { UpdatedLoan };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }

  public async getInvoiceById(invoiceId: ObjectId): Promise<{ invoice: any }> {
    try {
      const invoice = await this.patientLoanModel.findOne({ invoiceId: invoiceId });
      return { invoice };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  public async getInvoiceByLoanId(invoiceId: Number, contactNumber: Number): Promise<{ invoice: any }> {
    try {
      const invoice = await this.patientLoanModel.findOne({ invoiceId: invoiceId, contactNumber: contactNumber });
      return { invoice };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  public async getAproveLoneByLLCode(KOCode: string): Promise<{ InvoiceNumberdata: any }> {
    try {
      const InvoiceNumberdata = await this.ApprovedLoans.findOne({ KOCode: KOCode });
      return { InvoiceNumberdata };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  public async getAllApprovedloans(IFilterDTO: IFilterDTO): Promise<{ data: any }> {
    try {
      //pagination
      var pageNumber = 1;
      var pageSize = 0;
      if (IFilterDTO.pageNumber) {
        var pageNumber = IFilterDTO.pageNumber;
      }
      if (IFilterDTO.pageSize) {
        var pageSize = IFilterDTO.pageSize;
      }
      //search
      var searchFilters = [];
      searchFilters.push({ _id: { $exists: true } });

      if (IFilterDTO.searchTerm != undefined) {
        searchFilters.push({
          $or: [
            { FullName: { $regex: IFilterDTO.searchTerm, $options: 'i' } },
            { KOCode: { $regex: IFilterDTO.searchTerm, $options: 'i' } },
            { LLCode: { $regex: IFilterDTO.searchTerm, $options: 'i' } },
            { Lender: { $regex: IFilterDTO.searchTerm, $options: 'i' } },
          ],
        });
      }
      // date filter
      if (IFilterDTO.dateFrom != undefined || (null && IFilterDTO.dateTo != undefined) || null) {
        var dateFrom = IFilterDTO.dateFrom;
        var dateTo = IFilterDTO.dateTo.setDate(IFilterDTO.dateTo.getDate() + 1);
        var dateTo2 = new Date(dateTo);
        searchFilters.push({ UpdatedDate: { $gte: dateFrom, $lte: dateTo2 } });
      }
      //Status Filter
      if (IFilterDTO.Status != undefined || null) {
        searchFilters.push({ Status: IFilterDTO.Status });
      }

      var productCount = await this.ApprovedLoans.find({ $and: searchFilters }).countDocuments();

      var numberOfPages = pageSize === 0 ? 1 : Math.ceil(productCount / pageSize);

      var products = await this.ApprovedLoans.find({ $and: searchFilters })
        .sort({ UpdatedDate: -1 })
        .skip((pageNumber - 1) * pageSize)
        .limit(pageSize);

      var data = { products, numberOfPages };
      return { data };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }

  public async getLoanByKoCode(KOCode: string): Promise<{ loan: any }> {
    try {
      const loan = await this.loans.findOne({ KOCode: KOCode });
      return { loan };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }

  public async addRepayment(patientLoanRepayment: patientLoanRepaymentDC): Promise<{ repaymentupdated: any }> {
    try {
      var repaymentupdate = await this.patientLoanRepaymentModel.create({
        ...patientLoanRepayment,
      });

      const repaymentupdated = repaymentupdate.toObject();

      return { repaymentupdated };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  public async UpdateDisburshmentAtBimaGarate(loan_id: string) {
    try {
      var invoiceDetails: any = await this.patientLoanModel.findOne({ loan_id: loan_id });
      var Caseid = invoiceDetails.caseId;
      var obj: any = {
        invoicedetails: invoiceDetails.invoiceId,
        loanamt: invoiceDetails.Disbursed_Amount,
        borrower_name: invoiceDetails.borrowerName ? invoiceDetails.borrowerName : invoiceDetails.patientName,
        appdt: this.dateformate(invoiceDetails.Approval_Date),
        disbdt: this.dateformate(invoiceDetails.Disbursement_Date),
        disbstatus: 'Loan Disbursed',
      };
      return await this.UpdateDisbersment(obj, Caseid);
    } catch (error) {
      return { success: false, message: 'Failed to update Disbursement at Bima Garage' };
    }
  }
  public async token() {
    let url = `${BG_URL}/api/token/`;
    let userinfo = {
      username: 'digisparsh-api',
      password: 'Digi@1234',
    };
    let token = await axios.post(url, userinfo);

    return token.data.access;
  }

  public dateformate(yourDate) {
    const offset = yourDate.getTimezoneOffset();
    yourDate = new Date(yourDate.getTime() - offset * 60 * 1000);
    return yourDate.toISOString().split('T')[0];
  }
  public async UpdateDisbersment(UpdateClaimStage5: any, PatientId: number) {
    let url = `${BG_URL}/external/api/recdisb/${PatientId}`;
    let access_token = await this.token();
    let Response = await axios.patch(url, UpdateClaimStage5, {
      headers: {
        Authorization: `Bearer ${access_token}`,
      },
    });
    ///
    const config: AxiosRequestConfig = {
      method: 'POST',
      url: `http://localhost:3061/api/auth/whatsappClient`,
      data: {
        text: `Disbursement updated\nCaseId: ${PatientId}`,
        notificationId: null,
        organization: 'Bima',
      },
      headers: {
        'Content-Type': 'application/json',
      },
    };
    const response: AxiosResponse = await axios(config);
    return Response;
  }
  public async getInvoiceBy_Id(req: Request, res: Response): Promise<{ data: any }> {
    try {
      const id = req.query._id.toString();
      const usr = await this.patientLoanModel.aggregate([
        { $match: { _id: Types.ObjectId(id) } },
        {
          $lookup: {
            from: 'patientloanrepayments',
            localField: 'invoiceId',
            foreignField: 'invoiceId',
            as: 'repaymentData',
          },
        },
      ]);
      var data = usr;
      return { data };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  // agreement & mandate
  public async createMandateForm(IFilterDTO: IFilterDTO): Promise<{ success: Boolean; message: String }> {
    try {
      const invoiceDetails = await this.patientLoanModel.findOne({ _id: IFilterDTO._id });

      var digioObj: any = {};

      digioObj.customer_email = invoiceDetails.emailId;
      digioObj.customer_name = invoiceDetails.accountHolderName;
      digioObj.customer_ref_number = invoiceDetails.invoiceId;
      digioObj.customer_mobile = invoiceDetails.contactNumber;
      digioObj.customer_account_number = invoiceDetails.accountNumber;
      digioObj.destination_bank_id = invoiceDetails.IFSCCode;
      digioObj.first_collection_date = moment().format('YYYY-MM-DD');
      digioObj.instrument_type = 'debit';
      digioObj.is_recurring = true;
      digioObj.frequency = 'Monthly';
      digioObj.management_category = 'L001';
      digioObj.maximum_amount = invoiceDetails.finalApprovedAmount;

      const config: AxiosRequestConfig = {
        method: 'POST',
        url: `${process.env.digioURL}/v3/client/mandate/create_form`,
        data: {
          auth_mode: 'api',
          corporate_config_id: process.env.corporate_config_id,
          customer_identifier: invoiceDetails.contactNumber,
          mandate_type: 'create',
          notify_customer: 'true',
          mandate_data: digioObj,
        },
        auth: {
          username: process.env.digioUsername,
          password: process.env.digioSecret,
        },
      };
      let response;
      try {
        response = await axios(config);
      } catch (e) {
        console.log(e.response.data);
        return {
          success: false,
          message: e.response.data.message,
        };
      }

      const updateMandateDetails = await this.patientLoanModel.findByIdAndUpdate(
        { _id: IFilterDTO._id },
        { $set: { invoiceSubStatus: 'Awaiting E-Nach', mandate_id: response.data.mandate_id } },
        { useFindAndModify: false },
      );

      return { success: true, message: `E-Nach link sent to mobile no. ${invoiceDetails.contactNumber}` };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  public async sendAgreementPdf(IFilterDTO: IFilterDTO): Promise<{ success: Boolean; message: String }> {
    try {
      const invoiceDetails = await this.patientLoanModel.findOne({ _id: Types.ObjectId(IFilterDTO._id) });
      console.log('invoiceDetails', invoiceDetails);
      // const invoiceDetails = await this.patientLoanModel.aggregate([
      //   { $match: { _id: Types.ObjectId(IFilterDTO._id) } },
      //   {
      //     $lookup: {
      //       from: 'organizationschemas',
      //       localField: 'LenderId',
      //       foreignField: '_id',
      //       as: 'organizationData',
      //     },
      //   },
      //   {
      //     $unwind: {
      //       path: "$organizationData",
      //       preserveNullAndEmptyArrays: true
      //     }
      //   },
      //   {
      //     $set: { agreementTemplateId: "$organizationData.agreementTemplateId" }
      //   },
      //   {
      //     $project: { organizationData: 0 }
      //   },
      // ]);
      if (!invoiceDetails || !invoiceDetails || !invoiceDetails.agreementTemplateId) {
        return {
          success: false,
          message: 'Agreement Template not found',
        };
      }
      const invoiceData = invoiceDetails;
      invoiceData.scheme = invoiceData.scheme * 30;
      const todayDate = new Date().toUTCString().slice(5, 16);
      const age = getAge(invoiceData.dateOfBirth);
      const aadhar=await this.imageURLToBase64(invoiceData.uploadAadharFront); 
      const pan=await this.imageURLToBase64(invoiceData.uploadPAN); 
      const aadharb=await this.imageURLToBase64(invoiceData.uploadAadharBack); 
      const config: AxiosRequestConfig = {
        method: 'POST',
        url: `${process.env.digioURL}/v2/client/template/multi_templates/create_sign_request`,
        data: {
          templates: [
            {
              template_key: invoiceData.agreementTemplateId,
              template_values: {
                age: age,
                pan_no: invoiceData.PANNumber,
                product_name: 'Patient Reimbursement Loan',
                loan_tenure: invoiceData.scheme,
                application_no: invoiceData.loan_id,
                sanction_amount: invoiceData.finalApprovedAmount,
                borrower_name: invoiceData.borrowerName ? invoiceData.borrowerName : invoiceData.patientName,
                borrower_address: `${invoiceData.currentAddress}, ${invoiceData.currentCity}, ${invoiceData.currentState}`,
                date: todayDate,
                aadhar_front:aadhar,
                aadhar_back:aadharb,
                pan_card:pan,
                // AadharFront: `${invoiceData.uploadAadharFront}`,
                // PANCard:`${invoiceData.uploadPAN}`,
                // AadharBack: `${invoiceData.uploadAadharBack}`,

 
              }

            },
          ],
          signers: [
            {
              name: invoiceData.borrowerName ? invoiceData.borrowerName : invoiceData.patientName,
              identifier: invoiceData.contactNumber,
              reason: 'Loan Agreement',
              sign_type: 'electronic',
              signature_mode: 'otp',
            },
          ],
          send_sign_link: 'true',
          notify_signers: 'true',
          display_on_page: 'all',
        },
        auth: {
          username: process.env.digioUsername,
          password: process.env.digioSecret,
        },
      };
      let response;
      try {
        response = await axios(config);
      } catch (e) {
        console.log('digio error', e.response.statusText, e.response.data);
        return {
          success: false,
          message: e.response.statusText + '-' + e.response.data.message,
        };
      }

      const updateInvoice = await this.patientLoanModel.findByIdAndUpdate(
        { _id: invoiceData._id },
        { $set: { invoiceSubStatus: 'Awaiting Agreement Signing', agreementDocId: response.data.id } },
        { useFindAndModify: false },
      );
      if (updateInvoice) {
        return { success: true, message: `Agreement Sent to mobile no. ${invoiceData.contactNumber}` };
      }
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  private async imageURLToBase64(url:string){
    try {
     const image= await axios.get(url,{responseType:"arraybuffer"})
     return Buffer.from(image.data).toString('base64');
    } catch (e) {
      this.logger.error(e);
      throw e;
    }

  }
  public async verifyBankAccount(IPatientLoanDTO: IPatientLoanDTO): Promise<{ success: Boolean; message: String }> {
    try {
      const invoiceData = await this.patientLoanModel.findOneAndUpdate(
        { _id: IPatientLoanDTO._id },
        { $set: IPatientLoanDTO },
        { useFindAndModify: false, new: true },
      );

      const config: AxiosRequestConfig = {
        method: 'POST',
        auth: {
          username: process.env.digioUsername,
          password: process.env.digioSecret,
        },
      };

      if (invoiceData.KYCRequestId && invoiceData.KYCActionId) {
        config.url = `${process.env.digioURL}/client/kyc/v2/request/${invoiceData.KYCRequestId}/reattempt`;
        config.data = {
          action_ids: [invoiceData.KYCActionId],
        };
      } else {
        config.url = `${process.env.digioURL}/client/kyc/v2/request`;
        config.data = {
          customer_identifier: invoiceData.contactNumber,
          customer_name: invoiceData.patientName,
          reference_id: invoiceData.invoiceId,
          notify_customer: true,
          actions: [
            {
              type: 'PENNY_DROP',
              title: 'Bank Account Verification',
              description: 'Please enter bank account details for penny drop',
            },
          ],
        };
      }

      let response;
      try {
        response = await axios(config);
      } catch (e) {
        console.log('digio error', e.response.statusText, e.response.data);
        return {
          success: false,
          message: e.response.statusText + '-' + e.response.data.message,
        };
      }

      const updateInvoice = await this.patientLoanModel.findByIdAndUpdate(
        { _id: invoiceData._id },
        { $set: { invoiceSubStatus: 'Awaiting Bank Verification', KYCRequestId: response.data.id } },
        { useFindAndModify: false },
      );
      if (updateInvoice) {
        return { success: true, message: `Bank Verification URL Sent to mobile no. ${invoiceData.contactNumber}` };
      }
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
}

function getAge(dateString) {
  var today = new Date();
  var birthDate = new Date(dateString);
  var age = today.getFullYear() - birthDate.getFullYear();
  var m = today.getMonth() - birthDate.getMonth();
  if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
    age--;
  }
  return age;
}
