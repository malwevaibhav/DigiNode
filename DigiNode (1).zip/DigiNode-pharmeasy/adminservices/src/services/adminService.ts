/* eslint-disable no-var */
/* eslint-disable prettier/prettier */
import { Service, Inject } from 'typedi';
import { Request, Response } from 'express';
import {
  IUser,
  IUserInputDTO,
  IAggregatorDTO,
  IVendorDTO,
  ILenderDTO,
  IHospitalDTO,
  IPatientLoanDTO,
  IFilterDTO,
  IClaimInvoiceDTO,
  IOrgInputDTO

} from '../interfaces/IUser';
import { EventDispatcher, EventDispatcherInterface } from '../decorators/eventDispatcher';
import axios, { AxiosRequestConfig, AxiosResponse } from 'axios';
import argon2 from 'argon2';
import MailerService from './mailer';
import { randomBytes } from 'crypto';
import events from '../subscribers/events';
import { Types } from 'mongoose';
import MailJetService from '../loaders/mailjet';
const TaError = require('../api/utils/taerror');
const { OK, Created, Bad_Request, Unauthorized, Server_Error } = require('../api/utils/error.def');

@Service()
export default class adminSidebarService {
  constructor(
    @Inject('userModel') private userModel: Models.UserModel,
    @Inject('userDetailsModel') private userDetails: Models.UserDetailsModel,
    @Inject('organizationModel') private organizationModel: Models.organizationModel,
    @Inject('patientLoanModel') private patientLoanModel: Models.patientLoanModel,
    @Inject('ApprovedLoans') private ApprovedLoansModel: Models.ApprovedLoansModel,
    @Inject('loans') private loansModel: Models.loansModel,
    @Inject('ClaimInvoice') private Invoice: Models.ClaimInvoiceModel,
    @Inject('TransactionData') private TransactionData: Models.TransactionDataModel,
    @Inject('OSVModel') private OSVModel: Models.OSVModel,
    // @Inject('SupplierInvoice') private SupplierInvoice: Models.SupplierInvoiceModel,
    private mailer: MailerService,
    private mailjet: MailJetService,
    @Inject('logger') private logger,
    @EventDispatcher() private eventDispatcher: EventDispatcherInterface,
  ) { }

  public async getAllUsers(IFilterDTO: IFilterDTO): Promise<{ data: any }> {
    try {
      //pagination
      var pageNumber = 1;
      var pageSize = 0;
      if (IFilterDTO.pageNumber) {
        var pageNumber = IFilterDTO.pageNumber;
      }
      if (IFilterDTO.pageSize) {
        var pageSize = IFilterDTO.pageSize;
      }
      //search

      var filters = IFilterDTO.filters || [];
      var searchFilters = [];
      searchFilters.push({ isDeleted: false });
      if (IFilterDTO.searchTerm != undefined) {
        searchFilters.push({
          $or: [
            { name: { $regex: IFilterDTO.searchTerm, $options: 'i' } },
            { email: { $regex: IFilterDTO.searchTerm, $options: 'i' } },
            { role: { $regex: IFilterDTO.searchTerm, $options: 'i' } }
          ]
        })
      }
      if (IFilterDTO.organizationId) {
        searchFilters.push({ organizationId: Types.ObjectId(IFilterDTO.organizationId) })
      }

      // for (var element of filters) {
      //   searchFilters.push({ [element.searchField]: { $regex: element.searchTerm, $options: 'i' } });
      // }

      var userCount = await this.userModel.find({ $and: searchFilters }).countDocuments();
      var numberOfPages = pageSize === 0 ? 1 : Math.ceil(userCount / pageSize);
      var users = await this.userModel.aggregate([
        { $match: { $and: searchFilters } },
        { $sort: { createdAt: -1 } },
        { $skip: (pageNumber - 1) * pageSize },
        { $limit: pageSize ? pageSize : Number.MAX_SAFE_INTEGER },
        {
          $lookup: {
            from: 'organizationschemas',
            localField: 'organizationId',
            foreignField: '_id',
            as: 'organizationData',
          },
        },
        {
          $unwind: {
            path: "$organizationData",
            preserveNullAndEmptyArrays: true
          }
        },
        {
          $set: { nameOfOrganization: "$organizationData.nameOfOrganization", typeOfOrganization: "$organizationData.typeOfOrganization" }
        },
        {
          $project: { organizationData: 0 }
        },
      ]);

      var data = { users, numberOfPages };
      return { data };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }

  public async getAllLenderToAdmin(req: Request, res: Response): Promise<{ data: any }> {
    try {
      const usr = await this.organizationModel.find({ typeOfOrganization: 'Lender' }).sort({ updatedAt: -1 });
      var data = usr;
      return { data };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  public async getUserByIdToAdmin(req: Request, res: Response): Promise<{ data: any }> {
    try {
      const id = req.query._id.toString();
      const usr = await this.userModel.aggregate([
        { $match: { _id: Types.ObjectId(id) } },
        {
          $lookup: {
            from: 'organizationschemas',
            localField: 'organizationId',
            foreignField: '_id',
            as: 'orgData',
          },
        },
      ]);
      var data = usr;
      return { data };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  public async addUserByAdmin(
    userInputDTO: IUserInputDTO,
    currentUser: IUser,
  ): Promise<{ data: any; responseCode: any }> {
    try {
      const salt = randomBytes(32);
      this.logger.silly('Hashing password');
      const hashedPassword = await argon2.hash(userInputDTO.password, { salt });
      var email = userInputDTO.email.toLowerCase();
      const findUser = await this.userModel.findOne({ email: email });

      if (findUser && findUser.email) {
        return {
          data: {
            success: false,
            message: 'Email is already registered.',
          },
          responseCode: 400,
        };
      }
      const orgData = await this.organizationModel.findOne({ _id: userInputDTO.organizationId });
      
      if ((orgData.claimFinancing == false && userInputDTO.claimFinancing != false) ||
        (orgData.supplierFinancing == false && userInputDTO.supplierFinancing != false) ||
        (orgData.patientFinancing == false && userInputDTO.patientFinancing != false) ||
        (orgData.merchantFinancing == false && userInputDTO.merchantFinancing != false) ||
        (orgData.employeeManagement == false && userInputDTO.employeeManagement != false) ||
        (orgData.purchaseFinancing == false && userInputDTO.purchaseFinancing != false) 
      ) {
        return {
          data: {
            success: false,
            message: 'Not Authorized for this product',
          },
          responseCode: 400,
        };
      }
      
      this.logger.silly('Creating user db record');
      const userRecord = await this.userModel.create({
        ...userInputDTO,
        isActive: true,
        isDeleted: false,
        updatedAt: new Date().toUTCString(),
        createdAt: new Date().toUTCString(),
        updatedBy: currentUser._id,
        salt: salt.toString('hex'),
        password: hashedPassword,
        passwordUpdatedOn: new Date().toUTCString(),
      });
      
      if (!userRecord) {
        throw new Error('User cannot be created');
      }
      this.logger.silly('Sending welcome email');
      await this.mailer.SendWelcomeEmail(userRecord);
      // await this.mailjet.SendWelcomeEmail(userRecord)

      this.eventDispatcher.dispatch(events.user.signUp, { user: userRecord });

      const user = userRecord.toObject();
      Reflect.deleteProperty(user, 'password');
      Reflect.deleteProperty(user, 'salt');
      var data = { user, success: true };
      return { data, responseCode: Created };
    } catch (error) {
      this.logger.error(error);
      return {
        responseCode: Server_Error,
        data: { success: false, error: error },
      };
    }
  }
  public async updatePassword(req, userInputDTO: IUserInputDTO, currentUser: IUser): Promise<{ data: any }> {
    try {
      const id = req.query._id;
      const userDetails = await this.userModel.findOne({ _id: id });
      if (!userDetails) {
        return {
          data: {
            success: false,
            message: 'user not found',
          },
        };
      }
      const salt = randomBytes(32);
      this.logger.silly('Hashing password');
      const hashedPassword = await argon2.hash(userInputDTO.password, { salt });

      this.logger.silly('updating password');
      let passwordData: any = {};

      passwordData.updatedAt = new Date().toUTCString();
      passwordData.updatedBy = currentUser._id;
      passwordData.salt = salt.toString('hex');
      passwordData.password = hashedPassword;
      passwordData.passwordUpdatedOn = new Date().toUTCString();

      const userRecord = await this.userModel.findByIdAndUpdate(
        { _id: id },
        { $set: passwordData },
        { useFindAndModify: false, new: true },
      );
      if (!userRecord) {
        throw new Error('password cannot be updated');
      }

      const user = userRecord.toObject();
      Reflect.deleteProperty(user, 'password');
      Reflect.deleteProperty(user, 'salt');
      var data = { success: true };
      return { data };
    } catch (error) {
      this.logger.error(error);
      return {
        data: { success: false, error: error },
      };
    }
  }
  public async editUserByAdmin(
    userInputDTO: IUserInputDTO,
    currentUser: IUser,
    req: Request,
  ): Promise<{ data: any; responseCode: any }> {
    try {
      const id = req.query._id;
      this.logger.silly('updating user db record');
      let userData: any = {
        ...userInputDTO,
        updatedAt: new Date().toUTCString(),
        updatedBy: currentUser._id,
      };

      var email = userInputDTO.email.toLowerCase();
      const findUser = await this.userModel.findOne({ email: email });

      if (findUser && findUser._id != id) {
        return {
          data: {
            success: false,
            message: 'Email is already registered.',
          },
          responseCode: 400,
        };
      }

      const user = await this.userModel.findByIdAndUpdate(
        { _id: id },
        { $set: userData },
        { useFindAndModify: false, new: true },
      );
      var data = { success: true, message: user };
      return { data, responseCode: 200 };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  public async deleteUserByAdmin(req: Request, res: Response): Promise<{ data: any }> {
    try {
      const id = req.query._id;
      await this.userModel.findByIdAndUpdate(
        { _id: id },
        { $set: { isDeleted: true, isActive: false } },
        { useFindAndModify: false },
      );
      const data = { success: true, message: 'user deleted' };
      return { data };
    } catch (e) {
      this.logger.error(e);
      return {
        data: { success: false, error: e },
      };
    }
  }
  public async updateAggregator(req,
    IAggregatorDTO: IAggregatorDTO,
    currentUser: IUser,
  ): Promise<{ data: any; responseCode: any }> {
    try {
      var user = await this.userModel.findOne({ _id: req.query._id });
      if (!user) {
        return {
          responseCode: Bad_Request,
          data: {
            success: false,
            message: 'user not found',
          },
        };
      }
      var saveUserDetails = await this.userModel.findByIdAndUpdate(
        { _id: req.query._id },
        { $set: IAggregatorDTO, updatedAt: new Date().toUTCString(), updatedBy: currentUser._id },
        { useFindAndModify: false, upsert: true, new: true },
      );
      return {
        responseCode: Created,
        data: {
          success: true,
          message: 'success',
          user: saveUserDetails,
        },
      };
    } catch (error) {
      this.logger.error(error);
      return {
        responseCode: Bad_Request,
        data: {
          success: false,
          error: error,
        },
      };
    }
  }
  public async updateVendor(IVendorDTO: IVendorDTO, currentUser: IUser): Promise<{ data: any; responseCode: any }> {
    try {
      let userId = IVendorDTO.userId;
      var user = await this.userModel.findOne({ _id: userId });
      let vendeordata: any = {}
      if (!user) {
        return {
          responseCode: Bad_Request,
          data: {
            success: false,
            message: 'user not found',
          },
        };
      }
      if (IVendorDTO.VednorType) {
        vendeordata.VednorType = IVendorDTO.VednorType
      }
      if (IVendorDTO.GSTNumber) {
        vendeordata.GSTNumber = IVendorDTO.GSTNumber
      }
      if (IVendorDTO.PANNumber) {
        vendeordata.PANNumber = IVendorDTO.PANNumber
      }

      if (IVendorDTO.bankName) {
        vendeordata.bankName = IVendorDTO.bankName
      }
      if (IVendorDTO.accountNumber) {
        vendeordata.accountNumber = IVendorDTO.accountNumber
      }
      if (IVendorDTO.IFSCCode) {
        vendeordata.IFSCCode = IVendorDTO.IFSCCode
      }
      if (IVendorDTO.authorisedPersonName) {
        vendeordata.authorisedPersonName = IVendorDTO.authorisedPersonName
      }
      if (IVendorDTO.contactDetailsForAuthPerson) {
        vendeordata.contactDetailsForAuthPerson = IVendorDTO.contactDetailsForAuthPerson
      }
      if (IVendorDTO.PANNumberForAuthPerson) {
        vendeordata.PANNumberForAuthPerson = IVendorDTO.PANNumberForAuthPerson
      }
      if (IVendorDTO.relationShip) {
        vendeordata.relationShip = IVendorDTO.relationShip
      }
      if (IVendorDTO.KycDocument) {
        vendeordata.KycDocument = IVendorDTO.KycDocument
      }
      if (IVendorDTO.Other) {
        vendeordata.Other = IVendorDTO.Other
      }

      if (IVendorDTO.ParriPassu) {
        vendeordata.ParriPassu = IVendorDTO.ParriPassu
      }
      if (IVendorDTO.LastTwoYrBank) {
        vendeordata.LastTwoYrBank = IVendorDTO.LastTwoYrBank
      }
      if (IVendorDTO.LastAudFin) {
        vendeordata.LastAudFin = IVendorDTO.LastAudFin
      }
      if (IVendorDTO.LastTwoFin) {
        vendeordata.LastTwoFin = IVendorDTO.LastTwoFin
      }
      if (IVendorDTO.RegCert) {
        vendeordata.RegCert = IVendorDTO.RegCert
      }
      if (IVendorDTO.GstCert) {
        vendeordata.GstCert = IVendorDTO.GstCert
      }
      if (IVendorDTO.AddrProof) {
        vendeordata.AddrProof = IVendorDTO.AddrProof
      }


      if (IVendorDTO.RateOfDeduction) {
        vendeordata.RateOfDeduction = IVendorDTO.RateOfDeduction
      }
      if (IVendorDTO.NoOfDaysCreditPeriod) {
        vendeordata.NoOfDaysCreditPeriod = IVendorDTO.NoOfDaysCreditPeriod
      }
      if (IVendorDTO.SanctionLimit) {
        vendeordata.SanctionLimit = IVendorDTO.SanctionLimit
      }
      if (IVendorDTO.HospitalName) {
        vendeordata.HospitalName = IVendorDTO.HospitalName
      }
      if (IVendorDTO.HospitalName) {
        vendeordata.HospitalName = IVendorDTO.HospitalName
      }
      if (IVendorDTO.LTV) {
        vendeordata.LTV = IVendorDTO.LTV
      }
      if (IVendorDTO.HospitalId) {
        vendeordata.HospitalId = IVendorDTO.HospitalId
        let lenderdata: any = await this.userModel.findById({ _id: vendeordata.HospitalId })
        if (lenderdata) {
          vendeordata.LenderId = lenderdata.LenderId
        }
      }

      let saveUserDetails = await this.userModel.findByIdAndUpdate(
        { _id: userId },
        { $set: vendeordata, updatedAt: new Date().toUTCString(), updatedBy: currentUser._id },
        { useFindAndModify: false, upsert: true, new: true },
      );
      return {
        responseCode: Created,
        data: {
          success: true,
          message: 'success',
          user: saveUserDetails,
        },
      };
    } catch (error) {
      this.logger.error(error);
      return {
        responseCode: Bad_Request,
        data: {
          success: false,
          error: error,
        },
      };
    }
  }
  public async updateLender(ILenderDTO: ILenderDTO, currentUser: IUser): Promise<{ data: any; responseCode: any }> {
    try {
      let userId = ILenderDTO.userId;
      var user = await this.userModel.findOne({ _id: userId });
      if (!user) {
        return {
          responseCode: Bad_Request,
          data: {
            success: false,
            message: 'user not found',
          },
        };
      }
      let saveUserDetails = await this.userDetails.findByIdAndUpdate(
        { userId: userId },
        { $set: ILenderDTO, updatedAt: new Date().toUTCString(), updatedBy: currentUser._id },
        { useFindAndModify: false, upsert: true, new: true },
      );
      return {
        responseCode: Created,
        data: {
          success: true,
          message: 'success',
          user: saveUserDetails,
        },
      };
    } catch (error) {
      this.logger.error(error);
      return {
        responseCode: Bad_Request,
        data: {
          success: false,
          error: error,
        },
      };
    }
  }
  public async updateHospital(req: Request,
    IHospitalDTO: IHospitalDTO,
    currentUser: IUser,
  ): Promise<{ data: any; responseCode: any }> {
    try {
      var user = await this.userModel.findOne({ _id: req.query._id });
      if (!user) {
        return {
          responseCode: Bad_Request,
          data: {
            success: false,
            message: 'user not found',
          },
        };
      }
      let saveUserDetails = await this.userModel.findByIdAndUpdate(
        { _id: req.query._id },
        { $set: IHospitalDTO, updatedAt: new Date().toUTCString(), updatedBy: currentUser._id },
        { useFindAndModify: false, upsert: true, new: true },
      );
      // let lenderAssociation = await this.HospitalLenderAssociationModel.
      return {
        responseCode: Created,
        data: {
          success: true,
          message: 'success',
          user: saveUserDetails,
        },
      };
    } catch (error) {
      this.logger.error(error);
      return {
        responseCode: Bad_Request,
        data: {
          success: false,
          error: error,
        },
      };
    }
  }
  public async getClaimInvoicesToAdmin(IFilterDTO: IFilterDTO): Promise<{ data: any }> {
    try {
      //pagination
      var pageNumber = 1;
      var pageSize = 0;
      var total: any = {};
      if (IFilterDTO.pageNumber) {
        var pageNumber = IFilterDTO.pageNumber;
      }
      if (IFilterDTO.pageSize) {
        var pageSize = IFilterDTO.pageSize;
      }
      //search
      // var filters = IFilterDTO.filters || [];
      var searchFilters = [];
      // because search filter can't be an empty array
      searchFilters.push({ "LoanID": { $exists: true } });
      searchFilters.push({ isDeleted: false });

      if (IFilterDTO.Status != undefined || null) {
        searchFilters.push({ Status: IFilterDTO.Status });
      }
      if (IFilterDTO.searchTerm != undefined) {
        searchFilters.push({
          $or: [
            { nameOfHospital: { $regex: IFilterDTO.searchTerm, $options: 'i' } },
            { claimId: { $regex: IFilterDTO.searchTerm, $options: 'i' } },
            { patientName: { $regex: IFilterDTO.searchTerm, $options: 'i' } },
            {
              "$expr": {
                "$regexMatch": {
                  "input": { "$toString": "$LoanID" },
                  "regex": IFilterDTO.searchTerm
                }
              }
            }
          ]
        })
      }

      // for (var element of filters) {
      //   searchFilters.push({ [element.searchField]: { $regex: element.searchTerm, $options: 'i' } });
      // }
      var userCount = await this.Invoice.find({ $and: searchFilters }).countDocuments();
      var numberOfPages = pageSize === 0 ? 1 : Math.ceil(userCount / pageSize);
      var claimInvoices = await this.Invoice
        .find({ $and: searchFilters })
        .sort({ updatedAt: -1 })
        .skip((pageNumber - 1) * pageSize)
        .limit(pageSize);

      var totalAmount = await this.Invoice.aggregate([{ $match: { $and: searchFilters } }, { $group: { _id: '$_v', totalAmount: { $sum: '$LenderApprovalAmount' } } }
      ]);
      if (totalAmount.length != 0) {
        total.count = userCount
        total.totalAmount = totalAmount[0].totalAmount
      } else {
        total.count = 0
        total.totalAmount = 0
      }

      var data = { claimInvoices, numberOfPages, total };
      return { data };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  public async getAllInvoicesToAdmin(currentUser: IUser, IFilterDTO: IFilterDTO): Promise<{ data: any }> {
    try {
      //pagination
      var pageNumber = 1;
      var pageSize = 0;
      if (IFilterDTO.pageNumber) {
        var pageNumber = IFilterDTO.pageNumber;
      }
      if (IFilterDTO.pageSize) {
        var pageSize = IFilterDTO.pageSize;
      }
      //uninsured/ reimbursement
      // var insuredStatus = IFilterDTO.isInsured

      //search
      var filters = IFilterDTO.filters || [];
      var searchFilters = [];
      searchFilters.push({ isDeleted: false });

      if (IFilterDTO.searchTerm != undefined) {
        searchFilters.push({
          $or: [
            { emailId: { $regex: IFilterDTO.searchTerm, $options: 'i' } },
            { hospitalName: { $regex: IFilterDTO.searchTerm, $options: 'i' } },
            { patientName: { $regex: IFilterDTO.searchTerm, $options: 'i' } },
            { UWName: { $regex: IFilterDTO.searchTerm, $options: 'i' } },
            {
              "$expr": {
                "$regexMatch": {
                  "input": { "$toString": "$contactNumber" },
                  "regex": IFilterDTO.searchTerm
                }
              }
            },
            {
              "$expr": {
                "$regexMatch": {
                  "input": { "$toString": "$invoiceId" },
                  "regex": IFilterDTO.searchTerm
                }
              }
            },
            {
              "$expr": {
                "$regexMatch": {
                  "input": { "$toString": "$caseId" },
                  "regex": IFilterDTO.searchTerm
                }
              }
            }
          ]
        })
      }

      // if (IFilterDTO.dateFrom != undefined || (null && IFilterDTO.dateTo != undefined) || null) {
      //   searchFilters.push({ createdAt: { $gte: IFilterDTO.dateFrom, $lte: IFilterDTO.dateTo } });
      // }
      if (IFilterDTO.dateFrom != undefined || null && IFilterDTO.dateTo != undefined || null) {
        var dateFrom = IFilterDTO.dateFrom;
        var dateTo2 = IFilterDTO.dateTo.setDate(IFilterDTO.dateTo.getDate() + 1);
        var dateTo = new Date(dateTo2)
        searchFilters.push({ createdAt: { $gte: dateFrom, $lte: dateTo } });
      }

      if (IFilterDTO.organizationId != undefined || null) {
        searchFilters.push({ organizationId: Types.ObjectId(IFilterDTO.organizationId) });
      }

      if (IFilterDTO.invoiceStatus != undefined || null) {
        searchFilters.push({ invoiceStatus: IFilterDTO.invoiceStatus });
      }

      if (IFilterDTO.invoiceSubStatus != undefined || null) {
        searchFilters.push({ invoiceSubStatus: IFilterDTO.invoiceSubStatus });
      }
      if (IFilterDTO.isInsured != undefined || null) {
        searchFilters.push({ isInsured: IFilterDTO.isInsured });
        //   if(IFilterDTO.isInsured){
        //     searchFilters.push({UWPartnerApproved : true});
        //   }
        // } else {
        //   searchFilters.push({ $or: [{ isInsured: false }, { UWPartnerApproved : true }] });
      }
      // for (var element of filters) {
      //   searchFilters.push({ [element.searchField]: { $regex: element.searchTerm, $options: 'i' } });
      // }
      var userCount = await this.patientLoanModel.find({ $and: searchFilters }).countDocuments();
      var numberOfPages = pageSize === 0 ? 1 : Math.ceil(userCount / pageSize);
      var patientLoans = await this.patientLoanModel.aggregate([
        { $match: { $and: searchFilters } },
        { $sort: { updatedAt: -1 } },
        { $skip: (pageNumber - 1) * pageSize },
        { $limit: pageSize ? pageSize : Number.MAX_SAFE_INTEGER },
        {
          $lookup: {
            from: 'bgcases',
            localField: 'caseId',
            foreignField: 'case_id',
            as: 'BGData',
          },
        },
        {
          $unwind: {
            path: "$BGData",
            preserveNullAndEmptyArrays: true
          }
        },
        {
          $set: { claim_status: "$BGData.claim_status" }
        },
        {
          $project: { BGData: 0 }
        },
        {
          $lookup: {
            from: 'users',
            localField: 'DSPLAssignee',
            foreignField: '_id',
            as: 'assigneeData',
          },
        },
        {
          $unwind: {
            path: "$assigneeData",
            preserveNullAndEmptyArrays: true
          }
        },
        {
          $set: { assigneeName: "$assigneeData.name" }
        },
        {
          $project: { assigneeData: 0 }
        },{
          $lookup: {
            from: 'patientrepayments',
            localField: 'invoiceId',
            foreignField: 'invoiceId',
            as: 'patientrepaymentsDetails',
          },
        },
        {
          $lookup: {
            from: 'organizationschemas',
            localField: 'organizationId',
            foreignField: '_id',
            as: 'orgData',
          }
        },
        {
          $lookup: {
            from: 'mandatedetails',
            let:{"id":"$mandateDetailsId"},
            pipeline:[
              {
                "$match":{ "_id":{$exists:true},
                  "$expr":{"$eq":["$_id","$$id"]},
                 
                }
              }
            ],            
            as: 'mandateDetails',
          },
        },
      ]);
      if (currentUser.accessControl == 0) {
        for (let invoice of patientLoans) {
          if (invoice.orgData[0] && invoice.orgData[0].primaryDSPLAssignee &&
            invoice.orgData[0].primaryDSPLAssignee.equals(currentUser._id) &&
            invoice.DSPLAssignee &&
            invoice.DSPLAssignee.equals(currentUser._id)
          ) {
            invoice.checkbox = true;
            delete invoice.orgData;
          } else {
            invoice.checkbox = false;
            delete invoice.orgData;
          }
        }
      }
      var DApprovedInvoiceCount = 0;
      var totalFundedAmount = 0;
      // var total: any = {};

      var totalAmount = await this.patientLoanModel.aggregate([{ $match: { $and: searchFilters } }, { $group: { _id: '$_v', totalAmount: { $sum: '$loanAmount' } } }
      ]);
      if (totalAmount.length != 0) {
        DApprovedInvoiceCount = userCount
        totalFundedAmount = totalAmount[0].totalAmount
      } else {
        DApprovedInvoiceCount = 0
        totalFundedAmount = 0
      }

      var data = { DApprovedInvoiceCount, totalFundedAmount, patientLoans, numberOfPages };
      return { data };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }

  public async deleteInvoiceToAdmin(currentUser: IUser, patientLoanDTO: IPatientLoanDTO): Promise<{ data: any }> {
    try {
      const id = patientLoanDTO._id;
      var invoice = await this.patientLoanModel.findOne({ _id: id })
      if (invoice.invoiceStatus != "Pending") {
        return { data: { success: false, message: "Cannot delete Invoice" } }
      }

      var deleteInvoice = await this.patientLoanModel.findByIdAndUpdate({ _id: id }, { $set: { isDeleted: true, updatedBy: currentUser._id } });
      //pending invoice      
      if (deleteInvoice) {
        var data = { success: true, message: "Invoice deleted Successfully" };
        return { data };
      }

    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  public async getInvoiceByIdToAdmin(req: Request, res: Response): Promise<{ data: any }> {
    try {
      const invoiceData = await this.patientLoanModel.findOne({ _id: req.query._id })
      // const orgData = await this.organizationModel.findOne({ _id: res.organizationId });
      const id = req.query._id.toString();
      const user = await this.patientLoanModel.aggregate([
        { $match: { _id: Types.ObjectId(id) } },
        {
          $lookup: {
            from: 'patientloanrepayments',
            localField: 'invoiceId',
            foreignField: 'invoiceId',
            as: 'repaymentData',
          },

        },
        // {

        //   $lookup: {
        //     from: 'organizationschemas',
        //     localField: 'organizationId',
        //     foreignField: '_id',
        //     as: 'orgData',
        //   },
        // },
        {
          $lookup: {
            from: 'patientrepayments',
            localField: 'invoiceId',
            foreignField: 'invoiceId',
            as: 'patientrepaymentsDetails',
          },
        },
        {
         $sort:{'patientrepaymentsDetails.createdAt':-1}
        },
        {
          $lookup: {
            from: 'mandatedetails',
            let:{"id":"$mandateDetailsId"},
            pipeline:[
              {
                "$match":{ "_id":{$exists:true},
                  "$expr":{"$eq":["$_id","$$id"]},
                 
                }
              }
            ],            
            as: 'mandateDetails',
          },
        },
        {
          $set: { LenderName: "$LenderData.nameOfOrganization" }
        },
        {
          $project: { LenderData: 0 }
        },
     
      ]);

      ///
      var usr = user[0]
      var data = usr;
      return { data };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  public async getClaimInvoiceByIdToAdmin(req: Request, res: Response): Promise<{ data: any, repaymentData: any }> {
    try {
      const id = req.query._id.toString();
      const usr = await this.Invoice.findOne({ _id: id })
      var repaymentData;
      if (usr) {
        repaymentData = await this.TransactionData.find({ invoiceId: usr._id })
      }

      var data = usr;
      return { data, repaymentData };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  public async editInvoiceByAdmin(req, currentUser: IUser, patientLoanDTO: IPatientLoanDTO, orgInputDTO: IOrgInputDTO): Promise<{ data: any }> {
    try {
      const id = req.query._id;
      // if (patientLoanDTO.loan_id) {
      //   const invoiceDetails = await this.patientLoanModel.findOne({ loan_id: patientLoanDTO.loan_id });
      //   if (invoiceDetails) {
      //     return {
      //       data: { success: false, message: "Duplicate Loan ID" }
      //     };
      //   }
      // }  
      if (patientLoanDTO?.LenderId) {
        var lenderDetails = await this.organizationModel.findOne({ _id: patientLoanDTO.LenderId });
        console.log(lenderDetails, "lenderDetails");
        if (lenderDetails?.lenderType == 'Offline') {
          patientLoanDTO.invoiceSubStatus = "InProcess"
        }
      }
      // if(currentUser.email="ayuhealth@ayuhealth.in"){
      //   if(!patientLoanDTO?.contactNoRefPerson ||patientLoanDTO.contactNoRefPerson=='null'){
      //     delete patientLoanDTO.contactNoRefPerson
      //   }
      // }
      let invoiceData: any = {};
      invoiceData.invoiceStatus = patientLoanDTO.invoiceStatus;
      if (patientLoanDTO.invoiceStatus == 'InProcess') {
      }
      if (patientLoanDTO.digiComment) {
        invoiceData.digiComment = patientLoanDTO.digiComment;
      }
      if (patientLoanDTO.invoiceSubStatus == 'Pending E-nach and E-agreement' && patientLoanDTO.loanAmount != 0) {
        patientLoanDTO.invoiceSubStatus = 'Succesful E-nach and E-agreement'
        patientLoanDTO.invoiceStatus = 'Hospital Invoice Pending'
      }
      if ((patientLoanDTO.invoiceSubStatus == 'Cust Call Pending' && patientLoanDTO.bankAssociated != "null" && patientLoanDTO.invoiceStatus != 'Save as Draft')
        || patientLoanDTO.invoiceSubStatus == 'Additional Information' && patientLoanDTO.bankAssociated != "null") {
        patientLoanDTO.invoiceSubStatus = 'Pending E-nach and E-agreement'
        patientLoanDTO.invoiceStatus = 'Approved'
      }
      if (patientLoanDTO.invoiceStatus == 'Conditional acceptance') {
        patientLoanDTO.invoiceSubStatus = 'Additional Information'
        patientLoanDTO.invoiceStatus = 'Accepted'
      }
      if (patientLoanDTO.invoiceStatus == 'Save as Draft') {
        patientLoanDTO.invoiceSubStatus = 'Cust Call Pending'
        patientLoanDTO.invoiceStatus = 'Accepted'
      }
      if (patientLoanDTO.loan_id) {
        invoiceData.loan_id = patientLoanDTO.loan_id;
      }
      if (patientLoanDTO.LenderId) {
        invoiceData.LenderId = patientLoanDTO.LenderId;
      }
      if (patientLoanDTO.finalApprovedAmount && patientLoanDTO.interest) {
        var interestAmount = (patientLoanDTO.finalApprovedAmount * patientLoanDTO.interest) / 100;
        var processingPer = (patientLoanDTO.finalApprovedAmount * patientLoanDTO.processingFees) / 100;

        var GST = ((processingPer + interestAmount) * 18) / 100;

        var deductions = interestAmount + processingPer + GST;

        var DisbursementAmount = patientLoanDTO.finalApprovedAmount - deductions;

        var emiAmount = 0;
        var EMITenure = 0;
        if (patientLoanDTO.isInsured == false) {
          //uninsured
          emiAmount = DisbursementAmount / patientLoanDTO.scheme;
          emiAmount = Math.round((emiAmount + Number.EPSILON) * 100) / 100;
          EMITenure = patientLoanDTO.scheme;
        } else {
          //reimbursement
          emiAmount = DisbursementAmount;
          EMITenure = patientLoanDTO.scheme;
        }
        patientLoanDTO.PF_Amount = processingPer;
        patientLoanDTO.GST_Amount = GST;
        patientLoanDTO.Disbursed_Amount = DisbursementAmount;
        patientLoanDTO.interest_Amount = interestAmount;
        patientLoanDTO.deduction_Amount = deductions;
        patientLoanDTO.EMI_Amount = emiAmount;
        patientLoanDTO.EMI_Tenure = EMITenure;
      }
      // if (patientLoanDTO.invoiceSubStatus == 'Cust Call Pending' && req.body.isInsured == 'false' ) {
      //   patientLoanDTO.invoiceSubStatus = "Upload Final Bill"
      // }
      if (patientLoanDTO.invoiceStatus == 'Withdraw') {
        patientLoanDTO.invoiceSubStatus = 'Withdraw'
      }
      if (patientLoanDTO.invoiceStatus == 'InProcess' && req.body.isInsured == 'false') {
        patientLoanDTO.invoiceStatus = 'Accepted'
        patientLoanDTO.invoiceSubStatus = 'Cust Call Pending'
      }

      if (patientLoanDTO.invoiceSubStatus == 'Ready to Disburse') {
        patientLoanDTO.invoiceStatus = "Disbursed"
        patientLoanDTO.invoiceSubStatus = "Disbursement Done"
      }
      if (patientLoanDTO.invoiceSubStatus == 'Pending Disbursement') {
        patientLoanDTO.invoiceStatus = "Approved by Lender"
        patientLoanDTO.invoiceSubStatus = "Ready to Disburse"
      }

      if (patientLoanDTO.LenderId) {
        invoiceData.LenderId = patientLoanDTO.LenderId;
      }
      if (patientLoanDTO.invoiceStatus == 'Withdraw') {
        patientLoanDTO.invoiceSubStatus = 'Withdraw'
      }
       if (patientLoanDTO.invoiceStatus == 'Rejected' &&  patientLoanDTO.invoiceSubStatus != "Rejected by Lender") {
        patientLoanDTO.invoiceSubStatus = "Rejected by DSPL"
      }
      // if(patientLoanDTO.invoiceStatus == 'InProcess'){
      //   invoiceData.invoiceSubStatus = 'Pending at Lender'
      // }
      // console.log(patientLoanDTO.invoiceStatus);
      // console.log(lenderDetails.lenderType, "lenderDetails.lenderType");
      
      
      if ((req.body.uploadConsentDoc || patientLoanDTO.invoiceStatus == 'InProcess') && lenderDetails?.lenderType != 'Offline') 
      { patientLoanDTO.invoiceSubStatus = 'Pending at Lender' }

      if (patientLoanDTO.invoiceStatus=="Pending" && patientLoanDTO.invoiceSubStatus == 'Rejected by DSPL') {
        patientLoanDTO.invoiceStatus = 'Pending'
        patientLoanDTO.invoiceSubStatus = 'Pending at DSPL'
      }
     if( patientLoanDTO.invoiceStatus=="Pending" &&patientLoanDTO.invoiceSubStatus == 'Rejected by Lender'){
        patientLoanDTO.invoiceStatus = 'InProcess'
        patientLoanDTO.invoiceSubStatus = 'Pending at Lender'
      } 
      // if(patientLoanDTO.invoiceStatus == 'InProcess'){
      //   invoiceData.invoiceSubStatus = 'Pending at Lender'
      // }
      // if ((req.body.uploadConsentDoc || patientLoanDTO.invoiceStatus == 'InProcess') && (lenderDetails.lenderType?lenderDetails.lenderType: null != 'Offline' && req.body.isInsured != 'false') ) 
      // { patientLoanDTO.invoiceSubStatus = 'Pending at Lender' }

      // if(patientLoanDTO.scheme == undefined){
      //   invoiceData.scheme = 0
      // }
      // invoiceData.updatedAt = new Date().toUTCString();
      // invoiceData.updatedBy = currentUser._id;
      // invoiceData.organizationId = currentUser.organizationId
      // let saveUserDetails = await this.organizationModel.findByIdAndUpdate(
      //   { _id: patientLoanDTO.organizationId },
      //   { $set: orgInputDTO, updatedAt: new Date().toUTCString(), updatedBy: currentUser._id, LenderId: patientLoanDTO.LenderId },
      //   { useFindAndModify: false, upsert: true, new: true },
      // );
     
      const invoice = await this.patientLoanModel.findByIdAndUpdate(
        { _id: id },
        {
          $set: patientLoanDTO,
          updatedAt: new Date().toUTCString(),
          updatedBy: currentUser._id, LenderId: patientLoanDTO.LenderId,
        },
        { useFindAndModify: false, upsert: true, new: true },

      );
      // let patientstatus = {
      //   invoiceStatus: patientLoanDTO.invoiceStatus,
      //   id: id,
      //   invoiceSubStatus: patientLoanDTO.invoiceSubStatus,
      //   digiComment: patientLoanDTO.digiComment,
      // };
      var data = { success: true, message: `${patientLoanDTO.invoiceStatus} Successfully` , id: id,};
      return { data };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  public async editClaimInvoiceByAdmin(req, currentUser: IUser, claimInvoiceDTO: IClaimInvoiceDTO): Promise<{ data: any }> {
    try {
      const id = req.query._id;
      await this.Invoice.findOne({ _id: id });
      let invoiceData: any = {};
      if (claimInvoiceDTO.Status == true) {
        invoiceData.Status = 'DSPL Approved';
      } else {
        invoiceData.Status = 'DSPL Rejected';
      }
      invoiceData.DigiSparshComment = claimInvoiceDTO.DigiSparshComment;
      invoiceData.updatedAt = new Date().toUTCString();
      invoiceData.DresponseDate = new Date().toUTCString()
      // invoiceData.updatedBy = currentUser._id;

      const invoice = await this.Invoice.findByIdAndUpdate(
        { _id: id },
        { $set: invoiceData },
        { useFindAndModify: false, new: true },
      );
      var data = { success: true, message: invoice };
      return { data };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  public async deleteClaimInvoicesToAdmin(currentUser: IUser, claimInvoiceDTO: IClaimInvoiceDTO): Promise<{ data: any }> {
    try {
      const id = claimInvoiceDTO._id;
      var invoice = await this.Invoice.findOne({ _id: id })
      if (invoice.Status != "Pending") {
        return { data: { success: false, message: "Cannot delete Claim Invoice" } }
      }

      var deleteInvoice = await this.Invoice.findByIdAndUpdate({ _id: id }, { $set: { isDeleted: true, updatedBy: currentUser._id } });
      //pending invoice      
      if (deleteInvoice) {
        var data = { success: true, message: "Claim Invoice deleted Successfully" };
        return { data };
      }

    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  public async updateAssignee(currentUser: IUser, patientLoanDTO: IPatientLoanDTO): Promise<{ data: any }> {
    try {
      let invoiceIds = patientLoanDTO.invoiceIds.map(s => Types.ObjectId(s));
      if (currentUser.accessControl == 3 || currentUser.accessControl == 4) {
        await this.patientLoanModel.updateMany(
          { _id: { $in: invoiceIds } },
          { $set: { DSPLAssignee: Types.ObjectId(patientLoanDTO.assigneeId) } }
        )
        return { data: { success: true, message: "Invoices Updated Successfully" } };
      } else if (currentUser.accessControl == 1 || currentUser.accessControl == 2) {
        var failedInvoiceId = [];
        var updatedInvoiceId = [];
        for (let id of invoiceIds) {
          var invoiceData: any = await this.patientLoanModel.aggregate([
            { $match: { _id: id } },
            {
              $lookup: {
                from: 'organizationschemas',
                localField: 'organizationId',
                foreignField: '_id',
                as: 'orgData',
              },
            }
          ])
          if (invoiceData[0].orgData[0] && invoiceData[0].orgData[0].primaryDSPLAssignee &&
            invoiceData[0].orgData[0].primaryDSPLAssignee.equals(currentUser._id) &&
            invoiceData[0].DSPLAssignee.equals(currentUser._id)) {
            await this.patientLoanModel.updateOne(
              { _id: id },
              { $set: { DSPLAssignee: Types.ObjectId(invoiceData[0].orgData[0].secondaryDSPLAssignee) } }
            )
            updatedInvoiceId.push(invoiceData[0].invoiceId)
          }
        }
        return { data: { success: true, message: `Invoices Updated Successfully` } };
      }
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }

  // get Merchant list NICT
  public async getMerchantList(IFilterDTO: IFilterDTO): Promise<{ data: any }> {
    try {
      //pagination
      var pageNumber = 1;
      var pageSize = 0;
      if (IFilterDTO.pageNumber) {
        var pageNumber = IFilterDTO.pageNumber;
      }
      if (IFilterDTO.pageSize) {
        var pageSize = IFilterDTO.pageSize;
      }

      var searchFilters = [];
      searchFilters.push({ _id: { $exists: true } });

      //search filter
      if (IFilterDTO.searchTerm != undefined) {
        searchFilters.push({
          $or: [
            { FullName: { $regex: IFilterDTO.searchTerm, $options: 'i' } },
            { KOCode: { $regex: IFilterDTO.searchTerm, $options: 'i' } },
            { Lender: { $regex: IFilterDTO.searchTerm, $options: 'i' } },
          ]
        })
      }
      //date filter
      if (IFilterDTO.dateFrom != undefined || null && IFilterDTO.dateTo != undefined || null) {
        var dateFrom = IFilterDTO.dateFrom;
        var dateTo = IFilterDTO.dateTo.setDate(IFilterDTO.dateTo.getDate() + 1);
        var dateTo2 = new Date(dateTo)
        searchFilters.push({ UpdatedDate: { $gte: dateFrom, $lte: dateTo2 } });
      }

      var userCount = await this.loansModel.find({ $and: searchFilters }).countDocuments();
      var numberOfPages = pageSize === 0 ? 1 : Math.ceil(userCount / pageSize);
      var merchantUserList = await this.loansModel
        .find({ $and: searchFilters })
        .sort({ UpdatedDate: -1 })
        .skip((pageNumber - 1) * pageSize)
        .limit(pageSize);

      var todaysCount = 0;
      var todaysAmount = 0;
      var today = new Date();
      var todayDate = new Date(today.setHours(0, 0, 0, 0));
      var tomorrow = new Date(today.setDate(today.getDate() + 1));

      var merchantData = await this.loansModel.aggregate([
        {
          $facet: {
            todaysCount: [
              { $match: { UpdatedDate: { $gte: todayDate, $lte: tomorrow } } },
              { $count: 'total' }
            ],
            todaysAmount: [
              { $match: { UpdatedDate: { $gte: todayDate, $lte: tomorrow } } },
              { $group: { _id: '$_v', total: { $sum: '$LoanAmount' } } },
            ],
          },
        },
      ]);

      if (merchantData[0].todaysCount[0] != undefined) {
        todaysCount = merchantData[0].todaysCount[0].total
      }
      if (merchantData[0].todaysAmount[0] != undefined) {
        todaysAmount = merchantData[0].todaysAmount[0].total
      }

      var data = { merchantUserList, numberOfPages, todaysCount, todaysAmount };
      return { data };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }

  // merchant details
  public async getMerchantById(req: Request): Promise<{ data: any }> {
    try {
      const merchantId = req.query.koCode;
      var merchantUser = await this.loansModel.findOne({ KOCode: merchantId });
      var data = { merchantUser };

      return { data };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }

  // Update Loans NICT admin
  public async updateLoansToAdmin(req: Request): Promise<{ updatedData: any }> {
    try {
      const Code = req.query.KoCode;
      const {
        FullName,
        ApplicantsPanNo,
        ApplicantsAadhaarNo,
        DateOfBirth,
        Occupation,
        Country,
        City,
        BankAssociated,
        CurrentAddress,
        State,
        Pincode,
        MobileNumber,
        EmailId,
        LoanAmount,
        Scheme,
        ReferenceName,
        AlternateContactNumber,
        Interest,
        ProcessingFees,
        EMIAmount,
        uploadAadharDoc,
        uploadAadharDocs,
        uploadPANDoc,
        AccountNumber,
        District,
        Branch,
        IFSCCode,
        AccountHolderName,
        ApproveOrReject,
        valueChanged,
        AccountNumberForSBI,
      } = req.body;

      var dateObj = new Date().toISOString();

      let data = {
        ApproveOrReject,
        uploadAadharDoc,
        uploadAadharDocs,
        valueChanged,
        uploadPANDoc,
        AccountNumber,
        AccountNumberForSBI,
        FullName,
        ApplicantsPanNo,
        Country,
        City,
        ApplicantsAadhaarNo,
        DateOfBirth,
        Occupation,
        BankAssociated,
        CurrentAddress,
        State,
        Pincode,
        MobileNumber,
        LoanAmount,
        EmailId,
        Scheme,
        ReferenceName,
        AlternateContactNumber,
        Interest,
        ProcessingFees,
        EMIAmount,
        District,
        Branch,
        IFSCCode,
        AccountHolderName,
      };

      data.ApproveOrReject = ApproveOrReject;
      // data.UpdatedDate = dateObj;

      if (uploadAadharDoc) {
        data.uploadAadharDoc = uploadAadharDoc;
      }
      if (uploadAadharDocs) {
        data.uploadAadharDocs = uploadAadharDocs;
      }
      if (valueChanged) {
        data.valueChanged = valueChanged;
      }
      if (uploadPANDoc) {
        data.uploadPANDoc = uploadPANDoc;
      }
      if (AccountNumber) {
        data.AccountNumber = AccountNumber;
      }
      if (AccountNumberForSBI) {
        data.AccountNumberForSBI = AccountNumberForSBI;
      }
      if (FullName) {
        data.FullName = FullName;
      }
      if (ApplicantsPanNo) {
        data.ApplicantsPanNo = ApplicantsPanNo;
      }
      if (Country) {
        data.Country = Country;
      }
      if (City) {
        data.City = City;
      }
      if (ApplicantsAadhaarNo) {
        data.ApplicantsAadhaarNo = ApplicantsAadhaarNo;
      }
      if (DateOfBirth) {
        data.DateOfBirth = DateOfBirth;
      }
      if (Occupation) {
        data.Occupation = Occupation;
      }
      if (BankAssociated) {
        data.BankAssociated = BankAssociated;
      }
      if (CurrentAddress) {
        data.CurrentAddress = CurrentAddress;
      }
      if (State) {
        data.State = State;
      }
      if (Pincode) {
        data.Pincode = Pincode;
      }
      if (MobileNumber) {
        data.MobileNumber = MobileNumber;
      }
      if (LoanAmount) {
        data.LoanAmount = LoanAmount;
      }
      if (EmailId) {
        data.EmailId = EmailId;
      }
      if (Scheme) {
        data.Scheme = Scheme;
      }
      if (ReferenceName) {
        data.ReferenceName = ReferenceName;
      }
      if (AlternateContactNumber) {
        data.AlternateContactNumber = AlternateContactNumber;
      }
      if (Interest) {
        data.Interest = Interest;
      }
      if (ProcessingFees) {
        data.ProcessingFees = ProcessingFees;
      }
      if (EMIAmount) {
        data.EMIAmount = EMIAmount;
      }
      ///////////////////////////
      if (District) {
        data.District = District;
      }
      if (Branch) {
        data.Branch = Branch;
      }
      if (IFSCCode) {
        data.IFSCCode = IFSCCode;
      }
      if (AccountHolderName) {
        data.AccountHolderName = AccountHolderName;
      }

      const updateTPA = await this.loansModel.updateOne({ KOCode: Code }, { $set: data }, { useFindAndModify: false });
      var updatedData = {
        success: true,
        message: 'Data Update Successfully',
      };
      return { updatedData };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  // offline cases patient loan
  public async getOrgByName(orgName): Promise<{ data: any }> {
    try {
      const orgData = await this.organizationModel.findOne(
        { nameOfOrganization: orgName },
      );
      return { data: orgData };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  public async getPatientInvoice(Unique_Ref_No): Promise<{ invoice: any }> {
    try {
      const invoice = await this.patientLoanModel.findOne(
        { Unique_Ref_No: Unique_Ref_No },
        // { $set: invoiceData },
        // { useFindAndModify: false, upsert: true, new: true },
      );
      return { invoice };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  public async uploadPatientInvoice(invoiceData): Promise<{ invoice: any }> {
    try {
      const invoice = await this.patientLoanModel.create(invoiceData);
      return { invoice };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  public async updatePatientInvoice(invoiceData): Promise<{ invoice: any }> {
    try {
      const invoice = await this.patientLoanModel.findOneAndUpdate(
        { Unique_Ref_No: invoiceData.Unique_Ref_No },
        { $set: invoiceData },
        { useFindAndModify: false, new: true },
      );
      return { invoice };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  public async userActivation(IUserInputDTO: IUser): Promise<{ success: boolean, message: string }> {
    try {
      await this.userModel.findByIdAndUpdate({ _id: IUserInputDTO._id }, { $set: IUserInputDTO }, { useFindAndModify: false });
      return { success: true, message: 'user updated' };
    } catch (e) {
      this.logger.error(e);
      return {
        success: false, message: e,
      }
    }
  }

  public async getOSVDetails(): Promise<{ osvEmpName: string, osvEmpId: string, osvEmpOrg: string }> {
    try {
      const osvDetails = await this.OSVModel.find();
      return { osvEmpName: osvDetails[0].osvEmpName, osvEmpId: osvDetails[0].osvEmpId, osvEmpOrg: osvDetails[0].osvEmpOrg }
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }



  public async getAddressByPIN(req: Request): Promise<{ success: Boolean, message: any }> {
    try {
      const config: AxiosRequestConfig = {
        method: 'GET',
        url: `https://api.postalpincode.in/pincode/${req.query.pincode}`,
        headers: {
          'Content-Type': 'application/json',
        }
      };
      const response: AxiosResponse = await axios(config);

      if (response && response.data && response.data[0] && response.data[0].Status == 'Success' && response.data[0].PostOffice && response.data[0].PostOffice[0]) {
        return {
          success: true, message: response.data[0].PostOffice[0]
        };
      }
      else {
        return { success: false, message: "Error fetching pin code data" }
      }
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }

  // public async userActivation(IUserInputDTO: IUser): Promise<{ success: boolean, message: string }> {
  //   try {
  //     await this.userModel.findByIdAndUpdate({ _id: IUserInputDTO._id }, { $set: IUserInputDTO }, { useFindAndModify: false });
  //     return { success: true, message: 'user updated' };
  //   } catch (e) {
  //     this.logger.error(e);
  //     return {
  //       success: false, message: e,
  //     }
  //   }
  // }

}
