import { Service, Inject } from 'typedi';
import { Request, Response } from 'express';
import { IFilterDTO, AHAssociationDTO } from '../interfaces/IUser';
import { Types } from 'mongoose';

@Service()
export default class AHAssociationService {
  constructor(
    @Inject('organizationModel') private organizationModel: Models.organizationModel,
    @Inject('AHAssociationModels') private AHAssociationModel: Models.AHAssociationModels,
    @Inject('logger') private logger,
  ) { }

  public async updateAHAssociation(AHAssociationDTO: AHAssociationDTO): Promise<{ data: any }> {
    try {
      const associationDetails = await this.organizationModel.findOneAndUpdate(
        { _id: AHAssociationDTO.aggregatorId, },
        {
          $set: {
            hospitals: AHAssociationDTO.hospitals,
            updatedAt: new Date().toUTCString()
          }
        },
        { useFindAndModify: false, new: true },
      );
      return { data: { success: true, message: "Association updated" } };
    }
    catch (error) {
      this.logger.error(error);
      throw error
    }
  }

  public async getEmployeeLoanById(qube_ref_id: string, qube_loan_id: string): Promise<{ EmployeeLoan: any }> {
    try {
      var EmployeeLoan = await this.AHAssociationModel.findOne({ qube_ref_id: qube_ref_id, qube_loan_id: qube_loan_id });
      return { EmployeeLoan };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }

  // public async updateEmployeeLoan(AHAssociationDTO: AHAssociationDTO, usrObj): Promise<{ EmployeeLoan: any }> {
  //   try {
  //     var EmployeeLoan = await this.AHAssociationModel.findOneAndUpdate(
  //       { _id: usrObj.aggregatorId, },
  //       {
  //           $set: {
  //               hospitals: AHAssociationDTO.hospitals,
  //               updatedAt: new Date().toUTCString()
  //           }
  //       },
  //       { useFindAndModify: false, new: true },
  //     );
  //     return { EmployeeLoan };
  //   } catch (e) {
  //     this.logger.error(e);
  //     throw e;
  //   }
  // }

  public async addHospital(companyConstantBank: any): Promise<{ companyConstantBankdata: any }> {
    try {
    
      var companyConstantBankdata = await this.AHAssociationModel.insertMany([...companyConstantBank]);


      return { companyConstantBankdata };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }

  public async getAllHospitals(): Promise<{ companyConstant: any }> {
    try {
      const companyConstant = await this.AHAssociationModel.find({});
      return { companyConstant };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
}