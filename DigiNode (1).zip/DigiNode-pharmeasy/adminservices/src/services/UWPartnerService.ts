import { Service, Inject } from 'typedi';
import { Request, Response } from 'express';
import { IOrgInputDTO, IFilterDTO, IPartnerDTO, IUser, IPatientLoanDTO } from '../interfaces/IUser';
import moment from 'moment';
import pushToQueue from '../loaders/rabbitMQ'

@Service()
export default class UWPartnerService {
    constructor(
        @Inject('organizationModel') private organizationModel: Models.organizationModel,
        @Inject('UWPartnerModel') private UWPartnerModel: Models.UWPartnerModel,
        @Inject('ClaimInvoice') private Invoice: Models.ClaimInvoiceModel,
        @Inject('TransactionData') private TransactionData: Models.TransactionDataModel,
        @Inject('patientLoanModel') private patientLoanModel: Models.patientLoanModel,
        @Inject('logger') private logger,
    ) { }

    public async addPartnerAssociation(orgInputDTO: IOrgInputDTO): Promise<{ data: any }> {
        try {
            const OrgRecord = await this.organizationModel.findByIdAndUpdate(
                { _id: orgInputDTO.organizationId },
                {
                    $set: {
                        UWPartners: orgInputDTO.UWPartners,
                        updatedAt: new Date().toUTCString()
                    }
                },
                { useFindAndModify: false, new: true },
            );
            return { data: { success: true, message: "Partner successfully associated" } };
        }
        catch (error) {
            this.logger.error(error);
            throw error;
        }
    }
    // public async getPartnersToAdmin(IFilterDTO: IFilterDTO): Promise<{ data: any }> {
    //     try {
    //         var pageNumber = 1;
    //         var pageSize = 0;
    //         if (IFilterDTO.pageNumber) {
    //             var pageNumber = IFilterDTO.pageNumber;
    //         }
    //         if (IFilterDTO.pageSize) {
    //             var pageSize = IFilterDTO.pageSize;
    //         }
    //         var searchFilters = [];
    //         searchFilters.push({ isDeleted: false });

    //         var userCount = await this.UWPartnerModel.find({ $and: searchFilters }).countDocuments();
    //         var numberOfPages = pageSize === 0 ? 1 : Math.ceil(userCount / pageSize);

    //         var partners = await this.UWPartnerModel.find({ $and: searchFilters }).sort({ createdAt: -1 }).skip((pageNumber - 1) * pageSize).limit(pageSize);

    //         var data = { success: true, partners, numberOfPages };
    //         return { data };
    //     }
    //     catch (error) {
    //         this.logger.error(error);
    //         throw error;
    //     }
    // }
    // public async addPartnerByAdmin(IPartnerDTO: IPartnerDTO): Promise<{ data: any }> {
    //     try {
    //         const partnerInDb = await this.UWPartnerModel.findOne({ partnerName: IPartnerDTO.partnerName, isDeleted: false })
    //         if (partnerInDb != undefined) {
    //             return { data: { success: false, message: "Partner already exists with provided name" } }
    //         }
    //         const partner = await this.UWPartnerModel.create({
    //             ...IPartnerDTO
    //         });

    //         var data = { success: true, message: "Partner Added Successfully" }
    //         return { data };
    //     }
    //     catch (error) {
    //         this.logger.error(error);
    //         throw error
    //     }
    // }
    // public async editPartnerByAdmin(IPartnerDTO: IPartnerDTO): Promise<{ data: any }> {
    //     try {
    //         const partnerInDb = await this.UWPartnerModel.findOne({ partnerName: IPartnerDTO.partnerName, isDeleted: false })
    //         if (partnerInDb != undefined) {
    //             return { data: { success: false, message: "Partner already exists with provided name" } }
    //         }
    //         const partner = await this.UWPartnerModel.findByIdAndUpdate(
    //             { _id: IPartnerDTO._id },
    //             { $set: { partnerName: IPartnerDTO.partnerName } },
    //             { useFindAndModify: false, new: true },
    //         );
    //         var data = { success: true, message: "Partner Updated Successfully", partner }
    //         return { data };
    //     }
    //     catch (error) {
    //         this.logger.error(error);
    //         throw error
    //     }
    // }
    // public async deletePartnerByAdmin(IPartnerDTO: IPartnerDTO): Promise<{ data: any }> {
    //     try {
    //         const partner = await this.UWPartnerModel.findByIdAndUpdate(
    //             { _id: IPartnerDTO._id },
    //             { $set: { isDeleted: true } },
    //             { useFindAndModify: false, new: true },
    //         );
    //         var data = { success: true, message: "Partner Deleted Successfully" }
    //         return { data };
    //     }
    //     catch (error) {
    //         this.logger.error(error);
    //         throw error
    //     }
    // }
    public async partnerDashboard(currentUser: IUser, IFilterDTO: IFilterDTO): Promise<{ data: any }> {
        try {
            var searchFilters = [];
            searchFilters.push({ isDeleted: false });
            searchFilters.push({ UWName: currentUser.name });

            if (IFilterDTO.dateFrom != undefined || null && IFilterDTO.dateTo != undefined || null) {
                searchFilters.push({ createdAt: { $gte: IFilterDTO.dateFrom, $lte: IFilterDTO.dateTo } });
            }
            var orgData = await this.organizationModel.find({ "UWPartners": { $elemMatch: { partnerName: currentUser.name } } })

            var associatedHospitals = 0;
            var associatedAggregators = 0;
            for (let org of orgData) {
                if (org.typeOfOrganization == "Hospital") { var associatedHospitals = associatedHospitals + 1 }
                if (org.typeOfOrganization == "Aggregator") { var associatedAggregators = associatedAggregators + 1 }
            }

            var dashboardData = await this.patientLoanModel.aggregate([
                {
                    $facet: {
                        totalUninsuredCount: [{ $match: { isInsured: false, $and: searchFilters } }, { $count: 'total' }],
                        totalReimbursementCount: [{ $match: { isInsured: true, $and: searchFilters } }, { $count: 'total' }],
                        totalCount: [{ $match: { $and: searchFilters } }, { $count: 'total' }],
                        totalAmount: [
                            { $match: { $and: searchFilters } },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],
                        totalUninsuredAmount: [
                            { $match: { isInsured: false, $and: searchFilters } },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],
                        totalReimbursementAmount: [
                            { $match: { isInsured: true, $and: searchFilters } },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],
                        totalInProcessCount: [
                            {
                                $match: {
                                    $and: [
                                        { $and: searchFilters },
                                        {
                                            $or: [
                                                { invoiceStatus: 'Pending' },
                                                { invoiceStatus: 'InProcess' },
                                                { invoiceStatus: 'Approved' },
                                            ],
                                        },
                                    ],
                                },
                            },
                            { $count: 'total' },
                        ],
                        uninsuredInProcessCount: [
                            {
                                $match: {
                                    $and: [
                                        { isInsured: false },
                                        { $and: searchFilters },
                                        {
                                            $or: [
                                                { invoiceStatus: 'Pending' },
                                                { invoiceStatus: 'InProcess' },
                                                { invoiceStatus: 'Approved' },
                                            ],
                                        },
                                    ],
                                },
                            },
                            { $count: 'total' },
                        ],
                        reimbursementInProcessCount: [
                            {
                                $match: {
                                    $and: [
                                        { isInsured: true },
                                        { $and: searchFilters },
                                        {
                                            $or: [
                                                { invoiceStatus: 'Pending' },
                                                { invoiceStatus: 'InProcess' },
                                                { invoiceStatus: 'Approved' },
                                            ],
                                        },
                                    ],
                                },
                            },
                            { $count: 'total' },
                        ],
                        totalInProcessAmount: [
                            {
                                $match: {
                                    $and: [
                                        { $and: searchFilters },
                                        {
                                            $or: [
                                                { invoiceStatus: 'Pending' },
                                                { invoiceStatus: 'InProcess' },
                                                { invoiceStatus: 'Approved' },
                                            ],
                                        },
                                    ],
                                },
                            },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],
                        uninsuredInProcessAmount: [
                            {
                                $match: {
                                    $and: [
                                        { isInsured: false },
                                        { $and: searchFilters },
                                        {
                                            $or: [
                                                { invoiceStatus: 'Pending' },
                                                { invoiceStatus: 'InProcess' },
                                                { invoiceStatus: 'Approved' },
                                            ],
                                        },
                                    ],
                                },
                            },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],
                        reimbursementInProcessAmount: [
                            {
                                $match: {
                                    $and: [
                                        { isInsured: true },
                                        { $and: searchFilters },
                                        {
                                            $or: [
                                                { invoiceStatus: 'Pending' },
                                                { invoiceStatus: 'InProcess' },
                                                { invoiceStatus: 'Approved' },
                                            ],
                                        },
                                    ],
                                },
                            },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],
                        totalFundedCount: [{ $match: { invoiceStatus: 'Disbursed', $and: searchFilters } }, { $count: 'total' }],
                        uninsuredFundedCount: [
                            { $match: { $and: [{ isInsured: false }, { invoiceStatus: 'Disbursed' }, { $and: searchFilters }] } },
                            { $count: 'total' },
                        ],
                        reimbursementFundedCount: [
                            { $match: { $and: [{ isInsured: true }, { invoiceStatus: 'Disbursed' }, { $and: searchFilters }] } },
                            { $count: 'total' },
                        ],
                        totalFundedAmount: [
                            { $match: { invoiceStatus: 'Disbursed', $and: searchFilters } },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],
                        uninsuredFundedAmount: [
                            { $match: { $and: [{ isInsured: false }, { invoiceStatus: 'Disbursed' }, { $and: searchFilters }] } },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],
                        reimbursementFundedAmount: [
                            { $match: { $and: [{ isInsured: true }, { invoiceStatus: 'Disbursed' }, { $and: searchFilters }] } },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],

                        totalRepaidCount: [{ $match: { invoiceStatus: 'Closed', $and: searchFilters } }, { $count: 'total' }],
                        uninsuredRepaidCount: [
                            { $match: { $and: [{ isInsured: false }, { invoiceStatus: 'Closed' }, { $and: searchFilters }] } },
                            { $count: 'total' },
                        ],
                        reimbursementRepaidCount: [
                            { $match: { $and: [{ isInsured: true }, { invoiceStatus: 'Closed' }, { $and: searchFilters }] } },
                            { $count: 'total' },
                        ],
                        totalRepaidAmount: [
                            { $match: { invoiceStatus: 'Closed', $and: searchFilters } },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],
                        uninsuredRepaidAmount: [
                            { $match: { $and: [{ isInsured: false }, { invoiceStatus: 'Closed' }, { $and: searchFilters }] } },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],
                        reimbursementRepaidAmount: [
                            { $match: { $and: [{ isInsured: true }, { invoiceStatus: 'Closed' }, { $and: searchFilters }] } },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],

                        totalRejectedCount: [{ $match: { invoiceStatus: 'Rejected', $and: searchFilters } }, { $count: 'total' }],
                        uninsuredRejectedCount: [
                            { $match: { $and: [{ isInsured: false }, { invoiceStatus: 'Rejected' }, { $and: searchFilters }] } },
                            { $count: 'total' },
                        ],
                        reimbursementRejectedCount: [
                            { $match: { $and: [{ isInsured: true }, { invoiceStatus: 'Rejected' }, { $and: searchFilters }] } },
                            { $count: 'total' },
                        ],
                        totalRejectedAmount: [
                            { $match: { invoiceStatus: 'Rejected', $and: searchFilters } },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],
                        uninsuredRejectedAmount: [
                            { $match: { $and: [{ isInsured: false }, { invoiceStatus: 'Rejected' }, { $and: searchFilters }] } },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],
                        reimbursementRejectedAmount: [
                            { $match: { $and: [{ isInsured: true }, { invoiceStatus: 'Rejected' }, { $and: searchFilters }] } },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],
                    },
                },
            ]);

            var totalCount: 0; var totalUninsuredCount: 0; var totalReimbursementCount: 0;
            var totalAmount: 0; var totalUninsuredAmount: 0; var totalReimbursementAmount: 0;

            var totalInProcessCount = 0; var uninsuredInProcessCount = 0; var reimbursementInProcessCount = 0;
            var totalInProcessAmount = 0; var uninsuredInProcessAmount = 0; var reimbursementInProcessAmount = 0;

            var totalFundedCount = 0; var uninsuredFundedCount = 0; var reimbursementFundedCount = 0;
            var totalFundedAmount = 0; var uninsuredFundedAmount = 0; var reimbursementFundedAmount = 0;

            var totalRepaidCount = 0; var uninsuredRepaidCount = 0; var reimbursementRepaidCount = 0;
            var totalRepaidAmount = 0; var uninsuredRepaidAmount = 0; var reimbursementRepaidAmount = 0;

            var totalRejectedCount = 0; var uninsuredRejectedCount = 0; var reimbursementRejectedCount = 0;
            var totalRejectedAmount = 0; var uninsuredRejectedAmount = 0; var reimbursementRejectedAmount = 0;

            if (dashboardData[0].totalUninsuredCount[0] != undefined) { totalUninsuredCount = dashboardData[0].totalUninsuredCount[0].total }
            if (dashboardData[0].totalReimbursementCount[0] != undefined) { totalReimbursementCount = dashboardData[0].totalReimbursementCount[0].total }
            if (dashboardData[0].totalCount[0] != undefined) { totalCount = dashboardData[0].totalCount[0].total }
            if (dashboardData[0].totalAmount[0] != undefined) { totalAmount = dashboardData[0].totalAmount[0].total }
            if (dashboardData[0].totalUninsuredAmount[0] != undefined) { totalUninsuredAmount = dashboardData[0].totalUninsuredAmount[0].total }
            if (dashboardData[0].totalReimbursementAmount[0] != undefined) { totalReimbursementAmount = dashboardData[0].totalReimbursementAmount[0].total }

            if (dashboardData[0].totalInProcessCount[0] != undefined) { totalInProcessCount = dashboardData[0].totalInProcessCount[0].total }
            if (dashboardData[0].uninsuredInProcessCount[0] != undefined) { uninsuredInProcessCount = dashboardData[0].uninsuredInProcessCount[0].total }
            if (dashboardData[0].reimbursementInProcessCount[0] != undefined) { reimbursementInProcessCount = dashboardData[0].reimbursementInProcessCount[0].total }

            if (dashboardData[0].totalInProcessAmount[0] != undefined) { totalInProcessAmount = dashboardData[0].totalInProcessAmount[0].total }
            if (dashboardData[0].uninsuredInProcessAmount[0] != undefined) { uninsuredInProcessAmount = dashboardData[0].uninsuredInProcessAmount[0].total }
            if (dashboardData[0].reimbursementInProcessAmount[0] != undefined) { reimbursementInProcessAmount = dashboardData[0].reimbursementInProcessAmount[0].total }

            if (dashboardData[0].totalFundedCount[0] != undefined) { totalFundedCount = dashboardData[0].totalFundedCount[0].total }
            if (dashboardData[0].uninsuredFundedCount[0] != undefined) { uninsuredFundedCount = dashboardData[0].uninsuredFundedCount[0].total }
            if (dashboardData[0].reimbursementFundedCount[0] != undefined) { reimbursementFundedCount = dashboardData[0].reimbursementFundedCount[0].total }

            if (dashboardData[0].totalFundedAmount[0] != undefined) { totalFundedAmount = dashboardData[0].totalFundedAmount[0].total }
            if (dashboardData[0].uninsuredFundedAmount[0] != undefined) { uninsuredFundedAmount = dashboardData[0].uninsuredFundedAmount[0].total }
            if (dashboardData[0].reimbursementFundedAmount[0] != undefined) { reimbursementFundedAmount = dashboardData[0].reimbursementFundedAmount[0].total }

            if (dashboardData[0].totalRepaidCount[0] != undefined) { totalRepaidCount = dashboardData[0].totalRepaidCount[0].total }
            if (dashboardData[0].uninsuredRepaidCount[0] != undefined) { uninsuredRepaidCount = dashboardData[0].uninsuredRepaidCount[0].total }
            if (dashboardData[0].reimbursementRepaidCount[0] != undefined) { reimbursementRepaidCount = dashboardData[0].reimbursementRepaidCount[0].total }

            if (dashboardData[0].totalRepaidAmount[0] != undefined) { totalRepaidAmount = dashboardData[0].totalRepaidAmount[0].total }
            if (dashboardData[0].uninsuredRepaidAmount[0] != undefined) { uninsuredRepaidAmount = dashboardData[0].uninsuredRepaidAmount[0].total }
            if (dashboardData[0].reimbursementRepaidAmount[0] != undefined) { reimbursementRepaidAmount = dashboardData[0].reimbursementRepaidAmount[0].total }

            if (dashboardData[0].totalRejectedCount[0] != undefined) { totalRejectedCount = dashboardData[0].totalRejectedCount[0].total }
            if (dashboardData[0].uninsuredRejectedCount[0] != undefined) { uninsuredRejectedCount = dashboardData[0].uninsuredRejectedCount[0].total }
            if (dashboardData[0].reimbursementRejectedCount[0] != undefined) { reimbursementRejectedCount = dashboardData[0].reimbursementRejectedCount[0].total }

            if (dashboardData[0].totalRejectedAmount[0] != undefined) { totalRejectedAmount = dashboardData[0].totalRejectedAmount[0].total }
            if (dashboardData[0].uninsuredRejectedAmount[0] != undefined) { uninsuredRejectedAmount = dashboardData[0].uninsuredRejectedAmount[0].total }
            if (dashboardData[0].reimbursementRejectedAmount[0] != undefined) { reimbursementRejectedAmount = dashboardData[0].reimbursementRejectedAmount[0].total }

            //graphs
            var date = moment.utc();
            var currentMonth = date.month() + 1;
            var currentMonthYear = date.year();
            var previousMonth1 = date.subtract(1, 'month').month() + 1;
            var previousMonthYear1 = date.year();
            var previousMonth2 = date.subtract(1, 'months').month() + 1;
            var previousMonthYear2 = date.year();
            var previousMonth3 = date.subtract(1, 'months').month() + 1;
            var previousMonthYear3 = date.year();
            var previousMonth4 = date.subtract(1, 'months').month() + 1;
            var previousMonthYear4 = date.year();
            var previousMonth5 = date.subtract(1, 'months').month() + 1;
            var previousMonthYear5 = date.year();

            //Amount of Uploaded Invoices(Monthly)

            var invoiceAmount1 = 0; var invoiceAmount2 = 0; var invoiceAmount3 = 0; var invoiceAmount4 = 0; var invoiceAmount5 = 0; var invoiceAmount6 = 0;

            var invoiceAmountData = await this.patientLoanModel.aggregate([
                {
                    $facet: {
                        invoiceAmount1: [
                            { $project: { UWName: 1, loanAmount: 1, month: { $month: '$createdAt' } } },
                            { $match: { month: currentMonth, UWName: currentUser.name } },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],
                        invoiceAmount2: [
                            { $project: { UWName: 1, loanAmount: 1, month: { $month: '$createdAt' } } },
                            { $match: { month: previousMonth1, UWName: currentUser.name } },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],
                        invoiceAmount3: [
                            { $project: { UWName: 1, loanAmount: 1, month: { $month: '$createdAt' } } },
                            { $match: { month: previousMonth2, UWName: currentUser.name } },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],
                        invoiceAmount4: [
                            { $project: { UWName: 1, loanAmount: 1, month: { $month: '$createdAt' } } },
                            { $match: { month: previousMonth3, UWName: currentUser.name } },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],
                        invoiceAmount5: [
                            { $project: { UWName: 1, loanAmount: 1, month: { $month: '$createdAt' } } },
                            { $match: { month: previousMonth4, UWName: currentUser.name } },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],
                        invoiceAmount6: [
                            { $project: { UWName: 1, loanAmount: 1, month: { $month: '$createdAt' } } },
                            { $match: { month: previousMonth5, UWName: currentUser.name } },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],
                    },
                },
            ]);
            if (invoiceAmountData[0].invoiceAmount1[0] != undefined) { invoiceAmount1 = invoiceAmountData[0].invoiceAmount1[0].total }
            if (invoiceAmountData[0].invoiceAmount2[0] != undefined) { invoiceAmount2 = invoiceAmountData[0].invoiceAmount2[0].total }
            if (invoiceAmountData[0].invoiceAmount3[0] != undefined) { invoiceAmount3 = invoiceAmountData[0].invoiceAmount3[0].total }
            if (invoiceAmountData[0].invoiceAmount4[0] != undefined) { invoiceAmount4 = invoiceAmountData[0].invoiceAmount4[0].total }
            if (invoiceAmountData[0].invoiceAmount5[0] != undefined) { invoiceAmount4 = invoiceAmountData[0].invoiceAmount5[0].total }
            if (invoiceAmountData[0].invoiceAmount6[0] != undefined) { invoiceAmount5 = invoiceAmountData[0].invoiceAmount6[0].total }

            var invoiceAmountGraph = [
                [invoiceAmount1, currentMonth, currentMonthYear],
                [invoiceAmount2, previousMonth1, previousMonthYear1],
                [invoiceAmount3, previousMonth2, previousMonthYear2],
                [invoiceAmount4, previousMonth3, previousMonthYear3],
                [invoiceAmount5, previousMonth4, previousMonthYear4],
                [invoiceAmount6, previousMonth5, previousMonthYear5],
            ];

            //Count of Uploaded Invoices(Monthly)

            var invoiceCount1 = 0; var invoiceCount2 = 0; var invoiceCount3 = 0; var invoiceCount4 = 0; var invoiceCount5 = 0; var invoiceCount6 = 0;

            var invoiceCountData = await this.patientLoanModel.aggregate([
                {
                    $facet: {
                        invoiceCount1: [
                            { $project: { UWName: 1, loanCount: 1, month: { $month: '$createdAt' } } },
                            { $match: { month: currentMonth, UWName: currentUser.name } },
                            { $count: 'total' },
                        ],
                        invoiceCount2: [
                            { $project: { UWName: 1, loanCount: 1, month: { $month: '$createdAt' } } },
                            { $match: { month: previousMonth1, UWName: currentUser.name } },
                            { $count: 'total' },
                        ],
                        invoiceCount3: [
                            { $project: { UWName: 1, loanCount: 1, month: { $month: '$createdAt' } } },
                            { $match: { month: previousMonth2, UWName: currentUser.name } },
                            { $count: 'total' },
                        ],
                        invoiceCount4: [
                            { $project: { UWName: 1, loanCount: 1, month: { $month: '$createdAt' } } },
                            { $match: { month: previousMonth3, UWName: currentUser.name } },
                            { $count: 'total' },
                        ],
                        invoiceCount5: [
                            { $project: { UWName: 1, loanCount: 1, month: { $month: '$createdAt' } } },
                            { $match: { month: previousMonth4, UWName: currentUser.name } },
                            { $count: 'total' },
                        ],
                        invoiceCount6: [
                            { $project: { UWName: 1, loanCount: 1, month: { $month: '$createdAt' } } },
                            { $match: { month: previousMonth5, UWName: currentUser.name } },
                            { $count: 'total' },
                        ],
                    },
                },
            ]);
            if (invoiceCountData[0].invoiceCount1[0] != undefined) { invoiceCount1 = invoiceCountData[0].invoiceCount1[0].total }
            if (invoiceCountData[0].invoiceCount2[0] != undefined) { invoiceCount2 = invoiceCountData[0].invoiceCount2[0].total }
            if (invoiceCountData[0].invoiceCount3[0] != undefined) { invoiceCount3 = invoiceCountData[0].invoiceCount3[0].total }
            if (invoiceCountData[0].invoiceCount4[0] != undefined) { invoiceCount4 = invoiceCountData[0].invoiceCount4[0].total }
            if (invoiceCountData[0].invoiceCount5[0] != undefined) { invoiceCount4 = invoiceCountData[0].invoiceCount5[0].total }
            if (invoiceCountData[0].invoiceCount6[0] != undefined) { invoiceCount5 = invoiceCountData[0].invoiceCount6[0].total }

            var invoiceCountGraph = [
                [invoiceCount1, currentMonth, currentMonthYear],
                [invoiceCount2, previousMonth1, previousMonthYear1],
                [invoiceCount3, previousMonth2, previousMonthYear2],
                [invoiceCount4, previousMonth3, previousMonthYear3],
                [invoiceCount5, previousMonth4, previousMonthYear4],
                [invoiceCount6, previousMonth5, previousMonthYear5],
            ];

            //Amount of Reimbursement Invoices(Monthly)

            var InProcessAmount1 = 0; var InProcessAmount2 = 0; var InProcessAmount3 = 0; var InProcessAmount4 = 0; var InProcessAmount5 = 0; var InProcessAmount6 = 0;
            var fundedAmount1 = 0; var fundedAmount2 = 0; var fundedAmount3 = 0; var fundedAmount4 = 0; var fundedAmount5 = 0; var fundedAmount6 = 0;
            var repaidAmount1 = 0; var repaidAmount2 = 0; var repaidAmount3 = 0; var repaidAmount4 = 0; var repaidAmount5 = 0; var repaidAmount6 = 0;
            var rejectedAmount1 = 0; var rejectedAmount2 = 0; var rejectedAmount3 = 0; var rejectedAmount4 = 0; var rejectedAmount5 = 0; var rejectedAmount6 = 0;

            var invoiceAmountData = await this.patientLoanModel.aggregate([
                {
                    $facet: {
                        InProcessAmount1: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    isInsured: 1,
                                    UWName: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: currentMonth,
                                    UWName: currentUser.name,
                                    isInsured: false,
                                    $or: [
                                        { invoiceStatus: 'InProcess' }, { invoiceStatus: 'Pending' }
                                    ]
                                },
                            },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],
                        InProcessAmount2: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth1,
                                    UWName: currentUser.name,
                                    isInsured: false,
                                    $or: [
                                        { invoiceStatus: 'InProcess' }, { invoiceStatus: 'Pending' }
                                    ]
                                },
                            },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],
                        InProcessAmount3: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth2,
                                    UWName: currentUser.name,
                                    isInsured: false,
                                    $or: [
                                        { invoiceStatus: 'InProcess' }, { invoiceStatus: 'Pending' }
                                    ]
                                },
                            },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],
                        InProcessAmount4: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth3,
                                    UWName: currentUser.name,
                                    isInsured: false,
                                    $or: [
                                        { invoiceStatus: 'InProcess' }, { invoiceStatus: 'Pending' }
                                    ]
                                },
                            },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],
                        InProcessAmount5: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth4,
                                    UWName: currentUser.name,
                                    isInsured: false,
                                    $or: [
                                        { invoiceStatus: 'InProcess' }, { invoiceStatus: 'Pending' }
                                    ]
                                },
                            },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],
                        InProcessAmount6: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth5,
                                    UWName: currentUser.name,
                                    isInsured: false,
                                    $or: [
                                        { invoiceStatus: 'InProcess' }, { invoiceStatus: 'Pending' }
                                    ]
                                },
                            },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],

                        fundedAmount1: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: currentMonth,
                                    UWName: currentUser.name,
                                    isInsured: false,
                                    invoiceStatus: 'Disbursed',
                                },
                            },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],
                        fundedAmount2: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth1,
                                    UWName: currentUser.name,
                                    isInsured: false,
                                    invoiceStatus: 'Disbursed',
                                },
                            },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],
                        fundedAmount3: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth2,
                                    UWName: currentUser.name,
                                    isInsured: false,
                                    invoiceStatus: 'Disbursed',
                                },
                            },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],
                        fundedAmount4: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth3,
                                    UWName: currentUser.name,
                                    isInsured: false,
                                    invoiceStatus: 'Disbursed',
                                },
                            },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],
                        fundedAmount5: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth4,
                                    UWName: currentUser.name,
                                    isInsured: false,
                                    invoiceStatus: 'Disbursed',
                                },
                            },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],
                        fundedAmount6: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth5,
                                    UWName: currentUser.name,
                                    isInsured: false,
                                    invoiceStatus: 'Disbursed',
                                },
                            },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],

                        repaidAmount1: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: currentMonth,
                                    UWName: currentUser.name,
                                    isInsured: false,
                                    invoiceStatus: 'Closed',
                                },
                            },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],
                        repaidAmount2: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth1,
                                    UWName: currentUser.name,
                                    isInsured: false,
                                    invoiceStatus: 'Closed',
                                },
                            },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],
                        repaidAmount3: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth2,
                                    UWName: currentUser.name,
                                    isInsured: false,
                                    invoiceStatus: 'Closed',
                                },
                            },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],
                        repaidAmount4: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth3,
                                    UWName: currentUser.name,
                                    isInsured: false,
                                    invoiceStatus: 'Closed',
                                },
                            },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],
                        repaidAmount5: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth4,
                                    UWName: currentUser.name,
                                    isInsured: false,
                                    invoiceStatus: 'Closed',
                                },
                            },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],
                        repaidAmount6: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth5,
                                    UWName: currentUser.name,
                                    isInsured: false,
                                    invoiceStatus: 'Closed',
                                },
                            },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],

                        rejectedAmount1: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: currentMonth,
                                    UWName: currentUser.name,
                                    isInsured: false,
                                    invoiceStatus: 'Rejected',
                                },
                            },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],
                        rejectedAmount2: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth1,
                                    UWName: currentUser.name,
                                    isInsured: false,
                                    invoiceStatus: 'Rejected',
                                },
                            },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],
                        rejectedAmount3: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth2,
                                    UWName: currentUser.name,
                                    isInsured: false,
                                    invoiceStatus: 'Rejected',
                                },
                            },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],
                        rejectedAmount4: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth3,
                                    UWName: currentUser.name,
                                    isInsured: false,
                                    invoiceStatus: 'Rejected',
                                },
                            },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],
                        rejectedAmount5: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth4,
                                    UWName: currentUser.name,
                                    isInsured: false,
                                    invoiceStatus: 'Rejected',
                                },
                            },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],
                        rejectedAmount6: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth5,
                                    UWName: currentUser.name,
                                    isInsured: false,
                                    invoiceStatus: 'Rejected',
                                },
                            },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],
                    },
                },
            ]);
            if (invoiceAmountData[0].InProcessAmount1[0] != undefined) { InProcessAmount1 = invoiceAmountData[0].InProcessAmount1[0].total }
            if (invoiceAmountData[0].InProcessAmount2[0] != undefined) { InProcessAmount2 = invoiceAmountData[0].InProcessAmount2[0].total }
            if (invoiceAmountData[0].InProcessAmount3[0] != undefined) { InProcessAmount3 = invoiceAmountData[0].InProcessAmount3[0].total }
            if (invoiceAmountData[0].InProcessAmount4[0] != undefined) { InProcessAmount4 = invoiceAmountData[0].InProcessAmount4[0].total }
            if (invoiceAmountData[0].InProcessAmount5[0] != undefined) { InProcessAmount4 = invoiceAmountData[0].InProcessAmount5[0].total }
            if (invoiceAmountData[0].InProcessAmount6[0] != undefined) { InProcessAmount5 = invoiceAmountData[0].InProcessAmount6[0].total }

            if (invoiceAmountData[0].fundedAmount1[0] != undefined) { fundedAmount1 = invoiceAmountData[0].fundedAmount1[0].total }
            if (invoiceAmountData[0].fundedAmount2[0] != undefined) { fundedAmount2 = invoiceAmountData[0].fundedAmount2[0].total }
            if (invoiceAmountData[0].fundedAmount3[0] != undefined) { fundedAmount3 = invoiceAmountData[0].fundedAmount3[0].total }
            if (invoiceAmountData[0].fundedAmount4[0] != undefined) { fundedAmount4 = invoiceAmountData[0].fundedAmount4[0].total }
            if (invoiceAmountData[0].fundedAmount5[0] != undefined) { fundedAmount4 = invoiceAmountData[0].fundedAmount5[0].total }
            if (invoiceAmountData[0].fundedAmount6[0] != undefined) { fundedAmount5 = invoiceAmountData[0].fundedAmount6[0].total }

            if (invoiceAmountData[0].repaidAmount1[0] != undefined) { repaidAmount1 = invoiceAmountData[0].repaidAmount1[0].total }
            if (invoiceAmountData[0].repaidAmount2[0] != undefined) { repaidAmount2 = invoiceAmountData[0].repaidAmount2[0].total }
            if (invoiceAmountData[0].repaidAmount3[0] != undefined) { repaidAmount3 = invoiceAmountData[0].repaidAmount3[0].total }
            if (invoiceAmountData[0].repaidAmount4[0] != undefined) { repaidAmount4 = invoiceAmountData[0].repaidAmount4[0].total }
            if (invoiceAmountData[0].repaidAmount5[0] != undefined) { repaidAmount4 = invoiceAmountData[0].repaidAmount5[0].total }
            if (invoiceAmountData[0].repaidAmount6[0] != undefined) { repaidAmount5 = invoiceAmountData[0].repaidAmount6[0].total }

            if (invoiceAmountData[0].rejectedAmount1[0] != undefined) { rejectedAmount1 = invoiceAmountData[0].rejectedAmount1[0].total }
            if (invoiceAmountData[0].rejectedAmount2[0] != undefined) { rejectedAmount2 = invoiceAmountData[0].rejectedAmount2[0].total }
            if (invoiceAmountData[0].rejectedAmount3[0] != undefined) { rejectedAmount3 = invoiceAmountData[0].rejectedAmount3[0].total }
            if (invoiceAmountData[0].rejectedAmount4[0] != undefined) { rejectedAmount4 = invoiceAmountData[0].rejectedAmount4[0].total }
            if (invoiceAmountData[0].rejectedAmount5[0] != undefined) { rejectedAmount4 = invoiceAmountData[0].rejectedAmount5[0].total }
            if (invoiceAmountData[0].rejectedAmount6[0] != undefined) { rejectedAmount5 = invoiceAmountData[0].rejectedAmount6[0].total }

            var InProcessAmountGraph = [
                [InProcessAmount1, currentMonth, currentMonthYear],
                [InProcessAmount2, previousMonth1, previousMonthYear1],
                [InProcessAmount3, previousMonth2, previousMonthYear2],
                [InProcessAmount4, previousMonth3, previousMonthYear3],
                [InProcessAmount5, previousMonth4, previousMonthYear4],
                [InProcessAmount6, previousMonth5, previousMonthYear5],
            ];
            var fundedAmountGraph = [
                [fundedAmount1, currentMonth, currentMonthYear],
                [fundedAmount2, previousMonth1, previousMonthYear1],
                [fundedAmount3, previousMonth2, previousMonthYear2],
                [fundedAmount4, previousMonth3, previousMonthYear3],
                [fundedAmount5, previousMonth4, previousMonthYear4],
                [fundedAmount6, previousMonth5, previousMonthYear5],
            ];
            var repaidAmountGraph = [
                [repaidAmount1, currentMonth, currentMonthYear],
                [repaidAmount2, previousMonth1, previousMonthYear1],
                [repaidAmount3, previousMonth2, previousMonthYear2],
                [repaidAmount4, previousMonth3, previousMonthYear3],
                [repaidAmount5, previousMonth4, previousMonthYear4],
                [repaidAmount6, previousMonth5, previousMonthYear5],
            ];
            var rejectedAmountGraph = [
                [rejectedAmount1, currentMonth, currentMonthYear],
                [rejectedAmount2, previousMonth1, previousMonthYear1],
                [rejectedAmount3, previousMonth2, previousMonthYear2],
                [rejectedAmount4, previousMonth3, previousMonthYear3],
                [rejectedAmount5, previousMonth4, previousMonthYear4],
                [rejectedAmount6, previousMonth5, previousMonthYear5],
            ];

            //Count of Reimbursement Invoices(Monthly)

            var InProcessCount1 = 0; var InProcessCount2 = 0; var InProcessCount3 = 0; var InProcessCount4 = 0; var InProcessCount5 = 0; var InProcessCount6 = 0;
            var fundedCount1 = 0; var fundedCount2 = 0; var fundedCount3 = 0; var fundedCount4 = 0; var fundedCount5 = 0; var fundedCount6 = 0;
            var repaidCount1 = 0; var repaidCount2 = 0; var repaidCount3 = 0; var repaidCount4 = 0; var repaidCount5 = 0; var repaidCount6 = 0;
            var rejectedCount1 = 0; var rejectedCount2 = 0; var rejectedCount3 = 0; var rejectedCount4 = 0; var rejectedCount5 = 0; var rejectedCount6 = 0;

            var invoiceCountData = await this.patientLoanModel.aggregate([
                {
                    $facet: {
                        InProcessCount1: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: currentMonth,
                                    UWName: currentUser.name,
                                    isInsured: false,
                                    $or: [
                                        { invoiceStatus: 'InProcess' }, { invoiceStatus: 'Pending' }
                                    ]
                                },
                            },
                            { $count: 'total' },
                        ],
                        InProcessCount2: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth1,
                                    UWName: currentUser.name,
                                    isInsured: false,
                                    $or: [
                                        { invoiceStatus: 'InProcess' }, { invoiceStatus: 'Pending' }
                                    ]
                                },
                            },
                            { $count: 'total' },
                        ],
                        InProcessCount3: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth2,
                                    UWName: currentUser.name,
                                    isInsured: false,
                                    $or: [
                                        { invoiceStatus: 'InProcess' }, { invoiceStatus: 'Pending' }
                                    ]
                                },
                            },
                            { $count: 'total' },
                        ],
                        InProcessCount4: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth3,
                                    UWName: currentUser.name,
                                    isInsured: false,
                                    $or: [
                                        { invoiceStatus: 'InProcess' }, { invoiceStatus: 'Pending' }
                                    ]
                                },
                            },
                            { $count: 'total' },
                        ],
                        InProcessCount5: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth4,
                                    UWName: currentUser.name,
                                    isInsured: false,
                                    $or: [
                                        { invoiceStatus: 'InProcess' }, { invoiceStatus: 'Pending' }
                                    ]
                                },
                            },
                            { $count: 'total' },
                        ],
                        InProcessCount6: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth5,
                                    UWName: currentUser.name,
                                    isInsured: false,
                                    $or: [
                                        { invoiceStatus: 'InProcess' }, { invoiceStatus: 'Pending' }
                                    ]
                                },
                            },
                            { $count: 'total' },
                        ],

                        fundedCount1: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: currentMonth,
                                    UWName: currentUser.name,
                                    isInsured: false,
                                    invoiceStatus: 'Disbursed',
                                },
                            },
                            { $count: 'total' },
                        ],
                        fundedCount2: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth1,
                                    UWName: currentUser.name,
                                    isInsured: false,
                                    invoiceStatus: 'Disbursed',
                                },
                            },
                            { $count: 'total' },
                        ],
                        fundedCount3: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth2,
                                    UWName: currentUser.name,
                                    isInsured: false,
                                    invoiceStatus: 'Disbursed',
                                },
                            },
                            { $count: 'total' },
                        ],
                        fundedCount4: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth3,
                                    UWName: currentUser.name,
                                    isInsured: false,
                                    invoiceStatus: 'Disbursed',
                                },
                            },
                            { $count: 'total' },
                        ],
                        fundedCount5: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth4,
                                    UWName: currentUser.name,
                                    isInsured: false,
                                    invoiceStatus: 'Disbursed',
                                },
                            },
                            { $count: 'total' },
                        ],
                        fundedCount6: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth5,
                                    UWName: currentUser.name,
                                    isInsured: false,
                                    invoiceStatus: 'Disbursed',
                                },
                            },
                            { $count: 'total' },
                        ],

                        repaidCount1: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: currentMonth,
                                    UWName: currentUser.name,
                                    isInsured: false,
                                    invoiceStatus: 'Closed',
                                },
                            },
                            { $count: 'total' },
                        ],
                        repaidCount2: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth1,
                                    UWName: currentUser.name,
                                    isInsured: false,
                                    invoiceStatus: 'Closed',
                                },
                            },
                            { $count: 'total' },
                        ],
                        repaidCount3: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth2,
                                    UWName: currentUser.name,
                                    isInsured: false,
                                    invoiceStatus: 'Closed',
                                },
                            },
                            { $count: 'total' },
                        ],
                        repaidCount4: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth3,
                                    UWName: currentUser.name,
                                    isInsured: false,
                                    invoiceStatus: 'Closed',
                                },
                            },
                            { $count: 'total' },
                        ],
                        repaidCount5: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth4,
                                    UWName: currentUser.name,
                                    isInsured: false,
                                    invoiceStatus: 'Closed',
                                },
                            },
                            { $count: 'total' },
                        ],
                        repaidCount6: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth5,
                                    UWName: currentUser.name,
                                    isInsured: false,
                                    invoiceStatus: 'Closed',
                                },
                            },
                            { $count: 'total' },
                        ],

                        rejectedCount1: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: currentMonth,
                                    UWName: currentUser.name,
                                    isInsured: false,
                                    invoiceStatus: 'Rejected',
                                },
                            },
                            { $count: 'total' },
                        ],
                        rejectedCount2: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth1,
                                    UWName: currentUser.name,
                                    isInsured: false,
                                    invoiceStatus: 'Rejected',
                                },
                            },
                            { $count: 'total' },
                        ],
                        rejectedCount3: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth2,
                                    UWName: currentUser.name,
                                    isInsured: false,
                                    invoiceStatus: 'Rejected',
                                },
                            },
                            { $count: 'total' },
                        ],
                        rejectedCount4: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth3,
                                    UWName: currentUser.name,
                                    isInsured: false,
                                    invoiceStatus: 'Rejected',
                                },
                            },
                            { $count: 'total' },
                        ],
                        rejectedCount5: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth4,
                                    UWName: currentUser.name,
                                    isInsured: false,
                                    invoiceStatus: 'Rejected',
                                },
                            },
                            { $count: 'total' },
                        ],
                        rejectedCount6: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth5,
                                    UWName: currentUser.name,
                                    isInsured: false,
                                    invoiceStatus: 'Rejected',
                                },
                            },
                            { $count: 'total' },
                        ],
                    },
                },
            ]);
            if (invoiceCountData[0].InProcessCount1[0] != undefined) { InProcessCount1 = invoiceCountData[0].InProcessCount1[0].total }
            if (invoiceCountData[0].InProcessCount2[0] != undefined) { InProcessCount2 = invoiceCountData[0].InProcessCount2[0].total }
            if (invoiceCountData[0].InProcessCount3[0] != undefined) { InProcessCount3 = invoiceCountData[0].InProcessCount3[0].total }
            if (invoiceCountData[0].InProcessCount4[0] != undefined) { InProcessCount4 = invoiceCountData[0].InProcessCount4[0].total }
            if (invoiceCountData[0].InProcessCount5[0] != undefined) { InProcessCount4 = invoiceCountData[0].InProcessCount5[0].total }
            if (invoiceCountData[0].InProcessCount6[0] != undefined) { InProcessCount5 = invoiceCountData[0].InProcessCount6[0].total }

            if (invoiceCountData[0].fundedCount1[0] != undefined) { fundedCount1 = invoiceCountData[0].fundedCount1[0].total }
            if (invoiceCountData[0].fundedCount2[0] != undefined) { fundedCount2 = invoiceCountData[0].fundedCount2[0].total }
            if (invoiceCountData[0].fundedCount3[0] != undefined) { fundedCount3 = invoiceCountData[0].fundedCount3[0].total }
            if (invoiceCountData[0].fundedCount4[0] != undefined) { fundedCount4 = invoiceCountData[0].fundedCount4[0].total }
            if (invoiceCountData[0].fundedCount5[0] != undefined) { fundedCount4 = invoiceCountData[0].fundedCount5[0].total }
            if (invoiceCountData[0].fundedCount6[0] != undefined) { fundedCount5 = invoiceCountData[0].fundedCount6[0].total }

            if (invoiceCountData[0].repaidCount1[0] != undefined) { repaidCount1 = invoiceCountData[0].repaidCount1[0].total }
            if (invoiceCountData[0].repaidCount2[0] != undefined) { repaidCount2 = invoiceCountData[0].repaidCount2[0].total }
            if (invoiceCountData[0].repaidCount3[0] != undefined) { repaidCount3 = invoiceCountData[0].repaidCount3[0].total }
            if (invoiceCountData[0].repaidCount4[0] != undefined) { repaidCount4 = invoiceCountData[0].repaidCount4[0].total }
            if (invoiceCountData[0].repaidCount5[0] != undefined) { repaidCount4 = invoiceCountData[0].repaidCount5[0].total }
            if (invoiceCountData[0].repaidCount6[0] != undefined) { repaidCount5 = invoiceCountData[0].repaidCount6[0].total }

            if (invoiceCountData[0].rejectedCount1[0] != undefined) { rejectedCount1 = invoiceCountData[0].rejectedCount1[0].total }
            if (invoiceCountData[0].rejectedCount2[0] != undefined) { rejectedCount2 = invoiceCountData[0].rejectedCount2[0].total }
            if (invoiceCountData[0].rejectedCount3[0] != undefined) { rejectedCount3 = invoiceCountData[0].rejectedCount3[0].total }
            if (invoiceCountData[0].rejectedCount4[0] != undefined) { rejectedCount4 = invoiceCountData[0].rejectedCount4[0].total }
            if (invoiceCountData[0].rejectedCount5[0] != undefined) { rejectedCount4 = invoiceCountData[0].rejectedCount5[0].total }
            if (invoiceCountData[0].rejectedCount6[0] != undefined) { rejectedCount5 = invoiceCountData[0].rejectedCount6[0].total }

            var InProcessCountGraph = [
                [InProcessCount1, currentMonth, currentMonthYear],
                [InProcessCount2, previousMonth1, previousMonthYear1],
                [InProcessCount3, previousMonth2, previousMonthYear2],
                [InProcessCount4, previousMonth3, previousMonthYear3],
                [InProcessCount5, previousMonth4, previousMonthYear4],
                [InProcessCount6, previousMonth5, previousMonthYear5],
            ];
            var fundedCountGraph = [
                [fundedCount1, currentMonth, currentMonthYear],
                [fundedCount2, previousMonth1, previousMonthYear1],
                [fundedCount3, previousMonth2, previousMonthYear2],
                [fundedCount4, previousMonth3, previousMonthYear3],
                [fundedCount5, previousMonth4, previousMonthYear4],
                [fundedCount6, previousMonth5, previousMonthYear5],
            ];
            var repaidCountGraph = [
                [repaidCount1, currentMonth, currentMonthYear],
                [repaidCount2, previousMonth1, previousMonthYear1],
                [repaidCount3, previousMonth2, previousMonthYear2],
                [repaidCount4, previousMonth3, previousMonthYear3],
                [repaidCount5, previousMonth4, previousMonthYear4],
                [repaidCount6, previousMonth5, previousMonthYear5],
            ];
            var rejectedCountGraph = [
                [rejectedCount1, currentMonth, currentMonthYear],
                [rejectedCount2, previousMonth1, previousMonthYear1],
                [rejectedCount3, previousMonth2, previousMonthYear2],
                [rejectedCount4, previousMonth3, previousMonthYear3],
                [rejectedCount5, previousMonth4, previousMonthYear4],
                [rejectedCount6, previousMonth5, previousMonthYear5],
            ];

            //Amount of Uninsured Invoices(Monthly)
            var InProcessAmount1 = 0; var InProcessAmount2 = 0; var InProcessAmount3 = 0; var InProcessAmount4 = 0; var InProcessAmount5 = 0; var InProcessAmount6 = 0;
            var fundedAmount1 = 0; var fundedAmount2 = 0; var fundedAmount3 = 0; var fundedAmount4 = 0; var fundedAmount5 = 0; var fundedAmount6 = 0;
            var repaidAmount1 = 0; var repaidAmount2 = 0; var repaidAmount3 = 0; var repaidAmount4 = 0; var repaidAmount5 = 0; var repaidAmount6 = 0;
            var rejectedAmount1 = 0; var rejectedAmount2 = 0; var rejectedAmount3 = 0; var rejectedAmount4 = 0; var rejectedAmount5 = 0; var rejectedAmount6 = 0;

            var invoiceAmountData = await this.patientLoanModel.aggregate([
                {
                    $facet: {
                        InProcessAmount1: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: currentMonth,
                                    UWName: currentUser.name,
                                    isInsured: true,
                                    $or: [
                                        { invoiceStatus: 'InProcess' }, { invoiceStatus: 'Pending' }
                                    ]
                                },
                            },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],
                        InProcessAmount2: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth1,
                                    UWName: currentUser.name,
                                    isInsured: true,
                                    $or: [
                                        { invoiceStatus: 'InProcess' }, { invoiceStatus: 'Pending' }
                                    ]
                                },
                            },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],
                        InProcessAmount3: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth2,
                                    UWName: currentUser.name,
                                    isInsured: true,
                                    $or: [
                                        { invoiceStatus: 'InProcess' }, { invoiceStatus: 'Pending' }
                                    ]
                                },
                            },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],
                        InProcessAmount4: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth3,
                                    UWName: currentUser.name,
                                    isInsured: true,
                                    $or: [
                                        { invoiceStatus: 'InProcess' }, { invoiceStatus: 'Pending' }
                                    ]
                                },
                            },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],
                        InProcessAmount5: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth4,
                                    UWName: currentUser.name,
                                    isInsured: true,
                                    $or: [
                                        { invoiceStatus: 'InProcess' }, { invoiceStatus: 'Pending' }
                                    ]
                                },
                            },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],
                        InProcessAmount6: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth5,
                                    UWName: currentUser.name,
                                    isInsured: true,
                                    $or: [
                                        { invoiceStatus: 'InProcess' }, { invoiceStatus: 'Pending' }
                                    ]
                                },
                            },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],

                        fundedAmount1: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: currentMonth,
                                    UWName: currentUser.name,
                                    isInsured: true,
                                    invoiceStatus: 'Disbursed',
                                },
                            },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],
                        fundedAmount2: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth1,
                                    UWName: currentUser.name,
                                    isInsured: true,
                                    invoiceStatus: 'Disbursed',
                                },
                            },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],
                        fundedAmount3: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth2,
                                    UWName: currentUser.name,
                                    isInsured: true,
                                    invoiceStatus: 'Disbursed',
                                },
                            },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],
                        fundedAmount4: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth3,
                                    UWName: currentUser.name,
                                    isInsured: true,
                                    invoiceStatus: 'Disbursed',
                                },
                            },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],
                        fundedAmount5: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth4,
                                    UWName: currentUser.name,
                                    isInsured: true,
                                    invoiceStatus: 'Disbursed',
                                },
                            },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],
                        fundedAmount6: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth5,
                                    UWName: currentUser.name,
                                    isInsured: true,
                                    invoiceStatus: 'Disbursed',
                                },
                            },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],

                        repaidAmount1: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: currentMonth,
                                    UWName: currentUser.name,
                                    isInsured: true,
                                    invoiceStatus: 'Closed',
                                },
                            },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],
                        repaidAmount2: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth1,
                                    UWName: currentUser.name,
                                    isInsured: true,
                                    invoiceStatus: 'Closed',
                                },
                            },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],
                        repaidAmount3: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth2,
                                    UWName: currentUser.name,
                                    isInsured: true,
                                    invoiceStatus: 'Closed',
                                },
                            },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],
                        repaidAmount4: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth3,
                                    UWName: currentUser.name,
                                    isInsured: true,
                                    invoiceStatus: 'Closed',
                                },
                            },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],
                        repaidAmount5: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth4,
                                    UWName: currentUser.name,
                                    isInsured: true,
                                    invoiceStatus: 'Closed',
                                },
                            },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],
                        repaidAmount6: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth5,
                                    UWName: currentUser.name,
                                    isInsured: true,
                                    invoiceStatus: 'Closed',
                                },
                            },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],

                        rejectedAmount1: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: currentMonth,
                                    UWName: currentUser.name,
                                    isInsured: true,
                                    invoiceStatus: 'Rejected',
                                },
                            },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],
                        rejectedAmount2: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth1,
                                    UWName: currentUser.name,
                                    isInsured: true,
                                    invoiceStatus: 'Rejected',
                                },
                            },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],
                        rejectedAmount3: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth2,
                                    UWName: currentUser.name,
                                    isInsured: true,
                                    invoiceStatus: 'Rejected',
                                },
                            },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],
                        rejectedAmount4: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth3,
                                    UWName: currentUser.name,
                                    isInsured: true,
                                    invoiceStatus: 'Rejected',
                                },
                            },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],
                        rejectedAmount5: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth4,
                                    UWName: currentUser.name,
                                    isInsured: true,
                                    invoiceStatus: 'Rejected',
                                },
                            },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],
                        rejectedAmount6: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth5,
                                    UWName: currentUser.name,
                                    isInsured: true,
                                    invoiceStatus: 'Rejected',
                                },
                            },
                            { $group: { _id: '$_v', total: { $sum: '$loanAmount' } } },
                        ],
                    },
                },
            ]);
            if (invoiceAmountData[0].InProcessAmount1[0] != undefined) { InProcessAmount1 = invoiceAmountData[0].InProcessAmount1[0].total }
            if (invoiceAmountData[0].InProcessAmount2[0] != undefined) { InProcessAmount2 = invoiceAmountData[0].InProcessAmount2[0].total }
            if (invoiceAmountData[0].InProcessAmount3[0] != undefined) { InProcessAmount3 = invoiceAmountData[0].InProcessAmount3[0].total }
            if (invoiceAmountData[0].InProcessAmount4[0] != undefined) { InProcessAmount4 = invoiceAmountData[0].InProcessAmount4[0].total }
            if (invoiceAmountData[0].InProcessAmount5[0] != undefined) { InProcessAmount4 = invoiceAmountData[0].InProcessAmount5[0].total }
            if (invoiceAmountData[0].InProcessAmount6[0] != undefined) { InProcessAmount5 = invoiceAmountData[0].InProcessAmount6[0].total }

            if (invoiceAmountData[0].fundedAmount1[0] != undefined) { fundedAmount1 = invoiceAmountData[0].fundedAmount1[0].total }
            if (invoiceAmountData[0].fundedAmount2[0] != undefined) { fundedAmount2 = invoiceAmountData[0].fundedAmount2[0].total }
            if (invoiceAmountData[0].fundedAmount3[0] != undefined) { fundedAmount3 = invoiceAmountData[0].fundedAmount3[0].total }
            if (invoiceAmountData[0].fundedAmount4[0] != undefined) { fundedAmount4 = invoiceAmountData[0].fundedAmount4[0].total }
            if (invoiceAmountData[0].fundedAmount5[0] != undefined) { fundedAmount4 = invoiceAmountData[0].fundedAmount5[0].total }
            if (invoiceAmountData[0].fundedAmount6[0] != undefined) { fundedAmount5 = invoiceAmountData[0].fundedAmount6[0].total }

            if (invoiceAmountData[0].repaidAmount1[0] != undefined) { repaidAmount1 = invoiceAmountData[0].repaidAmount1[0].total }
            if (invoiceAmountData[0].repaidAmount2[0] != undefined) { repaidAmount2 = invoiceAmountData[0].repaidAmount2[0].total }
            if (invoiceAmountData[0].repaidAmount3[0] != undefined) { repaidAmount3 = invoiceAmountData[0].repaidAmount3[0].total }
            if (invoiceAmountData[0].repaidAmount4[0] != undefined) { repaidAmount4 = invoiceAmountData[0].repaidAmount4[0].total }
            if (invoiceAmountData[0].repaidAmount5[0] != undefined) { repaidAmount4 = invoiceAmountData[0].repaidAmount5[0].total }
            if (invoiceAmountData[0].repaidAmount6[0] != undefined) { repaidAmount5 = invoiceAmountData[0].repaidAmount6[0].total }

            if (invoiceAmountData[0].rejectedAmount1[0] != undefined) { rejectedAmount1 = invoiceAmountData[0].rejectedAmount1[0].total }
            if (invoiceAmountData[0].rejectedAmount2[0] != undefined) { rejectedAmount2 = invoiceAmountData[0].rejectedAmount2[0].total }
            if (invoiceAmountData[0].rejectedAmount3[0] != undefined) { rejectedAmount3 = invoiceAmountData[0].rejectedAmount3[0].total }
            if (invoiceAmountData[0].rejectedAmount4[0] != undefined) { rejectedAmount4 = invoiceAmountData[0].rejectedAmount4[0].total }
            if (invoiceAmountData[0].rejectedAmount5[0] != undefined) { rejectedAmount4 = invoiceAmountData[0].rejectedAmount5[0].total }
            if (invoiceAmountData[0].rejectedAmount6[0] != undefined) { rejectedAmount5 = invoiceAmountData[0].rejectedAmount6[0].total }

            var InProcessAmount = [
                [InProcessAmount1, currentMonth, currentMonthYear],
                [InProcessAmount2, previousMonth1, previousMonthYear1],
                [InProcessAmount3, previousMonth2, previousMonthYear2],
                [InProcessAmount4, previousMonth3, previousMonthYear3],
                [InProcessAmount5, previousMonth4, previousMonthYear4],
                [InProcessAmount6, previousMonth5, previousMonthYear5],
            ];
            var fundedAmount = [
                [fundedAmount1, currentMonth, currentMonthYear],
                [fundedAmount2, previousMonth1, previousMonthYear1],
                [fundedAmount3, previousMonth2, previousMonthYear2],
                [fundedAmount4, previousMonth3, previousMonthYear3],
                [fundedAmount5, previousMonth4, previousMonthYear4],
                [fundedAmount6, previousMonth5, previousMonthYear5],
            ];
            var repaidAmount = [
                [repaidAmount1, currentMonth, currentMonthYear],
                [repaidAmount2, previousMonth1, previousMonthYear1],
                [repaidAmount3, previousMonth2, previousMonthYear2],
                [repaidAmount4, previousMonth3, previousMonthYear3],
                [repaidAmount5, previousMonth4, previousMonthYear4],
                [repaidAmount6, previousMonth5, previousMonthYear5],
            ];
            var rejectedAmount = [
                [rejectedAmount1, currentMonth, currentMonthYear],
                [rejectedAmount2, previousMonth1, previousMonthYear1],
                [rejectedAmount3, previousMonth2, previousMonthYear2],
                [rejectedAmount4, previousMonth3, previousMonthYear3],
                [rejectedAmount5, previousMonth4, previousMonthYear4],
                [rejectedAmount6, previousMonth5, previousMonthYear5],
            ];

            //Count of UnInsured Invoices(Monthly)
            var InProcessCount1 = 0; var InProcessCount2 = 0; var InProcessCount3 = 0; var InProcessCount4 = 0; var InProcessCount5 = 0; var InProcessCount6 = 0;
            var fundedCount1 = 0; var fundedCount2 = 0; var fundedCount3 = 0; var fundedCount4 = 0; var fundedCount5 = 0; var fundedCount6 = 0;
            var repaidCount1 = 0; var repaidCount2 = 0; var repaidCount3 = 0; var repaidCount4 = 0; var repaidCount5 = 0; var repaidCount6 = 0;
            var rejectedCount1 = 0; var rejectedCount2 = 0; var rejectedCount3 = 0; var rejectedCount4 = 0; var rejectedCount5 = 0; var rejectedCount6 = 0;

            var invoiceCountData = await this.patientLoanModel.aggregate([
                {
                    $facet: {
                        InProcessCount1: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: currentMonth,
                                    UWName: currentUser.name,
                                    isInsured: true,
                                    $or: [
                                        { invoiceStatus: 'InProcess' }, { invoiceStatus: 'Pending' }
                                    ]
                                },
                            },
                            { $count: 'total' },
                        ],
                        InProcessCount2: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth1,
                                    UWName: currentUser.name,
                                    isInsured: true,
                                    $or: [
                                        { invoiceStatus: 'InProcess' }, { invoiceStatus: 'Pending' }
                                    ]
                                },
                            },
                            { $count: 'total' },
                        ],
                        InProcessCount3: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth2,
                                    UWName: currentUser.name,
                                    isInsured: true,
                                    $or: [
                                        { invoiceStatus: 'InProcess' }, { invoiceStatus: 'Pending' }
                                    ]
                                },
                            },
                            { $count: 'total' },
                        ],
                        InProcessCount4: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth3,
                                    UWName: currentUser.name,
                                    isInsured: true,
                                    $or: [
                                        { invoiceStatus: 'InProcess' }, { invoiceStatus: 'Pending' }
                                    ]
                                },
                            },
                            { $count: 'total' },
                        ],
                        InProcessCount5: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth4,
                                    UWName: currentUser.name,
                                    isInsured: true,
                                    $or: [
                                        { invoiceStatus: 'InProcess' }, { invoiceStatus: 'Pending' }
                                    ]
                                },
                            },
                            { $count: 'total' },
                        ],
                        InProcessCount6: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth5,
                                    UWName: currentUser.name,
                                    isInsured: true,
                                    $or: [
                                        { invoiceStatus: 'InProcess' }, { invoiceStatus: 'Pending' }
                                    ]
                                },
                            },
                            { $count: 'total' },
                        ],

                        fundedCount1: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: currentMonth,
                                    UWName: currentUser.name,
                                    isInsured: true,
                                    invoiceStatus: 'Disbursed',
                                },
                            },
                            { $count: 'total' },
                        ],
                        fundedCount2: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth1,
                                    UWName: currentUser.name,
                                    isInsured: true,
                                    invoiceStatus: 'Disbursed',
                                },
                            },
                            { $count: 'total' },
                        ],
                        fundedCount3: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth2,
                                    UWName: currentUser.name,
                                    isInsured: true,
                                    invoiceStatus: 'Disbursed',
                                },
                            },
                            { $count: 'total' },
                        ],
                        fundedCount4: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth3,
                                    UWName: currentUser.name,
                                    isInsured: true,
                                    invoiceStatus: 'Disbursed',
                                },
                            },
                            { $count: 'total' },
                        ],
                        fundedCount5: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth4,
                                    UWName: currentUser.name,
                                    isInsured: true,
                                    invoiceStatus: 'Disbursed',
                                },
                            },
                            { $count: 'total' },
                        ],
                        fundedCount6: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth5,
                                    UWName: currentUser.name,
                                    isInsured: true,
                                    invoiceStatus: 'Disbursed',
                                },
                            },
                            { $count: 'total' },
                        ],

                        repaidCount1: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: currentMonth,
                                    UWName: currentUser.name,
                                    isInsured: true,
                                    invoiceStatus: 'Closed',
                                },
                            },
                            { $count: 'total' },
                        ],
                        repaidCount2: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth1,
                                    UWName: currentUser.name,
                                    isInsured: true,
                                    invoiceStatus: 'Closed',
                                },
                            },
                            { $count: 'total' },
                        ],
                        repaidCount3: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth2,
                                    UWName: currentUser.name,
                                    isInsured: true,
                                    invoiceStatus: 'Closed',
                                },
                            },
                            { $count: 'total' },
                        ],
                        repaidCount4: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth3,
                                    UWName: currentUser.name,
                                    isInsured: true,
                                    invoiceStatus: 'Closed',
                                },
                            },
                            { $count: 'total' },
                        ],
                        repaidCount5: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth4,
                                    UWName: currentUser.name,
                                    isInsured: true,
                                    invoiceStatus: 'Closed',
                                },
                            },
                            { $count: 'total' },
                        ],
                        repaidCount6: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth5,
                                    UWName: currentUser.name,
                                    isInsured: true,
                                    invoiceStatus: 'Closed',
                                },
                            },
                            { $count: 'total' },
                        ],

                        rejectedCount1: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: currentMonth,
                                    UWName: currentUser.name,
                                    isInsured: true,
                                    invoiceStatus: 'Rejected',
                                },
                            },
                            { $count: 'total' },
                        ],
                        rejectedCount2: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth1,
                                    UWName: currentUser.name,
                                    isInsured: true,
                                    invoiceStatus: 'Rejected',
                                },
                            },
                            { $count: 'total' },
                        ],
                        rejectedCount3: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth2,
                                    UWName: currentUser.name,
                                    isInsured: true,
                                    invoiceStatus: 'Rejected',
                                },
                            },
                            { $count: 'total' },
                        ],
                        rejectedCount4: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth3,
                                    UWName: currentUser.name,
                                    isInsured: true,
                                    invoiceStatus: 'Rejected',
                                },
                            },
                            { $count: 'total' },
                        ],
                        rejectedCount5: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth4,
                                    UWName: currentUser.name,
                                    isInsured: true,
                                    invoiceStatus: 'Rejected',
                                },
                            },
                            { $count: 'total' },
                        ],
                        rejectedCount6: [
                            {
                                $project: {
                                    invoiceStatus: 1,
                                    UWName: 1,
                                    isInsured: 1,
                                    loanAmount: 1,
                                    month: { $month: '$createdAt' },
                                },
                            },
                            {
                                $match: {
                                    month: previousMonth5,
                                    UWName: currentUser.name,
                                    isInsured: true,
                                    invoiceStatus: 'Rejected',
                                },
                            },
                            { $count: 'total' },
                        ],
                    },
                },
            ]);
            if (invoiceCountData[0].InProcessCount1[0] != undefined) { InProcessCount1 = invoiceCountData[0].InProcessCount1[0].total }
            if (invoiceCountData[0].InProcessCount2[0] != undefined) { InProcessCount2 = invoiceCountData[0].InProcessCount2[0].total }
            if (invoiceCountData[0].InProcessCount3[0] != undefined) { InProcessCount3 = invoiceCountData[0].InProcessCount3[0].total }
            if (invoiceCountData[0].InProcessCount4[0] != undefined) { InProcessCount4 = invoiceCountData[0].InProcessCount4[0].total }
            if (invoiceCountData[0].InProcessCount5[0] != undefined) { InProcessCount4 = invoiceCountData[0].InProcessCount5[0].total }
            if (invoiceCountData[0].InProcessCount6[0] != undefined) { InProcessCount5 = invoiceCountData[0].InProcessCount6[0].total }

            if (invoiceCountData[0].fundedCount1[0] != undefined) { fundedCount1 = invoiceCountData[0].fundedCount1[0].total }
            if (invoiceCountData[0].fundedCount2[0] != undefined) { fundedCount2 = invoiceCountData[0].fundedCount2[0].total }
            if (invoiceCountData[0].fundedCount3[0] != undefined) { fundedCount3 = invoiceCountData[0].fundedCount3[0].total }
            if (invoiceCountData[0].fundedCount4[0] != undefined) { fundedCount4 = invoiceCountData[0].fundedCount4[0].total }
            if (invoiceCountData[0].fundedCount5[0] != undefined) { fundedCount4 = invoiceCountData[0].fundedCount5[0].total }
            if (invoiceCountData[0].fundedCount6[0] != undefined) { fundedCount5 = invoiceCountData[0].fundedCount6[0].total }

            if (invoiceCountData[0].repaidCount1[0] != undefined) { repaidCount1 = invoiceCountData[0].repaidCount1[0].total }
            if (invoiceCountData[0].repaidCount2[0] != undefined) { repaidCount2 = invoiceCountData[0].repaidCount2[0].total }
            if (invoiceCountData[0].repaidCount3[0] != undefined) { repaidCount3 = invoiceCountData[0].repaidCount3[0].total }
            if (invoiceCountData[0].repaidCount4[0] != undefined) { repaidCount4 = invoiceCountData[0].repaidCount4[0].total }
            if (invoiceCountData[0].repaidCount5[0] != undefined) { repaidCount4 = invoiceCountData[0].repaidCount5[0].total }
            if (invoiceCountData[0].repaidCount6[0] != undefined) { repaidCount5 = invoiceCountData[0].repaidCount6[0].total }

            if (invoiceCountData[0].rejectedCount1[0] != undefined) { rejectedCount1 = invoiceCountData[0].rejectedCount1[0].total }
            if (invoiceCountData[0].rejectedCount2[0] != undefined) { rejectedCount2 = invoiceCountData[0].rejectedCount2[0].total }
            if (invoiceCountData[0].rejectedCount3[0] != undefined) { rejectedCount3 = invoiceCountData[0].rejectedCount3[0].total }
            if (invoiceCountData[0].rejectedCount4[0] != undefined) { rejectedCount4 = invoiceCountData[0].rejectedCount4[0].total }
            if (invoiceCountData[0].rejectedCount5[0] != undefined) { rejectedCount4 = invoiceCountData[0].rejectedCount5[0].total }
            if (invoiceCountData[0].rejectedCount6[0] != undefined) { rejectedCount5 = invoiceCountData[0].rejectedCount6[0].total }

            var InProcessCount = [
                [InProcessCount1, currentMonth, currentMonthYear],
                [InProcessCount2, previousMonth1, previousMonthYear1],
                [InProcessCount3, previousMonth2, previousMonthYear2],
                [InProcessCount4, previousMonth3, previousMonthYear3],
                [InProcessCount5, previousMonth4, previousMonthYear4],
                [InProcessCount6, previousMonth5, previousMonthYear5],
            ];
            var fundedCount = [
                [fundedCount1, currentMonth, currentMonthYear],
                [fundedCount2, previousMonth1, previousMonthYear1],
                [fundedCount3, previousMonth2, previousMonthYear2],
                [fundedCount4, previousMonth3, previousMonthYear3],
                [fundedCount5, previousMonth4, previousMonthYear4],
                [fundedCount6, previousMonth5, previousMonthYear5],
            ];
            var repaidCount = [
                [repaidCount1, currentMonth, currentMonthYear],
                [repaidCount2, previousMonth1, previousMonthYear1],
                [repaidCount3, previousMonth2, previousMonthYear2],
                [repaidCount4, previousMonth3, previousMonthYear3],
                [repaidCount5, previousMonth4, previousMonthYear4],
                [repaidCount6, previousMonth5, previousMonthYear5],
            ];
            var rejectedCount = [
                [rejectedCount1, currentMonth, currentMonthYear],
                [rejectedCount2, previousMonth1, previousMonthYear1],
                [rejectedCount3, previousMonth2, previousMonthYear2],
                [rejectedCount4, previousMonth3, previousMonthYear3],
                [rejectedCount5, previousMonth4, previousMonthYear4],
                [rejectedCount6, previousMonth5, previousMonthYear5],
            ];

            //claim invoice count
            var claimInvoiceCount = await this.Invoice.find({ UWName: currentUser.name }).countDocuments();

            var data = {
                claimInvoiceCount: claimInvoiceCount,
                associatedAggregators: associatedAggregators,
                associatedHospitals: associatedHospitals,

                totalUninsuredCount: totalUninsuredCount,
                totalReimbursementCount: totalReimbursementCount,
                totalCount: totalCount,
                totalAmount: totalAmount,
                totalUninsuredAmount: totalUninsuredAmount,
                totalReimbursementAmount: totalReimbursementAmount,

                totalInProcessCount: totalInProcessCount,
                uninsuredInProcessCount: uninsuredInProcessCount,
                reimbursementInProcessCount: reimbursementInProcessCount,

                totalInProcessAmount: totalInProcessAmount,
                uninsuredInProcessAmount: uninsuredInProcessAmount,
                reimbursementInProcessAmount: reimbursementInProcessAmount,

                totalFundedCount: totalFundedCount,
                uninsuredFundedCount: uninsuredFundedCount,
                reimbursementFundedCount: reimbursementFundedCount,

                totalFundedAmount: totalFundedAmount,
                uninsuredFundedAmount: uninsuredFundedAmount,
                reimbursementFundedAmount: reimbursementFundedAmount,

                totalRepaidCount: totalRepaidCount,
                uninsuredRepaidCount: uninsuredRepaidCount,
                reimbursementRepaidCount: reimbursementRepaidCount,

                totalRepaidAmount: totalRepaidAmount,
                uninsuredRepaidAmount: uninsuredRepaidAmount,
                reimbursementRepaidAmount: reimbursementRepaidAmount,

                totalRejectedCount: totalRejectedCount,
                uninsuredRejectedCount: uninsuredRejectedCount,
                reimbursementRejectedCount: reimbursementRejectedCount,

                totalRejectedAmount: totalRejectedAmount,
                uninsuredRejectedAmount: uninsuredRejectedAmount,
                reimbursementRejectedAmount: reimbursementRejectedAmount,

                invoiceAmountGraph: invoiceAmountGraph,
                invoiceCountGraph: invoiceCountGraph,

                unInsuredAmountGraph: {
                    InProcessAmount: InProcessAmountGraph,
                    fundedAmount: fundedAmountGraph,
                    repaidAmount: repaidAmountGraph,
                    rejectedAmount: rejectedAmountGraph,
                },
                unInsuredCountGraph: {
                    InProcessCount: InProcessCountGraph,
                    fundedCount: fundedCountGraph,
                    repaidCount: repaidCountGraph,
                    rejectedCount: rejectedCountGraph,
                },
                reimbursementAmountGraph: {
                    InProcessAmountGraph: InProcessAmount,
                    fundedAmountGraph: fundedAmount,
                    repaidAmountGraph: repaidAmount,
                    rejectedAmountGraph: rejectedAmount,
                },
                reimbursementCountGraph: {
                    InProcessCountGraph: InProcessCount,
                    fundedCountGraph: fundedCount,
                    repaidCountGraph: repaidCount,
                    rejectedCountGraph: rejectedCount,
                },
            };
            return { data };
        } catch (e) {
            this.logger.error(e);
            throw e;
        }
    }
    public async getAllInvoices(IFilterDTO: IFilterDTO, currentUser: IUser): Promise<{ data: any }> {
        try {
            //pagination
            var pageNumber = 1;
            var pageSize = 0;
            var total: any = {};
            if (IFilterDTO.pageNumber) {
                var pageNumber = IFilterDTO.pageNumber;
            }
            if (IFilterDTO.pageSize) {
                var pageSize = IFilterDTO.pageSize;
            }
            //filters
            var searchFilters = [];
            searchFilters.push({ isDeleted: false });
            searchFilters.push({ UWName: currentUser.name });

            if (IFilterDTO.dateFrom != undefined && IFilterDTO.dateTo != undefined) {
                searchFilters.push({ createdAt: { $gte: IFilterDTO.dateFrom, $lte: IFilterDTO.dateTo } });
            }

            if (IFilterDTO.organizationId != undefined || null) {
                searchFilters.push({ organizationId: IFilterDTO.organizationId });
            }
            if (IFilterDTO.Status != undefined) {
                searchFilters.push({ invoiceStatus: IFilterDTO.Status });
            }
            if (IFilterDTO.searchTerm != undefined) {
                searchFilters.push({
                    $or: [
                        { emailId: { $regex: IFilterDTO.searchTerm, $options: 'i' } },
                        { hospitalName: { $regex: IFilterDTO.searchTerm, $options: 'i' } },
                        { patientName: { $regex: IFilterDTO.searchTerm, $options: 'i' } },
                        { caseId: { $regex: IFilterDTO.searchTerm, $options: 'i' } },
                        {
                            "$expr": {
                                "$regexMatch": {
                                    "input": { "$toString": "$invoiceId" },
                                    "regex": IFilterDTO.searchTerm
                                }
                            }
                        },
                        {
                            "$expr": {
                                "$regexMatch": {
                                    "input": { "$toString": "$contactNumber" },
                                    "regex": IFilterDTO.searchTerm
                                }
                            }
                        }
                    ]
                })
            }
            var userCount = await this.patientLoanModel.find({ $and: searchFilters }).count();
            var numberOfPages = pageSize === 0 ? 1 : Math.ceil(userCount / pageSize);
            var patientLoans = await this.patientLoanModel
                .find({ $and: searchFilters })
                .sort({ updatedAt: -1 })
                .skip((pageNumber - 1) * pageSize)
                .limit(pageSize);

            if (patientLoans.length != 0) {
                total.totalAmount = 0;
                total.count = userCount
                for (var e of patientLoans) {
                    total.totalAmount = total.totalAmount + e.loanAmount
                }
            } else {
                total.count = 0
                total.totalAmount = 0
            }
            var data = { patientLoans, numberOfPages, total };
            return { data };
        } catch (e) {
            this.logger.error(e);
            throw e;
        }
    }
    public async getAllClaimInvoices(IFilterDTO: IFilterDTO, currentUser: IUser): Promise<{ data: any }> {
        try {
            //pagination
            var pageNumber = 1;
            var pageSize = 0;
            var total: any = {};
            if (IFilterDTO.pageNumber) {
                var pageNumber = IFilterDTO.pageNumber;
            }
            if (IFilterDTO.pageSize) {
                var pageSize = IFilterDTO.pageSize;
            }
            var searchFilters = [];
            searchFilters.push({ "LoanID": { $exists: true } });
            searchFilters.push({ UWName: currentUser.name });
            searchFilters.push({ isDeleted: false });

            if (IFilterDTO.Status != undefined || null) {
                searchFilters.push({ Status: IFilterDTO.Status });
            }
            if (IFilterDTO.searchTerm != undefined) {
                searchFilters.push({
                    $or: [
                        { nameOfHospital: { $regex: IFilterDTO.searchTerm, $options: 'i' } },
                        { claimId: { $regex: IFilterDTO.searchTerm, $options: 'i' } },
                        { patientName: { $regex: IFilterDTO.searchTerm, $options: 'i' } },
                        {
                            "$expr": {
                                "$regexMatch": {
                                    "input": { "$toString": "$LoanID" },
                                    "regex": IFilterDTO.searchTerm
                                }
                            }
                        }
                    ]
                })
            }

            var userCount = await this.Invoice.find({ $and: searchFilters }).countDocuments();
            var numberOfPages = pageSize === 0 ? 1 : Math.ceil(userCount / pageSize);
            var claimInvoices = await this.Invoice
                .find({ $and: searchFilters })
                .sort({ updatedAt: -1 })
                .skip((pageNumber - 1) * pageSize)
                .limit(pageSize);

            var totalAmount = await this.Invoice.aggregate([{ $match: { $and: searchFilters } }, { $group: { _id: '$_v', totalAmount: { $sum: '$LenderApprovalAmount' } } }
            ]);
            if (totalAmount.length != 0) {
                total.count = userCount
                total.totalAmount = totalAmount[0].totalAmount
            } else {
                total.count = 0
                total.totalAmount = 0
            }

            var data = { claimInvoices, numberOfPages, total };
            return { data };
        } catch (e) {
            this.logger.error(e);
            throw e;
        }
    }
    public async getInvoiceById(req: Request, res: Response): Promise<{ data: any }> {
        try {
            const id = req.query._id.toString();
            const usr = await this.patientLoanModel.findOne({ _id: id })
            var data = usr;
            return { data }
        } catch (e) {
            this.logger.error(e);
            throw e;
        }
    }
    public async getClaimInvoiceById(req: Request, res: Response): Promise<{ data: any, repaymentData: any }> {
        try {
            const id = req.query._id.toString();
            const usr = await this.Invoice.findOne({ _id: id })
            var repaymentData;
            if (usr) {
                repaymentData = await this.TransactionData.find({ invoiceId: usr._id })
            }

            var data = usr;
            return { data, repaymentData };
        } catch (e) {
            this.logger.error(e);
            throw e;
        }
    }
    public async getAllOrg(IFilterDTO: IFilterDTO, currentUser: IUser): Promise<{ data: any }> {
        try {
            //pagination
            var pageNumber = 1;
            var pageSize = 0;
            if (IFilterDTO.pageNumber) {
                var pageNumber = IFilterDTO.pageNumber;
            }
            if (IFilterDTO.pageSize) {
                var pageSize = IFilterDTO.pageSize;
            }
            //filters
            var searchFilters = [];
            searchFilters.push({ isDeleted: false });
            searchFilters.push({ "UWPartners": { $elemMatch: { partnerName: currentUser.name } } })

            if (IFilterDTO.typeOfOrganization != undefined || null) {
                searchFilters.push({ typeOfOrganization: IFilterDTO.typeOfOrganization });
            }

            if (IFilterDTO.searchTerm != undefined) {
                searchFilters.push({
                    $or: [
                        { emailId: { $regex: IFilterDTO.searchTerm, $options: 'i' } },
                        { nameOfOrganization: { $regex: IFilterDTO.searchTerm, $options: 'i' } }
                    ]
                })
            }
            // , { nameOfOrganization: 1, typeOfOrganization: 1, email: 1 }
            var userCount = await this.organizationModel.find({ $and: searchFilters }).count();
            var numberOfPages = pageSize === 0 ? 1 : Math.ceil(userCount / pageSize);
            var org = await this.organizationModel
                .find({ $and: searchFilters })
                .sort({ updatedAt: -1 })
                .skip((pageNumber - 1) * pageSize)
                .limit(pageSize);
            var data = { org, numberOfPages };
            return { data };
        } catch (e) {
            this.logger.error(e);
            throw e;
        }
    }
    public async updatePatientInvoice(currentUser: IUser, patientLoanDTO: IPatientLoanDTO, approvalLetter): Promise<{ data: any }> {
        try {
            const invoiceDetails = await this.patientLoanModel.findOne({ _id: patientLoanDTO._id });
            let invoiceData: any = {};
            if (patientLoanDTO.invoiceStatus == "Approved") {
                if (approvalLetter) {
                    invoiceData.invoiceStatus = "Approved"
                    invoiceData.invoiceSubStatus = "Pending Agreement Signing"
                    invoiceData.approvalLetter = patientLoanDTO.approvalLetter
                }
                else {
                    invoiceData.invoiceSubStatus = "Bill Upload Pending"
                    invoiceData.UWApprovedAmount = patientLoanDTO.UWApprovedAmount
                }
                if (!invoiceDetails.loanAmount) { invoiceData.loanAmount = patientLoanDTO.UWApprovedAmount }

                //invoiceData.UWApprovedAmount = patientLoanDTO.UWApprovedAmount
                if (invoiceDetails.lenderApprovedAmount) {
                    if (invoiceData.UWApprovedAmount > invoiceDetails.lenderApprovedAmount) {
                        invoiceData.finalApprovedAmount = invoiceDetails.lenderApprovedAmount
                        invoiceData.UWComment = patientLoanDTO.UWComment
                    }
                    else if (invoiceData.UWApprovedAmount <= invoiceDetails.lenderApprovedAmount) {
                        invoiceData.finalApprovedAmount = invoiceData.UWApprovedAmount
                        invoiceData.UWComment = patientLoanDTO.UWComment
                    }
                } else {
                    if (patientLoanDTO.UWApprovedAmount > invoiceDetails.UWApprovedAmount) {
                        invoiceData.finalApprovedAmount = patientLoanDTO.UWApprovedAmount
                        invoiceData.UWComment = patientLoanDTO.UWComment
                    }
                    else if (patientLoanDTO.UWApprovedAmount <= invoiceDetails.UWApprovedAmount && patientLoanDTO.UWApprovedAmount != 0) {
                        invoiceData.finalApprovedAmount = patientLoanDTO.UWApprovedAmount
                        invoiceData.UWComment = patientLoanDTO.UWComment
                    }
                    //else if (!invoiceDetails.UWApprovedAmount) { invoiceData.finalApprovedAmount = patientLoanDTO.UWApprovedAmount }
                }
            } else if (patientLoanDTO.invoiceStatus == "Rejected") {
                invoiceData.invoiceStatus = "Rejected"
                invoiceData.invoiceSubStatus = "Rejected by Under-Writing Partner"
                invoiceData.UWComment = patientLoanDTO.UWComment
            }
            else if (patientLoanDTO.invoiceStatus == "Request Additional Information") {
                invoiceData.invoiceStatus = "Rejected"
                invoiceData.invoiceSubStatus = "Additional Information requested by Under-Writing Partner"
                invoiceData.UWComment = patientLoanDTO.UWComment
            }
            if(patientLoanDTO.UWApprovedAmount && invoiceDetails.interest){
                var interestAmount = (patientLoanDTO.UWApprovedAmount * invoiceDetails.interest) / 100;
                var processingPer = (patientLoanDTO.UWApprovedAmount * invoiceDetails.processingFees) / 100;

                var GST = ((processingPer + interestAmount) * 18) / 100;

                var deductions = interestAmount + processingPer + GST;

                var TotalDisbursementAmount = patientLoanDTO.UWApprovedAmount - deductions;

                console.log(TotalDisbursementAmount, "DisbursementAmount")
                invoiceData.Disbursed_Amount = TotalDisbursementAmount;
                invoiceData.GST_Amount = GST;
                invoiceData.PF_Amount = processingPer;
                invoiceData.interest_Amount = interestAmount;
                invoiceData.deduction_Amount = deductions;
            }
            invoiceData.updatedBy = currentUser._id;
            const invoice = await this.patientLoanModel.findByIdAndUpdate(
                { _id: patientLoanDTO._id },
                { $set: invoiceData , approvalLetter:approvalLetter},
                { useFindAndModify: false, new: true },
            );
            var data = { success: true, message: `${patientLoanDTO.invoiceStatus} Successfully` };
            return { data };
        } catch (e) {
            this.logger.error(e);
            throw e;
        }
    }
    public async updateSettlement(patientDTO: IPatientLoanDTO): Promise<{ success: Boolean, message: String }> {
        try {
            if (patientDTO.invoiceSubStatus == 'Settled') { patientDTO.invoiceStatus = 'Settled' }
            const invoice = await this.patientLoanModel.findByIdAndUpdate({ _id: patientDTO._id },
                { $set: patientDTO },
                { new: true, useFindAndModify: false }
            );
            if (invoice && invoice.invoiceSubStatus == 'Settled') {
                pushToQueue(JSON.stringify({
                    msgType: "mandatePresentation",
                    mandateUMRN: invoice.mandateUMRN,
                    finalApprovedAmount: invoice.finalApprovedAmount,
                    _id: patientDTO._id
                }));
            }

            return { success: true, message: 'Settlement details updated' }
        } catch (e) {
            this.logger.error(e);
            throw e;
        }
    }
}