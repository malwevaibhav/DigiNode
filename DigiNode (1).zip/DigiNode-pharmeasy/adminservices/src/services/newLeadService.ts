import { Service, Inject } from 'typedi';
import { IFilterDTO } from '../interfaces/IUser';


@Service()
export default class newLeadService {
    constructor(
        @Inject('newLeadModel') private newLeadModel: Models.newLeadModel,
        @Inject('logger') private logger,
    ) { }


    public async getNewLeads(IFilterDTO: IFilterDTO): Promise<{ leads: Array<object>, numberOfPages: number }> {
        try {
            //pagination
            var pageNumber = 1;
            var pageSize = 0;
            if (IFilterDTO.pageNumber) { var pageNumber = IFilterDTO.pageNumber }
            if (IFilterDTO.pageSize) { var pageSize = IFilterDTO.pageSize }
            //search
            var searchFilters = [];
            // searchFilters.push({ isDeleted: false });
            searchFilters.push({ _id: { $exists: true } });
            if (IFilterDTO.searchTerm != undefined) {
                searchFilters.push({
                    $or: [
                        { name: { $regex: IFilterDTO.searchTerm, $options: 'i' } },
                        { email: { $regex: IFilterDTO.searchTerm, $options: 'i' } },
                        { leadType: { $regex: IFilterDTO.searchTerm, $options: 'i' } }
                    ]
                })
            }
            if (IFilterDTO.leadType != undefined) {
                searchFilters.push({ leadType: IFilterDTO.leadType })
            }
            if (IFilterDTO.isInsured != undefined) {
                searchFilters.push({ isInsured: IFilterDTO.isInsured })
            }
            if (IFilterDTO.product != undefined) {
                searchFilters.push({ product: IFilterDTO.product })
            }

            var userCount = await this.newLeadModel.find({ $and: searchFilters }).countDocuments();
            var numberOfPages = pageSize === 0 ? 1 : Math.ceil(userCount / pageSize);

            var leads = await this.newLeadModel.find({ $and: searchFilters })
                .sort({ updatedAt: -1 })
                .skip((pageNumber - 1) * pageSize)
                .limit(pageSize);

            return { leads, numberOfPages };
        } catch (e) {
            this.logger.error(e);
            throw e;
        }
    }
    public async newLeadDashboard(IFilterDTO: IFilterDTO): Promise<{ totalPatient: number, totalHospital: number, totalPartner: number, totalContact: number, leadCountGraph: Object }> {
        try {
            var searchFilters = [];
            // searchFilters.push({ isDeleted: false });
            searchFilters.push({ _id: { $exists: true } });
            if (IFilterDTO.dateFrom != undefined || null && IFilterDTO.dateTo != undefined || null) {
                searchFilters.push({ createdAt: { $gte: IFilterDTO.dateFrom, $lte: IFilterDTO.dateTo } });
            }
            var dashboardData = await this.newLeadModel.aggregate([
                {
                    $facet: {
                        totalPatient: [{ $match: { leadType: "Patient", $and: searchFilters } }, { $count: 'total' }],
                        totalHospital: [{ $match: { leadType: "Hospital", $and: searchFilters } }, { $count: 'total' }],
                        totalPartner: [{ $match: { leadType: "Partner", $and: searchFilters } }, { $count: 'total' }],
                        totalContact: [{ $match: { leadType: "Contact", $and: searchFilters } }, { $count: 'total' }],

                        registeredCount: [{ $match: { leadStatus: { $exists: true }, $and: searchFilters } }, { $count: 'total' }],
                        openCount: [{ $match: { leadStatus: "Open", $and: searchFilters } }, { $count: 'total' }],
                        onBoardedCount: [{ $match: { leadStatus: "On Boarded", $and: searchFilters } }, { $count: 'total' }],
                        notConvertedCount: [{ $match: { leadStatus: "Not COnverted", $and: searchFilters } }, { $count: 'total' }],
                    }
                },
            ]);

            var totalPatient: 0;
            var totalHospital: 0;
            var totalPartner: 0;
            var totalContact: 0;

            var registeredCount: 0;
            var openCount: 0
            var onBoardedCount: 0;
            var notConvertedCount: 0;

            if (dashboardData[0].totalPatient[0] != undefined) { totalPatient = dashboardData[0].totalPatient[0].total; } else { totalPatient = 0; }
            if (dashboardData[0].totalHospital[0] != undefined) { totalHospital = dashboardData[0].totalHospital[0].total; } else { totalHospital = 0; }
            if (dashboardData[0].totalPartner[0] != undefined) { totalPartner = dashboardData[0].totalPartner[0].total; } else { totalPartner = 0; }
            if (dashboardData[0].totalContact[0] != undefined) { totalContact = dashboardData[0].totalContact[0].total; } else { totalContact = 0; }

            if (dashboardData[0].registeredCount[0] != undefined) { registeredCount = dashboardData[0].registeredCount[0].total; } else { registeredCount = 0; }
            if (dashboardData[0].openCount[0] != undefined) { openCount = dashboardData[0].openCount[0].total; } else { openCount = 0; }
            if (dashboardData[0].onBoardedCount[0] != undefined) { onBoardedCount = dashboardData[0].onBoardedCount[0].total; } else { onBoardedCount = 0; }
            if (dashboardData[0].notConvertedCount[0] != undefined) { notConvertedCount = dashboardData[0].notConvertedCount[0].total; } else { notConvertedCount = 0; }

            return {
                totalPatient: totalPatient,
                totalHospital: totalHospital,
                totalPartner: totalPartner,
                totalContact: totalContact,
                leadCountGraph: {
                    registeredCount: registeredCount,
                    onBoardedCount: onBoardedCount,
                    notConvertedCount: notConvertedCount,
                    openCount: openCount
                }
            };
        } catch (e) {
            this.logger.error(e);
            throw e;
        }
    }
    public async updateLead(IFilterDTO: IFilterDTO): Promise<{ success: Boolean, message: String }> {
        try {
            const updateLead = await this.newLeadModel.findByIdAndUpdate(
                { _id: IFilterDTO._id },
                { $set: { leadStatus: IFilterDTO.leadStatus } },
                { useFindAndModify: false },
            );
            return { success: true, message: `Lead Updated Successfully` }
        } catch (e) {
            this.logger.error(e);
            throw e;
        }
    }
}
