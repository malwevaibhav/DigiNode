import { Service, Inject } from 'typedi';
import { Request, Response } from 'express';
import { IFilterDTO, ISupplierInvoiceDTO } from '@/interfaces/IUser';
@Service()
export default class supplierAdminService {
  constructor(
    @Inject('SupplierAdminDashboard') private SupplierAdminDashboardModel: Models.SupplierAdminDashboardModel,
    @Inject('organizationModel') private organizationModel: Models.organizationModel,
    @Inject('purchaseInvoiceModel') private purchaseInvoiceModel: Models.purchaseInvoiceModel,
    @Inject('SupplierUser') private SupplierUserModel: Models.SupplierUserModel,
    @Inject('TransactionData') private TransactionData: Models.TransactionDataModel,
    @Inject('logger') private logger,
    @Inject('userModel') private userModel: Models.UserModel,
    @Inject('DPAssociationModel') private DPAssociationModel: Models.DPAssociationModel,
  ) {
  }

  public async getSDash(req: Request): Promise<{ data: any }> {
    try {
      const userRecord = await this.SupplierAdminDashboardModel.find({}).sort({ jobLastUpdatedOn: -1 }).limit(1)
      var data = userRecord
      return { data };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  public async supplierDashboardJob(req: Request): Promise<{ dashboardData: any }> {
    try {
      const TotalVendor = await this.organizationModel.find({ typeOfOrganization: "Vendor", supplierFinancing: true });
      const TotLender = await this.organizationModel.find({ typeOfOrganization: "Lender", supplierFinancing: true });
      const TotHosp = await this.organizationModel.find({ typeOfOrganization: "Hospital", supplierFinancing: true });

      var associationDetails = await this.DPAssociationModel.aggregate([{
        $facet: {
          "sanctionSum": [
            { $match: { _id: { $exists: true } } },
            { $group: { _id: "_v", total: { $sum: "$creditLimit" } } }
          ],
          "availableSum": [
            { $match: { _id: { $exists: true } } },
            { $group: { _id: "_v", total: { $sum: "$AvailableLimit" } } }
          ],
          "utilizedSum": [
            { $match: { _id: { $exists: true } } },
            { $group: { _id: "_v", total: { $sum: "$UtilizedAmount" } } }
          ],
          "repaymentSum": [
            { $match: { _id: { $exists: true } } },
            { $group: { _id: "_v", total: { $sum: "$Repayment" } } }
          ]
        }
      }]);

      var TotalSanctionLimit = 0;
      var TotalUtilizedLimit = 0;
      var TotalAvailableLimit = 0;
      var TotalRepaymentsLimit = 0;
      var TotalInvoicesAmount = 0;
      var TotalfundedPaidAmount = 0;
      var TotalPendingAmount = 0;
      var TotalRejectedAmount = 0;
      var AllVendor;
      var TotRepaymentCount = 0;
      if (associationDetails[0].sanctionSum[0] != undefined) { TotalSanctionLimit = associationDetails[0].sanctionSum[0].total; } else { TotalSanctionLimit = 0; }
      if (associationDetails[0].utilizedSum[0] != undefined) { TotalUtilizedLimit = associationDetails[0].utilizedSum[0].total; } else { TotalUtilizedLimit = 0; }
      if (associationDetails[0].availableSum[0] != undefined) { TotalAvailableLimit = associationDetails[0].availableSum[0].total; } else { TotalAvailableLimit = 0; }
      if (associationDetails[0].repaymentSum[0] != undefined) { TotalRepaymentsLimit = associationDetails[0].repaymentSum[0].total; } else { TotalRepaymentsLimit = 0; }

      var Totalinvoices; var Totalfunded; var Totalpending; var Totalrejected;
      const everyData = await this.purchaseInvoiceModel.aggregate([{
        $facet: {
          "repayCount": [{ $match: { Status: "Fully Repaid" } }, { $count: "total" }],
          "invoicedataSum": [
            { $match: {} },
            { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } }
          ],
          "invoicedataCount": [{ $match: {} }, { $count: "total" }],
          "fundedSum": [
            {
              $match: {
                $or: [{ Status: "Disbursed" }, { Status: "Partially Repaid" }, { Status: "Fully Repaid" }, { Status: "Hospital Repaid" }
                ]
              }
            }, { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } }
          ],
          "fundedCount": [{
            $match: {
              $or: [{ Status: "Disbursed" }, { Status: "Partially Repaid" }, { Status: "Fully Repaid" }, { Status: "Hospital Repaid" }]
            }
          }, { $count: "total" }],
          "pendingSum": [
            { $match: { $or: [{ Status: "Pending" }, { Status: "Hospital Approved" }, { Status: "Lender Approved" }, { Status: "DSPL Approved" }] } },
            { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } }
          ],
          "pendingCount": [{ $match: { $or: [{ Status: "Pending" }, { Status: "Hospital Approved" }, { Status: "Lender Approved" }, { Status: "DSPL Approved" }] } }, { $count: "total" }],
          "rejectedSum": [
            { $match: { $or: [{ Status: "Hospital Rejected" }, { Status: "Lender Rejected" }, { Status: "DSPL Rejected" }] } },
            { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } }
          ],
          "rejectedCount": [{ $match: { $or: [{ Status: "Hospital Rejected" }, { Status: "Lender Rejected" }, { Status: "DSPL Rejected" }] } }, { $count: "total" }],
        }
      }])

      if (everyData[0].repayCount[0] != undefined) { TotRepaymentCount = everyData[0].repayCount[0].total; } else { TotRepaymentCount = 0; }
      if (everyData[0].invoicedataSum[0] != undefined) { TotalInvoicesAmount = everyData[0].invoicedataSum[0].total; } else { TotalInvoicesAmount = 0; }
      if (everyData[0].invoicedataCount[0] != undefined) { Totalinvoices = everyData[0].invoicedataCount[0].total; } else { Totalinvoices = 0; }
      if (everyData[0].fundedSum[0] != undefined) { TotalfundedPaidAmount = everyData[0].fundedSum[0].total; } else { TotalfundedPaidAmount = 0; }
      if (everyData[0].fundedCount[0] != undefined) { Totalfunded = everyData[0].fundedCount[0].total; } else { Totalfunded = 0; }
      if (everyData[0].pendingSum[0] != undefined) { TotalPendingAmount = everyData[0].pendingSum[0].total; } else { TotalPendingAmount = 0; }
      if (everyData[0].pendingCount[0] != undefined) { Totalpending = everyData[0].pendingCount[0].total; } else { Totalpending = 0; }
      if (everyData[0].rejectedSum[0] != undefined) { TotalRejectedAmount = everyData[0].rejectedSum[0].total; } else { TotalRejectedAmount = 0; }
      if (everyData[0].rejectedCount[0] != undefined) { Totalrejected = everyData[0].rejectedCount[0].total; } else { Totalrejected = 0; }

      //funded invoice graph

      var sum1 = 0; var sum2 = 0; var sum3 = 0;
      var sum4 = 0; var sum5 = 0; var sum6 = 0;
      var forcalc = new Date();
      var thismonth = forcalc.getMonth() + 1;
      var t = forcalc.getFullYear();
      var this1 = new Date(t, thismonth - 1, 1);

      var month1 = forcalc.getMonth();
      if (month1 <= 0) {
        month1 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month1);
      var a = forcalc.getFullYear();
      var d1m1 = new Date(a, month1 - 1, 1);
      var laster1 = new Date(a, month1, 0);
      laster1.setHours(23, 59, 59, 0)

      var month2 = forcalc.getMonth() - 1;
      if (month2 <= 0) {
        month2 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month2);
      var b = forcalc.getFullYear();
      var d1m2 = new Date(b, month2 - 1, 1);
      var laster2 = new Date(b, month2, 0);
      laster2.setHours(23, 59, 59, 0);

      var month3 = forcalc.getMonth() - 1;
      if (month3 <= 0) {
        month3 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month3);
      var c = forcalc.getFullYear();
      var d1m3 = new Date(c, month3 - 1, 1);
      var laster3 = new Date(c, month3, 0);
      laster3.setHours(23, 59, 59, 0)

      var month4 = forcalc.getMonth() - 1;
      if (month4 <= 0) {
        month4 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month4);
      var d = forcalc.getFullYear();
      var d1m4 = new Date(d, month4 - 1, 1);
      var laster4 = new Date(d, month4, 0);
      laster4.setHours(23, 59, 59, 0)

      var month5 = forcalc.getMonth() - 1;
      if (month5 <= 0) {
        month5 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month5);
      var e = forcalc.getFullYear();
      var d1m5 = new Date(e, month5 - 1, 1);
      var laster5 = new Date(e, month5, 0);
      laster5.setHours(23, 59, 59, 0)

      var todaydate = new Date();

      var countser2 = await this.purchaseInvoiceModel.aggregate([{
        $facet: {
          "sumone": [
            { $match: { InvoiceDate: { $gte: this1, $lte: todaydate } }, },
            { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } }
          ],
          "sumtwo": [
            { $match: { InvoiceDate: { $gte: d1m1, $lte: laster1 } }, },
            { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } }
          ],
          "sumthree": [
            { $match: { InvoiceDate: { $gte: d1m2, $lte: laster2 } }, },
            { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } }
          ],
          "sumfour": [
            { $match: { InvoiceDate: { $gte: d1m3, $lte: laster3 } }, },
            { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } }
          ],
          "sumfive": [
            { $match: { InvoiceDate: { $gte: d1m4, $lte: laster4 } }, },
            { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } }
          ],
          "sumsix": [
            { $match: { InvoiceDate: { $gte: d1m5, $lte: laster5 } }, },
            { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } }
          ]
        }
      }])

      if (countser2[0].sumone[0] != undefined) { sum1 = countser2[0].sumone[0].total; } else { sum1 = 0; }
      if (countser2[0].sumtwo[0] != undefined) { sum2 = countser2[0].sumtwo[0].total; } else { sum2 = 0; }
      if (countser2[0].sumthree[0] != undefined) { sum3 = countser2[0].sumthree[0].total; } else { sum3 = 0; }
      if (countser2[0].sumfour[0] != undefined) { sum4 = countser2[0].sumfour[0].total; } else { sum4 = 0; }
      if (countser2[0].sumfive[0] != undefined) { sum5 = countser2[0].sumfive[0].total; } else { sum5 = 0; }
      if (countser2[0].sumsix[0] != undefined) { sum6 = countser2[0].sumsix[0].total; } else { sum6 = 0; }

      var getFundedInvoiceGraphToAdmin = [[sum1, thismonth, t], [sum2, month1, a], [sum3, month2, b], [sum4, month3, c],
      [sum5, month4, d], [sum6, month5, e]];

      //getLApprovedInvoiceGraphToAdmin

      var sum1 = 0; var sum2 = 0; var sum3 = 0;
      var sum4 = 0; var sum5 = 0; var sum6 = 0;
      var forcalc = new Date();
      var thismonth = forcalc.getMonth() + 1;
      var t = forcalc.getFullYear();
      var this1 = new Date(t, thismonth - 1, 1);

      var month1 = forcalc.getMonth();
      if (month1 <= 0) {
        month1 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month1);
      var a = forcalc.getFullYear();
      var d1m1 = new Date(a, month1 - 1, 1);
      var laster1 = new Date(a, month1, 0);
      laster1.setHours(23, 59, 59, 0)

      var month2 = forcalc.getMonth() - 1;
      if (month2 <= 0) {
        month2 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month2);
      var b = forcalc.getFullYear();
      var d1m2 = new Date(b, month2 - 1, 1);
      var laster2 = new Date(b, month2, 0);
      laster2.setHours(23, 59, 59, 0);

      var month3 = forcalc.getMonth() - 1;
      if (month3 <= 0) {
        month3 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month3);
      var c = forcalc.getFullYear();
      var d1m3 = new Date(c, month3 - 1, 1);
      var laster3 = new Date(c, month3, 0);
      laster3.setHours(23, 59, 59, 0)

      var month4 = forcalc.getMonth() - 1;
      if (month4 <= 0) {
        month4 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month4);
      var d = forcalc.getFullYear();
      var d1m4 = new Date(d, month4 - 1, 1);
      var laster4 = new Date(d, month4, 0);
      laster4.setHours(23, 59, 59, 0)

      var month5 = forcalc.getMonth() - 1;
      if (month5 <= 0) {
        month5 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month5);
      var e = forcalc.getFullYear();
      var d1m5 = new Date(e, month5 - 1, 1);
      var laster5 = new Date(e, month5, 0);
      laster5.setHours(23, 59, 59, 0)

      var todaydate = new Date();

      var countser2 = await this.purchaseInvoiceModel.aggregate([{
        $facet: {
          "sumone": [
            { $match: { $and: [{ InvoiceDate: { $gte: this1, $lte: todaydate } }, { $or: [{ Status: "Lender Approved" }, { Status: "Hospital Approved" }, { Status: "Fully Repaid" }, { Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Partially Repaid" }] }] }, },
            { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } }
          ],
          "sumtwo": [
            { $match: { $and: [{ InvoiceDate: { $gte: d1m1, $lte: laster1 } }, { $or: [{ Status: "Lender Approved" }, { Status: "Hospital Approved" }, { Status: "Fully Repaid" }, { Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Partially Repaid" }] }] }, },
            { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } }
          ],
          "sumthree": [
            { $match: { $and: [{ InvoiceDate: { $gte: d1m2, $lte: laster2 } }, { $or: [{ Status: "Lender Approved" }, { Status: "Hospital Approved" }, { Status: "Fully Repaid" }, { Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Partially Repaid" }] }] }, },
            { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } }
          ],
          "sumfour": [
            { $match: { $and: [{ InvoiceDate: { $gte: d1m3, $lte: laster3 } }, { $or: [{ Status: "Lender Approved" }, { Status: "Hospital Approved" }, { Status: "Fully Repaid" }, { Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Partially Repaid" }] }] }, },
            { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } }
          ],
          "sumfive": [
            { $match: { $and: [{ InvoiceDate: { $gte: d1m4, $lte: laster4 } }, { $or: [{ Status: "Lender Approved" }, { Status: "Hospital Approved" }, { Status: "Fully Repaid" }, { Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Partially Repaid" }] }] }, },
            { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } }
          ],
          "sumsix": [
            { $match: { $and: [{ InvoiceDate: { $gte: d1m5, $lte: laster5 } }, { $or: [{ Status: "Lender Approved" }, { Status: "Hospital Approved" }, { Status: "Fully Repaid" }, { Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Partially Repaid" }] }] }, },
            { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } }
          ]
        }
      }])

      if (countser2[0].sumone[0] != undefined) { sum1 = countser2[0].sumone[0].total; } else { sum1 = 0; }
      if (countser2[0].sumtwo[0] != undefined) { sum2 = countser2[0].sumtwo[0].total; } else { sum2 = 0; }
      if (countser2[0].sumthree[0] != undefined) { sum3 = countser2[0].sumthree[0].total; } else { sum3 = 0; }
      if (countser2[0].sumfour[0] != undefined) { sum4 = countser2[0].sumfour[0].total; } else { sum4 = 0; }
      if (countser2[0].sumfive[0] != undefined) { sum5 = countser2[0].sumfive[0].total; } else { sum5 = 0; }
      if (countser2[0].sumsix[0] != undefined) { sum6 = countser2[0].sumsix[0].total; } else { sum6 = 0; }


      const getLApprovedInvoiceGraphToAdmin = [[sum1, thismonth, t], [sum2, month1, a], [sum3, month2, b], [sum4, month3, c], [sum5, month4, d], [sum6, month5, e]]

      //getInvoiceGraphToAdmin

      var sum1 = 0;
      var sum2 = 0;
      var sum3 = 0;
      var sum4 = 0;
      var sum5 = 0;
      var sum6 = 0;
      var forcalc = new Date();
      var thismonth = forcalc.getMonth() + 1;
      var t = forcalc.getFullYear();
      var this1 = new Date(t, thismonth - 1, 1);

      var month1 = forcalc.getMonth();
      if (month1 <= 0) {
        month1 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month1);
      var a = forcalc.getFullYear();
      var d1m1 = new Date(a, month1 - 1, 1);
      var laster1 = new Date(a, month1, 0);
      laster1.setHours(23, 59, 59, 0)

      var month2 = forcalc.getMonth() - 1;
      if (month2 <= 0) {
        month2 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month2);
      var b = forcalc.getFullYear();
      var d1m2 = new Date(b, month2 - 1, 1);
      var laster2 = new Date(b, month2, 0);
      laster2.setHours(23, 59, 59, 0);

      var month3 = forcalc.getMonth() - 1;
      if (month3 <= 0) {
        month3 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month3);
      var c = forcalc.getFullYear();
      var d1m3 = new Date(c, month3 - 1, 1);
      var laster3 = new Date(c, month3, 0);
      laster3.setHours(23, 59, 59, 0)

      var month4 = forcalc.getMonth() - 1;
      if (month4 <= 0) {
        month4 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month4);
      var d = forcalc.getFullYear();
      var d1m4 = new Date(d, month4 - 1, 1);
      var laster4 = new Date(d, month4, 0);
      laster4.setHours(23, 59, 59, 0)

      var month5 = forcalc.getMonth() - 1;
      if (month5 <= 0) {
        month5 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month5);
      var e = forcalc.getFullYear();
      var d1m5 = new Date(e, month5 - 1, 1);
      var laster5 = new Date(e, month5, 0);
      laster5.setHours(23, 59, 59, 0)

      var todaydate = new Date();

      var countser2 = await this.purchaseInvoiceModel.aggregate([{
        $facet: {
          "sumone": [
            { $match: { $and: [{ PaymentDate: { $gte: this1, $lte: todaydate } }, { $or: [{ Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Fully Repaid" }, { Status: "Partially Repaid" }, { Status: "Partially Repaid" }] }] }, },
            { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } }
          ],
          "sumtwo": [
            { $match: { $and: [{ PaymentDate: { $gte: d1m1, $lte: laster1 } }, { $or: [{ Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Fully Repaid" }, { Status: "Partially Repaid" }, { Status: "Partially Repaid" }] }] }, },
            { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } }
          ],
          "sumthree": [
            { $match: { $and: [{ PaymentDate: { $gte: d1m2, $lte: laster2 } }, { $or: [{ Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Fully Repaid" }, { Status: "Partially Repaid" }, { Status: "Partially Repaid" }] }] }, },
            { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } }
          ],
          "sumfour": [
            { $match: { $and: [{ PaymentDate: { $gte: d1m3, $lte: laster3 } }, { $or: [{ Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Fully Repaid" }, { Status: "Partially Repaid" }, { Status: "Partially Repaid" }] }] }, },
            { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } }
          ],
          "sumfive": [
            { $match: { $and: [{ PaymentDate: { $gte: d1m4, $lte: laster4 } }, { $or: [{ Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Fully Repaid" }, { Status: "Partially Repaid" }, { Status: "Partially Repaid" }] }] }, },
            { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } }
          ],
          "sumsix": [
            { $match: { $and: [{ PaymentDate: { $gte: d1m5, $lte: laster5 } }, { $or: [{ Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Fully Repaid" }, { Status: "Partially Repaid" }, { Status: "Partially Repaid" }] }] }, },
            { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } }
          ]
        }
      }])

      if (countser2[0].sumone[0] != undefined) { sum1 = countser2[0].sumone[0].total; } else { sum1 = 0; }
      if (countser2[0].sumtwo[0] != undefined) { sum2 = countser2[0].sumtwo[0].total; } else { sum2 = 0; }
      if (countser2[0].sumthree[0] != undefined) { sum3 = countser2[0].sumthree[0].total; } else { sum3 = 0; }
      if (countser2[0].sumfour[0] != undefined) { sum4 = countser2[0].sumfour[0].total; } else { sum4 = 0; }
      if (countser2[0].sumfive[0] != undefined) { sum5 = countser2[0].sumfive[0].total; } else { sum5 = 0; }
      if (countser2[0].sumsix[0] != undefined) { sum6 = countser2[0].sumsix[0].total; } else { sum6 = 0; }


      var getInvoiceGraphToAdmin = [[sum1, thismonth, t], [sum2, month1, a], [sum3, month2, b], [sum4, month3, c], [sum5, month4, d], [sum6, month5, e]]

      //getAdminGraphOne

      var sum1 = 0; var sum2 = 0; var sum3 = 0; var sum4 = 0; var sum5 = 0; var sum6 = 0;

      var InProcesssum1 = 0; var InProcesssum2 = 0; var InProcesssum3 = 0;
      var InProcesssum4 = 0; var InProcesssum5 = 0; var InProcesssum6 = 0;

      var Disbursedsum1 = 0; var Disbursedsum2 = 0; var Disbursedsum3 = 0;
      var Disbursedsum4 = 0; var Disbursedsum5 = 0; var Disbursedsum6 = 0;

      var Repaidsum1 = 0; var Repaidsum2 = 0; var Repaidsum3 = 0;
      var Repaidsum4 = 0; var Repaidsum5 = 0; var Repaidsum6 = 0;

      var Rejectedsum1 = 0; var Rejectedsum2 = 0; var Rejectedsum3 = 0;
      var Rejectedsum4 = 0; var Rejectedsum5 = 0; var Rejectedsum6 = 0;

      var forcalc = new Date();
      var thismonth = forcalc.getMonth() + 1;
      var t = forcalc.getFullYear();
      var this1 = new Date(t, thismonth - 1, 1);

      var month1 = forcalc.getMonth();
      if (month1 <= 0) {
        month1 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month1);
      var a = forcalc.getFullYear();
      var d1m1 = new Date(a, month1 - 1, 1);
      var laster1 = new Date(a, month1, 0);
      laster1.setHours(23, 59, 59, 0)

      var month2 = forcalc.getMonth() - 1;
      if (month2 <= 0) {
        month2 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month2);
      var b = forcalc.getFullYear();
      var d1m2 = new Date(b, month2 - 1, 1);
      var laster2 = new Date(b, month2, 0);
      laster2.setHours(23, 59, 59, 0);

      var month3 = forcalc.getMonth() - 1;
      if (month3 <= 0) {
        month3 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month3);
      var c = forcalc.getFullYear();
      var d1m3 = new Date(c, month3 - 1, 1);
      var laster3 = new Date(c, month3, 0);
      laster3.setHours(23, 59, 59, 0)

      var month4 = forcalc.getMonth() - 1;
      if (month4 <= 0) {
        month4 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month4);
      var d = forcalc.getFullYear();
      var d1m4 = new Date(d, month4 - 1, 1);
      var laster4 = new Date(d, month4, 0);
      laster4.setHours(23, 59, 59, 0)

      var month5 = forcalc.getMonth() - 1;
      if (month5 <= 0) {
        month5 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month5);
      var e = forcalc.getFullYear();
      var d1m5 = new Date(e, month5 - 1, 1);
      var laster5 = new Date(e, month5, 0);
      laster5.setHours(23, 59, 59, 0)
      var todaydate = new Date();
      var countone = await this.purchaseInvoiceModel.aggregate([{
        $facet: {
          "sumone": [{ $match: { InvoiceDate: { $gte: this1, $lte: todaydate } } }, { $count: "total" }],
          "sumtwo": [{ $match: { InvoiceDate: { $gte: d1m1, $lte: laster1 } } }, { $count: "total" }],
          "sumthree": [{ $match: { InvoiceDate: { $gte: d1m2, $lte: laster2 } } }, { $count: "total" }],
          "sumfour": [{ $match: { InvoiceDate: { $gte: d1m3, $lte: laster3 } } }, { $count: "total" }],
          "sumfive": [{ $match: { InvoiceDate: { $gte: d1m4, $lte: laster4 } } }, { $count: "total" }],
          "sumsix": [{ $match: { InvoiceDate: { $gte: d1m5, $lte: laster5 } } }, { $count: "total" }],

          "InProsumone": [{ $match: { $and: [{ InvoiceDate: { $gte: this1, $lte: todaydate } }, { $or: [{ Status: "Pending" }, { Status: "Hospital Approved" }, { Status: "Lender Approved" }, { Status: "DSPL Approved" }] }] } }, { $count: "total" }],
          "InProsumtwo": [{ $match: { $and: [{ InvoiceDate: { $gte: d1m1, $lte: laster1 } }, { $or: [{ Status: "Pending" }, { Status: "Hospital Approved" }, { Status: "Lender Approved" }, { Status: "DSPL Approved" }] }] } }, { $count: "total" }],
          "InProsumthree": [{ $match: { $and: [{ InvoiceDate: { $gte: d1m2, $lte: laster2 } }, { $or: [{ Status: "Pending" }, { Status: "Hospital Approved" }, { Status: "Lender Approved" }, { Status: "DSPL Approved" }] }] } }, { $count: "total" }],
          "InProsumfour": [{ $match: { $and: [{ InvoiceDate: { $gte: d1m3, $lte: laster3 } }, { $or: [{ Status: "Pending" }, { Status: "Hospital Approved" }, { Status: "Lender Approved" }, { Status: "DSPL Approved" }] }] } }, { $count: "total" }],
          "InProsumfive": [{ $match: { $and: [{ InvoiceDate: { $gte: d1m4, $lte: laster4 } }, { $or: [{ Status: "Pending" }, { Status: "Hospital Approved" }, { Status: "Lender Approved" }, { Status: "DSPL Approved" }] }] } }, { $count: "total" }],
          "InProsumsix": [{ $match: { $and: [{ InvoiceDate: { $gte: d1m5, $lte: laster5 } }, { $or: [{ Status: "Pending" }, { Status: "Hospital Approved" }, { Status: "Lender Approved" }, { Status: "DSPL Approved" }] }] } }, { $count: "total" }],

          "Disbursedsumone": [{ $match: { $and: [{ InvoiceDate: { $gte: this1, $lte: todaydate } }, { $or: [{ Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Fully Repaid" }, { Status: "Partially Repaid" }] }] } }, { $count: "total" }],
          "Disbursedsumtwo": [{ $match: { $and: [{ InvoiceDate: { $gte: d1m1, $lte: laster1 } }, { $or: [{ Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Fully Repaid" }, { Status: "Partially Repaid" }] }] } }, { $count: "total" }],
          "Disbursedsumthree": [{ $match: { $and: [{ InvoiceDate: { $gte: d1m2, $lte: laster2 } }, { $or: [{ Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Fully Repaid" }, { Status: "Partially Repaid" }] }] } }, { $count: "total" }],
          "Disbursedsumfour": [{ $match: { $and: [{ InvoiceDate: { $gte: d1m3, $lte: laster3 } }, { $or: [{ Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Fully Repaid" }, { Status: "Partially Repaid" }] }] } }, { $count: "total" }],
          "Disbursedsumfive": [{ $match: { $and: [{ InvoiceDate: { $gte: d1m4, $lte: laster4 } }, { $or: [{ Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Fully Repaid" }, { Status: "Partially Repaid" }] }] } }, { $count: "total" }],
          "Disbursedsumsix": [{ $match: { $and: [{ InvoiceDate: { $gte: d1m5, $lte: laster5 } }, { $or: [{ Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Fully Repaid" }, { Status: "Partially Repaid" }] }] } }, { $count: "total" }],

          "Repaidsumone": [{ $match: { $and: [{ InvoiceDate: { $gte: this1, $lte: todaydate } }, { Status: "Fully Repaid" }] } }, { $count: "total" }],
          "Repaidsumtwo": [{ $match: { $and: [{ InvoiceDate: { $gte: d1m1, $lte: laster1 } }, { Status: "Fully Repaid" }] } }, { $count: "total" }],
          "Repaidsumthree": [{ $match: { $and: [{ InvoiceDate: { $gte: d1m2, $lte: laster2 } }, { Status: "Fully Repaid" }] } }, { $count: "total" }],
          "Repaidsumfour": [{ $match: { $and: [{ InvoiceDate: { $gte: d1m3, $lte: laster3 } }, { Status: "Fully Repaid" }] } }, { $count: "total" }],
          "Repaidsumfive": [{ $match: { $and: [{ InvoiceDate: { $gte: d1m4, $lte: laster4 } }, { Status: "Fully Repaid" }] } }, { $count: "total" }],
          "Repaidsumsix": [{ $match: { $and: [{ InvoiceDate: { $gte: d1m5, $lte: laster5 } }, { Status: "Fully Repaid" }] } }, { $count: "total" }],

          "Rejectedsumone": [{ $match: { $and: [{ InvoiceDate: { $gte: this1, $lte: todaydate } }, { $or: [{ Status: "Hospital Rejected" }, { Status: "Lender Rejected" }, { Status: "DSPL Rejected" }] }] } }, { $count: "total" }],
          "Rejectedsumtwo": [{ $match: { $and: [{ InvoiceDate: { $gte: d1m1, $lte: laster1 } }, { $or: [{ Status: "Hospital Rejected" }, { Status: "Lender Rejected" }, { Status: "DSPL Rejected" }] }] } }, { $count: "total" }],
          "Rejectedsumthree": [{ $match: { $and: [{ InvoiceDate: { $gte: d1m2, $lte: laster2 } }, { $or: [{ Status: "Hospital Rejected" }, { Status: "Lender Rejected" }, { Status: "DSPL Rejected" }] }] } }, { $count: "total" }],
          "Rejectedsumfour": [{ $match: { $and: [{ InvoiceDate: { $gte: d1m3, $lte: laster3 } }, { $or: [{ Status: "Hospital Rejected" }, { Status: "Lender Rejected" }, { Status: "DSPL Rejected" }] }] } }, { $count: "total" }],
          "Rejectedsumfive": [{ $match: { $and: [{ InvoiceDate: { $gte: d1m4, $lte: laster4 } }, { $or: [{ Status: "Hospital Rejected" }, { Status: "Lender Rejected" }, { Status: "DSPL Rejected" }] }] } }, { $count: "total" }],
          "Rejectedsumsix": [{ $match: { $and: [{ InvoiceDate: { $gte: d1m5, $lte: laster5 } }, { $or: [{ Status: "Hospital Rejected" }, { Status: "Lender Rejected" }, { Status: "DSPL Rejected" }] }] } }, { $count: "total" }]
        }
      }])

      if (countone[0].sumone[0] != undefined) { sum1 = countone[0].sumone[0].total; } else { sum1 = 0; }
      if (countone[0].sumtwo[0] != undefined) { sum2 = countone[0].sumtwo[0].total; } else { sum2 = 0; }
      if (countone[0].sumthree[0] != undefined) { sum3 = countone[0].sumthree[0].total; } else { sum3 = 0; }
      if (countone[0].sumfour[0] != undefined) { sum4 = countone[0].sumfour[0].total; } else { sum4 = 0; }
      if (countone[0].sumfive[0] != undefined) { sum5 = countone[0].sumfive[0].total; } else { sum5 = 0; }
      if (countone[0].sumsix[0] != undefined) { sum6 = countone[0].sumsix[0].total; } else { sum6 = 0; }

      if (countone[0].InProsumone[0] != undefined) { InProcesssum1 = countone[0].InProsumone[0].total; } else { InProcesssum1 = 0; }
      if (countone[0].InProsumtwo[0] != undefined) { InProcesssum2 = countone[0].InProsumtwo[0].total; } else { InProcesssum2 = 0; }
      if (countone[0].InProsumthree[0] != undefined) { InProcesssum3 = countone[0].InProsumthree[0].total; } else { InProcesssum3 = 0; }
      if (countone[0].InProsumfour[0] != undefined) { InProcesssum4 = countone[0].InProsumfour[0].total; } else { InProcesssum4 = 0; }
      if (countone[0].InProsumfive[0] != undefined) { InProcesssum5 = countone[0].InProsumfive[0].total; } else { InProcesssum5 = 0; }
      if (countone[0].InProsumsix[0] != undefined) { InProcesssum6 = countone[0].InProsumsix[0].total; } else { InProcesssum6 = 0; }

      if (countone[0].Disbursedsumone[0] != undefined) { Disbursedsum1 = countone[0].Disbursedsumone[0].total; } else { Disbursedsum1 = 0; }
      if (countone[0].Disbursedsumtwo[0] != undefined) { Disbursedsum2 = countone[0].Disbursedsumtwo[0].total; } else { Disbursedsum2 = 0; }
      if (countone[0].Disbursedsumthree[0] != undefined) { Disbursedsum3 = countone[0].Disbursedsumthree[0].total; } else { Disbursedsum3 = 0; }
      if (countone[0].Disbursedsumfour[0] != undefined) { Disbursedsum4 = countone[0].Disbursedsumfour[0].total; } else { Disbursedsum4 = 0; }
      if (countone[0].Disbursedsumfive[0] != undefined) { Disbursedsum5 = countone[0].Disbursedsumfive[0].total; } else { Disbursedsum5 = 0; }
      if (countone[0].Disbursedsumsix[0] != undefined) { Disbursedsum6 = countone[0].Disbursedsumsix[0].total; } else { Disbursedsum6 = 0; }

      if (countone[0].Repaidsumone[0] != undefined) { Repaidsum1 = countone[0].Repaidsumone[0].total; } else { Repaidsum1 = 0; }
      if (countone[0].Repaidsumtwo[0] != undefined) { Repaidsum2 = countone[0].Repaidsumtwo[0].total; } else { Repaidsum2 = 0; }
      if (countone[0].Repaidsumthree[0] != undefined) { Repaidsum3 = countone[0].Repaidsumthree[0].total; } else { Repaidsum3 = 0; }
      if (countone[0].Repaidsumfour[0] != undefined) { Repaidsum4 = countone[0].Repaidsumfour[0].total; } else { Repaidsum4 = 0; }
      if (countone[0].Repaidsumfive[0] != undefined) { Repaidsum5 = countone[0].Repaidsumfive[0].total; } else { Repaidsum5 = 0; }
      if (countone[0].Repaidsumsix[0] != undefined) { Repaidsum6 = countone[0].Repaidsumsix[0].total; } else { Repaidsum6 = 0; }

      if (countone[0].Rejectedsumone[0] != undefined) { Rejectedsum1 = countone[0].Rejectedsumone[0].total; } else { Rejectedsum1 = 0; }
      if (countone[0].Rejectedsumtwo[0] != undefined) { Rejectedsum2 = countone[0].Rejectedsumtwo[0].total; } else { Rejectedsum2 = 0; }
      if (countone[0].Rejectedsumthree[0] != undefined) { Rejectedsum3 = countone[0].Rejectedsumthree[0].total; } else { Rejectedsum3 = 0; }
      if (countone[0].Rejectedsumfour[0] != undefined) { Rejectedsum4 = countone[0].Rejectedsumfour[0].total; } else { Rejectedsum4 = 0; }
      if (countone[0].Rejectedsumfive[0] != undefined) { Rejectedsum5 = countone[0].Rejectedsumfive[0].total; } else { Rejectedsum5 = 0; }
      if (countone[0].Rejectedsumsix[0] != undefined) { Rejectedsum6 = countone[0].Rejectedsumsix[0].total; } else { Rejectedsum6 = 0; }

      var monthsAndYears = [[thismonth, t], [month1, a], [month2, b], [month3, c], [month4, d], [month5, e]]
      var All = [sum1, sum2, sum3, sum4, sum5, sum6]
      var InProcess = [InProcesssum1, InProcesssum2, InProcesssum3, InProcesssum4, InProcesssum5, InProcesssum6]
      var Disbursed = [Disbursedsum1, Disbursedsum2, Disbursedsum3, Disbursedsum4, Disbursedsum5, Disbursedsum6]
      var Repaid = [Repaidsum1, Repaidsum2, Repaidsum3, Repaidsum4, Repaidsum5, Repaidsum6]
      var Rejected = [Rejectedsum1, Rejectedsum2, Rejectedsum3, Rejectedsum4, Rejectedsum5, Rejectedsum6]

      //getLastPieGraphForAdmin

      var FundedSum = 0;
      var UnderPaidsum = 0;
      var OverPaidsum = 0;
      var FullPaidsum = 0;
      var forcalc = new Date();
      var thismonth = forcalc.getMonth() + 1;
      var t = forcalc.getFullYear();
      var this1 = new Date(t, thismonth - 1, 1);

      var month1 = forcalc.getMonth();
      if (month1 <= 0) {
        month1 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month1);
      var a = forcalc.getFullYear();
      var d1m1 = new Date(a, month1 - 1, 1);
      var laster1 = new Date(a, month1, 0);
      laster1.setHours(23, 59, 59, 0)

      var month2 = forcalc.getMonth() - 1;
      if (month2 <= 0) {
        month2 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month2);
      var b = forcalc.getFullYear();
      var d1m2 = new Date(b, month2 - 1, 1);
      var laster2 = new Date(b, month2, 0);
      laster2.setHours(23, 59, 59, 0);

      var month3 = forcalc.getMonth() - 1;
      if (month3 <= 0) {
        month3 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month3);
      var c = forcalc.getFullYear();
      var d1m3 = new Date(c, month3 - 1, 1);
      var laster3 = new Date(c, month3, 0);
      laster3.setHours(23, 59, 59, 0)

      var month4 = forcalc.getMonth() - 1;
      if (month4 <= 0) {
        month4 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month4);
      var d = forcalc.getFullYear();
      var d1m4 = new Date(d, month4 - 1, 1);
      var laster4 = new Date(d, month4, 0);
      laster4.setHours(23, 59, 59, 0)

      var month5 = forcalc.getMonth() - 1;
      if (month5 <= 0) {
        month5 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month5);
      var e = forcalc.getFullYear();
      var d1m5 = new Date(e, month5 - 1, 1);
      var laster5 = new Date(e, month5, 0);
      laster5.setHours(23, 59, 59, 0)

      var todaydate = new Date();


      var countone = await this.purchaseInvoiceModel.aggregate([{
        $facet: {
          "sumone": [{
            $match: {
              $and: [{ InvoiceDate: { $gte: d1m5, $lte: todaydate } },
              { $or: [{ Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Fully Repaid" }, { Status: "Partially Repaid" }] }
              ],
            }
          }, { $count: "total" }],
          "sumtwo": [{
            $match: {
              $and: [{ InvoiceDate: { $gte: d1m5, $lte: todaydate } },
              { Status: "Fully Repaid" }, { SettleStatus: "UnderPaid" }
              ],
            }
          }, { $count: "total" }],
          "sumthree": [{
            $match: {
              $and: [{ InvoiceDate: { $gte: d1m5, $lte: todaydate } },
              { Status: "Fully Repaid" }, { SettleStatus: "FullPaid" }
              ],
            }
          }, { $count: "total" }],
          "sumfour": [{
            $match: {
              $and: [{ InvoiceDate: { $gte: d1m5, $lte: todaydate } },
              { Status: "Fully Repaid" }, { SettleStatus: "OverPaid" }
              ],
            }
          }, { $count: "total" }],

        }
      }])

      if (countone[0].sumone[0] != undefined) { FundedSum = countone[0].sumone[0].total; } else { FundedSum = 0; }
      if (countone[0].sumtwo[0] != undefined) { UnderPaidsum = countone[0].sumtwo[0].total; } else { UnderPaidsum = 0; }
      if (countone[0].sumthree[0] != undefined) { FullPaidsum = countone[0].sumthree[0].total; } else { FullPaidsum = 0; }
      if (countone[0].sumfour[0] != undefined) { OverPaidsum = countone[0].sumfour[0].total; } else { OverPaidsum = 0; }


      var TotalFunded = FundedSum
      var UnderPaid = UnderPaidsum
      var OverPaid = OverPaidsum
      var FullPaid = FullPaidsum

      //getSecondPieGraphForAdmin

      var forcalc = new Date();
      var thismonth = forcalc.getMonth() + 1;
      var t = forcalc.getFullYear();
      var this1 = new Date(t, thismonth - 1, 1);

      var month1 = forcalc.getMonth();
      if (month1 <= 0) {
        month1 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month1);
      var a = forcalc.getFullYear();
      var d1m1 = new Date(a, month1 - 1, 1);
      var laster1 = new Date(a, month1, 0);
      laster1.setHours(23, 59, 59, 0)

      var month2 = forcalc.getMonth() - 1;
      if (month2 <= 0) {
        month2 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month2);
      var b = forcalc.getFullYear();
      var d1m2 = new Date(b, month2 - 1, 1);
      var laster2 = new Date(b, month2, 0);
      laster2.setHours(23, 59, 59, 0);

      var month3 = forcalc.getMonth() - 1;
      if (month3 <= 0) {
        month3 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month3);
      var c = forcalc.getFullYear();
      var d1m3 = new Date(c, month3 - 1, 1);
      var laster3 = new Date(c, month3, 0);
      laster3.setHours(23, 59, 59, 0)

      var month4 = forcalc.getMonth() - 1;
      if (month4 <= 0) {
        month4 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month4);
      var d = forcalc.getFullYear();
      var d1m4 = new Date(d, month4 - 1, 1);
      var laster4 = new Date(d, month4, 0);
      laster4.setHours(23, 59, 59, 0)

      var month5 = forcalc.getMonth() - 1;
      if (month5 <= 0) {
        month5 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month5);
      var e = forcalc.getFullYear();
      var d1m5 = new Date(e, month5 - 1, 1);
      var laster5 = new Date(e, month5, 0);
      laster5.setHours(23, 59, 59, 0)

      var todaydate = new Date();

      var TotalSum; var Fundedsum;
      var countone = await this.purchaseInvoiceModel.aggregate([{
        $facet: {
          "sumone": [{
            $match: { InvoiceDate: { $gte: d1m5, $lte: todaydate } }
          }, { $count: "total" }],
          "sumtwo": [{
            $match: {
              $and: [{ InvoiceDate: { $gte: d1m5, $lte: todaydate } },
              { $or: [{ Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Fully Repaid" }, { Status: "Partially Repaid" }] }
              ],
            }
          }, { $count: "total" }],

        }
      }])

      if (countone[0].sumone[0] != undefined) { TotalSum = countone[0].sumone[0].total; } else { TotalSum = 0; }
      if (countone[0].sumtwo[0] != undefined) { Fundedsum = countone[0].sumtwo[0].total; } else { Fundedsum = 0; }

      var TotalInvoices = TotalSum
      // var TotalFunded = Fundedsum

      var dashboardData = await this.SupplierAdminDashboardModel.create({
        TotalVendor: TotalVendor.length,
        TotalLenders: TotLender.length,
        TotalHospitals: TotHosp.length,
        TotalUtilizedLimit: TotalUtilizedLimit,
        TotalRepaymentCount: TotRepaymentCount,
        TotalRepaymentsLimit: TotalRepaymentsLimit,
        TotalSanctionLimit: TotalSanctionLimit,
        TotalAvailableLimit: TotalAvailableLimit,
        TotalinvoicesCount: Totalinvoices,
        TotalInvoicesAmount: TotalInvoicesAmount,
        TotalPendingCount: Totalpending,
        TotalPendingAmount: TotalPendingAmount,
        TotalfundedCount: Totalfunded,
        TotalfundedPaidAmount: TotalfundedPaidAmount,
        TotalRejectedCount: Totalrejected,
        TotalRejectedAmount: TotalRejectedAmount,
        getFundedInvoiceGraphToAdmin: getFundedInvoiceGraphToAdmin,
        getLApprovedInvoiceGraphToAdmin: getLApprovedInvoiceGraphToAdmin,
        getInvoiceGraphToAdmin: getInvoiceGraphToAdmin,

        monthsAndYears: monthsAndYears,
        All: All,
        InProcess: InProcess,
        Disbursed: Disbursed,
        Repaid: Repaid,
        Rejected: Rejected,
        TotalFunded: TotalFunded,
        UnderPaid: UnderPaid,
        OverPaid: OverPaid,
        FullPaid: FullPaid,
        TotalInvoices: TotalInvoices,

        jobLastUpdatedOn: new Date().toUTCString()
      });
      return { dashboardData };
    }
    catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  public async getAllHospital(req: Request): Promise<{ data: any }> {
    try {
      var invoices = await this.organizationModel.find({ typeOfOrganization: 'Hospital' });
      if (invoices) {
        var AggregatorInvoices = invoices.length;
      }
      var data = ({ count: AggregatorInvoices, message: invoices })
      return { data };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  public async getAllLenderToAdmin(req: Request): Promise<{ data: any }> {
    try {
      const invoices = await this.userModel.find({ $and: [{ userType: 4 }, { role: 'Lender' }] }).sort({ updateAt: -1 });
      if (invoices) {
        var AggregatorInvoices = invoices.length;
      }
      var data = ({ count: AggregatorInvoices, message: invoices })
      return { data };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  public async getUserByIdToAdmin(req: Request): Promise<{ data: any }> {
    try {
      const Id = req.query._id;
      const usr = await this.userModel.findOne({ _id: Id });
      var data = usr
      return { data };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  public async getAllVendorToAdmin(req: Request): Promise<{ data: any }> {
    try {
      const invoices = await this.organizationModel.find({ typeOfOrganization: "Vendor" });
      if (invoices) {
        var AggregatorInvoices = invoices.length;
      }
      var data = ({ count: AggregatorInvoices, message: invoices })
      return { data };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  public async getPFInvoiceToAdmin(IFilterDTO: IFilterDTO): Promise<{ data: any }> {
    try {
      //pagination
      var pageNumber = 1;
      var pageSize = 0;
      var total: any = {};
      if (IFilterDTO.pageNumber) {
        var pageNumber = IFilterDTO.pageNumber;
      }
      if (IFilterDTO.pageSize) {
        var pageSize = IFilterDTO.pageSize;
      }
      var searchFilters = [];
      // because search filter can't be an empty array
      searchFilters.push({ "_id": { $exists: true } });

      if (IFilterDTO.Status != undefined || null) {
        searchFilters.push({ Status: IFilterDTO.Status });
      }
      if (IFilterDTO.searchTerm != undefined) {
        searchFilters.push({
          $or: [
            { hospitalName: { $regex: IFilterDTO.searchTerm, $options: 'i' } },
            { vendorName: { $regex: IFilterDTO.searchTerm, $options: 'i' } },
            {
              "$expr": {
                "$regexMatch": {
                  "input": { "$toString": "$LoanID" },
                  "regex": IFilterDTO.searchTerm
                }
              }
            }
          ]
        })
      }
      var userCount = await this.purchaseInvoiceModel.find({ $and: searchFilters }).countDocuments();
      var numberOfPages = pageSize === 0 ? 1 : Math.ceil(userCount / pageSize);
      var supplierInvoices = await this.purchaseInvoiceModel
        .find({ $and: searchFilters })
        .sort({ updatedAt: -1 })
        .skip((pageNumber - 1) * pageSize)
        .limit(pageSize);

      var totalAmount = await this.purchaseInvoiceModel.aggregate([{ $match: { $and: searchFilters } }, { $group: { _id: '$_v', totalAmount: { $sum: '$LTVAmount' } } }
      ]);
      if (totalAmount.length != 0) {
        total.count = userCount
        total.totalAmount = totalAmount[0].totalAmount
      } else {
        total.count = 0
        total.totalAmount = 0
      }
      var data = { supplierInvoices, numberOfPages, total };
      return { data };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  public async getPFInvoiceByIdToAdmin(IFilterDTO: IFilterDTO): Promise<{ data: any }> {
    try {
      const invoice = await this.purchaseInvoiceModel.findOne({
        _id: IFilterDTO._id
      });
      var repaymentData;
      if (invoice) {
        repaymentData = await this.TransactionData.find({ invoiceId: invoice._id })
      }
      var data = { invoice, repaymentData };
      return { data };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  public async editPFInvoiceByAdmin(IFilterDTO: IFilterDTO, ISupplierInvoiceDTO: ISupplierInvoiceDTO): Promise<{ data: any }> {
    try {
      const id = IFilterDTO._id;
      await this.purchaseInvoiceModel.findOne({ _id: id });
      let invoiceData: any = {};
      if (ISupplierInvoiceDTO.Status == true) {
        invoiceData.Status = 'DSPL Approved';
      } else {
        invoiceData.Status = 'DSPL Rejected';
      }
      invoiceData.updatedAt = new Date().toUTCString();
      invoiceData.DresponseDate = new Date().toUTCString()
      // invoiceData.updatedBy = currentUser._id;

      const invoice = await this.purchaseInvoiceModel.findByIdAndUpdate(
        { _id: id },
        { $set: invoiceData },
        { useFindAndModify: false, new: true },
      );
      var data = { success: true, message: invoice };
      return { data };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
}
