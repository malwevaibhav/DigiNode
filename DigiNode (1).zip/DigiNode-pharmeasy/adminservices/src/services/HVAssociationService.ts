import { Service, Inject } from 'typedi';
import { Request, Response } from 'express';
import { IFilterDTO, HVAssociationDTO } from '../interfaces/IUser';
import { Types } from 'mongoose';

@Service()
export default class  HVAssociationService {
    constructor(
        @Inject('HVAssociationModel') private HVAssociationModel: Models.HVAssociationModel,
        @Inject('logger') private logger,
    ) { }

    public async getAssociations(IFilterDTO: IFilterDTO): Promise<{ data: any }> {
        try {
            var pageNumber = 1;
            var pageSize = 0;
            if (IFilterDTO.pageNumber) {
                var pageNumber = IFilterDTO.pageNumber;
            }
            if (IFilterDTO.pageSize) {
                var pageSize = IFilterDTO.pageSize;
            }
            var searchFilters = [];
            searchFilters.push({ isDeleted: false });
            if (IFilterDTO.searchTerm != undefined) {
                searchFilters.push({
                  $or: [
                    { hospitalName: { $regex: IFilterDTO.searchTerm, $options: 'i' } },
                    { vendorName: { $regex: IFilterDTO.searchTerm, $options: 'i' } }
                  ]
                })
              }

            var userCount = await this.HVAssociationModel.find({ $and: searchFilters }).countDocuments();
            var numberOfPages = pageSize === 0 ? 1 : Math.ceil(userCount / pageSize);

            var HVAssociations = await this.HVAssociationModel.find({ $and: searchFilters }).sort({ createdAt: -1 }).skip((pageNumber - 1) * pageSize).limit(pageSize);

            var data = { success: true, HVAssociations, numberOfPages };
            return { data };
        }
        catch (error) {
            this.logger.error(error);
            throw error;
        }
    }
    public async updateAssociation(HVAssociationDTO: HVAssociationDTO): Promise<{ data: any }> {
        try {
            const associationDetails = await this.HVAssociationModel.findOne({
                hospitalId: Types.ObjectId(HVAssociationDTO.hospitalId),
                vendorId: Types.ObjectId(HVAssociationDTO.vendorId)
            })
            if (associationDetails) {
                var data = { success: true, message: "Association already exists" }
                return { data };
            }

            const association = await this.HVAssociationModel.create(
                {
                    hospitalName: HVAssociationDTO.hospitalName,
                    vendorName: HVAssociationDTO.vendorName,
                    hospitalId: HVAssociationDTO.hospitalId,
                    vendorId: HVAssociationDTO.vendorId,
                }
            );
            var data = { success: true, message: "Association Updated Successfully" }
            return { data };
        }
        catch (error) {
            this.logger.error(error);
            throw error
        }
    }
    public async deleteAssociation(IFilterDTO: IFilterDTO): Promise<{ data: any }> {
        try {
            const partner = await this.HVAssociationModel.findByIdAndUpdate(
                { _id: IFilterDTO._id },
                { $set: { isDeleted: true } },
                { useFindAndModify: false, new: true },
            );
            var data = { success: true, message: "Association Deleted Successfully" }
            return { data };
        }
        catch (error) {
            this.logger.error(error);
            throw error
        }
    }
}