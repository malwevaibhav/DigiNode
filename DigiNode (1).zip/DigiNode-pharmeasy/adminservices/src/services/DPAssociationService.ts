import { Service, Inject } from 'typedi';
// import { Request, Response } from 'express';
import { IFilterDTO, HVAssociationDTO, DPAssociationDTO } from '../interfaces/IUser';
import { Types } from 'mongoose';
import { IUser } from '../interfaces/IUser'; 

@Service()
export default class DPAssociationService {
  IUser: any;
  constructor(
    // @Inject('HVAssociationModel') private HVAssociationModel: Models.HVAssociationModel,
    @Inject('DPAssociationModel') private DPAssociationModel: Models.DPAssociationModel,
    // @Inject('IUser') private IUser: Models.UserModel,
    @Inject('userModel') private userModel: Models.UserModel,

    @Inject('logger') private logger,
  ) { }

  public async getAssociations(IFilterDTO: IFilterDTO): Promise<{ data: any }> {
    try {
      var pageNumber = 1;
      var pageSize = 0;
      if (IFilterDTO.pageNumber) {
        var pageNumber = IFilterDTO.pageNumber;
      }
      if (IFilterDTO.pageSize) {
        var pageSize = IFilterDTO.pageSize;
      }
      var searchFilters = [];
      searchFilters.push({ isDeleted: false });
      if (IFilterDTO.searchTerm != undefined) {
        searchFilters.push({
          $or: [
            { hospitalName: { $regex: IFilterDTO.searchTerm, $options: 'i' } },
            { vendorName: { $regex: IFilterDTO.searchTerm, $options: 'i' } },
          ],
        });
      }

      var userCount = await this.DPAssociationModel.find({ $and: searchFilters }).countDocuments();
      var numberOfPages = pageSize === 0 ? 1 : Math.ceil(userCount / pageSize);

      var DPAssociations = await this.DPAssociationModel.find({ $and: searchFilters })
        .sort({ createdAt: -1 })
        .skip((pageNumber - 1) * pageSize)
        .limit(pageSize);

      var data = { success: true, DPAssociations, numberOfPages };
      return { data };
    } catch (error) {
      this.logger.error(error);
      throw error;
    }
  }
  public async addDistributor(DPAssociationDTO: DPAssociationDTO): Promise<{ data: any }> {

    const associationDetails = await this.DPAssociationModel.findOne({
      distributorId: Types.ObjectId(DPAssociationDTO.distributorId),
    });
    try {
      if (associationDetails == null) {
        const association = await this.DPAssociationModel.create({
          distributorName: DPAssociationDTO.distributorName,
          PmanufactureName: DPAssociationDTO.PmanufactureName,
          distributorId: DPAssociationDTO.distributorId,
          PmanufactureId: DPAssociationDTO.PmanufactureId,
          AvailableLimit: DPAssociationDTO.AvailableLimit,
          creditLimit: DPAssociationDTO.AvailableLimit,
          

        });
        var data = { success: true, message: 'Association Updated Successfully', resp: association };
        return { data };
      }
      else {
        let data = { success: true, message: "Association already exists" }
        return { data };
      }
    }


    catch (error) {

      this.logger.error(error);
      throw error
    }
  }

  public async deleteAssociation(IFilterDTO: IFilterDTO): Promise<{ data: any }> {
    try {
      const partner = await this.DPAssociationModel.findByIdAndUpdate(
        { _id: IFilterDTO._id },
        { $set: { isDeleted: true } },
        { useFindAndModify: false, new: true },
      );
      var data = { success: true, message: 'Association Deleted Successfully' };
      return { data };
    } catch (error) {
      this.logger.error(error);
      throw error;
    }
  }

  public async distLimitByAdmin(dPAssociationDTO: DPAssociationDTO, IUser: IUser) {
    try {

      var objectId = Types.ObjectId(dPAssociationDTO.PmanufactureId)
      const limit = await this.DPAssociationModel.aggregate([
        {
          $match: {
            PmanufactureId: objectId
          },
        },
        {

          $group:
          {
            _id: null,
            Pmanufacture_Limit: { $sum: "$AvailableLimit" },
          }
        },
        {
          $project: {
            _id: 0,
            Pmanufacture_Limit: 1
          }
        },
      ])
      let pvendorLimitValue = limit[0].Pmanufacture_Limit
       
      const rr = await this.userModel.updateOne({
        organizationId: objectId
      },
       {
        $set: {
          AvailableLimit: pvendorLimitValue
        }
      });
      // let updatedLimit = await this.userModel.aggregate([
      //   {
      //     $match: {
      //       _id: objectId
      //     },
      //   },
      //   {
      //     $set: {
      //       AvailableLimit: pvendorLimitValue
      //     }
      //   },
      //   {
      //     $out: "users"
      //   },
      // ])
   
      return {
        data: {
          success: true,
          message: "Limit Updated Successfully",
          PmanufactureLimit: pvendorLimitValue
        }
      }

    }
    catch (error) {
      this.logger.error(error);
      return {
        data: { success: false, error: error }
      }
    }
  }
}
