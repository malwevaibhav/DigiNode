import { Service, Inject } from 'typedi';
import { Request, Response } from 'express';
import axios from 'axios'
import { count } from 'console';
import { IFilterDTO } from '@/interfaces/IUser';
const BG_URL = process.env.BG_URL;
@Service()
export default class bimaGarageService {
  constructor(
    @Inject('BgCasesModel') private BgCasesModel: Models.BgCasesModel,
    @Inject('logger') private logger,
    @Inject('userModel') private userModel: Models.UserModel,
  ) { }


  public async getDashboardForBimaGarage(IFilterDTO:IFilterDTO): Promise<{ BemagarageLocalDash: any }> {
    try {
      //dashboar api 
      // var pageNumber = 1;
      // var pageSize = 0;
      // if (IFilterDTO.pageNumber) {
      //   var pageNumber = IFilterDTO.pageNumber;
      // }
      // if (IFilterDTO.pageSize) {
      //   var pageSize = IFilterDTO.pageSize;
      // }

    var Totalcases = 0;
    var update1Count=0;
    var update1Cases = 0;

    var update2Count=0;
    var update2Cases = 0;

    var update3Count=0;
    var update3Cases = 0;

    var update4Count=0;
    var update4Cases = 0;

    var update5Count=0;
    var update5Cases = 0;

    var update6Count=0;
    var update6Cases = 0;

    var update7Count=0;
    var update7Cases = 0;
    var update8Count=0;
    var update8Cases = 0;
    var update9Count=0;
    var update9Cases = 0;

    var settlementAmt=0
    var PendingSettlementAmt=0

    var numberOfPages=0

    let TotalHospital:any = await this.userModel.find({"BGHospitalId":{$exists:true}}).count()
     
    var countone = await this.BgCasesModel.aggregate([
      {
        $facet: {
          totalbimacase: [{ $match: {} }, { $count: "total" }],

          

           setteleAmt:[
           { $match: {} },{$group:{_id: 0,total: { $sum: {$toDouble: "$expense_total"}}}}],

           penddingSetteleAmt:[{ $match: {} },{$group:{_id: 0,total: { $sum: {$toDouble: "$fappr_amt"}}}}],

          update1No: [
            {
              $match: {
                $or: [
                  { claim_status: "Preauth Initiated" },
                ],
              },
            },
            { $count: "total" }
          ],
          update1Users: [
            {
              $match: {
                $or: [
                  { claim_status: "Preauth Initiated" },
        
                ],
              },
            },{$group:{_id: 0,total: { $sum: {$toDouble: "$preauth_iniamt"}}}}
            // { $skip: (pageNumber - 1) * pageSize },
            // { $limit: pageSize },         
          ],

          update2No: [
            {
              $match: {
                $or: [
                  { claim_status: "PreAuth Approved" },
                ],
              },
            },
            { $count: "total" }
          ],
          update2Users: [
            {
              $match: {
                $or: [
                  { claim_status: "PreAuth Approved" },
        
                ],
              },
            },{$group:{_id: 0,total: { $sum: {$toDouble: "$preauth_apamt"}}}}         
          ],

          update3No: [
            {
              $match: {
                $or: [
                  { claim_status: "Final Approval Initiated" },
                ],
              },
            },
            { $count: "total" }
          ],
          update3Users: [
            {
              $match: {
                $or: [
                  { claim_status: "Final Approval Initiated" },
        
                ],
              },
            }  ,{$group:{_id: 0,total: { $sum: {$toDouble: "$expense_total"}}}}       
          ],

          update4No: [
            {
              $match: {
                $or: [
                  { claim_status: "Final Approval Received" },
                ],
              },
            },
            { $count: "total" }
          ],
          update4Users: [
            {
              $match: {
                $or: [
                  { claim_status: "Final Approval Received" },
        
                ],
              },
            } ,{$group:{_id: 0,total: { $sum: {$toDouble: "$fappr_amt"}}}}        
          ],

          update5No: [
            {
              $match: {
                $or: [
                  { claim_status: "File Dispatched" },
                ],
              },
            },
            { $count: "total" }
          ],
          update5Users: [
            {
              $match: {
                $or: [
                  { claim_status: "File Dispatched" },
        
                ],
              },
            }         
          ],

          update6No: [
            {
              $match: {
                $or: [
                  { claim_status: "Claim Settled" },
                ],
              },
            },
            { $count: "total" }
          ],
          update6Users: [
            {
              $match: {
                $or: [
                  { claim_status: "Claim Settled" },
        
                ],
              },
            }         
          ],
          update7No: [
            {
              $match: {
                $or: [
                  { claim_status: "Query Pending" },
                ],
              },
            },
            { $count: "total" }
          ],
          update7Users: [
            {
              $match: {
                $or: [
                  { claim_status: "Query Pending" },
        
                ],
              },
            }         
          ],
          update8No: [
            {
              $match: {
                $or: [
                  { claim_status: "New" },
                ],
              },
            },
            { $count: "total" }
          ],
          update8Users: [
            {
              $match: {
                $or: [
                  { claim_status: "New" },
        
                ],
              },
            }  ,{$group:{_id: 0,total: { $sum: {$toDouble: "$deposit_amount"}}}}       
          ],
          update9No: [
            {
              $match: {
                $or: [
                  { disbstatus: "Loan Disbursed" },
                ],
              },
            },
            { $count: "total" }
          ],
          update9Users: [
            {
              $match: {
                $or: [
                  { disbstatus: "Loan Disbursed" },
        
                ],
              },
            } ,{$group:{_id: 0,total: { $sum: {$toDouble: "$loanamt"}}}}        
          ],

        }
      }
    ])

    // var numberOfPages = pageSize === 0 ? 1 : Math.ceil( countone[0].update1No[0].total/ pageSize)

    if(countone[0].totalbimacase[0]!=undefined){
      Totalcases = countone[0].totalbimacase[0].total;
    } else{
      Totalcases=0
    }

    if(countone[0].update1No[0]!=undefined){
      update1Count = countone[0].update1No[0].total
    }else{
      update1Count=0
    }
    if(countone[0].update1Users[0]!=undefined){
      update1Cases = countone[0].update1Users[0].total
    }else{
      update1Cases=0
    }

    if(countone[0].update2No[0]!=undefined){
      update2Count = countone[0].update2No[0].total
    }else{
      update2Count=0
    }
    if(countone[0].update2Users[0]!=undefined){
      update2Cases = countone[0].update2Users[0].total
    }else{
      update2Cases=0
    }

    if(countone[0].update3No[0]!=undefined){
      update3Count = countone[0].update3No[0].total
    }else{
      update3Count=0
    }
    if(countone[0].update3Users[0]!=undefined){
      update3Cases = countone[0].update2Users[0].total
    }else{
      update3Cases=0
    }

    if(countone[0].update4No[0]!=undefined){
      update4Count = countone[0].update4No[0].total
    }else{
      update4Count=0
    }
    if(countone[0].update4Users[0]!=undefined){
      update4Cases = countone[0].update4Users[0].total
    }else{
      update4Cases=0
    }

    if(countone[0].update5No[0]!=undefined){
      update5Count = countone[0].update5No[0].total
    }else{
      update5Count=0
    }
    if(countone[0].update5Users[0]!=undefined){
      update5Cases = countone[0].update5Users
    }else{
      update5Cases=0
    }

    if(countone[0].update6No[0]!=undefined){
      update6Count = countone[0].update6No[0].total
    }else{
      update6Count=0
    }
    if(countone[0].update6Users[0]!=undefined){
      update6Cases = countone[0].update6Users
    }else{
      update6Cases=0
    }
    if(countone[0].update7No[0]!=undefined){
      update7Count = countone[0].update7No[0].total
    }else{
      update7Count=0
    }
    if(countone[0].update7Users[0]!=undefined){
      update7Cases = countone[0].update7Users
    }else{
      update7Cases=0
    }
    if(countone[0].update8No[0]!=undefined){
      update8Count = countone[0].update8No[0].total
    }else{
      update8Count=0
    }
    if(countone[0].update8Users[0]!=undefined){
      update8Cases = countone[0].update8Users[0].total
    }else{
      update8Cases=0
    }
    if(countone[0].update9No[0]!=undefined){
      update9Count = countone[0].update9No[0].total
    }else{
      update9Count=0
    }
    if(countone[0].update9Users[0]!=undefined){
      update9Cases = countone[0].update9Users[0].total
    }else{
      update9Cases=0
    }
    if(countone[0].setteleAmt[0]!=undefined){
      settlementAmt = countone[0].setteleAmt[0].total
    }else{
      settlementAmt=0
    }

    if(countone[0].penddingSetteleAmt[0]!=undefined){
      PendingSettlementAmt = countone[0].penddingSetteleAmt[0].total
    }else{
      PendingSettlementAmt=0
    }
if(TotalHospital){
  TotalHospital=TotalHospital
}else{
  TotalHospital=0
}
    var BemagarageLocalDash = {
      date:{
        Totalcases:Totalcases,
        TotalHospital:TotalHospital,
        "Preauth_Initiated_count":update1Count,
        "Preauth_Initiated_cases":update1Cases,
        
        "PreAuth_Approved_Count":update2Count,
        "PreAuth_Approved_Cases":update2Cases,

        "Final_Approval_Initiated_Count":update3Count,
        "Final_Approval_Initiated_Cases":update3Cases,

        "Final_Approval_Received_Count":update4Count,
        "Final_Approval_Received_Cases":update4Cases,

        "File_Dispatched_Count":update5Count,
        "File_Dispatched_Cases":update5Cases,

        "Claim_Settled_Count":update6Count,
        "Claim_Settled_Cases":update6Cases,


        "Query_Pending_Count":update7Count,
        "Query_Pending_Cases":update7Cases,
        "New_Count":update8Count,
        "New_Cases":update8Cases,
        "Disbursed_Count":update9Count,
        "Disbursed_Cases":update9Cases,

        settlementAmt:settlementAmt,
        PendingSettlementAmt:PendingSettlementAmt,
      } 
    };
      return { BemagarageLocalDash };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }

  }

  public async token() {
    let url = `${BG_URL}/api/token/`
    let userinfo = {
      "username": "digisparsh-api",
      "password": "Digi@1234"
    }
    let token = await axios.post(url, userinfo)

    return token.data.access
  }

    //dashboar api of Bimamgarage (Case Statistics)
  public async getDashofBG(): Promise<{ data: any }> {
    let url = `${BG_URL}/external/api/case-stats/`
    let access_token = await this.token();
    let Response = await axios.get(url, {
      headers: {
        'Authorization': `Bearer ${access_token}`
      }
    })

    return Response.data

  }
  public async getDashofBimagarage(): Promise<{data:any}>{
    let data:any={};
try {

  let TotalHospital = this.userModel.find({"BGHospitalId":{$exists:true}}).count()
  if(TotalHospital){
    data.TotalHospital=TotalHospital
  }else
  {
    data.TotalHospital=0
  }
  let caselist= this.BgCasesModel.aggregate([{
    $facet: {
      totalbimacase: [{ $match: {} }, { $count: "total" }],
    
    
    
    }

  }]);
  
} catch (error) {
  console.log(error);
  return error
  
}





return {data}
  }
}
