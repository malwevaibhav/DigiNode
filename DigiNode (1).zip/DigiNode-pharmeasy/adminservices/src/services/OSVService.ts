import { Service, Inject } from 'typedi';
import { IOSVDTO, IUser } from '../interfaces/IUser';

@Service()
export default class adminSidebarService {
    constructor(
        @Inject('OSVModel') private OSVModel: Models.OSVModel,
        @Inject('logger') private logger,
    ) { }

    public async getOSVDetails(): Promise<{ data: any }> {
        try {
            const usr = await this.OSVModel.find();
            return { data: { success: true, osvDetails: usr[0] } };
        } catch (e) {
            this.logger.error(e);
            throw e;
        }
    }
    public async updateOSVDetails(IOSVDTO: IOSVDTO, currentUser: IUser): Promise<{ data: any }> {
        try {
            const osvDetails = await this.OSVModel.findByIdAndUpdate(
                { _id: IOSVDTO._id },
                { $set: IOSVDTO, updatedBy: currentUser._id },
                { useFindAndModify: false, upsert: true, new: true },
            );
            if (!osvDetails) {
                throw new Error('OSV Details cannot be updated');
            }

            var data = { success: true, osvDetails };
            return { data };
        } catch (error) {
            this.logger.error(error);
            return {
                data: { success: false, error: error },
            };
        }
    }
}
