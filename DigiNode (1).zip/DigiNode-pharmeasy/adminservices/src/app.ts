import 'reflect-metadata'; // We need this in order to use @Decorators

import config from './config';

import express from 'express';

import Logger from './loaders/logger';

async function startServer() {
  const app = express();
  // let http = require("http").Server(app);
  // let io = require("socket.io")(http);
  /**
   * A little hack here
   * Import/Export can only be used in 'top-level code'
   * Well, at least in node 10 without babel and at the time of writing
   * So we are using good old require.
   **/
  await require('./loaders').default({ expressApp: app });

  // http
  app
  .listen(config.port, () => {
    Logger.info(`
    ######################################################################
      ✌️✌️   Server listening on port: ${config.port} for AdminServices ✌️✌️ 
      ####################################################################
    `);
  }).on('error', err => {
    Logger.error(err);
    process.exit(1);
  });
//   io.on('connection', function(socket) {
//     console.log('New client connected with id in admin AdminServices = ', socket.id);
//     socket.on('disconnect', function(reason) {
//         console.log('A client disconnected with id = ', socket.id, " reason ==> ", reason);
//     });
//     socket.on("join", message => {
//       console.log("Message Received: " + message);
//       io.emit("message", { type: "new-message", text: message });
//     });
// });

// app.set('socketio', io)
}

startServer();
