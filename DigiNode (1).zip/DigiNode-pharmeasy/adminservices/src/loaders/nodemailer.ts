import nodemailer from 'nodemailer'
import toCsv from 'to-csv'
import * as cron from 'node-cron'

//const cronJob = CronJob;

export default class MailerService {
    cronJob: any;

    // public async sendMailForPatient(invoiceId, uploadfile) {


    //     const transporter = nodemailer.createTransport({
    //         service: 'outlook',
    //         auth: {
    //             user: 'connect@digisparsh.in',
    //             pass: 'Digisparsh@2022',
    //         },
    //     });
    //     const specification = {
    //         from: 'connect@digisparsh.in',
    //         to: 'mahesh.pawar@moreyeahs.in',
    //         subject: `Invoice no ${invoiceId} : Claim finance alert: Pending Approval New Case`,
    //          html: `<h4>Dear Ops Team,</h4></br><p>A new Claim finance case Invoice no <span style="color:#008F99;">${invoiceId}</span> is pending for your approval.</p>
    //          <p>Kindly login and approve the same.</p>
    //          <p>Or Pls click the below link for your approval.</p>
    //          <a href="https://portal.digisparsh.in/Select">https://portal.digisparsh.in/Select</a>
          
    //          <h4>Regards</h4>
    //          <h4>Tech team</h4>`,
    //          attachments: [
    //             // { 
    //             //     filename: 'how_to_add_summernote_editor_in_laravel.png',
    //             //     content: json2csv(content)
    //             // }
    //         ] 
    //     };
    //     // this.cronJob = new cronJob('* 1 * * * *', async () => {

    //     cron.schedule(' 45 * * * *', () => {

    //         try {
    //             transporter.sendMail(specification, (err, result) => {
    //                 if (err) {
    //                     console.log(err);
    //                 }
    //                 console.log('sent:' + result.response);
    //             });
    //         } catch (e) {
    //             console.log('ERRR = ', e);
    //             throw e;
    //         }
    //     })

    //     // })

    // }
}

