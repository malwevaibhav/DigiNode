import config from '../config';
import EmailSequenceJob from '../jobs/emailSequence';
import Agenda from 'agenda';
import dashboardDataJob from '../jobs/dashboardDataJob';
import claimDueDateJob from '../jobs/claimDueDateJob';
import dailyReportJob from '../jobs/dailyReportJob';

export default ({ agenda }: { agenda: Agenda }) => {
  agenda.define(
    'send-email',
    { priority: 'high', concurrency: config.agenda.concurrency },
    // @TODO Could this be a static method? Would it be better?
    new EmailSequenceJob().handler,
  );
  agenda.define(
    'updateDashboardData',
    {priority: 'high', concurrency: config.agenda.concurrency},
    new dashboardDataJob().handler,
  );

  agenda.define(
    'claimDueDateJob',
    {priority: 'high', concurrency: config.agenda.concurrency},
    new claimDueDateJob().handler,
  );
  agenda.define(
    'dailyReportJob',
    {priority: 'high', concurrency: config.agenda.concurrency},
    new dailyReportJob().handler,
  );

  (async function() {
    await agenda.start();
    await agenda.every('1 hour', "updateDashboardData", {},{ timezone: "Asia/Kolkata"})
    await agenda.every('24 hours',"claimDueDateJob", {},{ timezone: "Asia/Kolkata"})
    await agenda.every('0 21 * * *',"dailyReportJob", {},{ timezone: "Asia/Kolkata"})
  })();
};
