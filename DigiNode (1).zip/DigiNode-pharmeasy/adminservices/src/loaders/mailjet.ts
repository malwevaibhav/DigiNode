const mailjet = require('node-mailjet')
    .connect(process.env.MJ_APIKEY_PUBLIC, process.env.MJ_APIKEY_PRIVATE)

import { Service } from 'typedi';

@Service()
export default class MailJetService {
    constructor(
    ) { }

    public async SendWelcomeEmail(user) {
        const request = mailjet
            .post("send", { 'version': 'v3.1' })
            .request({
                "Messages": [
                    {
                        "From": {
                            "Email": process.env.MJ_FROM_EMAIL,
                            "Name": process.env.MJ_FROM_NAME
                        },
                        "To": [
                            {
                                "Email": user.email,
                                "Name": user.name
                            }
                        ],
                        "Subject": "Welcome To Digisparsh.",
                        "TextPart": "My first Mailjet email",
                        "HTMLPart": `<!DOCTYPE html>
                        <html lang="en">
                        <head>
                            <meta charset="UTF-8">
                            <meta http-equiv="X-UA-Compatible" content="IE=edge">
                            <meta name="viewport" content="width=device-width, initial-scale=1.0">
                            <link rel="preconnect" href="https://fonts.googleapis.com">
                        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
                        <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@500;700&display=swap" rel="stylesheet">
                            <title>Document</title>
                        </head>
                        <body style="margin: 0px; padding: 0px;">
                            <div  style="width: 100%; height: 100vh;display: flex; justify-content: center;" cellpadding="0" cellspacing="0">
                                <div style="width: 25%; align-self:center;padding: 50px 50px; box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
                                transition: 0.3s;">
                                    <div style="display: flex;justify-content: center;background-color: #ECF6F6;">
                                        <img style="display:block; line-height:0px; font-size:0px; border:0px;width: 396px;
                                        margin-bottom: 50px ;" src="https://uatresource.blob.core.windows.net/uatcontainer/Frame%207573.png" width="109" height="103" alt="logo">
                                    </div>
                            
                        <div style="
                        font-family: 'DM Sans',sans-serif;
                        font-style: normal;
                        font-weight: 700;
                        font-size: 22px;
                        line-height: 29px;
                        text-transform: capitalize;
                        ;
                        ">
                            <h4 style="margin: 0px;">Hello</h4>
                            <h4 style="margin: 4px 0px">Yash Verma</h4>
                        
                           <span style="font-family: 'DM Sans',sans-serif;
                           font-style: normal;
                           font-weight: 500;
                           font-size: 15px;
                           line-height: 20px; color: #ACACAC" >Here are your password reset instructions.</span> 
                           <hr>
                        </div>
                        
                        <div style="display: flex;text-align: justify;font-family: 'DM Sans',sans-serif;
                        font-style: normal;
                        font-weight: 500;
                        font-size: 15px;
                        line-height: 20px;">
                            You are receiving this email because you requested for a password reset for your DigiSparsh account. Click on the link below to set a new password.
                        </div>
                        <div style="display: flex;justify-content: center;font-family: 'DM Sans',sans-serif;
                        font-style: normal;
                        font-weight: 500;
                        font-size: 15px;
                        line-height: 20px; margin: 35px 0px;">
                            <a style="display: block;
                            width: 115px;
                            height: 25px;
                            background: #4E9CAF;
                            padding: 10px;
                            text-align: center;
                            border-radius: 5px;
                            color: white;
                            font-weight: bold;
                            line-height: 25px;" >Reset Password</a>
                        </div>
                        <div style="
                        font-family: 'DM Sans',sans-serif;
                        font-style: normal;
                        font-weight: 700;
                        font-size: 22px;
                        line-height: 29px;
                        text-transform: capitalize;
                        ;
                        ">
                             <h4 style="margin: 0px;">Thank you,</h4>
                            <h4 style="margin: 4px 0px">Team DigiSparsh</h4>
                        </div>
                        
                        <div style="font-family: 'DM Sans',sans-serif;display: flex;text-align: justify;
                        font-style: normal;
                        font-weight: 500;
                        font-size: 15px;
                        line-height: 20px; color: #ACACAC">
                           Alternatively, you can copy and paste the following link in your browser. <a href="">link</a>
                           
                        </div>
                        <br><br>
                        <div style="font-family: 'DM Sans',sans-serif;display: flex;text-align: justify;
                        font-style: normal;
                        font-weight: 500;
                        font-size: 15px;
                        line-height: 20px; color: #ACACAC">
                            If you did not make this request, please ignore this email - we have not changed your password.
                        </div>
                        
                        
                        
                                </div>
                              
                        
                            </div>
                        </body>
                        </html>`,
                        "CustomID": "AppGettingStartedTest"
                    }
                ]
            })
        request
            .then((result) => {
                console.log(result.body)
            })
            .catch((err) => {
                console.log(err.statusCode)
            })
    }
}




