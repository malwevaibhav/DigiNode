const amqplib = require('amqplib/callback_api');
// RabbitMQ Producer
let producerChannel;
amqplib.connect('amqp://localhost',{timeout: 200000}, function (error, connection) {
  if (error) {
    throw error;
  }
  connection.createChannel(function (error1, channel) {
    if (error1) {
      throw error1;
    }
    producerChannel = channel
  });

});

const pushToQueue = async (msg) => {
  try {
    producerChannel.assertQueue('digioQueue', {
      durable: true
    });
    producerChannel.sendToQueue('digioQueue', Buffer.from(msg), {
      persistent: true
    });
    console.log("Sent '%s'", msg);

  } catch (e) {
    console.log(e);
    throw e;
  }
}

export default pushToQueue;