
import { Router, Request, Response, NextFunction, query } from 'express';
import { Container } from 'typedi';
import digioService from '../../services/digioService';
import { Logger } from 'winston';
var fs = require('fs');
var multer = require('multer');
var path = require('path')
const storage_V2 = multer.memoryStorage()
const route = Router();
const uploadBuffer = multer({
    storage: storage_V2,
    limits: { fieldSize: 10 * 1024 * 1024 },
  },
  
  )
export default (app: Router) => {
    app.use('/digio', route);
    route.post('/updateMandateStatus',
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('digio/updateMandateStatus: %o', req.body);
            try {
                const digioServiceInstance = Container.get(digioService);
                const { success } = await digioServiceInstance.updateMandateStatus(req);
                return res.status(200).json({ success });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.post('/updateAgreementStatus',
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('digio/updateAgreementStatus: %o', req.body);
            try {
                const digioServiceInstance = Container.get(digioService);
                const { success } = await digioServiceInstance.updateAgreementStatus(req);
                return res.status(200).json({ success });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.post('/updateKYCStatus',
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('digio/updateKYCStatus: %o', req.body);
            try {
                const digioServiceInstance = Container.get(digioService);
                const { success } = await digioServiceInstance.updateKYCStatus(req);
                return res.status(200).json({ success });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.post('/updateDebitStatus',
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('digio/updateDebitStatus: %o', req.body);
            try {
                const digioServiceInstance = Container.get(digioService);
                const { success } = await digioServiceInstance.updateDebitStatus(req);
                return res.status(200).json({ success });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.get('/getMantateDetails',
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('digio/getMantateDetails: %o', req.query);
            try { 
                const invoiceId= Number(req.query.invoiceId)
                const mandate_id:string= req.query.mandate_id.toString()
                const digioServiceInstance = Container.get(digioService);
                const data = await digioServiceInstance.getMandateDetails(invoiceId,mandate_id);
                return res.status(200).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.get('/updateMandate',
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('digio/updateMandate: %o', req.query);
            try { 
              
                const digioServiceInstance = Container.get(digioService);
                const data = await digioServiceInstance.updateMandate();
                return res.status(200).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.post('/mailSendTOLendor',
    uploadBuffer.fields([
        { name: 'Mandate_Details' },
      ]),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('digio/mailSendTOLendor: %o', req.query);
            try { 
              
                const digioServiceInstance = Container.get(digioService);
                const data = await digioServiceInstance.mailSendTOLendor(req.body);
                return res.status(200).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
};
