
import { Router, Request, Response, NextFunction } from 'express';
import { Container } from 'typedi';
import digiService from '../../services/digiService';
import nodeMailerService from '../../loaders/nodemailer';
import { ILeadDTO, IFilterDTO, IUser } from '../../interfaces/IUser';
import { celebrate, Joi, errors } from 'celebrate';
import { Logger } from 'winston';

import util from 'util' 
const gc = require('../GCP/gcp')
const bucket = gc.bucket('digisparsh_images')
var fs = require('fs');
var multer = require('multer');
var path = require('path')


const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'uploads/')
    },
    filename: function (req, file, cb) {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9)
        cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname))
    }
})

const upload = multer({
    storage: storage,
    limits: { fieldSize: 10 * 1024 * 1024 }
})


// This is for google cloud platform!!
const storage_V2 = multer.memoryStorage()
const uploadBuffer = multer({
    storage: storage_V2,
    limits: { fieldSize: 10 * 1024 * 1024 },
},
)

const uploadImage = (file) => new Promise((resolve, reject) => {
    const { originalname, buffer } = file

    const blob = bucket.file(Date.now().toString()+originalname.replace(/ /g, "_"))
    const blobStream = blob.createWriteStream({
        resumable: false
    })

    var blobb = blobStream.on('finish', () => {
        const publicUrl = util.format(
            `https://storage.googleapis.com/${bucket.name}/${blob.name}`
        )
        console.log(publicUrl)
        resolve(publicUrl)

    })
        .on('error', (err) => {
            reject(`Unable to upload image, something went wrong=>${err}`)
        })
        .end(buffer)

})




const route = Router();

export default (app: Router) => {
    app.use('/digisparsh', route);
    // route.post('/createNewLead',
    //     celebrate({
    //         body: Joi.object({
    //             leadType: Joi.string().required().valid('Patient', 'Hospital', 'Partner', 'Contact'),
    //             name: Joi.string().required(),
    //             contactNumber: Joi.string().required().min(10).max(10).pattern(/^[0-9]+$/).required(),
    //             altContactNumber: Joi.string().required().min(10).max(10).pattern(/^[0-9]+$/).required(),
    //             email: Joi.string().required().regex(/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/),
    //             address: Joi.string(),
    //             isInsured: Joi.boolean().when('leadType', { is: 'Patient', then: Joi.required(), otherwise: Joi.forbidden() }),
    //             insuranceName: Joi.string().when('isInsured', { is: true, then: Joi.required(), otherwise: Joi.forbidden() }),
    //             financialAssistance: Joi.string().when('isInsured', { is: false, then: Joi.required(), otherwise: Joi.forbidden() }),
    //             specialty: Joi.string().when('leadType', { is: 'Hospital', then: Joi.required(), otherwise: Joi.forbidden() }),
    //             product: Joi.string().valid('Invoice Claim Financing', 'Supplier Financing').when('leadType', { is: 'Hospital', then: Joi.required(), otherwise: Joi.forbidden() }),
    //             cashlessClaimFinancing: Joi.boolean().when('product', { is: 'Invoice Claim Financing', then: Joi.required(), otherwise: Joi.forbidden() }),
    //             message: Joi.string().when('leadType', { is: 'Contact', then: Joi.required(), otherwise: Joi.forbidden() }),
    //         }),
    //     }),
    //     async (req: Request, res: Response, next: NextFunction) => {
    //         const logger: Logger = Container.get('logger');
    //         logger.debug('Calling createNewLead: %o', req.body);
    //         try {
    //             const digiServiceInstance = Container.get(digiService);
    //             const { success, message } = await digiServiceInstance.createNewLead(req.body as ILeadDTO);
    //             return res.status(201).json({ success, message });
    //         } catch (e) {
    //             logger.error('🔥 error: %o', e);
    //             return next(e);
    //         }
    //     },
    // );
    // route.get('/getHospitalLocation',
    //     celebrate({
    //         query: {
    //             searchTerm: Joi.string()
    //         },
    //     }),
    //     async (req: Request, res: Response, next: NextFunction) => {
    //         const logger: Logger = Container.get('logger');
    //         logger.debug('getHospitalLocation: %o', req.query);
    //         try {
    //             const digiServiceInstance = Container.get(digiService);
    //             const { locations } = await digiServiceInstance.getHospitalLocation(req.query as unknown as IFilterDTO);
    //             return res.status(201).json({ locations });
    //         } catch (e) {
    //             logger.error('🔥 error: %o', e);
    //             return next(e);
    //         }
    //     }
    // );
    route.post('/contactUsForm',
        celebrate({
            body: Joi.object({
                name: Joi.string().required(),
                contactNumber: Joi.string().required().min(10).max(10).pattern(/^[0-9]+$/).required(),
                email: Joi.string().required(),
                message: Joi.string().required(),
            }),
        }),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('Calling contactUsForm: %o', req.body);
            try {
                const digiServiceInstance = Container.get(digiService);
                const { success, message } = await digiServiceInstance.contactUsForm(req.body as ILeadDTO);
                return res.status(201).json({ success, message });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );

    route.get(
        '/lenderStatus',
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('Calling landerStatus: %o', req.query);
            try {
                const digiServiceInstance = Container.get(digiService);
                console.log(req.query);
                const { data } = await digiServiceInstance.LenderStatus(req.query as unknown as IUser);
                return res.status(201).json({ data: data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );

    route.get(
        '/dsplStatus',
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('getInvoiceByIdToAdmin: %o', req.query);
            try {

                const digiServiceInstance = Container.get(digiService);
                // console.log(req.query);
                const { data } = await digiServiceInstance.dsplInvoiceStatus(req.query as unknown as IUser);
                return res.status(201).json({ data: data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );

    route.post('/uploadAadharFrontGCP',
        uploadBuffer.fields([{ name: "uploadAadharFront" }]),
        async (req: Request, res: Response, next: NextFunction) => {
            let { uploadAadharFront } = req.body;
            let files = req['files'] as { [fieldname: string]: Express.Multer.File[] };
            const logger: Logger = Container.get('logger');
            logger.debug('claim/invoiceUpload: %o', req.body);


            if (files.uploadAadharFront) {
                uploadAadharFront = await uploadImage(files.uploadAadharFront[0]);
                console.log("HERE - ", uploadAadharFront);

                // uploadAadharFront = uploadAadharFront.split('?')[0];
            }
            return res.status(200).json({
                status: true,
                data: uploadAadharFront
            });

        })
    route.post('/uploadAadharBackGCP',
        uploadBuffer.fields([{ name: "uploadAadharBack" }]),
        async (req: Request, res: Response, next: NextFunction) => {
            let { uploadAadharBack } = req.body;
            let files = req['files'] as { [fieldname: string]: Express.Multer.File[] };
            const logger: Logger = Container.get('logger');
            logger.debug('claim/invoiceUpload: %o', req.body);


            if (files.uploadAadharBack) {
                uploadAadharBack = await uploadImage(files.uploadAadharBack[0]);
                console.log("HERE - ", uploadAadharBack);

                // uploadAadharBack = uploadAadharBack.split('?')[0];
            }
            return res.status(200).json({
                status: true,
                data: uploadAadharBack
            });

        })

    route.post('/uploadPanGCP',
        uploadBuffer.fields([{ name: "uploadPAN" }]),
        async (req: Request, res: Response, next: NextFunction) => {
            let { uploadPAN } = req.body;
            let files = req['files'] as { [fieldname: string]: Express.Multer.File[] };
            const logger: Logger = Container.get('logger');
            logger.debug('claim/invoiceUpload: %o', req.body);


            if (files.uploadPAN) {
                uploadPAN = await uploadImage(files.uploadPAN[0]);
                console.log("HERE - ", uploadPAN);

                // uploadPAN = uploadPAN.split('?')[0];
            }
            return res.status(200).json({
                status: true,
                data: uploadPAN
            });

        })

    route.post('/sendemailToEmandate',
      //  uploadBuffer.fields([{ name: "uploadAadharBack" }]),
        async (req: Request, res: Response, next: NextFunction) => {
            let { uploadAadharBack } = req.body;
            let files = req['files'] as { [fieldname: string]: Express.Multer.File[] };
            const logger: Logger = Container.get('logger');
            logger.debug('claim/invoiceUpload: %o', req.body);


            const digiServiceInstance = Container.get(nodeMailerService);
            const retur = await digiServiceInstance.sendemailToEmandate(req.body as ILeadDTO);

            return res.status(200).json({
                status: true,
                data: uploadAadharBack,
                retur
            });

        })
    route.use(errors());
};