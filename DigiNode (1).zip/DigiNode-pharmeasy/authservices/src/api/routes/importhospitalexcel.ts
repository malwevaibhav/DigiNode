import { Router, Request, Response, NextFunction } from 'express';
import basicAuth from 'express-basic-auth';
import agendash from 'agendash'
import { Container } from 'typedi'
import config from '../../config'
import { errors } from 'celebrate';
import { Logger } from 'winston';
import excel from 'exceljs';
import excelToJson from 'convert-excel-to-json';

import { hospitalexldoc } from '@/models/importHospitalExcelSchema';
import excelService from '../../services/importhospitalexcelservice';
import middlewares from '../middlewares';

const route = Router();
var fs = require('fs');
var multer = require('multer');
var path = require('path')
const storage = multer.diskStorage({
  destination: './uploads/',
  filename: function (req, file, cb) {
    cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
  },
});

const uploaders = multer({
  storage: storage,
  limits: { fieldSize: 10 * 1024 * 1024 }
});
export default (app: Router) => {
 app.use('/excel', route);

 route.post('/ImportHospitalExcel',
 async (req: Request, res: Response, next: NextFunction) => {
  const logger: Logger = Container.get('logger');
  var dirPath;
  var destPath;
  var numFiles;
  var filesarr;
  var filepaths;
  var fileWithExt = [];
  try {
    const excelservice = Container.get(excelService);
    uploaders.fields([{ name: 'uploadfile' }])(req, res, err => {
      dirPath = './uploads/' + req.files['uploadfile'][0].filename;
      var ran = Math.floor(Math.random() * 90000) + 10000;
      console.log(dirPath,"jdjdjdjdjdjd");
      
  
      const excelData = excelToJson({
        sourceFile: './uploads/' + req.files['uploadfile'][0].filename,
        sheets: [
          {
            // Excel Sheet Name
            name: 'sheet1',
            // Header Row -> be skipped and will not be present at our result object.
            header: {
              rows: 1,
            },
            // Mapping columns to keys
            columnToKey: {
              '*': '{{columnHeader}}',
            },
          }
        ],
      });
  
      if (!(excelData.sheet1.length)) {
        return res.status(400).json({
          success: false,
          error: 'Blank sheet not uploaded',
        });
      }
  
      var arr = [];
      async function invoicer() {
        var hospitalDatacount = excelData.sheet1.length;
        var hospitalData = excelData.sheet1;
        console.log(hospitalData)
        // var uninsuredInvoiceCount = excelData.Uninsured.length;
        var updateCount = 0;
        var addCount = 0;
        var failData = [];
        var updatedata = [];
        // console.log("reimbursementInvoiceCount : ", reimbursementInvoiceCount);
        // console.log("uninsuredInvoiceCount: ", uninsuredInvoiceCount);
  
        for (var i = 0; i < excelData.sheet1.length; i++) {
          if (!(
            excelData.sheet1[i].Name &&
            excelData.sheet1[i]['Beneficiary Account Name'] &&
            excelData.sheet1[i]['Bank Name'] &&
            excelData.sheet1[i]['Account Number'] &&
            excelData.sheet1[i]['Branch']&& 
            excelData.sheet1[i]['IFSC Code'] &&  
            excelData.sheet1[i]['Aggregator']
          )) {
            var statusIssue: any = {};
            statusIssue.Name = excelData.sheet1[i].Name;
            statusIssue.Reason = 'Incomplete data';
            failData.push(statusIssue);
            continue;
          }
          var invoiceData = {
            hospitalName:  excelData.sheet1[i].Name ,
            hsopitalLegalName: excelData.sheet1[i]['Beneficiary Account Name'],
            hospitalBankName:excelData.sheet1[i]['Bank Name'],
            hospitalBankAccNumber:excelData.sheet1[i]['Account Number'] ,
            hospitalBankBranch:  excelData.sheet1[i]['Branch'],
            hospitalBankIFSC:  excelData.sheet1[i]['IFSC Code'] ,
            aggregatorName:excelData.sheet1[i]['Aggregator']
          }
        // const hospitalExist = await excelservice.checkHospitalByLegalName(invoiceData)
        // if(hospitalExist?.success == true){
        //      const update=await excelservice.UpdateBankDetails(invoiceData)
        //      if(update){
        //       updatedata.push(update)
        //        updateCount++
        //        continue;
        //      }
        // }
            const invoice = await excelservice.createHospitalBank(invoiceData);
            if(invoice){

              addCount++;
            }
          
        }
       
        fs.unlinkSync('./uploads/' + req.files['uploadfile'][0].filename);
        return res.status(200).json({
          success: true,
          updateCount,
          addCount,
          failData,
          updatedata,
          message: 'uploaded',
        });
      }
      invoicer();
    });
  } catch (e) {
    logger.error('🔥 error: %o', e);
    return next(e);
}



 })


 route.post('/hospitalBankDetails', async (req: Request, res: Response, next: NextFunction) => {
  const logger: Logger = Container.get('logger');
  logger.debug('Calling hospitalBankDetails: %o', req.body);
  try {
      const excelservice = Container.get(excelService);
      const { success, message } = await excelservice.createHospitalBank(req.body as hospitalexldoc);
      return res.status(201).json({ success, message });
  } catch (e) {
      logger.error('🔥 error: %o', e);
      return next(e);
  }

 })
 route.get('/getAllHospitalBankDetails',
  middlewares.isAuth,
  middlewares.attachCurrentUser
 ,async (req: Request, res: Response, next: NextFunction) => {
  const logger: Logger = Container.get('logger');
  logger.debug('Calling excel/getAllHospitalBankDetails: %o', req.body);
  try {
    console.log(req.currentUser)
      const excelservice = Container.get(excelService);
      const { success,HosBankDetails, message } = await excelservice.getAllHospitalBankDetails(req.currentUser?.organizationId);
      return res.status(201).json({ success,HosBankDetails, message });
  } catch (e) {
      logger.error('🔥 error: %o', e);
      return next(e);
  }
 })


      route.use(errors());
  } 