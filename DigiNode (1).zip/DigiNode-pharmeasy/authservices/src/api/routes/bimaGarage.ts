import { IFilterDTO } from '@/interfaces/IUser';
import { Router, Request, Response, NextFunction } from 'express';
import { Container } from 'typedi';
import BimaService from '../../services/BGservice';
import { Logger } from 'winston';
import { celebrate, Joi, errors } from 'celebrate';
import DateExtension from '@joi/date';
const JoiDate = Joi.extend(DateExtension);
import middlewares from '../middlewares';
import { IBGPatientDTO, IPatientLoanDTO } from '@/interfaces/IBimaGarage';
import FormData from "form-data"
var multer = require('multer');
var path = require('path')
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/')
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9)
    cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname))
  }
})
const { BlobServiceClient } = require("@azure/storage-blob");
const containerName = "uatcontainer";
const sasToken = "sv=2021-06-08&ss=bfqt&srt=sco&sp=rwdlacupiytfx&se=2024-02-20T16:47:15Z&st=2023-02-20T08:47:15Z&spr=https&sig=BDmeVstReLGKpmVAufC%2FKQd2afDfAPdO4LzQgdB1SXo%3D";
const storageAccountName = "uatresource";
const key = "uaEjdcwzjVO7U7qv/JFnOnsEXUxQHQ46zI4x+onZBXL9UPCLEfEk+xd0sMB0ZWmZGuRLXdxjDzBIUba3A5CUrw==";

const createBlobInContainer = async (containerClient, file) => {
  const blobClient = containerClient.getBlockBlobClient(file.filename);
  const options = { blobHTTPHeaders: { blobContentType: file.mimetype } };

  var a = await blobClient.uploadData(
    fs.readFileSync("uploads/" + file.filename),
    options
  );
  return blobClient.url;
};

const uploadFileToBlob = async (file) => {
  if (!file) return [];
  const blobService = new BlobServiceClient(
    `https://${storageAccountName}.blob.core.windows.net/?${sasToken}`
  );
  const containerClient = blobService.getContainerClient(containerName);
  var response = await createBlobInContainer(containerClient, file);
  return response;
};

const digiSparshKeyBG = process.env.digiApiKeyBG
const upload = multer({
  storage: storage,
  limits: { fieldSize: 10 * 1024 * 1024 }
})
var fs = require('fs');

const route = Router();

export default (app: Router) => {

  app.use('/bima', route);

  route.get('/token', async (req: any, res: any, next) => {
    const bimaServiceInstance = Container.get(BimaService);
    const data = await bimaServiceInstance.token();
    res.send({ token: data })
  })

  route.get('/check-patient', celebrate({
    query: Joi.object({
      mobileNumber: Joi.number().required(),
    }),
  }), async (req: Request, res: Response, next: NextFunction) => {
    const logger: Logger = Container.get('logger');
    // logger.debug('Calling Sign-Up endpoint with body: %o', req.query);
    try {
      const mobileNumber = req.query.mobileNumber
      const bimaServiceInstance = Container.get(BimaService);
      const data = await bimaServiceInstance.check_patient(mobileNumber);
      return res.status(201).json(data);
    } catch (e) {
      logger.error('🔥 error: %o', e);
      return next(e);
    }
  },
  );
  route.get('/check-case', celebrate({
    query: Joi.object({
      PatientId: Joi.number().required(),
    }),
  }), async (req: Request, res: Response, next: NextFunction) => {
    const logger: Logger = Container.get('logger');
    // logger.debug('Calling Sign-Up endpoint with body: %o', req.query);
    try {
      const PatientId = req.query.PatientId
      const bimaServiceInstance = Container.get(BimaService);
      const data = await bimaServiceInstance.check_case(PatientId);
      return res.status(201).json(data);
    } catch (e) {
      logger.error('🔥 error: %o', e);
      return next(e);
    }
  },
  );
  route.post('/CreateHospital', celebrate({
    body: Joi.object({
      hospital_name: Joi.string().required(),
      city: Joi.string().required(),
      state: Joi.string().required(),
    }),
  }), async (req: Request, res: Response, next: NextFunction) => {
    const logger: Logger = Container.get('logger');
    // logger.debug('Calling Sign-Up endpoint with body: %o', req.body);
    try {
      // const PatientId=req.query.PatientId
      const bimaServiceInstance = Container.get(BimaService);
      const data = await bimaServiceInstance.CreateHospital(req.body);
      return res.status(201).json(data);
    } catch (e) {
      logger.error('🔥 error: %o', e);
      return next(e);
    }
  },
  );
  route.post('/CreatePatient', middlewares.isAuth, middlewares.attachCurrentUser, upload.single('policy_doc'), async (req: any, res: Response, next: NextFunction) => {
    const logger: Logger = Container.get('logger');
    const bimaServiceInstance = Container.get(BimaService);
    let data: any = {}
    let patientData: any = {};

    let form_data = new FormData();
    for (var key in req.body) {
      form_data.append(key, req.body[key]);
    }
    try {

      if (req.file) {
        form_data.append('policy_doc', fs.createReadStream('uploads/' + req.file.filename), req.file.filename)
      }

      if (req.currentUser.BGHospitalId) {
        data = await bimaServiceInstance.CreatePatient(form_data);
        if (data) {

          patientData = await bimaServiceInstance.addPatient(req.body as IBGPatientDTO, data, req.currentUser.BGHospitalId);
        } else {
          return res.status(400).json({ data: "Mobile No. Already Exist At Bima Garage", success: false })
        }

        return res.status(201).json({ data, patientData, success: true })
      } else {
        let hospitaldata = {
          hospital_name: req.currentUser.name,
          city: req.currentUser.address[0].city,
          state: req.currentUser.address[0].state,
        };
        let approveddata = await bimaServiceInstance.CreateHospital(hospitaldata);
        if (approveddata.Message == 'Hospital Created Successfully') {
          const hospitalUpdatedData = await bimaServiceInstance.updateUser(
            req.currentUser,
            approveddata.payload.data.id,
          );
          data = await bimaServiceInstance.CreatePatient(form_data);
          patientData = await bimaServiceInstance.addPatient(req.body as IBGPatientDTO, data, approveddata.payload.data.id);
          return res.status(201).json({ data, patientData, success: true })
        } else {
          return res.status(400).json({ Message: 'Unable to create Hospital at BG' });
        }
      }

    } catch (e) {
      logger.error('🔥 error: %o', e);
      return next(e);
    }
  },
  );

  route.post('/createCase', middlewares.isAuth, middlewares.attachCurrentUser, async (req: Request, res: Response, next: NextFunction) => {
    const logger: Logger = Container.get('logger');
    logger.debug('Calling Sign-Up endpoint with body: %o', req.body);
    let data: any = {}
    let caseData: any = {}
    try {
      const bimaServiceInstance = Container.get(BimaService);
      const BgCaseInstance = Container.get(BimaService);
      // req.body.hospital=req.currentUser.BGHospitalId
      let newbody = Object.assign({ hospital: Number(req.currentUser.BGHospitalId), claim_status: "New" }, req.body)

      data = await bimaServiceInstance.createCase(newbody);
      if (data.Message = 'Case Created Successfully') {
        caseData = await BgCaseInstance.addCase(newbody, data);
        return res.status(201).json({ data, caseData, success: true });
      } else {
        return res.status(201).json({ Message: "Unable to create Case", success: false });
      }



    } catch (e) {
      logger.error('🔥 error: %o', e);
      return next(e);
    }
  },
  );

  route.get('/CaseStatistics', async (req: Request, res: Response, next: NextFunction) => {
    const logger: Logger = Container.get('logger');
    // logger.debug('Calling Sign-Up endpoint with body: %o', req.query);
    try {

      const bimaServiceInstance = Container.get(BimaService);
      const data = await bimaServiceInstance.CaseStatistics();
      return res.status(201).json(data);
    } catch (e) {
      logger.error('🔥 error: %o', e);
      return next(e);
    }
  },
  );
  route.get('/getHospitalList',

    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      // logger.debug('Calling Sign-Up endpoint with body: %o', req.query);
      try {

        const bimaServiceInstance = Container.get(BimaService);
        const data = await bimaServiceInstance.hospitaldata();
        return res.status(201).json(data);
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
  route.get('/getAllFundedCases', celebrate({
    query: {
      pageNumber: Joi.number().positive().allow(null),
      pageSize: Joi.number().positive().allow(null),
      caseId: Joi.string().allow(null),
      dateFrom: JoiDate.date().allow(null),
      dateTo: JoiDate.date().allow(null),

    },
  }),

    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      // logger.debug('Calling Sign-Up endpoint with body: %o', req.query);
      try {
        let digiSparshKeyBG2 = req.headers.digiapikeybg
        if (digiSparshKeyBG != digiSparshKeyBG2) {
          return res.status(401).json({ data: { success: false, message: "UnAuthorized User" } })
        }
        const bimaServiceInstance = Container.get(BimaService);
        const data = await bimaServiceInstance.getAllFundedCases(req.query as unknown as IFilterDTO);
        return res.status(201).json(data);
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
  route.get('/getCaseList', celebrate({
    query: {
      pageNumber: Joi.number().positive(),
      pageSize: Joi.number().positive(),
      id: Joi.string().required()


    },
  }), async (req: Request, res: Response, next: NextFunction) => {
    const logger: Logger = Container.get('logger');
    // logger.debug('Calling Sign-Up endpoint with body: %o', req.query);
    try {

      // var body = req.query;
      const bimaServiceInstance = Container.get(BimaService);
      const data = await bimaServiceInstance.caselist(req.query as any);
      return res.status(201).json(data);
    } catch (e) {
      logger.error('🔥 error: %o', e);
      return next(e);
    }
  },
  );


  route.get('/getCaseById', celebrate({
    query: {
      case_id: Joi.number().required()
    },
  }), async (req: Request, res: Response, next: NextFunction) => {
    const logger: Logger = Container.get('logger');
    // logger.debug('Calling Sign-Up endpoint with body: %o', req.query);
    try {
      let case_id = req.query.case_id
      const bimaServiceInstance = Container.get(BimaService);
      const data = await bimaServiceInstance.caseById(case_id);
      return res.status(201).json({ data });
    } catch (e) {
      logger.error('🔥 error: %o', e);
      return next(e);
    }
  },
  );
  route.post('/updateCaseById', celebrate({
    body: {
      case_id: Joi.number().required()
    },
  }), async (req: Request, res: Response, next: NextFunction) => {
    const logger: Logger = Container.get('logger');
    // logger.debug('Calling Sign-Up endpoint with body: %o', req.query);
    try {

      let digiSparshKeyBG2 = req.headers.digiapikeybg
      if (digiSparshKeyBG != digiSparshKeyBG2) {
        return res.status(401).json({ data: { success: false, message: "UnAuthorized User" } })
      }


      let case_id = req.body.case_id
      const bimaServiceInstance = Container.get(BimaService);
      const data = await bimaServiceInstance.updateCaseById(case_id);
      return res.status(201).json({ data });
    } catch (e) {
      logger.error('🔥 error: %o', e);
      return next(e);
    }
  },
  );

  route.get('/getPatientList', middlewares.isAuth, middlewares.attachCurrentUser,
    celebrate({
      body: {
        pageNumber: Joi.number().positive(),
        pageSize: Joi.number().positive(),

      },
    }), async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      // logger.debug('Calling Sign-Up endpoint with body: %o', req.query);
      try {
        console.log(req.currentUser.BGHospitalId)
        if (req.currentUser.BGHospitalId) {
          let body = Object.assign({ BGHospitalId: req.currentUser.BGHospitalId }, req.query)
          const bimaServiceInstance = Container.get(BimaService);
          const data = await bimaServiceInstance.patientlist(body);
          return res.status(201).json(data);
        } else {
          return res.status(201).json({ data: { numberOfPages: 1, Caselist: [], userCount: 0 } });
        }

      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );

  route.get('/insuranceco', async (req: Request, res: Response, next: NextFunction) => {
    const logger: Logger = Container.get('logger');
    // logger.debug('Calling Sign-Up endpoint with body: %o', req.query);
    try {
      const bimaServiceInstance = Container.get(BimaService);
      const data = await bimaServiceInstance.insuranceco();
      return res.status(201).json(data);
    } catch (e) {
      logger.error('🔥 error: %o', e);
      return next(e);
    }
  },
  );

  route.get('/tpa', async (req: Request, res: Response, next: NextFunction) => {
    const logger: Logger = Container.get('logger');
    // logger.debug('Calling Sign-Up endpoint with body: %o', req.query);
    try {
      const bimaServiceInstance = Container.get(BimaService);
      const data = await bimaServiceInstance.getTpa();
      return res.status(201).json(data);
    } catch (e) {
      logger.error('🔥 error: %o', e);
      return next(e);
    }
  },
  );

  route.patch('/UpdateClaimStage1', upload.single('preauth_form'), celebrate({
    body: Joi.object({
      claim_status: Joi.number().required(),
      preauth_inidate: Joi.string().allow(null),
      preauth_iniamt: Joi.string().allow(null),


    }),
    query: Joi.object({
      PatientId: Joi.number().required()
    })
  }), async (req: any, res: Response, next: NextFunction) => {
    const logger: Logger = Container.get('logger');
    // logger.debug('Calling Sign-Up endpoint with body: %o', req.body);
    try {

      // console.log(fs.createReadStream('uploads/'+req.file.filename));
      let formData = new FormData();
      formData.append('claim_status', req.body.claim_status)
      if (req.body.preauth_inidate) {
        formData.append('preauth_inidate', req.body.preauth_inidate)
      }
      if (req.body.preauth_iniamt) {
        formData.append('preauth_iniamt', req.body.preauth_iniamt)
      }

      if (req.file) {
        formData.append('preauth_form', fs.createReadStream('uploads/' + req.file.filename), req.file.filename)
      }


      const PatientId = Number(req.query.PatientId);

      const bimaServiceInstance = Container.get(BimaService);
      const data = await bimaServiceInstance.UpdateClaimStage1(formData, PatientId);
      if (data['Message'] == "Claim Stage 1 Completed Successfully, PreAuth Initiated.") {
        let updatedcase = await bimaServiceInstance.updatedcase(data.payload);
        return res.status(201).json({ success: true, data, updatedcase });
      } else {
        return res.status(400).json({ success: false });
      }

    } catch (e) {
      logger.error('🔥 error: %o', e);
      return next(e);
    }
  },
  );
  route.patch('/UpdateClaimStage2', upload.single('pre_auth_appr_letter'), celebrate({
    body: Joi.object({
      claim_status: Joi.string().required(),
      prauth_apdate: Joi.string(),
      preauth_apamt: Joi.string(),
      claim_number: Joi.string(),



    }),
    query: Joi.object({
      PatientId: Joi.number().required()
    })
  }), async (req: any, res: Response, next: NextFunction) => {
    const logger: Logger = Container.get('logger');
    // logger.debug('Calling Sign-Up endpoint with body: %o', req.body);
    let formData = new FormData();
    formData.append('claim_status', req.body.claim_status)
    if (req.body.prauth_apdate) {
      formData.append('prauth_apdate', req.body.prauth_apdate)
    }
    if (req.body.preauth_apamt) {
      formData.append('preauth_apamt', req.body.preauth_apamt)
    }
    if (req.body.claim_number) {
      formData.append('claim_number', req.body.claim_number)
    }

    if (req.file) {
      formData.append('pre_auth_appr_letter', fs.createReadStream('uploads/' + req.file.filename), req.file.filename)
    }
    try {
      const PatientId = Number(req.query.PatientId);

      const bimaServiceInstance = Container.get(BimaService);
      const data = await bimaServiceInstance.UpdateClaimStage2(formData, PatientId);
      if (data['Message'] == "Claim Stage 2 Completed Successfully, PreAuth Approved.") {
        let updatedcase = await bimaServiceInstance.updatedcase(data.payload);
        return res.status(201).json({ success: true, data, updatedcase });
      } else {
        return res.status(400).json({ success: false });
      }

    } catch (e) {
      logger.error('🔥 error: %o', e);
      return next(e);
    }
  },
  );
  route.patch('/UpdateClaimStage3', upload.single('fin_bill_summ'), celebrate({
    body: Joi.object({
      claim_status: Joi.string().required(),
      discharge_date: Joi.string(),
      billing_date: Joi.string(),
      finalapreq_date: Joi.string(),
      nursing_charges: Joi.string(),
      room_charges: Joi.string(),
      other_charges: Joi.string(),
      expense_pharmacy: Joi.string(),
      expense_diagnosis: Joi.string(),
      expense_total: Joi.string(),

    }),
    query: Joi.object({
      PatientId: Joi.number().required()
    })
  }), async (req: any, res: Response, next: NextFunction) => {
    const logger: Logger = Container.get('logger');
    // logger.debug('Calling Sign-Up endpoint with body: %o', req.body);
    try {
      let formData = new FormData();
      for (var key in req.body) {
        formData.append(key, req.body[key]);
      }

      if (req.file) {
        formData.append('fin_bill_summ', fs.createReadStream('uploads/' + req.file.filename), req.file.filename)
      }
      const PatientId = Number(req.query.PatientId);
      const bimaServiceInstance = Container.get(BimaService);
      const data = await bimaServiceInstance.UpdateClaimStage3(formData, PatientId);
      if (data['Message'] == "Claim Stage 3 Completed Successfully, Final Approval Initiated.") {
        let updatedcase = await bimaServiceInstance.updatedcase(data.payload);
        return res.status(201).json({ success: true, data, updatedcase });
      } else {
        return res.status(400).json({ success: false });
      }

    } catch (e) {
      logger.error('🔥 error: %o', e);
      return next(e);
    }
  },
  );

  route.patch('/UpdateClaimStage4', upload.single('final_appr_letter'),
    celebrate({
      body: Joi.object({
        claim_status: Joi.string().required(),
        fappr_deduction_amt: Joi.string(),
        fappr_amt: Joi.string(),
        fappr_date: Joi.string(),
        fappr_hosp_disc: Joi.string(),

        non_medical_amt: Joi.string(),
        co_pay_d_amt: Joi.string(),
        other_deduction: Joi.string(),
        fappr_deduction_reason: Joi.string(),
      }),
      query: Joi.object({
        PatientId: Joi.number().required()
      })
    }), async (req: any, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      // logger.debug('Calling Sign-Up endpoint with body: %o', req.body);
      try {
        let formData = new FormData();
        for (var key in req.body) {
          formData.append(key, req.body[key]);
        }

        if (req.file) {
          formData.append('final_appr_letter', fs.createReadStream('uploads/' + req.file.filename), req.file.filename)
        }
        const PatientId = Number(req.query.PatientId);
        const bimaServiceInstance = Container.get(BimaService);
        const data = await bimaServiceInstance.UpdateClaimStage4(formData, PatientId);
        if (data['Message'] == "Claim Stage 4 Completed Successfully, Final Approval Received.") {
          let updatedcase = await bimaServiceInstance.updatedcase(data.payload);
          return res.status(201).json({ success: true, data, updatedcase });
        } else {
          return res.status(400).json({ success: false });
        }

      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );

  route.patch('/UpdateClaimStage5', upload.single('notes'),
    celebrate({
      body: Joi.object({
        claim_status: Joi.string().required(),
        file_sentdate: Joi.string(),
        tracking_no: Joi.string(),
        courier_company: Joi.string(),
        notes: Joi.string()
      }),
      query: Joi.object({
        PatientId: Joi.string().required()
      })
    }), async (req: any, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      // logger.debug('Calling Sign-Up endpoint with body: %o', req.body);
      try {
        let formData = new FormData();
        for (var key in req.body) {
          formData.append(key, req.body[key]);
        }

        if (req.file) {
          formData.append('notes', fs.createReadStream('uploads/' + req.file.filename), req.file.filename)
        }
        const PatientId = Number(req.query.PatientId);
        const bimaServiceInstance = Container.get(BimaService);
        const data = await bimaServiceInstance.UpdateClaimStage5(formData, PatientId);
        if (data['Message'] == "Claim Stage 5 Completed Successfully, File Dispatched.") {
          let updatedcase = await bimaServiceInstance.updatedcase(data.payload);
          return res.status(201).json({ success: true, data, updatedcase });
        } else {
          return res.status(400).json({ success: false });
        }

      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
  route.patch('/UpdateDisbersment', upload.single('notes'),
    celebrate({
      body: Joi.object({
        loanid: Joi.string().required(),
        loanamt: Joi.string(),
        borrower_name: Joi.string(),
        appdt: Joi.string(),
        disbdt: Joi.string(),
        disbstatus: Joi.string()
      }),
      query: Joi.object({
        CaseId: Joi.string().required()
      })
    }), async (req: any, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      // logger.debug('Calling Sign-Up endpoint with body: %o', req.body);
      try {

        const PatientId = Number(req.query.CaseId);
        const bimaServiceInstance = Container.get(BimaService);
        const invoice: any = await bimaServiceInstance.getInvoiceByCaseId(PatientId)
        if (invoice) {
          console.log(invoice)
          req.body.loanid = invoice.invoiceId
        }

        let formData = new FormData();
        for (var key in req.body) {
          formData.append(key, req.body[key]);
        }



        const data = await bimaServiceInstance.UpdateDisbersment(formData, PatientId);
        if (data['Message'] == "Received Disbursement Successfully.") {
          // let updatedcase = await bimaServiceInstance.updatedcase(data.payload);
          return res.status(200).json({ success: true, data });
        } else {
          return res.status(400).json({ success: false });
        }

      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );

  route.patch('/UpdateClaimStage6', upload.single('settlement_letter_file'), celebrate({
    body: Joi.object({
      claim_status: Joi.string().required(),
      utrno: Joi.string(),
      utr_date: Joi.string(),
      settlement_letter: Joi.string(),
      discharge_date: Joi.string(),
      deduction_amount: Joi.string(),
      deduction_reason: Joi.string(),
      deduction_tds: Joi.string(),
      admission_type: Joi.string(),
      cheque_amount: Joi.string(),

    }),
    query: Joi.object({
      PatientId: Joi.number().required()
    })
  }), async (req: any, res: Response, next: NextFunction) => {
    const logger: Logger = Container.get('logger');
    // logger.debug('Calling Sign-Up endpoint with body: %o', req.body);
    try {
      let formData = new FormData();
      for (var key in req.body) {
        formData.append(key, req.body[key]);
      }

      if (req.file) {
        formData.append('settlement_letter_file', fs.createReadStream('uploads/' + req.file.filename), req.file.filename)
      }
      const PatientId = Number(req.query.PatientId);
      const bimaServiceInstance = Container.get(BimaService);
      const data = await bimaServiceInstance.UpdateClaimStage6(formData, PatientId);
      if (data['Message'] == "Claim Stage 6 Completed Successfully, Claim Settled.") {
        let updatedcase = await bimaServiceInstance.updatedcase(data.payload);
        return res.status(201).json({ success: true, data, updatedcase });
      } else {
        return res.status(400).json({ success: false });
      }

    } catch (e) {
      logger.error('🔥 error: %o', e);
      return next(e);
    }
  },
  );
  route.patch('/CaseReject', upload.single('claim_rejec_letter'), celebrate({
    body: Joi.object({
      claim_status: Joi.string().required(),
      rejection_comments: Joi.string(),


    }),
    query: Joi.object({
      PatientId: Joi.number().required()
    })
  }), async (req: any, res: Response, next: NextFunction) => {
    const logger: Logger = Container.get('logger');
    // logger.debug('Calling Sign-Up endpoint with body: %o', req.body);
    try {
      let formData = new FormData();
      for (var key in req.body) {
        formData.append(key, req.body[key]);
      }

      if (req.file) {
        formData.append('claim_rejec_letter', fs.createReadStream('uploads/' + req.file.filename), req.file.filename)
      }
      const PatientId = Number(req.query.PatientId);
      const bimaServiceInstance = Container.get(BimaService);
      const data = await bimaServiceInstance.CaseReject(formData, PatientId);
      if (data['Message'] == "Case Rejected Successfully.") {
        let updatedcase = await bimaServiceInstance.updatedcase(data.payload);
        return res.status(201).json({ success: true, data, updatedcase });
      } else {
        return res.status(400).json({ success: false });
      }

    } catch (e) {
      logger.error('🔥 error: %o', e);
      return next(e);
    }
  },
  );
  route.patch('/queryPending', celebrate({
    body: Joi.object({
      claim_status: Joi.string().required(),
      queryp_comments: Joi.string(),


    }),
    query: Joi.object({
      caseid: Joi.number().required()
    })
  }), async (req: any, res: Response, next: NextFunction) => {
    const logger: Logger = Container.get('logger');
    // logger.debug('Calling Sign-Up endpoint with body: %o', req.body);
    try {
      let formData = new FormData();
      for (var key in req.body) {
        formData.append(key, req.body[key]);
      }
      const caseid = Number(req.query.caseid);
      const bimaServiceInstance = Container.get(BimaService);
      const data = await bimaServiceInstance.CaseReject(formData, caseid);
      if (data['Message'] == "Case Rejected Successfully.") {
        let updatedcase = await bimaServiceInstance.updatedcase(data.payload);
        return res.status(201).json({ success: true, data, updatedcase });
      } else {
        return res.status(400).json({ success: false });
      }

    } catch (e) {
      logger.error('🔥 error: %o', e);
      return next(e);
    }
  },
  );
  route.get('/getPatientDetailsByMobileNumber', celebrate({
    query: Joi.object({
      MobileNumber: Joi.number().required()
    })
  }), async (req: any, res: Response, next: NextFunction) => {
    const logger: Logger = Container.get('logger');
    // logger.debug('Calling Sign-Up endpoint with body: %o', req.body);
    try {

      const MobileNumber = req.query.MobileNumber.toString();
      const bimaServiceInstance = Container.get(BimaService);
      const { data } = await bimaServiceInstance.getPatientDetailsByMobileNumber(MobileNumber);
      return res.status(201).json({ success: true, data });

    } catch (e) {
      logger.error('🔥 error: %o', e);
      return next(e);
    }
  },
  );

  route.patch('/editCase', upload.single('courier_receipt'), celebrate({
    body: Joi.object({
      id: Joi.string(),
      admission_type: Joi.string(),
      treatment_type: Joi.string(),
      room_type: Joi.string(),
      deposit_amount: Joi.string(),
      admission_date: Joi.string(),
      discharge_date: Joi.string(),
      ipdno: Joi.string(),
      ailment: Joi.string(),
      claim_number: Joi.string(),
      primary_doc: Joi.string(),
      tracking_no: Joi.string()


    })
  }), async (req: any, res: Response, next: NextFunction) => {
    const logger: Logger = Container.get('logger');
    // logger.debug('Calling Sign-Up endpoint with body: %o', req.body);
    try {
      let formData = new FormData();
      for (var key in req.body) {
        formData.append(key, req.body[key]);
      }

      if (req.file) {
        formData.append('courier_receipt', fs.createReadStream('uploads/' + req.file.filename), req.file.filename)
      }

      const bimaServiceInstance = Container.get(BimaService);
      const data = await bimaServiceInstance.EditCase(formData);
      if (data['Message'] == "Case Details Updated Successfully") {
        let updatedcase = await bimaServiceInstance.editcase(data.payload);
        return res.status(201).json({ success: true, data, updatedcase });
      } else {
        return res.status(400).json({ success: false });
      }

    } catch (e) {
      logger.error('🔥 error: %o', e);
      return next(e);
    }
  },
  );
  route.post('/upload_document',
    upload.single('case_file'),
    celebrate({
      body: Joi.object({
        caseId: Joi.string().required(),
        file_name: Joi.string().required(),
        case_file: Joi.any(),
      }),
    }), async (req: any, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug(`upload_document ${req.body.file_name} for case Id: ${req.body.caseId}`);
      try {
        req.body.case_file = await uploadFileToBlob(req.file);
        req.body.case_file = req.body.case_file.split('?')[0];
        const bimaServiceInstance = Container.get(BimaService);
        const data = await bimaServiceInstance.upload_document(req.body as IBGPatientDTO);
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );

  route.post('/addPatientInvoice',
    celebrate({
      body: {
        caseId: Joi.string().required(),
        firstname: Joi.string().required(),
        lastname: Joi.string().required(),
        emailId: Joi.string().required().regex(/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/),
        contactNumber: Joi.string().min(10).max(10).pattern(/^[0-9]+$/).required(),
        dateOfBirth: JoiDate.date().format('YYYY-MM-DD').required(),
        gender: Joi.string().required().valid('Male', 'Female'),
        occupation: Joi.string().required().valid('Salaried', 'Self Employed', 'Business'),
        companyName: Joi.string().required(),
        totalIncome: Joi.number().required(),
        currentAddr: Joi.object().keys({
          street: Joi.string().required(),
          state: Joi.string().required(),
          city: Joi.string().required(),
          pinCode: Joi.string().min(6).max(6).regex(/^[1-9][0-9]{5}$/).required()
        }).required(),
        permanentAddr: Joi.object().keys({
          street: Joi.string().required(),
          state: Joi.string().required(),
          city: Joi.string().required(),
          pinCode: Joi.string().min(6).max(6).regex(/^[1-9][0-9]{5}$/).required()
        }),
      },
    }), async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('bimaGarage/addPatientInvoice', req.body);
      try {
        if (req.headers.digiapikeybg != process.env.digiApiKeyBG) {
          return res.status(401).json({ data: { success: false, message: "UnAuthorized User" } })
        }
        const BGServiceInstance = Container.get(BimaService);
        const invoice = await BGServiceInstance.getInvoice(req.body as IPatientLoanDTO);
        if (invoice.patientLoan) {
          return res.status(400).json({ data: { success: false, message: "Invoice already exists with provided details", invoiceId: invoice.patientLoan.invoiceId } })
        }
        const data = await BGServiceInstance.addPatientInvoice(req.body as IPatientLoanDTO);
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
  route.post('/addReferenceDetails',
    celebrate({
      body: {
        invoiceId: Joi.number().required(),
        referenceName: Joi.string().required(),
        contactNoRefPerson: Joi.string().required().min(10).max(10).pattern(/^[0-9]+$/),
        relationship: Joi.string().required(),
        emailIdRefPerson: JoiDate.string().required().regex(/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/)
      },
    }),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('bimaGarage/addReferenceDetails', req.body);
      try {
        if (req.headers.digiapikeybg != process.env.digiApiKeyBG) {
          return res.status(401).json({ data: { success: false, message: "UnAuthorized User" } })
        }
        const BGServiceInstance = Container.get(BimaService);
        const invoice = await BGServiceInstance.getInvoice(req.body as IPatientLoanDTO);
        if (!invoice.patientLoan) {
          return res.status(400).json({ data: { success: false, message: "Invoice not found" } })
        }
        if (invoice.patientLoan.referenceName) {
          return res.status(400).json({ data: { success: false, message: "Reference Details already exists" } })
        }
        const data = await BGServiceInstance.addReferenceDetails(req.body as IPatientLoanDTO);
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
  route.post('/addLoanDetails',
    celebrate({
      body: {
        invoiceId: Joi.number().required(),
        borrowerName: Joi.string().required(),
        relation: Joi.string().required().valid('Self', 'Father', 'Mother', 'Brother', 'Sister', 'Son', 'Daughter', 'Wife', 'Husband', 'Relative'),
        bankAssociated: Joi.string().required(),
        branch: JoiDate.string().required(),
        IFSCCode: Joi.string().required().regex(/^[A-Za-z]{4}[a-zA-Z0-9]{7}$/),
        accountNumber: Joi.string().min(11).max(18).pattern(/^[0-9]+$/),
        loanAmount: Joi.number().required(),
        scheme: Joi.number().required().valid(1, 2, 3),
        BGApprovedAmt: Joi.number().required(),
        hospitalName: Joi.string().required(),
        insuranceco: Joi.number().required(),
        inhouse_tpa: Joi.boolean().required(),
        tpa: Joi.when('inhouse_tpa', { is: false, then: Joi.required() }),
        uhid: Joi.string().required(),
        policy_no: Joi.string().required(),
        sum_insured: Joi.number().required(),
        is_corporate: Joi.boolean().required(),
        corporate_name: Joi.when('is_corporate', { is: true, then: Joi.required() }),
        policy_startdt: JoiDate.date().format('YYYY-MM-DD').required(),
        policy_enddt: JoiDate.date().format('YYYY-MM-DD').required()
      },
    }),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('bimaGarage/addLoanDetails', req.body);
      try {
        if (req.headers.digiapikeybg != process.env.digiApiKeyBG) {
          return res.status(401).json({ data: { success: false, message: "UnAuthorized User" } })
        }
        const BGServiceInstance = Container.get(BimaService);
        const invoice = await BGServiceInstance.getInvoice(req.body as IPatientLoanDTO);
        if (!invoice.patientLoan) {
          return res.status(400).json({ data: { success: false, message: "Invoice not found" } })
        }
        if (invoice.patientLoan.EMI_Amount) {
          return res.status(400).json({ data: { success: false, message: "Loan Details already exists" } })
        }
        const data = await BGServiceInstance.addLoanDetails(req.body as IPatientLoanDTO);
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
  route.post('/uploadDocuments',
    upload.fields([
      { name: 'aadharFront' },
      { name: 'aadharBack' },
      { name: 'PANCard' },
      { name: 'cancelledCheque' },
      { name: 'insurancePolicy' },
      { name: 'hospitalBill' },
      { name: 'relationshipProof' },
      { name: 'incomeProof' },
      { name: 'bankStatement' },
      { name: 'otherDoc' }
    ]),
    celebrate({
      body: {
        invoiceId: Joi.number().required()
      }
    }),
    async (req: Request, res: Response, next: NextFunction) => {
      const files = req.files as { [fieldname: string]: Express.Multer.File[] };
      const logger: Logger = Container.get('logger');
      logger.debug('bimaGarage/uploadDocuments');
      try {
        if (req.headers.digiapikeybg != process.env.digiApiKeyBG) {
          return res.status(401).json({ data: { success: false, message: "UnAuthorized User" } })
        }

        const BGServiceInstance = Container.get(BimaService);
        const invoice = await BGServiceInstance.getInvoice(req.body as IPatientLoanDTO);

        if (!invoice.patientLoan) {
          return res.status(400).json({ data: { success: false, message: "Invoice not found" } })
        }

        if (invoice.patientLoan.uploadAadharFront) {
          return res.status(400).json({ data: { success: false, message: "Documents already exist" } })
        }

        if (!files.aadharFront || !files.aadharBack || !files.PANCard || !files.cancelledCheque || !files.insurancePolicy) {
          return res.status(400).json({ data: { success: false, message: "Please Upload all required documents" } })
        }

        if (invoice.patientLoan.relation != "Self" && !files.relationshipProof) {
          return res.status(400).json({ data: { success: false, message: "Relationship proof required when patient & borrower are not same" } })
        }

        req.body.uploadAadharFront = await uploadFileToBlob(files.aadharFront[0])
        req.body.uploadAadharFront = req.body.uploadAadharFront.split('?')[0];

        req.body.uploadAadharBack = await uploadFileToBlob(files.aadharBack[0])
        req.body.uploadAadharBack = req.body.uploadAadharBack.split('?')[0];

        req.body.uploadPAN = await uploadFileToBlob(files.PANCard[0])
        req.body.uploadPAN = req.body.uploadPAN.split('?')[0];

        req.body.uploadCancelledCheque = await uploadFileToBlob(files.cancelledCheque[0])
        req.body.uploadCancelledCheque = req.body.uploadCancelledCheque.split('?')[0];

        req.body.uploadInsurancePolicy = await uploadFileToBlob(files.insurancePolicy[0])
        req.body.uploadInsurancePolicy = req.body.uploadInsurancePolicy.split('?')[0];

        if (files.relationshipProof) {
          req.body.uploadProof = await uploadFileToBlob(files.relationshipProof[0])
          req.body.uploadProof = req.body.uploadProof.split('?')[0];
        }

        if (files.hospitalBill) {
          req.body.uploadHospitalBill = await uploadFileToBlob(files.hospitalBill[0])
          req.body.uploadHospitalBill = req.body.uploadHospitalBill.split('?')[0];
        }
        if (files.incomeProof) {
          req.body.uploadIncomeProof = await uploadFileToBlob(files.incomeProof[0])
          req.body.uploadIncomeProof = req.body.uploadIncomeProof.split('?')[0];
        }
        if (files.bankStatement) {
          req.body.uploadBankStatement = await uploadFileToBlob(files.bankStatement[0])
          req.body.uploadBankStatement = req.body.uploadBankStatement.split('?')[0];
        }
        if (files.otherDoc) {
          req.body.uploadOtherDoc = await uploadFileToBlob(files.otherDoc[0])
          req.body.uploadOtherDoc = req.body.uploadOtherDoc.split('?')[0];
        }

        const data = await BGServiceInstance.uploadDocuments(req.body as IPatientLoanDTO);
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
  route.use(errors());
}

