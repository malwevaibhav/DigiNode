import mongoose from 'mongoose';

const scrappedData = new mongoose.Schema({

    justDialID: {
        type: String,
        unique: true,
    },
    url: {
        type: String
    },
    name: {
        type: String,
    },
    address: {
        type: String
    },
    contactNo: {
        type: String
    },
    city: {
        type: String
    },
    latitude: {
        type: String
    },
    longitude: {
        type: String
    }
},
    {
        timestamps: true,
    }
);


export default mongoose.model<mongoose.Document>('scrappedData', scrappedData);

export interface scrappedDataDoc extends mongoose.Document {
    name: string,
    city: string,
    latitude: string,
    longitude: string,
    address: string
}