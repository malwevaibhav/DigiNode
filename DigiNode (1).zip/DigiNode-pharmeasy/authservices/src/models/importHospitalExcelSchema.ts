import { Organization } from '../../../userservices/src/models/organizationSchema';
import mongoose from 'mongoose';

const hospitalExlSchema = new mongoose.Schema({
    hospitalName: {
        type: String,
    },
    hsopitalLegalName: {
        type: String,
    },
    hospitalBankName: {
        type: String,
    },
    hospitalBankAccNumber: {
        type: String
    },
    hospitalBankBranch:{
        type:String
    },
    hospitalBankIFSC:{
        type:String
    },
    aggregatorName:{
        type:String
    }
});

export default mongoose.model<mongoose.Document>('hospitalexlschema', hospitalExlSchema);

export interface hospitalexldoc extends mongoose.Document {
    hospitalName:string,
    hsopitalLegalName:string,
    hospitalBankName:string,
    hospitalBankAccNumber:string,
    hospitalBankBranch:string,
    hospitalBankIFSC:string,
    aggregatorName:string,
}