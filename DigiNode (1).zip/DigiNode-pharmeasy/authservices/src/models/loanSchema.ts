import mongoose from 'mongoose';

const loansSchema = new mongoose.Schema(
  {
    KOCode: {
      type: String,
    },
    FullName: {
      type: String,
    },
    ApplicantsPanNo: {
      type: String,
    },
    ApplicantsAadhaarNo: {
      type: String,
    },
    DateOfBirth: {
      type: Date,
    },
    BankAssociated: {
      type: String,
    },
    Occupation: {
      type: String,
    },
    CurrentAddress: {
      type: String,
    },
    State: {
      type: String,
    },
    City: {
      type: String,
    },
    Country: {
      type: String,
    },
    uploadAadharDoc: {
      type: String,
    },
    uploadAadharDocs: {
      type: String,
    },
    uploadPANDoc: {
      type: String,
    },
    Pincode: {
      type: String,
    },
    MobileNumber: {
      type: String,
    },
    EmailId: {
      type: String,
    },
    LoanAmount: {
      type: Number,
    },
    LLCode: {
      type: String,
    },
    EMIAmount: {
      type: Number,
    },
    Scheme: {
      type: String,
    },
    ReferenceName: {
      type: String,
    },
    ActionNeeded: {
      type: String,
    },
    AlternateContactNumber: {
      type: Number,
    },
    Status: {
      type: String,
    },
    //String
    Interest: {
      type: String,
    },
    ProcessingFees: {
      type: String,
    },
    OfficeName: {
      type: String,
    },
    ROI: {
      type: String,
    },
    //For Disbursment
    AccountNumber: {
      type: String,
    },
    //For Repaymnet
    AccountNumberForSBI: {
      type: String,
    },
    District: {
      type: String,
    },
    Branch: {
      type: String,
    },
    BranchCode: {
      type: String,
    },
    IFSCCode: {
      type: String,
    },
    AccountHolderName: {
      type: String,
    },
    ApproveOrReject: {
      type: String,
    },
    valueChanged: {
      type: String,
    },
    ApplicationDate: {
      type: Date,
    },
    DisbursementDate: {
      type: Date,
    },
    RepaymentDate: {
      type: Date,
    },
    RepaymentDate1st: {
      type: Date,
    },
    RepaymentDate2nd: {
      type: Date,
    },
    RepaymentDate3rd: {
      type: Date,
    },
    RepaymentDate4th: {
      type: Date,
    },
    RepaymentDate5th: {
      type: Date,
    },
    RepaymentDate6th: {
      type: Date,
    },
    NachRegistration: {
      type: String,
    },
    Aggregator: {
      type: String,
    },
    startDate: {
      type: String,
    },
    endDate: {
      type: String,
    },
    CreatedDate: {
      type: Date,
    },
    UpdatedDate: {
      type: Date,
    },
    Lender: {
      type: String,
      default: null,
    },
  },
  {
    timestamps: true,
  },
);

export default mongoose.model<mongoose.Document>('loans', loansSchema);

export interface merchantLoanDoc extends mongoose.Document {
  KOCode: string,
 
  FullName: string,

  ApplicantsPanNo:string,
 
  ApplicantsAadhaarNo:string,
 
  DateOfBirth:Date,
 
  BankAssociated:string,
 
  Occupation:string,
 
  CurrentAddress:string,
 
  State:string,
 
  City:string,
 
  Country:string,
 
  uploadAadharDoc:string,
 
  uploadAadharDocs:string,
 
  uploadPANDoc:string,
 
  Pincode:string,
 
  MobileNumber:string,
 
  EmailId:string,
 
  LoanAmount:number,
 
  LLCode:string,
 
  EMIAmount:number,
 
  Scheme:string,
 
  ReferenceName:string,
 
  ActionNeeded:string,
 
  AlternateContactNumber:number,
 
  Status:string,
 
  //string
  Interest:string,
 
  ProcessingFees:string,
 
  OfficeName:string,
 
  ROI:string,
 
  //For Disbursment
  AccountNumber:string,
 
  //For Repaymnet
  AccountNumberForSBI:string,
 
  District:string,
 
  Branch:string,
 
  BranchCode:string,
 
  IFSCCode:string,
 
  AccountHolderName:string,
 
  ApproveOrReject:string,
 
  valueChanged:string,
 
  ApplicationDate:Date,
 
  DisbursementDate:Date,
 
  RepaymentDate:Date,
 
  RepaymentDate1st:Date,
 
  RepaymentDate2nd:Date,
 
  RepaymentDate3rd:Date,
 
  RepaymentDate4th:Date,
 
  RepaymentDate5th:Date,
 
  RepaymentDate6th:Date,
 
  NachRegistration:string,
 
  Aggregator:string,
 
  startDate:string,
 
  endDate:string,
 
  CreatedDate:Date,
 
  UpdatedDate:Date,
 
  Lender:string,
 
}
