import { Organization } from './../../../userservices/src/models/organizationSchema';
import mongoose from 'mongoose';

const mandateDetailsSchema = new mongoose.Schema({
    id: {
        type: String,
    },
    mandate_id: {
        type: String,
    },
    state: {
        type: String,
    },
    type: {
        type: String
    },
    umrn: {
        type: String
    },
    created_at: {
        type: Date
    },
    updated_at: {
        type: Date
    },
    mode: {
        type: String
    },
    auth_sub_mode: {
        type: String
    },
    bank_details:{
        type:Object
    },
    mandate_details:{
        type:Object
    },
    service_provider_details:{
        type:Object
    },
    invoiceId:{
        type:Number
    }
});

export default mongoose.model<mongoose.Document>('mandateDetails', mandateDetailsSchema);

export interface mandateDetails extends mongoose.Document {
    id:string,
    mandate_id:string,
    state:string,
    type:string,
    umrn:string,
    created_at:Date,
    updated_at:Date,
    mode:string,
    auth_sub_mode:string,
    bank_details:object,
    mandate_details:object,
    service_provider_details:object,
    invoiceId:number
}