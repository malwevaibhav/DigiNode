import mongoose from 'mongoose';

const digioLog = new mongoose.Schema({

    entities: {
        type: String
    },
    txn_timestamp: {
        type: Date
    },
    txn_reject_reason: {
        type: String
    },
    umrn: {
        type: String
    },
    auth_sub_mode: {
        type: String
    },
    txn_reject_code: {
        type: String
    },
    current_status: {
        type: String
    },
    message_id: {
        type: String
    },
    mandate_id: {
        type: String
    },
    npci_txn_id: {
        type: String
    },
    scheme_ref_number: {
        type: String
    },
    customer_ref_number: {
        type: String
    },
    tags: {
        type: String
    },
    created_at: {
        type: Date
    },
    digio_msg_id: {
        type: String
    },
    event: {
        type: String
    },
    // agreement webhook
    updated_at: {
        type: Date
    },
    sign_request_details: {
        type: Object
    },
    file_name: {
        type: String
    },
    agreement_status: {
        type: String
    },
    agreement_documentId: {
        type: String
    },
    signing_parties: {
        type: Array
    },
    others: {
        type: Object
    },
    // KYC webhook 
    KYCStatus: {
        type: String
    },
    KYCRequestId: {
        type: String
    },
    reference_id:{
        type: String
    },
    // nach debit
    mandateDebitId:{
        type: String
    },
    settlement_date:{
        type: Date
    },
    user_name:{
        type: String
    },
    amount_in_paise:{
        type: String
    },
    txn_reference:{
        type: String
    },
    scheduled_payment_id:{
        type: String
    },
    failure_reason:{
        type: String
    },
    failure_description:{
        type: String
    },
    status:{
        type: String
    },
    transaction_id:{
        type: String
    },
    total_payment_count:{
        type: String
    },
    processed_payment_count:{
        type: String
    },
    next_scheduled_settlement_date:{
        type: String
    },
    service_provider_name:{
        type: String
    },
    sponsor_bank_name:{
        type: String
    },
    transaction_type:{
        type: String
    }

}, { timestamps: true })


export default mongoose.model<mongoose.Document>('digioLog', digioLog);


