import { Organization } from './../../../userservices/src/models/organizationSchema';
import mongoose from 'mongoose';

const notificationSchema = new mongoose.Schema({
    text: {
        type: String,
    },
    sent: {
        type: Boolean,
    },
    read: {
        type: Boolean,
    },
    organization: {
        type: String
    },
    role:{
        type:String
    },
    organizationId:{
        type:mongoose.Schema.Types.ObjectId
    },
    UserId:{
        type:mongoose.Schema.Types.ObjectId
    }
});

export default mongoose.model<mongoose.Document>('notification', notificationSchema);

export interface notification extends mongoose.Document {
    text: string,
    sent: Boolean,
    read: Boolean,
    organization: string,
    role: string,
    organizationId:string
    UserId:string
}