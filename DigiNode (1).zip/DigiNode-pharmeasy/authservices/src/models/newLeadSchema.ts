import mongoose, { ObjectId } from 'mongoose';

const newLeadSchema = new mongoose.Schema(
    {
        leadType: {
            type: String,
            enum: ['Patient', 'Hospital', 'Partner', 'Contact'],
            required: [true, 'Please enter a lead type'],
        },

        name: {
            type: String,
            required: [true, 'Please enter a full name']
        },

        contactNumber: {
            type: String
        },

        altContactNumber: {
            type: String
        },

        email: {
            type: String,
            lowercase: true,
        },

        address: {
            type: String
        },

        isInsured: {
            type: Boolean
        },

        insuranceName: {
            type: String
        },

        financialAssistance: {
            type: String
        },

        specialty: {
            type: String
        },
        product: { 
            type: String
        },
        cashlessClaimFinancing: {
            type: Boolean
        },

        message: {
            type: String,
        },

        leadStatus: {
            type: String,
            enum: ['Open', 'On boarded', 'Not Converted'],
            default: "Open"
        }
    },
    { timestamps: true },

);

export default mongoose.model<mongoose.Document>('newLead', newLeadSchema);