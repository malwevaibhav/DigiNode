import { Container } from 'typedi';
import AuthService from "../services/auth";

var fs = require("fs");
const qrcode = require('qrcode-terminal');

const { Client, LocalAuth } = require('whatsapp-web.js');
const notifSchema = require("../models/notificationSchema").default;

const whatsappClient = new Client({ authStrategy: new LocalAuth() });

whatsappClient.on('qr', qr => {
  //qrcode.generate(qr, { small: true });
});

whatsappClient.on('ready', () => {
  console.log('whatsappClient is ready!');
  // getChats();
  // sendFailedNotifications();
});

whatsappClient.on('authenticated', (session) => {
  console.log('AUTHENTICATED', session);
});

whatsappClient.initialize().catch((err) => {
  console.log(err)
});

export default whatsappClient;

async function sendFailedNotifications() {
  try {
    console.log("sending failed notifications")

    const notifications = await notifSchema.find({ sent: false });
    for (var i = 0; i < notifications.length; i++) {
      console.log(i)
      var notification = notifications[i];
      const AuthServiceInstance = Container.get(AuthService);
      await AuthServiceInstance.whatsappClient(notification.text, notification._id, notification.organization)
    }
    console.log("notifications job completed")
  } catch (error) {
    console.log(error)
  }
}
async function getChats() {
  const chats = await whatsappClient.getChats()
  for (var i = 0; i < chats.length; i++) {
    var chat = chats[i];
    if (chat.isGroup) {
      console.log(chat.id, chat.name)
    }
  }
}