import config from '../config';
import EmailSequenceJob from '../jobs/emailSequence';
import Agenda from 'agenda';
import updateBGStatus from '../jobs/BGStatusJob';
import getBGPatientJob from '../jobs/getBGPatientJob';

export default ({ agenda }: { agenda: Agenda }) => {
  agenda.define(
    'send-email',
    { priority: 'high', concurrency: config.agenda.concurrency },
    // @TODO Could this be a static method? Would it be better?
    new EmailSequenceJob().handler,
  );

  // agenda.define(
  //   'updateBGStatus',
  //   {priority: 'high', concurrency: config.agenda.concurrency},
  //   new updateBGStatus().handler,
  // );
  // agenda.define(
  //   'getBGPatientJob',
  //   {priority: 'high', concurrency: config.agenda.concurrency},
  //   new getBGPatientJob().handler,
  // );

  (async function() {
    await agenda.start();
    //await agenda.every('8 hours',"updateBGStatus", {},{ timezone: "Asia/Kolkata"})
    //await agenda.every('8 hours',"getBGPatientJob", {},{ timezone: "Asia/Kolkata"})
  })();
};
