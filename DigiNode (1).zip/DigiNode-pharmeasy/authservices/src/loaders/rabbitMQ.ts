import axios, { AxiosRequestConfig, AxiosResponse } from 'axios';
import fs from 'fs';
import patientLoans from '../models/patientloans';
import moment from 'moment';

const amqplib = require('amqplib/callback_api');

import util from 'util'
import nodeMailerService from './nodemailer';
import { Container } from 'typedi/Container';
// const util = require('util')
const gc = require('../api/GCP/gcp')
const bucket = gc.bucket('digisparsh_images')

// Blob Storage
const { BlobServiceClient } = require("@azure/storage-blob");
const containerName = "uatcontainer";
const sasToken = "sv=2021-06-08&ss=bfqt&srt=sco&sp=rwdlacupiytfx&se=2024-02-20T16:47:15Z&st=2023-02-20T08:47:15Z&spr=https&sig=BDmeVstReLGKpmVAufC%2FKQd2afDfAPdO4LzQgdB1SXo%3D";
const storageAccountName = "uatresource";
const key = "uaEjdcwzjVO7U7qv/JFnOnsEXUxQHQ46zI4x+onZBXL9UPCLEfEk+xd0sMB0ZWmZGuRLXdxjDzBIUba3A5CUrw==";

const createBlobInContainer = async (containerClient, filename, mimetype) => {
  const blobClient = containerClient.getBlockBlobClient(filename);
  const options = { blobHTTPHeaders: { blobContentType: mimetype } };
  var a = await blobClient.uploadData(
    fs.readFileSync("uploads/" + filename),
    options
  );
  return blobClient.url;
};
const uploadFileToBlob = async (filename, mimetype) => {
  if (!filename || !mimetype) return [];
  const blobService = new BlobServiceClient(
    `https://${storageAccountName}.blob.core.windows.net/?${sasToken}`
  );
  const containerClient = blobService.getContainerClient(containerName);
  var response = await createBlobInContainer(containerClient, filename, mimetype);
  return response;
};
// Upload Image

const uploadImage = (originalname, buffer) => new Promise((resolve, reject) => {
  // const { originalname, buffer } = file

  const blob = bucket.file(originalname.replace(/ /g, "_"))
  const blobStream = blob.createWriteStream({
    resumable: false
  })

  var blobb = blobStream.on('finish', () => {
    const publicUrl = util.format(
      `https://storage.googleapis.com/${bucket.name}/${blob.name}`
    )
    console.log(publicUrl)
    resolve(publicUrl)

  })
    .on('error', (err) => {
      reject(`Unable to upload image, something went wrong=>${err}`)
    })
    .end(buffer)

})

// RabbitMQ Consumer

let consumerChannel;
amqplib.connect('amqp://localhost',{timeout: 200000}, (err, conn) => {
  if (err) throw err;

  conn.createChannel((err, channel) => {
    if (err) throw err;

    consumerChannel = channel

    consumerChannel.assertQueue('digioQueue');

    consumerChannel.consume('digioQueue', (msg) => {
      if (msg !== null) {
        const msgJSON = JSON.parse(msg.content.toString())
        // console.log('msgJSON ::=>', msgJSON);
        // console.log("************** msg end *******************");
        
        
        // console.log('digioQueue Msg', msgJSON);
        if (msgJSON.msgType == 'downloadAgreement' &&  msgJSON.agreementDocId != undefined) { downloadAgreementDoc(msg, msgJSON.agreementDocId, msgJSON._id) }
        else if (msgJSON.msgType == 'verifyBankAccount') { verifyBankAccount(msg, msgJSON.contactNumber, msgJSON.patientName, msgJSON.invoiceId, msgJSON._id) }
        else if (msgJSON.msgType == 'fetchBankDetails') { fetchBankDetails(msg, msgJSON.KYCRequestId, msgJSON.reference_id) }
        else if (msgJSON.msgType == 'fuzzyMatchName') { fuzzyMatchName(msg, msgJSON.patientName, msgJSON.borrowerName, msgJSON.accountHolderName, msgJSON._id) }
        else if (msgJSON.msgType == 'manageApproval') { manageApproval(msg, msgJSON.KYCRequestId, msgJSON.responseData) }
        else if (msgJSON.msgType == 'createMandateForm') { createMandateForm(msg, msgJSON.emailId, msgJSON.accountHolderName, msgJSON.invoiceId, msgJSON.contactNumber, msgJSON.accountNumber, msgJSON.IFSCCode, msgJSON.finalApprovedAmount, msgJSON._id) }
        else if (msgJSON.msgType == 'mandatePresentation') { mandatePresentation(msg, msgJSON.mandateUMRN, msgJSON.finalApprovedAmount, msgJSON._id) }
        // console.log(msgJSON.agreementDocId,"hhhhhhhhhhhhhhhh");
        
      } else {
        console.log('Consumer cancelled by server');
      }
    });
  });
});
// RabbitMQ Producer
let producerChannel;
amqplib.connect('amqp://localhost',{timeout: 200000}, function (error, connection) {

  if (error) {
    throw error;
  }
  connection.createChannel(function (error1, channel) {
    if (error1) {
      throw error1;
    }
    producerChannel = channel
  });

});

const pushToQueue = async (msg) => {
  try {
    producerChannel.assertQueue('digioQueue', {
      durable: true
    });
    producerChannel.sendToQueue('digioQueue', Buffer.from(msg), {
      persistent: true
    });
    console.log("Sent '%s'", msg);

  } catch (e) {
    console.log(e);
    throw e;
  }
}

export default pushToQueue;

// functions
const downloadAgreementDoc = async (msg, agreementDocId, _id) => {
  try {
    console.log("agreementDocId ::=>",agreementDocId);
    
    const config: AxiosRequestConfig = {
      method: 'GET',
      url: `${process.env.digioURL}/v2/client/document/download?document_id=${agreementDocId}`,
      auth: {
        username: process.env.digioUsername,
        password: process.env.digioSecret
      },
      responseType: 'stream'
    };
    let response;
    let fileName = `${Date.now()}-agreement.pdf`
    try {
      response = await axios(config);
    }
    catch (e) {
      console.log('digio error', e.response.statusText, e.response.data);
    }
    var agreementDocUrl;

    var stream = response.data.pipe(fs.createWriteStream(`uploads/${fileName}`))
    await new Promise(fulfill => stream.on('finish', fulfill));
    const fileBuffer =fs.readFileSync(`uploads/${fileName}`)
    const base64 =fs.readFileSync(`uploads/${fileName}`,{encoding: 'base64'})

    // GCP Implementation
    agreementDocUrl = await uploadImage(fileName, fileBuffer);
    agreementDocUrl = agreementDocUrl.split('?')[0];
  
   
    
    const nodeMailerservice = Container.get(nodeMailerService);
   
    fs.unlinkSync(`uploads/${fileName}`);

    const invoiceUpdate = await patientLoans.findByIdAndUpdate(
      { _id: _id },
      { $set: { agreementDocUrl: agreementDocUrl } },
      { useFindAndModify: false, new: true }
    )
      //Send email 
      if(invoiceUpdate){
        let maildata={
          // email:invoiceUpdate.email,
          patientName:invoiceUpdate.patientName,
          invoiceId:invoiceUpdate.invoiceId,
          blobData:base64
        }
        await nodeMailerservice.sendemailToOps(maildata)
      }
   
    if (invoiceUpdate && agreementDocUrl) { consumerChannel.ack(msg); }

  } catch (e) {
    console.log(e);
  }
}
const verifyBankAccount = async (msg, contactNumber, patientName, invoiceId, _id) => {
  try {
    const config: AxiosRequestConfig = {
      method: 'POST',
      url: `${process.env.digioURL}/client/kyc/v2/request`,
      data: {
        "customer_identifier": contactNumber,
        "customer_name": patientName,
        "reference_id": invoiceId,
        "notify_customer": true,
        "actions": [
          {
            "type": "PENNY_DROP",
            "title": "Bank Account Verification",
            "description": "Please enter bank account details for penny drop"
          }
        ]
      },
      auth: {
        username: process.env.digioUsername,
        password: process.env.digioSecret
      }
    };

    let response;
    try {
      response = await axios(config);
    }
    catch (e) {
      console.log('digio error', e.response.statusText, e.response.data);
    }
    const invoiceUpdate = await patientLoans.findByIdAndUpdate(
      { _id: _id },
      { $set: { invoiceSubStatus: "Awaiting Bank Verification", KYCRequestId: response.data.id } },
      { useFindAndModify: false }
    )
    if (invoiceUpdate) { consumerChannel.ack(msg); }

  } catch (e) {
    console.log(e);
    throw e;
  }
}
const fetchBankDetails = async (msg, KYCRequestId, reference_id) => {
  try {
    const config: AxiosRequestConfig = {
      method: 'POST',
      url: `${process.env.digioURL}/client/kyc/v2/${KYCRequestId}/response`,
      data: {},
      auth: {
        username: process.env.digioUsername,
        password: process.env.digioSecret
      }
    };
    let response;
    try {
      response = await axios(config);
    }
    catch (e) {
      console.log('digio error', e.response.statusText, e.response.data);
    }
    if (response && response.data && response.data.actions && response.data.actions[0] && response.data.actions[0].type == 'penny_drop' &&
      response.data.actions[0].details && response.data.actions[0].details.status == 'COMPLETED') {

      const invoiceData: any = await patientLoans.findOneAndUpdate(
        { KYCRequestId: KYCRequestId, invoiceId: reference_id },
        {
          $set: {
            // invoiceSubStatus: 'Pending E-Nach',
            accountNumber: response.data.actions[0].details.beneficiary_account_no,
            IFSCCode: response.data.actions[0].details.ifsc,
            accountHolderName: response.data.actions[0].details.beneficiary_name_with_bank
          }
        },
        { useFindAndModify: false, new: true }
      )
      if (invoiceData) {
        consumerChannel.ack(msg);
        pushToQueue(JSON.stringify({ msgType: "fuzzyMatchName", borrowerName: invoiceData.borrowerName, patientName: invoiceData.patientName, accountHolderName: invoiceData.accountHolderName, _id: invoiceData._id }));

      }
    }
  } catch (e) {
    console.log(e);
    throw e;
  }
}
const fuzzyMatchName = async (msg, patientName, borrowerName, accountHolderName, _id) => {
  try {
    var customerName = borrowerName ? borrowerName : patientName;
    const config: AxiosRequestConfig = {
      method: 'POST',
      url: `${process.env.digioURL}/v3/client/kyc/fuzzy_match`,
      data: {
        "context": "Name",
        "source": {
          "text": customerName
        },
        "target": {
          "text": accountHolderName
        },
        "confidence": 25
      },
      auth: {
        username: process.env.digioUsername,
        password: process.env.digioSecret
      }
    };
    let response;
    try {
      response = await axios(config);
    }
    catch (e) {
      console.log(e.response.data)
      return {
        success: false,
        message: e.response.data.message
      }
    }
    let invoiceDetails;
    if (response && response.data && response.data.matched == true) {
      invoiceDetails = await patientLoans.findByIdAndUpdate(
        { _id: _id },
        { $set: { invoiceSubStatus: "Awaiting E-Nach", mandate_id: response.data.mandate_id } },
        { useFindAndModify: false }
      )
      pushToQueue(JSON.stringify({
        msgType: "createMandateForm",
        emailId: invoiceDetails.emailId,
        accountHolderName,
        invoiceId: invoiceDetails.invoiceId,
        contactNumber: invoiceDetails.contactNumber,
        accountNumber: invoiceDetails.accountNumber,
        IFSCCode: invoiceDetails.IFSCCode,
        finalApprovedAmount: invoiceDetails.finalApprovedAmount,
        _id
      }));
    }
    else if (response && response.data && response.data.matched == false) {
      invoiceDetails = await patientLoans.findByIdAndUpdate(
        { _id: _id },
        { $set: { invoiceSubStatus: "Bank Verification Failed", failureReason: 'Borrower and account holder name did not match' } },
        { useFindAndModify: false }
      )
    }
    if (invoiceDetails) {
      consumerChannel.ack(msg);
      // pushToQueue(JSON.stringify({ msgType: "manageApproval", KYCRequestId: invoiceDetails.KYCRequestId, responseData: response.data }));
    }

  } catch (e) {
    console.log(e);
    throw e;
  }
}
const createMandateForm = async (msg, emailId, accountHolderName, invoiceId, contactNumber, accountNumber, IFSCCode, finalApprovedAmount, _id) => {
  try {
    var digioObj: any = {}

    digioObj.customer_email = emailId;
    digioObj.customer_name = accountHolderName;
    digioObj.customer_ref_number = invoiceId;
    digioObj.customer_mobile = contactNumber;
    digioObj.customer_account_number = accountNumber;
    digioObj.destination_bank_id = IFSCCode;
    digioObj.first_collection_date = moment().format('YYYY-MM-DD');
    digioObj.instrument_type = "debit";
    digioObj.is_recurring = true;
    digioObj.frequency = "Monthly";
    digioObj.management_category = "L001";
    digioObj.maximum_amount = finalApprovedAmount;
    let updateInvoice;
    const config: AxiosRequestConfig = {
      method: 'POST',
      url: `${process.env.digioURL}/v3/client/mandate/create_form`,
      data: {
        "auth_mode": "api",
        "corporate_config_id": process.env.corporate_config_id,
        "customer_identifier": contactNumber,
        "mandate_type": "create",
        "notify_customer": "true",
        "mandate_data": digioObj
      },
      auth: {
        username: process.env.digioUsername,
        password: process.env.digioSecret
      }
    };
    let response;
    try {
      response = await axios(config);
    }
    catch (e) {
      console.log(e.response.data)
      // not needed on production
      updateInvoice = await patientLoans.findByIdAndUpdate(
        { _id: _id },
        { $set: { invoiceSubStatus: "E-Nach Failed", NachFailureReason: e.response.data.message } },
        { useFindAndModify: false }
      )
    }

    if (response && response.data && response.data.mandate_id) {
      updateInvoice = await patientLoans.findByIdAndUpdate(
        { _id: _id },
        { $set: { invoiceSubStatus: "Awaiting E-Nach", mandate_id: response.data.mandate_id } },
        { useFindAndModify: false ,new:true}
      )
      if(updateInvoice){
        const nodeMailerservice = Container.get(nodeMailerService);
        await nodeMailerservice.sendemailToEmandate(updateInvoice)
      }
      
    }
    if (updateInvoice) { consumerChannel.ack(msg); }
  } catch (e) {
    console.log(e);
    throw e;
  }
}
const manageApproval = async (msg, KYCRequestId, responseData) => {
  try {
    const config: AxiosRequestConfig = {
      method: 'POST',
      url: `${process.env.digioURL}/client/kyc/v2/request/${KYCRequestId}/manage_approval`,
      auth: {
        username: process.env.digioUsername,
        password: process.env.digioSecret
      }
    };
    if (responseData.matched) { config.data = { "status": "APPROVED" } }
    else { config.data = { "status": "REJECTED" } }

    let response;
    try {
      response = await axios(config);
    }
    catch (e) {
      console.log('digio error', e.response.statusText, e.response.data);
    }
    console.log('Approval status', response.data.status)
    if (response.data.status = 'approved') { consumerChannel.ack(msg) }

  } catch (e) {
    console.log(e);
  }
}
const mandatePresentation = async (msg, mandateUMRN, finalApprovedAmount, _id) => {
  try {
    const config: AxiosRequestConfig = {
      method: 'POST',
      url: `${process.env.digioURL}/v3/client/nach_debit/scheduled/register`,
      data: {
        "umrn": mandateUMRN,
        "amount": finalApprovedAmount,
        // "settlement_date": "2021-10-16",
        "corporate_account_number": process.env.corporate_account_number,
        // "corporate_config_id": process.env.corporate_config_id,
        // "destination_bank_id": invoice.IFSCCode,
        // "customer_account_number": invoice.accountNumber,
        // "customer_name": invoice.borrowerName,
        // "frequency": "monthly"
      },
      auth: {
        username: process.env.digioUsername,
        password: process.env.digioSecret
      }
    };
    let response;
    try {
      response = await axios(config);
    }
    catch (e) {
      console.log('digio error', e.response.statusText, e.response.data);
    }
    if (response && response.data && response.data.id) {
      const updateInvoice = await patientLoans.findByIdAndUpdate({ _id: _id },
        { $set: { invoiceSubStatus: 'Mandate Presented', mandateDebitId: response.data.id, debitTxnId: response.data.upcoming_transaction.id } },
        { new: true, useFindAndModify: false }
      );
      if (updateInvoice) { consumerChannel.ack(msg); }
    }
  } catch (e) {
    console.log(e);
    throw e;
  }
}