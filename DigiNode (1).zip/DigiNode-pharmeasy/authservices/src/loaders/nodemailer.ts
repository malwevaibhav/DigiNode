const nodemailer = require('nodemailer');

export default class nodeMailerService {
    constructor(
    ) { }

   public async sendemailforPatient(invoiceData){
                console.log( "invoiceData" ,invoiceData);
                const email = "shivam.gupta@moreyeahs.in"
                const name = "operation"
                    var transporter = nodemailer.createTransport({
                      service: 'outlook',
                      host: 'smtp.office365.com',
                      port: 587,
                      auth: {
                        user: 'connect@digisparsh.in',
                        pass: 'Digisparsh@2022'
                      }
                    });
                  console.log(email, 'email')
                  var mailOptions = {
                    from: 'connect@digisparsh.in',
                    to: email,
                    subject: `Invoice no  ${invoiceData} : Patient finance alert: Pending disbursal for New Case`,
                    html: `<h4>Dear Thar Team,</h4></br>
            
             <p>A new patient reimbursement finance case Invoice  no <span style="color:#008F99;">${invoiceData}</span> is pending for your Disbursal.</p>
             <p>Kindly login and disburse the same.</p>
           
             <h4>Regards</h4>
             <h4>Tech team</h4>`
                  };
                  transporter.sendMail(mailOptions, function(error, info){
                      if (error) {
                        console.log(error);
                      } else {
                        console.log('Email sent: ' + info.response);
                      }
                    });
                  }
   public async sendemailToLendor(Data){
                console.log( "invoiceData" ,Data.invoiceData);
                const email ="rlazarus@moreyeahs.in"
                const name = "operation"
                    var transporter = nodemailer.createTransport({
                      service: 'outlook',
                      host: 'smtp.office365.com',
                      port: 587,
                      auth: {
                        user: 'connect@digisparsh.in',
                        pass: 'Digisparsh@2022'
                      }
                    });
                  console.log(email, 'email')
                  var mailOptions = {
                    from: 'connect@digisparsh.in',
                    to: email,
                    subject: `Invoice no  ${Data.invoiceData} : Mandate Details`,
                    html: `<h4>Dear Thar Team,</h4></br>
            
             <p>A new patient reimbursement finance case Invoice  no <span style="color:#008F99;">${Data.invoiceData}</span> ,Mandate Details</p>
             <p>Kindly Check</p>
           
             <h4>Regards</h4>
             <h4>Tech team</h4>`
                  };
                  transporter.sendMail(mailOptions, function(error, info){
                      if (error) {
                        console.log(error);
                      } else {
                        console.log('Email sent: ' + info.response);
                      }
                    });
                  }
   public async sendemailToOps(Data){
                console.log( "invoiceData" ,Data);
                const email ="rlazarus@moreyeahs.in"
                const name = "operation"
                    var transporter = nodemailer.createTransport({
                      service: 'outlook',
                      host: 'smtp.office365.com',
                      port: 587,
                      auth: {
                        user: 'connect@digisparsh.in',
                        pass: 'Digisparsh@2022'
                      }
                    });
                  console.log(email, 'email')
                  var mailOptions = {
                    from: 'connect@digisparsh.in',
                    to: email,
                    subject: `Patient Reimbursement Invoice no ${Data.invoiceId}: Customer Agreement signing alert`,
                    html: `<h4>Dear Ops Team,</h4></br>
            
             <p>Customer name${Data.patientName}Invoice no${Data.invoiceId} has successful signed the agreement.</p>
             <p>Please find attached the signed copy of the agreement in the PDF format.</p>
             <h4>Regards</h4>
             <h4>DSPL team</h4>`,
             attachments: [
              {
                filename: 'Agreement.pdf',
                path: Data.blobData,
              },
            ],
                  };
                  transporter.sendMail(mailOptions, function(error, info){
                      if (error) {
                        console.log(error);
                      } else {
                        console.log('Email sent: ' + info.response);
                      }
                    });
                  }
   async sendemailToEmandate(Data){
    console.log( "sendemailToEmandate" ,Data);
    console.log( "Data?.mandate_id" ,Data?.mandate_id);
    console.log( "Data?._doc.service_provider_details?.service_provider_name" ,Data?._doc.service_provider_details?.service_provider_name);
    console.log( "Data?._doc.service_provider_details?.service_provider_utility_code" ,Data?._doc.service_provider_details?.service_provider_utility_code);
    // console.log( "Data?.bank_details.bank_name" ,Data?.bank_details.bank_name);
    console.log( "Data?._doc.mandate_details?.customer_account_type" ,Data?._doc.mandate_details?.customer_account_type);
    console.log( "Data?._doc.mandate_details?.customer_account_number" ,Data?._doc.mandate_details?.customer_account_number);

                    const email =["rlazarus@moreyeahs.in","shivam.gupta@moreyeahs.in","mayank.bharade@moreyeahs.in","Hitesh.Bhatia@digisparsh.in"]
                    const name = "operation"
                        var transporter = nodemailer.createTransport({
                          service: 'outlook',
                          host: 'smtp.office365.com',
                          port: 587,
                          auth: {
                            user: 'connect@digisparsh.in',
                            pass: 'Digisparsh@2022'
                          }
                        });
                      console.log(email, 'email')
                      const dataX = `<h4>Dear Ops Team,</h4></br>
                
                      <p>Customer has successfully created the emandate for the Invoice no. ${Data.invoiceId}</p>
                      <p>The details of the mandate are as follows:-</p>
     
     
                      <p> Kindly login at DSPL portal for the generation of the PDF of the mandate.</p>
                      <ul>
                      <li>Mandate Id:-<b>${Data?.mandate_id}</b></li>
                      <li>Service Provider Name:-<b>${Data?._doc.service_provider_details?.service_provider_name}</b></li>
                      <li>Service provider Utility code:-<b>${Data?._doc.service_provider_details?.service_provider_utility_code}</b></li>
                      <li>Customer Account type:-<b>${Data?._doc.mandate_details?.customer_account_type}</b></li>
                      <li>Customer Account number:-<b>${Data?._doc.mandate_details?.customer_account_number}</b></li>
                    </ul>
                      <h4>Regards</h4>
                      <h4>Tech team</h4>`


                      var mailOptions = {
                        from: 'connect@digisparsh.in',
                        to: email,
                        subject: `Patient finance alert_Emandate Set up_Invoice no ${Data.invoiceId}`,
                        html: `${dataX}`
                      };

                      console.log(mailOptions)

                      transporter.sendMail(mailOptions, function(error, info){
                          if (error) {
                            console.log(error);
                          } else {
                            console.log('Email sent: ' + info.response);
                          }
                        });
                  }                   
}


