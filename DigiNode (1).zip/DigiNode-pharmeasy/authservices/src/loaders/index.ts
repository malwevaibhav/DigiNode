import expressLoader from './express';
import dependencyInjectorLoader from './dependencyInjector';
import mongooseLoader from './mongoose';
import jobsLoader from './jobs';
import Logger from './logger';
import whatsappClient from './whatsappClient';
//We have to import at least all the events once so they can be triggered
import './events';

export default async ({ expressApp }) => {
  const mongoConnection = await mongooseLoader();
  Logger.info('✌️ DB loaded and connected!');

  /**
   * WTF is going on here?
   *
   * We are injecting the mongoose models into the DI container.
   * I know this is controversial but will provide a lot of flexibility at the time
   * of writing unit tests, just go and check how beautiful they are!
   */

  const userModel = {
    name: 'userModel',
    // Notice the require syntax and the '.default'
    model: require('../models/user').default,
  };
  const organizationModel = {
    name: 'organizationModel',
    model: require('../models/organizationSchema').default,
  }
  const productMappingModel = {
    name: 'productMappingModel',
    model: require('../models/productMapping').default,
  }
  const merchantLoanModel = {
    name: 'merchantLoanModel',
    model: require('../models/loanSchema').default,
  }
  const approvedLoanModel = {
    name: 'approvedLoanModel',
    model: require('../models/approvedLoansSchema').default,
  }
  const BeemaGarageModel = {
    name: 'BeemaGarageModel',
    model: require('../models/BGpatientScheema').default,
  }
  const patientLoanModel = {
    name: 'patientLoanModel',
    // Notice the require syntax and the '.default'
    model: require('../models/patientloans').default,
  };
  const BGcaseModel = {
    name: 'BGcaseModel',
    model: require('../models/BGcaseScheema').default,
  }
  const notificationModel = {
    name: 'notificationModel',
    model: require('../models/notificationSchema').default,
  }
  const newLeadModel = {
    name: 'newLeadModel',
    // Notice the require syntax and the '.default'
    model: require('../models/newLeadSchema').default,
  };
  const scrappedDataModel = {
    name: 'scrappedData',
    model: require('../models/scrappedData').default,
  };
  const digioLogModel = {
    name: 'digioLogModel',
    model: require('../models/digioLogSchema').default,
  };
  const mandateDetailsModel = {
    name: 'mandateDetailsModel',
    model: require('../models/mandateDetailsSchema').default,
  };
  const importHospitalExcelSchema = {
    name: 'importHospitalExcelSchema',
    model: require('../models/importHospitalExcelSchema').default,
  };

  const { agenda } = await dependencyInjectorLoader({
    mongoConnection,
    models: [
      userModel,
      organizationModel,
      productMappingModel,
      merchantLoanModel,
      approvedLoanModel,
      // salaryModel,
      // whateverModel
      BeemaGarageModel,
      patientLoanModel,
      BGcaseModel,
      notificationModel,
      newLeadModel,
      scrappedDataModel,
      digioLogModel,
      mandateDetailsModel,
      importHospitalExcelSchema
    ],
  });
  Logger.info('✌️ Dependency Injector loaded');

  await jobsLoader({ agenda });
  Logger.info('✌️ Jobs loaded');

  await expressLoader({ app: expressApp });
  Logger.info('✌️ Express loaded');
};
