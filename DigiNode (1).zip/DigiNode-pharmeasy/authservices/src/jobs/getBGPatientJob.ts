import { Container } from 'typedi';
import { Logger } from 'winston';
import BimaService from '../services/BGservice';
import BGPatients from '../models/BGpatientScheema';

export default class getBGPatientJob {
    public async handler(job, done): Promise<void> {
        const Logger: Logger = Container.get('logger');
        Logger.debug('running getBGPatientJob job');
        try {
            const BimaServiceInstance = Container.get(BimaService);
            var patients = await BimaServiceInstance.getpatient();
            async function saveBGPatient() {
                try {
                    loop1: for (var i = 0; i < patients.length; i++) {
                        var patient = await BGPatients.findOne({ primary_phone: patients[i].primary_phone })
                        if (!patient) {
                            patients[i].Bg_Patient_id = patients[i].id;
                            delete patients[i].id
                            var savePatient = await BGPatients.create(patients[i])
                            if (savePatient){
                                Logger.debug(`New patient added, primary_phone: ${patients[i].primary_phone}`)
                            }
                        }

                    };
                } catch (e) { Logger.error(`🔥 Error updating patient (primary_phone) : ${patients[i].primary_phone}` + '-' + `${e}`) }

            }
            saveBGPatient();
            Logger.debug('Bima Status updated');
            done();
        } catch (e) {
            Logger.error('🔥 Error with getBGPatientJob Job: %o', e);
            done(e);
        }
    }
}
