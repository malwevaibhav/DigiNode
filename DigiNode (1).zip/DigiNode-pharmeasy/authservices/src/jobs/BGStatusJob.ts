import { Container } from 'typedi';
import { Logger } from 'winston';
import BimaService from '../services/BGservice';
import BGcase from '../models/BGcaseScheema';

export default class updateBGStatus {
    public async handler(job, done): Promise<void> {
        const Logger: Logger = Container.get('logger');
        Logger.debug('running updateBGStatus job');
        try {
            const bimaCases: any = await BGcase.find(
                {
                    $or: [
                        { claim_status: "Query Pending" },
                        { claim_status: "Preauth Initiated" },
                        { claim_status: "Final Approval Initiated" },
                        { claim_status: "File Dispatched" }]
                });
            async function updateBGStatus() {
                try {
                    loop1: for (var i = 0; i < bimaCases.length; i++) {
                        const BimaServiceInstance = Container.get(BimaService);
                        try { var BGCase = await BimaServiceInstance.check_case(bimaCases[i].case_id) }
                        catch (e) {
                            Logger.error(`🔥 Error updating case id : ${bimaCases[i].case_id}` + '-' + `${e.response.data.Message}`)
                            continue;
                        }

                        var updateCase = await BGcase.findOneAndUpdate(
                            { case_id: bimaCases[i].case_id },
                            { $set: { claim_status: BGCase.payload.claim_status } },
                            { useFindAndModify: false }
                        )
                    };
                } catch (e) { Logger.error(`🔥 Error updating case id : ${bimaCases[i].case_id}` + '-' + `${e}`) }

            }
            updateBGStatus();
            Logger.debug('Bima Status updated');
            done();
        } catch (e) {
            Logger.error('🔥 Error with updateBGStatus Job: %o', e);
            done(e);
        }
    }
}
