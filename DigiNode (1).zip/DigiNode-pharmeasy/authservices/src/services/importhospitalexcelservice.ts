import { Inject, Service } from "typedi";

@Service()
export default class excelService {
  constructor(
 
    @Inject('patientLoanModel') private patientLoanModel: Models.patientLoanModel,
    @Inject('importHospitalExcelSchema') private hospitalexlModel: Models.importHospitalExcelSchema,
    @Inject('organizationModel') private organizationModel: Models.organizationModel,
    @Inject('logger') private logger,
  ) {

  }
  public async   hospitalexlschema(req){
    const hospitaldata = {
      hospitalName: req.body.roomno,
      hsopitalLegalName: req.body.roomtype,
      hospitalBankName: req.body.bedcount,
      hospitalBankAccNumber: req.body.hospitalBankAccNumber,
      hospitalBankBranch: req.body.hospitalBankBranch,
      hospitalBankIFSC: req.body.hospitalBankIFSC
    };
  } 

  public async createHospitalBank(requestData){
    try {
      let invoicedata=   await this.hospitalexlModel.create(requestData)
      if(!invoicedata){
          return {success:false,message:"unable to create hospitalexl"}
      }
      console.log(invoicedata)
  
      return {
          success:true,
          message:invoicedata 
          
      }
   } catch (e) {
      this.logger.error(e);
      return {success:false}
   }
  

  }
  public async checkHospitalByLegalName(invoiceData){
    try {
      let invoiceSearchData:Array<object> = await this.hospitalexlModel.find({hsopitalLegalName:invoiceData?.hsopitalLegalName})
      if(invoiceSearchData?.length == 0){
        
        return {success:false}
      }

      return{
        success:true,
        invoiceData:invoiceSearchData
      }
    }  catch (e) {
      this.logger.error(e);
      return {success:false}
   }
  }
  public async UpdateBankDetails(data){
    try {
      let invoiceData = await this.hospitalexlModel.findOneAndUpdate({hospitalBankAccNumber:data.hospitalBankAccNumber},{$set:{...data}})
      if(!invoiceData){
        return {success:false}
      }
      return{
        success:true,
        invoiceData
      }
    }  catch (e) {
      this.logger.error(e);
      return {success:false}
   }
  }
  public async getAllHospitalBankDetails(OrgId){
    try {
      let orgDetails= await this.organizationModel.findById(OrgId)
      let HosBankDetails=[]
      if(!orgDetails){
        return {success:false,message:"Data Not Found"}
      }
      if(orgDetails?.typeOfOrganization=="Aggregator"){
         HosBankDetails = await this.hospitalexlModel.find({"aggregatorName":orgDetails.nameOfOrganization}).sort({"hospitalName":1})
        if(!HosBankDetails){
          return {success:false,message:"Data Not Found"}
        }
      }
      if(orgDetails?.typeOfOrganization=="Digisparsh"){
        HosBankDetails = await this.hospitalexlModel.find({}).sort({"hospitalName":1})
        if(!HosBankDetails){
          return {success:false,message:"Data Not Found"}
        }
      }
      
      return{
        success:true,
        HosBankDetails,
        message:"Bank Details Found Successfully"
      }
    }  catch (e) {
      this.logger.error(e);
      return {success:false}
   }
  }
}