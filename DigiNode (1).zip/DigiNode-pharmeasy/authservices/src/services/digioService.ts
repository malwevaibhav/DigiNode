import Container, { Service, Inject } from 'typedi';
import { Request, Response } from 'express';
import pushToQueue from '../loaders/rabbitMQ';
import nodeMailerService from '../loaders/nodemailer';
import axios, { AxiosRequestConfig, AxiosResponse } from 'axios';
@Service()
export default class digioService {
    constructor(
        @Inject('logger') private logger,
        @Inject('digioLogModel') private digioLogModel: Models.digioLogModel,
        @Inject('patientLoanModel') private patientLoanModel: Models.patientLoanModel,
        @Inject('mandateDetailsModel') private mandateDetailsModel: Models.mandateDetailsModel,
        @Inject('userModel') private userModel: Models.UserModel,
        private nodeMailerService: nodeMailerService,
    ) { }

    public async updateMandateStatus(req: Request): Promise<{ success: Boolean }> {
        try {
            var saveObj: any = {};

            saveObj.entities = req?.body?.entities[0]?req?.body?.entities[0]:'';
            saveObj.txn_timestamp = req?.body?.payload?.api_mandate?.txn_timestamp;
            saveObj.txn_reject_reason = req?.body?.payload?.api_mandate?.txn_reject_reason;
            saveObj.umrn = req?.body?.payload?.api_mandate?.umrn;
            saveObj.auth_sub_mode = req?.body?.payload?.api_mandate?.auth_sub_mode;
            saveObj.txn_reject_code = req?.body?.payload?.api_mandate?.txn_reject_code;
            saveObj.current_status = req?.body?.payload?.api_mandate?.current_status;
            saveObj.message_id = req?.body?.payload?.api_mandate?.message_id;
            saveObj.mandate_id = req?.body?.payload?.api_mandate?.id;
            saveObj.npci_txn_id = req?.body?.payload?.api_mandate?.npci_txn_id;
            saveObj.scheme_ref_number = req?.body?.payload?.api_mandate?.others?.scheme_ref_number;
            saveObj.customer_ref_number = req?.body?.payload?.api_mandate?.others?.customer_ref_number;
            saveObj.tags = req?.body?.payload?.api_mandate?.tags;
            saveObj.created_at = req?.body?.created_at;
            saveObj.digio_msg_id = req?.body?.id;
            saveObj.event = req?.body?.event;

            await this.digioLogModel.create(saveObj)
            const invoiceDataa = await this.patientLoanModel.findOne(
                { mandate_id: saveObj?.mandate_id },
            )
            if(!invoiceDataa){
                return { success: false}
            }
            if (saveObj.event == 'apimndt.authsuccess') {
                const updateInvoice = await this.patientLoanModel.findOneAndUpdate(
                    { mandate_id: saveObj.mandate_id },
                    { $set: { invoiceSubStatus: 'Mandate Authentication Successful' } }
                )
            }
            if (saveObj.event == 'apimndt.authfail') {
                await this.patientLoanModel.findOneAndUpdate(
                    { mandate_id: saveObj?.mandate_id },
                    { $set: { invoiceSubStatus: 'E-Nach Failed', NachFailureReason: 'Mandate Authorization Failed' } }
                )
            }
            else if (saveObj.event == 'apimndt.destaccept') {
                const invoiceData = await this.patientLoanModel.findOneAndUpdate(
                    { mandate_id: saveObj?.mandate_id },
                    { $set: { invoiceSubStatus: 'Pending for Disbursal', mandateUMRN: saveObj?.umrn } }
                )

                this.nodeMailerService.sendemailforPatient(invoiceData?.invoiceId);
            }
            else if (saveObj.event == 'apimndt.destreject') {
                await this.patientLoanModel.findOneAndUpdate(
                    { mandate_id: saveObj?.mandate_id },
                    { $set: { invoiceSubStatus: 'E-Nach Failed', NachFailureReason: 'Mandate Rejected by Destination Bank' } }
                )
            }
            await this.getMandateDetails(saveObj.customer_ref_number,saveObj?.mandate_id)

            return { success: true };
        } catch (e) {
            this.logger.error(e);
            throw e;
        }
    }
    public async updateAgreementStatus(req: Request): Promise<{ success: Boolean }> {
        try {
            var saveObj: any = {};

            saveObj.entities = req?.body?.entities[0]?req?.body?.entities[0]:'';
            saveObj.updated_at = req?.body?.payload?.document?.updated_at;
            saveObj.sign_request_details = req?.body?.payload?.document?.sign_request_details;
            saveObj.file_name = req?.body?.payload?.document?.file_name;
            saveObj.agreement_status = req?.body?.payload?.document?.agreement_status;
            saveObj.agreement_documentId = req?.body?.payload?.document?.id;
            saveObj.signing_parties = req?.body?.payload?.document?.signing_parties;
            saveObj.others = req?.body?.payload?.document?.others;
            saveObj.created_at = req?.body?.created_at;
            saveObj.digio_msg_id = req?.body?.id;
            saveObj.event = req?.body?.event;

            await this.digioLogModel.create(saveObj);
            const invoiceDataa = await this.patientLoanModel.findOne(
                { agreementDocId: saveObj.agreement_documentId },
            )
            if(!invoiceDataa){
                return { success: false}
            }
            if (saveObj.event == 'doc.signed') {
                const invoiceData = await this.patientLoanModel.findOneAndUpdate(
                    { agreementDocId: saveObj.agreement_documentId },
                    { $set: { invoiceSubStatus: 'Pending Bank Verification', agreementESignedOn: saveObj.updated_at } },
                    { useFindAndModify: false, new: true }
                )
                if (invoiceData) {
                    pushToQueue(JSON.stringify({ msgType: "downloadAgreement", agreementDocId: saveObj.agreement_documentId, _id: invoiceData._id }));
                    pushToQueue(JSON.stringify({ msgType: "verifyBankAccount", contactNumber: invoiceData.contactNumber, patientName: invoiceData.patientName, invoiceId: invoiceData?.invoiceId, _id: invoiceData._id }));
                }

            }
            else if (saveObj.event == 'esign.v3.sign.pending') {
                await this.patientLoanModel.findOneAndUpdate(
                    { agreementDocId: saveObj.agreement_documentId },
                    { $set: { invoiceSubStatus: 'Awaiting Agreement Signing' } }
                )
            }
            else if (saveObj.event == 'esign.v3.sign.failed') {
                await this.patientLoanModel.findOneAndUpdate(
                    { agreementDocId: saveObj.agreement_documentId },
                    { $set: { invoiceSubStatus: 'Agreement Signing Failed' } }
                )
            }

            return { success: true };
        } catch (e) {
            this.logger.error(e);
            throw e;
        }
    }
    public async updateKYCStatus(req: Request): Promise<{ success: Boolean }> {
        try {
            var saveObj: any = {};

            saveObj.entities = req?.body?.entities[0]?req?.body?.entities[0]:'';
            saveObj.KYCStatus = req?.body?.payload?.kyc_request?.status;
            saveObj.KYCRequestId = req?.body?.payload?.kyc_request?.id;
            saveObj.transaction_id = req?.body?.payload?.kyc_request?.transaction_id;
            saveObj.reference_id = req?.body?.payload?.kyc_request?.reference_id;
            saveObj.others = req?.body?.payload?.kyc_request?.others;
            saveObj.created_at = req?.body?.created_at;
            saveObj.digio_msg_id = req?.body?.id;
            saveObj.event = req?.body?.event;

            await this.digioLogModel.create(saveObj);
            const invoiceDataa = await this.patientLoanModel.findOne(
                {  KYCRequestId: saveObj.KYCRequestId, invoiceId: saveObj.reference_id },
            )
            if(!invoiceDataa){
                return{ success: false };
            }
            if (saveObj.event == 'kyc.request.completed') {
                // fetching bank details 
                pushToQueue(JSON.stringify({ msgType: "fetchBankDetails", KYCRequestId: saveObj.KYCRequestId, reference_id: saveObj.reference_id }));

                await this.patientLoanModel.findOneAndUpdate(
                    { KYCRequestId: saveObj.KYCRequestId, invoiceId: saveObj.reference_id },
                    //, { KYCRequestId: req.body.payload.kyc_action.id }
                    { $set: { invoiceSubStatus: 'KYC Completed' } },
                    { useFindAndModify: false }
                )
            }
            if (saveObj.event == 'kyc.request.rejected' || saveObj.event == 'kyc.request.expired') {
                var KYCFailureReason;
                if (saveObj.event == 'kyc.request.rejected') { KYCFailureReason = 'Penny Drop failed' }
                if (saveObj.event == 'kyc.request.expired') { KYCFailureReason = 'Bank verification request expired' }

                await this.patientLoanModel.findOneAndUpdate(
                    { KYCRequestId: saveObj.KYCRequestId, invoiceId: saveObj.reference_id },
                    { $set: { invoiceSubStatus: "Bank Verification Failed", KYCFailureReason: KYCFailureReason } },
                    { useFindAndModify: false }
                )
            }


            return { success: true };
        } catch (e) {
            this.logger.error(e);
            throw e;
        }
    }
    public async updateDebitStatus(req: Request): Promise<{ success: Boolean }> {
        try {
            var saveObj: any = {};

            saveObj.entities =req?.body?.entities[0]?req?.body?.entities[0]:'';
            saveObj.mandateDebitId = req?.body?.payload?.nach_debit?.id;
            saveObj.settlement_date = req?.body?.payload?.nach_debit?.settlement_date;
            saveObj.user_name = req?.body?.payload?.nach_debit?.user_name;
            saveObj.amount_in_paise = req?.body?.payload?.nach_debit?.amount_in_paise;
            saveObj.txn_reference = req?.body?.payload?.nach_debit?.txn_reference;
            saveObj.umrn = req?.body?.payload?.nach_debit?.umrn;
            saveObj.scheduled_payment_id = req?.body?.payload?.nach_debit?.scheduled_payment_id;
            saveObj.failure_reason = req?.body?.payload?.nach_debit?.failure_reason;
            saveObj.failure_description = req?.body?.payload?.nach_debit?.failure_description;
            saveObj.status = req?.body?.payload?.nach_debit?.status;
            saveObj.transaction_id = req?.body?.payload?.nach_debit?.transaction_id;
            saveObj.total_payment_count = req?.body?.payload?.nach_debit?.others?.total_payment_count;
            saveObj.processed_payment_count = req?.body?.payload?.nach_debit?.processed_payment_count;
            saveObj.next_scheduled_settlement_date = req?.body?.payload?.nach_debit?.next_scheduled_settlement_date;
            saveObj.others = req?.body?.payload?.nach_debit?.others;
            saveObj.service_provider_name = req?.body?.payload?.nach_debit?.service_provider_name;
            saveObj.sponsor_bank_name = req?.body?.payload?.nach_debit?.sponsor_bank_name;
            saveObj.transaction_type = req?.body?.payload?.nach_debit?.transaction_type;
            saveObj.created_at = req?.body?.created_at;
            saveObj.digio_msg_id = req?.body?.id;
            saveObj.event = req?.body?.event;

            await this.digioLogModel.create(saveObj)
            const invoiceDataa = await this.patientLoanModel.findOne(
                { mandateDebitId: saveObj.mandateDebitId, invoiceId: saveObj.others.customer_ref_number },
            )
            if(!invoiceDataa){
                return { success: false };
            }
            var updateObj: any = {};
            if (saveObj.event == 'nach.debit.txn.created') { updateObj.invoiceSubStatus = 'Debit transaction created' }
            else if (saveObj.event == 'nach.debit.txn.skipped') { updateObj.invoiceSubStatus = 'Debit transaction skipped' }
            else if (saveObj.event == 'nach.debit.txn.transuccess') { updateObj.invoiceSubStatus = 'Debit transaction successful', updateObj.debitFailureReason = saveObj.failure_reason }
            else if (saveObj.event == 'nach.debit.txn.tranfail') { updateObj.invoiceSubStatus = 'Debit transaction failed' }
            else if (saveObj.event == 'nach.debit.txn.spobankaccept') { updateObj.invoiceSubStatus = 'Debit transaction accepted by sponsor bank' }
            else if (saveObj.event == 'nach.debit.txn.spobankreject') { updateObj.invoiceSubStatus = 'Debit transaction rejected by sponsor bank', updateObj.debitFailureReason = saveObj.failure_reason }
            else if (saveObj.event == 'nach.debit.txn.failed') { updateObj.invoiceSubStatus = 'Debit transaction failed', updateObj.debitFailureReason = saveObj.failure_reason }
            else if (saveObj.event == 'nach.debit.txn.authenticated') { updateObj.invoiceSubStatus = 'Debit transaction authenticated' }
            else if (saveObj.event == 'nach.debit.txn.delayed') { updateObj.invoiceSubStatus = 'Debit transaction delayed' }
            else if (saveObj.event == 'nach.debit.success') { updateObj.invoiceSubStatus = 'Debit transaction success' }
  
            await this.patientLoanModel.findOneAndUpdate(
                { mandateDebitId: saveObj.mandateDebitId, invoiceId: saveObj.others.customer_ref_number },
                { $set: updateObj },
                { useFindAndModify: false }
            )

            return { success: true };
        } catch (e) {
               //this.logger.error(e);
               console.log("updateDebitStatus =>", e)
               //throw e;
        }
    }
    public async getMandateDetails(invoiceId:number,mandate_id:string){
        try {
            const config: AxiosRequestConfig = {
                method: 'GET',
                url: `${process.env.digioURL}/v3/client/mandate/${mandate_id}`,
                auth: {
                  username: process.env.digioUsername,
                  password: process.env.digioSecret
                }
              };
              let response;
              try {
                response = await axios(config);
              }
              catch (e) {
                console.log('digio getMandateDetails Error', e.response.statusText, e.response.data);
              }
              let mandateData; 
              if(response){
                let invoicedata= await this.patientLoanModel.findOne({ $and:[{invoiceId:invoiceId},{mandateDetailsId:{$exists:true}},{mandateDetailsId:{$ne:null}}] })
                if(!invoicedata){
                    mandateData= await this.mandateDetailsModel.create({...response.data,invoiceId:invoiceId})
                    await this.patientLoanModel.findOneAndUpdate({invoiceId},{$set:{
                        mandateDetailsId:mandateData._id  
                    }})
                }else{
                    mandateData=  await this.mandateDetailsModel.update({invoiceId},{$set:{...response.data,updated_at:new Date()}})
                    
                }
              
               if(mandateData){
                const nodeMailerservice = Container.get(nodeMailerService);
                await nodeMailerservice.sendemailToEmandate({...mandateData, email:invoicedata?.emailId})
                return {success:true,mandateData}
               }
              }
              return {success:false}
              
        } catch (e) {
            this.logger.error(e);
            return {success:false}
        }
    }

   public async updateMandate(){
 try {
    let invoicedata= await this.patientLoanModel.find({$and:[{mandate_id:{$exists:true}},{mandate_id:{$ne:null},mandateDetailsId:{$exists:false}}]})
    if(!invoicedata){
        return {success:false}
    }
    let successCount=0;
    let failCount=0;
    for await (const iterator of invoicedata) {
        let updatedRes= await this.getMandateDetails(iterator.invoiceId,iterator.mandate_id)
        if(updatedRes.success){
            successCount++ 
        }else{
            failCount ++
        }
    }

    return {
        success:true,
        successCount,
        failCount
    }
 } catch (e) {
    this.logger.error(e);
    return {success:false}
 }

   }
   public async mailSendTOLendor(data){
 try {
    let lenderDetails;
    let invoicedata= await this.patientLoanModel.find({invoiceId:data.invoiceId})
    if(!invoicedata){
        return {success:false}
    }
    console.log(invoicedata)
    if(invoicedata?.LenderId){
        lenderDetails = await this.userModel.find()
    }
   this.nodeMailerService.sendemailToLendor(invoicedata)

    return {
        success:true,
        
        
    }
 } catch (e) {
    this.logger.error(e);
    return {success:false}
 }

   }

};