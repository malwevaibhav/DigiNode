import { Service, Inject } from 'typedi';
import { ILeadDTO, IFilterDTO, IUser } from '../interfaces/IUser';
import { timeStamp } from 'console';

@Service()
export default class digiService {
  constructor(
    @Inject('newLeadModel') private newLeadModel: Models.newLeadModel,
    @Inject('scrappedData') private scrappedData: Models.scrappedDataModel,
    @Inject('patientLoanModel') private patientLoanModel: Models.patientLoanModel,
    @Inject('logger') private logger,
  ) {}

  // public async createNewLead(ILeadDTO: ILeadDTO): Promise<{ success: Boolean; message: string }> {
  //     try {
  //         const leadRecord = await this.newLeadModel.create({
  //             ...ILeadDTO
  //         });
  //         if (!leadRecord) {
  //             throw new Error('User cannot be created');
  //         }
  //         return { success: true, message: "Request Submitted" };
  //     } catch (e) {
  //         this.logger.error(e);
  //         throw e;
  //     }
  // }
  // public async getHospitalLocation(IFilterDTO: IFilterDTO): Promise<{ success: Boolean; locations: Array<Array<String>> }> {
  //     try {
  //         var locations = []
  //         var searchFilters = [];
  //         searchFilters.push({ _id: { $exists: true } });

  //         if (IFilterDTO.searchTerm != undefined) {
  //             searchFilters.push({
  //                 $or: [
  //                     { name: { $regex: IFilterDTO.searchTerm, $options: 'i' } },
  //                     { city: { $regex: IFilterDTO.searchTerm, $options: 'i' } },
  //                     { address: { $regex: IFilterDTO.searchTerm, $options: 'i' } }
  //                 ]
  //             })
  //         }
  //         const locationData = await this.scrappedData.find({ $and: searchFilters });
  //         for (let data of locationData) {
  //             locations.push([data.name, parseFloat(data.latitude), parseFloat(data.longitude)])
  //         }
  //         return { success: true, locations };
  //     } catch (e) {
  //         this.logger.error(e);
  //         throw e;
  //     }
  // }
  public async contactUsForm(ILeadDTO: ILeadDTO): Promise<{ success: Boolean; message: string }> {
    try {
      ILeadDTO.leadType = 'Contact';
      const leadRecord = await this.newLeadModel.create({
        ...ILeadDTO,
      });
      if (!leadRecord) {
        throw new Error('Error submitting form');
      }
      return { success: true, message: 'Request Submitted' };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }

  public async dsplInvoiceStatus(req: IUser): Promise<{ data: any }> {
    const reqest = req;
    try {
      let data = await this.patientLoanModel.find({ _id: req }).select({
        invoiceId: 1,
        invoiceSubStatus: 1,
        invoiceStatus: 1,
        digiComment:1
      });
      console.log(data);

      return { data: data };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }

  public async LenderStatus(req: IUser): Promise<{ data: any }> {
    const reqest = req;
    try {
      let data = await this.patientLoanModel.find({ _id: req }).select({
        invoiceId: 1,
        invoiceSubStatus: 1,
        loan_id:1,
        invoiceStatus: 1,
        lenderComment:1
      });
      console.log(data);

      return { data: data };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }

}
