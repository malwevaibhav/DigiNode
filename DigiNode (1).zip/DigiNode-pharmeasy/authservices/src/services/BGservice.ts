
import { response, Response } from 'express';
import { Service, Inject,Container } from 'typedi';
import MailerService from './mailer';
import { IBimaGarage, IBGPatientDTO, IBGcase, IPatientLoanDTO } from '../interfaces/IBimaGarage';
import jwt from 'jsonwebtoken';
import config from '../config';
import axios from 'axios';

import { EventDispatcher, EventDispatcherInterface } from '../decorators/eventDispatcher';
import { filter } from 'lodash';
import AuthService from './auth';
const BG_URL = process.env.BG_URL;
@Service()
export default class BimaService {
  constructor(
    @Inject('userModel') private userModel: Models.UserModel,
    @Inject('BeemaGarageModel') private BeemaGarageModel: Models.BeemaGarageModel,
    @Inject('BGcaseModel') private IBGcaseModel: Models.BGcaseModel,
    @Inject('patientLoanModel') private patientLoanModel: Models.patientLoanModel,

    private mailer: MailerService,
    @Inject('logger') private logger,
    @EventDispatcher() private eventDispatcher: EventDispatcherInterface,
  ) { }

  public async token() {
    let url = `${BG_URL}/api/token/`;
    let userinfo = {
      username: 'digisparsh-api',
      password: 'Digi@1234',
    };
    let token = await axios.post(url, userinfo);

    return token.data.access;
  }

  public async check_patient(mobileNumber: any) {
    let url = `${BG_URL}/external/api/check-patient/${mobileNumber}`;
    let access_token = await this.token();

    let Response = await axios.get(url, {
      headers: {
        Authorization: `Bearer ${access_token}`,
      },
    });

    return Response.data;
  }
  public async check_case(CaseId: any) {
    let url = `${BG_URL}/external/api/case-detail/${CaseId}`;
    let access_token = await this.token();

    let Response = await axios.get(url, {
      headers: {
        Authorization: `Bearer ${access_token}`,
      },
    });

    return Response.data;
  }
  public async CreateHospital(Hospitaldata: any) {
    let url = `${BG_URL}/external/api/create-hospital/`;

    let access_token = await this.token();

    let Response = await axios.post(url, Hospitaldata, {
      headers: {
        Authorization: `Bearer ${access_token}`,
      },
    });

    return Response.data;
  }
  public async CreatePatient(patientdata: any) {
    let url = `${BG_URL}/external/api/create-patient/`;
    let access_token = await this.token();
    let Response = await axios
      .post(url, patientdata, {
        headers: {
          Authorization: `Bearer ${access_token}`,
          ...patientdata.getHeaders(),
        },
      })
      .then(res => {
        return res.data;
      })
      .catch(err => {
        return err.data;
      });

    return Response;
  }

  public async addPatient(patientdata: IBGPatientDTO, urldata: any, hospitalid: any) {
    try {
      delete patientdata.policy_doc;

      const findUser = await this.BeemaGarageModel.findOne({ primary_phone: patientdata.primary_phone });
      if (findUser) {
        throw new Error('Patient record alredy exist');
      }
      const patientRecord = await this.BeemaGarageModel.create({ ...patientdata });
      if (!patientRecord) {
        throw new Error('Patient record cannot be created');
      }
      let id = urldata.payload.data.id;
      let newId = patientRecord._id;
      const addId = await this.BeemaGarageModel.findByIdAndUpdate(newId, {
        $set: { Bg_Patient_id: id.toString(), policy_doc: urldata.payload.data.policy_doc, Bg_HospitalId: hospitalid },
      });
      if (!addId) {
        throw new Error('Patient record id not saved');
      }
      const addPid = addId.toObject();
      var patientData = { addPid, success: true };
      return patientData;
    } catch (error) {
      this.logger.error(error);
    }
  }

  public async createCase(body: any) {
   
    
      let url = `${BG_URL}/external/api/create-case/`;

      let access_token = await this.token();

      let Response = await axios.post(url, body, {
        headers: {
          Authorization: `Bearer ${access_token}`,
        },
      });
      return Response.data;
    
  }

  public async addCase(casedata: IBGPatientDTO, urldata) {
    try {
      const caseRecord = await this.IBGcaseModel.create({
        ...Object.assign(casedata, { case_id: urldata.payload.data.id }),
      });
      const patientdata = await this.BeemaGarageModel.findOne({ Bg_Patient_id: casedata.customer });
      // const invocedata = await this.patientLoanModel.findOneAndUpdate(
      //   { contactNumber: Number(patientdata.primary_phone) },
      //   { $set: { UWPartnerApproved: false, caseId: urldata.payload.data.id } },
      // );
      //  const invocedat= await this.patientLoanModel.findOne({"contactNumber":Number(patientdata.primary_phone)})
      const caseRec = caseRecord.toObject();
      var caseData = { caseRec, success: true };
      ///
      var text = `New Case added\nCaseId: ${urldata.payload.data.id}`;
      const AuthServiceInstance = Container.get(AuthService);
      await AuthServiceInstance.whatsappClient(text, null,"Bima")
      ///
      return caseData;
    } catch (error) {
      this.logger.error(error);
    }
  }

  // CaseStatistics
  public async CaseStatistics() {
    let url = `${BG_URL}/external/api/case-stats/`;
    let access_token = await this.token();

    let Response = await axios.get(url, {
      headers: {
        Authorization: `Bearer ${access_token}`,
      },
    });

    return Response.data;
  }
  public async hospitaldata() {
    let url = `${BG_URL}/external/api/hospital`;
    let access_token = await this.token();

    let Response = await axios.get(url, {
      headers: {
        Authorization: `Bearer ${access_token}`,
      },
    });

    return Response.data;
  }
  public async getAllFundedCases(body) {
    try {
      //pagination
      var pageNumber = 1;
      var pageSize = 0;

      if (body.pageNumber) {
        var pageNumber = parseInt(body.pageNumber.toString());
      }
      if (body.pageSize) {
        var pageSize = parseInt(body.pageSize.toString());
      }
      //search

      var searchFilters = [];
      searchFilters.push({ invoiceStatus: 'Disbursed' }, { UWName: 'Bima Garage' });
      if (body.dateFrom != undefined || (null && body.dateTo != undefined) || null) {
        searchFilters.push({ updatedAt: { $gte: body.dateFrom, $lte: body.dateTo } });
      }
      if (body.caseId) {
        searchFilters.push({ caseId: body.caseId.toString() });
      }
      var userCount = await this.patientLoanModel.find({ $and: searchFilters }).count();
      var numberOfPages = pageSize === 0 ? 1 : Math.ceil(userCount / pageSize);
      var Caselist = await this.patientLoanModel
        .find({ $and: searchFilters })
        .sort({ createdAt: -1 })
        .skip((pageNumber - 1) * pageSize)
        .limit(pageSize);

      var PatientData = await this.patientLoanModel.aggregate([
        { $match: { $and: searchFilters } },
        { "$sort": { updatedAt: -1 } },
        { "$skip": (pageNumber - 1) * pageSize },
        { "$limit": pageSize ? pageSize : Number.MAX_SAFE_INTEGER },
        {
          $project: {
            caseId: 1,
            contactNumber: 1,
            patientName: 1,
            hospitalName: 1,
            loanAmount: 1,
            isDeleted: 1,
            invoiceStatus: 1,
            updatedAt: 1,
            _id: 0,
            Approval_Date: 1,
            Disbursed_Amount: 1,
            Disbursement_Date: 1,
            borrowerName: 1,
          },
        },
      ]);

      var data = { PatientData, numberOfPages, userCount };
      return data;
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  public async caselist(body) {
    try {
      //pagination
      var pageNumber = 1;
      var pageSize = 0;
      // const addId = await this.IBGcaseModel.find({customer:id.toString()})
      if (body.pageNumber) {
        var pageNumber = parseInt(body.pageNumber.toString());
      }
      if (body.pageSize) {
        var pageSize = parseInt(body.pageSize.toString());
      }
      //search

      var searchFilters = [];
      searchFilters.push({ customer: body.id.toString() });

      var userCount = await this.IBGcaseModel.find({ $and: searchFilters }).count();
      var numberOfPages = pageSize === 0 ? 1 : Math.ceil(userCount / pageSize);
      var Caselist = await this.IBGcaseModel.find({ $and: searchFilters })
        .sort({ createdAt: -1 })
        .skip((pageNumber - 1) * pageSize)
        .limit(pageSize);

      var PatientData = await this.IBGcaseModel.aggregate([
        { $match: { $and: searchFilters } },
        { $skip: (pageNumber - 1) * pageSize },
        // { "$limit": pageSize },
        {
          $lookup: {
            from: 'bgpatients',
            localField: 'customer',
            foreignField: 'Bg_Patient_id',
            as: 'patientdata',
          },
        },
      ]);

      var data = { PatientData, numberOfPages, userCount };
      return data;
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }

  public async caseById(case_id) {
    try {
      const casedetails = await this.check_case(case_id);
      let updatecase: any;
      let findUser: any;
      if (casedetails.payload.claim_status == 'PreAuth Approved') {
        const invocedata = await this.patientLoanModel.findOneAndUpdate(
          { contactNumber: casedetails.payload.customer },
          { $set: { UWPartnerApproved: true, UWApprovedAmount: Number(casedetails.payload.preauth_apamt) } },
        );
      }
      if (casedetails) {
        delete casedetails.payload.hospital;
        delete casedetails.payload.id;
        delete casedetails.payload.customer;
        updatecase = await this.IBGcaseModel.findOneAndUpdate(
          { case_id: case_id.toString() },
          { $set: casedetails.payload },
        );
      }
      if (updatecase) {
        findUser = await this.IBGcaseModel.aggregate([
          { $match: { $and: [{ case_id: case_id.toString() }] } },
          {
            $lookup: {
              from: 'bgpatients',
              localField: 'customer',
              foreignField: 'Bg_Patient_id',
              as: 'patientdata',
            },
          },
        ]);
        if (findUser[0]) {
          return findUser[0];
        } else {
          return [];
        }
      } else {
        return [];
      }
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  public async updateCaseById(case_id) {
    try {
      const casedetails = await this.check_case(case_id);
      let updatecase: any;
      if (casedetails.payload.claim_status == 'PreAuth Approved') {
        const invocedata = await this.patientLoanModel.findOneAndUpdate(
          { contactNumber: casedetails.payload.customer },
          { $set: { UWPartnerApproved: true, UWApprovedAmount: Number(casedetails.payload.preauth_apamt) } },
        );
      }
      if (casedetails) {
        delete casedetails.payload.hospital;
        delete casedetails.payload.id;
        delete casedetails.payload.customer;
        updatecase = await this.IBGcaseModel.findOneAndUpdate(
          { case_id: case_id.toString() },
          { $set: casedetails.payload },
        );
        if (updatecase) {
          // whatsapp notification
          var text =
            `${casedetails.payload.claim_status}\nCaseId: ${case_id}`;
            const AuthServiceInstance = Container.get(AuthService);
            await AuthServiceInstance.whatsappClient(text, null,"Bima")
          //
          return {
            success: true,
            message: 'Case Updated',
          };
        } else {
          return {
            success: false,
            message: 'Unable to Update Case',
          };
        }
      } else {
        return {
          success: false,
          message: 'Unable to get data from Bima Garage End',
        };
      }
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }

  public async patientlist(body) {
    try {
      //pagination
      var pageNumber = 1;
      var pageSize = 0;
      if (body.pageNumber) {
        var pageNumber = parseInt(body.pageNumber.toString());
      }
      if (body.pageSize) {
        var pageSize = parseInt(body.pageSize.toString());
      }
      var searchFilters = [];
      // var phone =  phone.toString()
      searchFilters.push({ _id: { $exists: true } });
      if (body.BGHospitalId) {
        searchFilters.push({ Bg_HospitalId: body.BGHospitalId })
      }
      if (body.primary_phone) {
        searchFilters.push({
          $or: [{ primary_phone: { $regex: body.primary_phone.toString(), $options: 'i' } }],
        });
      }

      var userCount = await this.BeemaGarageModel.find({ $and: searchFilters }).count();
      var numberOfPages = pageSize === 0 ? 1 : Math.ceil(userCount / pageSize);
      var Caselist = await this.BeemaGarageModel.find({ $and: searchFilters })
        .sort({ createdAt: -1 })
        .skip((pageNumber - 1) * pageSize)
        .limit(pageSize);
      return { numberOfPages, Caselist, userCount };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }

  public async insuranceco() {
    let url = `${BG_URL}/external/api/insuranceco`;
    let access_token = await this.token();

    let Response = await axios.get(url, {
      headers: {
        Authorization: `Bearer ${access_token}`,
      },
    });
    return Response.data;
  }

  public async getTpa() {
    let url = `${BG_URL}/external/api/tpa`;
    let access_token = await this.token();

    let Response = await axios.get(url, {
      headers: {
        Authorization: `Bearer ${access_token}`,
      },
    });
    return Response.data;
  }

  public async UpdateClaimStage1(UpdateClaimStage1: any, PatientId: number) {
    let url = `${BG_URL}/external/api/updclm-preauth-ini/${PatientId}`;
    let access_token = await this.token();
    let Response = await axios.patch(url, UpdateClaimStage1, {
      headers: {
        Authorization: `Bearer ${access_token}`,
        ...UpdateClaimStage1.getHeaders(),
      },
    });
    return Response.data;
  }

  public async UpdateClaimStage4(UpdateClaimStage4: any, PatientId: number) {
    let url = `${BG_URL}/external/api/updclm-fappr-rec/${PatientId}`;
    let access_token = await this.token();
    let Response = await axios.patch(url, UpdateClaimStage4, {
      headers: {
        Authorization: `Bearer ${access_token}`,
        ...UpdateClaimStage4.getHeaders(),
      },
    });
    return Response.data;
  }

  public async UpdateClaimStage5(UpdateClaimStage5: any, PatientId: number) {
    let url = `${BG_URL}/external/api/updclm-dispatch/${PatientId}`;
    let access_token = await this.token();
    let Response = await axios.patch(url, UpdateClaimStage5, {
      headers: {
        Authorization: `Bearer ${access_token}`,
        ...UpdateClaimStage5.getHeaders(),
      },
    });
    return Response.data;
  }
  public async UpdateDisbersment(UpdateClaimStage5: any, PatientId: number) {
    let url = `${BG_URL}/external/api/recdisb/${PatientId}`;
    let access_token = await this.token();
    let Response = await axios.patch(url, UpdateClaimStage5, {
      headers: {
        Authorization: `Bearer ${access_token}`,
        ...UpdateClaimStage5.getHeaders(),
      },
    });
    if (Response.data['Message'] == "Received Disbursement Successfully.") {
      var text = `Received Disbursement Successfully\n CaseId: ${PatientId}`;
      const AuthServiceInstance = Container.get(AuthService);
      await AuthServiceInstance.whatsappClient(text, null,"Bima")
    }
    return Response.data;
  }

  public async UpdateClaimStage6(UpdateClaimStage6: any, PatientId: number) {
    let url = `${BG_URL}/external/api/updclm-settled/${PatientId}`;
    let access_token = await this.token();
    let Response = await axios.patch(url, UpdateClaimStage6, {
      headers: {
        Authorization: `Bearer ${access_token}`,
        ...UpdateClaimStage6.getHeaders(),
      },
    });
    return Response.data;
  }
  public async UpdateClaimStage2(UpdateClaimStage2: any, PatientId: number) {
    let url = `${BG_URL}/external/api/updclm-preauth-appr/${PatientId}`;
    let access_token = await this.token();

    let Response = await axios.patch(url, UpdateClaimStage2, {
      headers: {
        Authorization: `Bearer ${access_token}`,
        ...UpdateClaimStage2.getHeaders(),
      },
    });

    return Response.data;
  }
  public async UpdateClaimStage3(UpdateClaimStage3: any, PatientId: number) {
    let url = `${BG_URL}/external/api/updclm-fappr-ini/${PatientId}`;
    let access_token = await this.token();

    let Response = await axios.patch(url, UpdateClaimStage3, {
      headers: {
        Authorization: `Bearer ${access_token}`,
        ...UpdateClaimStage3.getHeaders(),
      },
    });

    return Response.data;
  }
  public async updateUser(currentuser: any, data: any) {
    let localcdata = {
      BGHospitalId: data,
    };
    const updateUser = await this.userModel.findByIdAndUpdate(currentuser._id, { $set: localcdata });

    return updateUser;
  }
  public async updatedcase(Updated: any) {
    if (Updated.claim_status == 1) {
      Updated.claim_status = 'Preauth Initiated';
    }
    if (Updated.claim_status == 2) {
      Updated.claim_status = 'Preauth Approved';
    }
    if (Updated.claim_status == 3) {
      Updated.claim_status = 'Final Approval Initiated';
    }
    if (Updated.claim_status == 4) {
      Updated.claim_status = 'Final Approval Received';
    }
    if (Updated.claim_status == 5) {
      Updated.claim_status = 'File Dispatched';
    }
    if (Updated.claim_status == 6) {
      Updated.claim_status = 'Claim Settled';
    }
    if (Updated.claim_status == -2) {
      Updated.claim_status = 'Claim Rejected';
    }

    const updateUser = await this.IBGcaseModel.findOneAndUpdate({ case_id: Updated.id.toString() }, { $set: Updated });
    var text = `${Updated.claim_status}\n CaseId: ${Updated.id}`;
    const AuthServiceInstance = Container.get(AuthService);
      await AuthServiceInstance.whatsappClient(text, null,"Bima")

    return updateUser;
  }
  public async editcase(Updated: any) {
   

    const updateCase = await this.IBGcaseModel.findOneAndUpdate({ case_id: Updated["data"].id.toString() }, { $set: Updated["data"] });
    
    

    return updateCase;
  }
  public async getInvoiceByCaseId(caseid) {
    var invoice = this.patientLoanModel.findOne({ "caseId": caseid })
    if (invoice) {
      return invoice
    } else {
      return null;
    }
  }
  public async CaseReject(UpdateClaimStage6: any, PatientId: number) {
    let url = `${BG_URL}/external/api/casereject/${PatientId}`;
    let access_token = await this.token();
    let Response = await axios.patch(url, UpdateClaimStage6, {
      headers: {
        Authorization: `Bearer ${access_token}`,
        ...UpdateClaimStage6.getHeaders(),
      },
    });
    return Response.data;
  }
  public async EditCase(UpdateClaimStage6: any) {
    let url = `${BG_URL}/external/api/edit-case/`;
    let access_token = await this.token();
    let Response = await axios.patch(url, UpdateClaimStage6, {
      headers: {
        Authorization: `Bearer ${access_token}`,
        ...UpdateClaimStage6.getHeaders(),
      },
    });
    return Response.data;
  }
  public async queryPending(queryPending: any, caseid: number) {
    let url = `${BG_URL}/external/api/casereject/${caseid}`;
    let access_token = await this.token();
    let Response = await axios.patch(url, queryPending, {
      headers: {
        Authorization: `Bearer ${access_token}`,
        ...queryPending.getHeaders(),
      },
    });
    return Response.data;
  }
  public async getPatientDetailsByMobileNumber( MobileNumber: string) {
let patientdata= await this.BeemaGarageModel.findOne({"primary_phone":MobileNumber})

if(!patientdata){
return {data:{Ispatient:false}}
}else{
  let invoice = await this.patientLoanModel.findOne({"contactNumber":patientdata.primary_phone})
  return {data:{
    patientdata,
    invoice,
    Ispatient:true
  }}
}
   
     
    
  }

  public async getpatient() {
    let url = `${BG_URL}/external/api/getpatient`;
    let access_token = await this.token();

    let Response = await axios.get(url, {
      headers: {
        Authorization: `Bearer ${access_token}`,
      },
    });
    return Response.data;
  }
  public async upload_document(IBGPatientDTO: IBGPatientDTO): Promise<{ success: boolean, message: string }> {
    try {
      let body = {}
      body[IBGPatientDTO.file_name] = IBGPatientDTO.case_file;
      let url = `${BG_URL}/external/api/upload_document/${IBGPatientDTO.caseId}`;
      let access_token = await this.token();
      let Response = await axios.post(url, body, {
        headers: { Authorization: `Bearer ${access_token}`, },
      });
      if (Response.data.Message == 'File Uploaded Successfully') {
        let updateCase = await this.IBGcaseModel.findOneAndUpdate(
          { case_id: IBGPatientDTO.caseId },
          { $push: { case_files: body } },
          { useFindAndModify: false }
        )
        return { success: true, message: "Document uploaded successfully" }
      }
    }
    catch (e) {
      if (e.isAxiosError) {
        this.logger.error(`BimaGarage error: ${e.message}`, );
        throw e.message;
      }
      this.logger.error(e);
      throw e;
    }
  }
  public async addPatientInvoice(IPatientLoanDTO: IPatientLoanDTO): Promise<{ success: boolean, message: string, invoiceId: number }> {
    try {
      IPatientLoanDTO.isInsured = true;
      IPatientLoanDTO.addedViaApi = true;
      IPatientLoanDTO.patientName = IPatientLoanDTO.firstname + ' ' + IPatientLoanDTO.lastname;
      if (IPatientLoanDTO.permanentAddr) {
        IPatientLoanDTO.permanentAddress = IPatientLoanDTO.permanentAddr.street;
        IPatientLoanDTO.permanentCity = IPatientLoanDTO.permanentAddr.city;
        IPatientLoanDTO.permanentState = IPatientLoanDTO.permanentAddr.state;
        IPatientLoanDTO.permanentPinCode = IPatientLoanDTO.permanentAddr.pinCode;
      } else {
        IPatientLoanDTO.permanentAddress = IPatientLoanDTO.currentAddr.street;
        IPatientLoanDTO.permanentCity = IPatientLoanDTO.currentAddr.city;
        IPatientLoanDTO.permanentState = IPatientLoanDTO.currentAddr.state;
        IPatientLoanDTO.permanentPinCode = IPatientLoanDTO.currentAddr.pinCode;
      }

      IPatientLoanDTO.currentAddress = IPatientLoanDTO.currentAddr.street;
      IPatientLoanDTO.currentCity = IPatientLoanDTO.currentAddr.city;
      IPatientLoanDTO.currentState = IPatientLoanDTO.currentAddr.state;
      IPatientLoanDTO.currentPinCode = IPatientLoanDTO.currentAddr.pinCode;

      IPatientLoanDTO.UWName = "Bima Garage";

      const bgPatient = await this.BeemaGarageModel.create({
        firstname: IPatientLoanDTO.firstname,
        lastname: IPatientLoanDTO.lastname,
        email: IPatientLoanDTO.emailId,
        primary_phone: IPatientLoanDTO.contactNumber,
        dateofbirth: IPatientLoanDTO.dateOfBirth,
        gender: IPatientLoanDTO.gender,
        zip_code: IPatientLoanDTO.currentPinCode,
        address_line1: IPatientLoanDTO.currentAddress,
        city: IPatientLoanDTO.currentCity,
        district: IPatientLoanDTO.currentCity,
        state: IPatientLoanDTO.currentState
      });

      const patientLoan = await this.patientLoanModel.create({
        ...IPatientLoanDTO,
        isActive: true,
        isDeleted: false,
        updatedAt: new Date().toUTCString(),
        createdAt: new Date().toUTCString(),
        // updatedBy: currentUser._id,
        // createdBy: currentUser._id,
        // organizationId: currentUser.organizationId,
        // organizationName: req.currentOrg.nameOfOrganization,
      })

      return { success: true, message: "Invoice details added successfully", invoiceId: patientLoan.invoiceId }
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  public async addReferenceDetails(IPatientLoanDTO: IPatientLoanDTO): Promise<{ success: boolean, message: string }> {
    try {
      const patientLoan = await this.patientLoanModel.findOneAndUpdate(
        { invoiceId: IPatientLoanDTO.invoiceId },
        { $set: IPatientLoanDTO },
        { useFindAndModify: false }
      )
      return { success: true, message: "Reference details added successfully" }
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  public async addLoanDetails(IPatientLoanDTO: IPatientLoanDTO): Promise<{ success: boolean, message: string }> {
    try {
      IPatientLoanDTO.organizationName = IPatientLoanDTO.hospitalName;
      IPatientLoanDTO.UWApprovedAmount = IPatientLoanDTO.BGApprovedAmt;

      IPatientLoanDTO.interest = 6;
      IPatientLoanDTO.processingFees = 2;

      var interestAmount = (IPatientLoanDTO.loanAmount * IPatientLoanDTO.interest) / 100;
      var processingPer = (IPatientLoanDTO.loanAmount * IPatientLoanDTO.processingFees) / 100;

      var GST = (processingPer * 18) / 100;

      var deductions = interestAmount + processingPer + GST;

      var DisbursementAmount = IPatientLoanDTO.loanAmount - deductions;

      IPatientLoanDTO.GST_Amount = GST;
      IPatientLoanDTO.deduction_Amount = deductions;
      IPatientLoanDTO.PF_Amount = processingPer;
      IPatientLoanDTO.Disbursed_Amount = processingPer;
      IPatientLoanDTO.EMI_Amount = DisbursementAmount;
      IPatientLoanDTO.EMI_Tenure = IPatientLoanDTO.scheme;

      const patientLoan = await this.patientLoanModel.findOneAndUpdate(
        { invoiceId: IPatientLoanDTO.invoiceId },
        { $set: IPatientLoanDTO },
        { useFindAndModify: false }
      )

      var bgPatientObj: any = {
        insuranceco: IPatientLoanDTO.insuranceco,
        inhouse_tpa: IPatientLoanDTO.inhouse_tpa,
        tpa: IPatientLoanDTO.tpa,
        uhid: IPatientLoanDTO.uhid,
        policy_no: IPatientLoanDTO.policy_no,
        sum_insured: IPatientLoanDTO.sum_insured,
        is_corporate: IPatientLoanDTO.is_corporate,
        corporate_name: IPatientLoanDTO.corporate_name,
        policy_startdt: IPatientLoanDTO.policy_startdt,
        policy_enddt: IPatientLoanDTO.policy_enddt
      }
      const bgPatient = await this.BeemaGarageModel.findOneAndUpdate(
        { primary_phone: patientLoan.contactNumber.toString() },
        { $set: bgPatientObj },
        { useFindAndModify: false }
      );

      return { success: true, message: "Loan details added successfully" }
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  public async uploadDocuments(IPatientLoanDTO: IPatientLoanDTO): Promise<{ success: boolean, message: string }> {
    try {
      const patientLoan = await this.patientLoanModel.findOneAndUpdate(
        { invoiceId: IPatientLoanDTO.invoiceId },
        { $set: IPatientLoanDTO },
        { useFindAndModify: false }
      )

      const bgPatient = await this.BeemaGarageModel.findOneAndUpdate(
        { primary_phone: patientLoan.contactNumber.toString() },
        { $set: { policy_doc: IPatientLoanDTO.uploadInsurancePolicy } },
        { useFindAndModify: false }
      );

      return { success: true, message: "Documents added successfully" }
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  public async getInvoice(IPatientLoanDTO: IPatientLoanDTO): Promise<{ success: boolean, patientLoan: any }> {
    try {
      var searchFilters = [];
      searchFilters.push({ isDeleted: false });
      if (IPatientLoanDTO.invoiceId != undefined || null) {
        searchFilters.push({ invoiceId: IPatientLoanDTO.invoiceId });
      }
      if (IPatientLoanDTO.contactNumber != undefined || null) {
        searchFilters.push({ contactNumber: IPatientLoanDTO.contactNumber });
      }
      const patientLoan = await this.patientLoanModel.findOne({$and: searchFilters})
      return { success: true, patientLoan }
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
}
