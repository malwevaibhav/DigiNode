import { ObjectId } from "mongoose";

export interface IUser {
  _id: string;
  name: string;
  email: string;
  password: string;
  salt: string;
  organizationId: ObjectId;
  role: string
  testUser: boolean;
  passwordUpdatedOn: Date;
  BGHospitalId: string;
  address: Array<any>;
}
export interface IFilterDTO {
  _id: string;
  pageNumber: number;
  pageSize: number;
  dateFrom: Date;
  dateTo: Date;
  searchTerm: string;
  caseId: string;
}
export interface IUserInputDTO {
  name: string;
  email: string;
  password: string;
  role: String;
  address: Array<Object>;
  BGHospitalId: string;
}

export interface ILeadDTO {
  leadType: string,
  name: string,
  contactNumber: string
  altContactNumber: string,
  email: string,
  address: string,
  isInsured: boolean,
  insuranceName: string,
  financialAssistance: string,
  specialty: string,
  product: string,
  cashlessClaimFinancing: boolean,
  message: string
}
