export const whieListApi =[
    {url:"http://localhost:4200"},
    {url:"https://devnew.digisparsh.in"},
    {url:"https://portal.digisparsh.in"},
    {url:"https://uatnewdigi.digisparsh.in"},
]