import { Document, Model } from 'mongoose';
import { IUser } from '@/interfaces/IUser';
import { Organization } from '@/models/organizationSchema';
import { product } from '@/models/productSchema';
import { productMapping } from '@/models/productMapping';
import { ClaimInvoiceDoc } from '@/models/claimInvoiceSchema';
import { businessLogicDoc } from '@/models/businessLogicSchema';
import { LTVDoc } from '@/models/LTVMasters';
import { IncrementValueDoc } from '@/models/IncrementValues';
import { SupplierInvoiceDoc } from '@/models/SupplierInvoiceSchema';
import { HVAssociationDoc } from '@/models/HVAssociationModel';
import { DPAssociationDoc } from '@/models/DPAassociationModel';
import { TransactionDoc } from '@/models/TransactionData';
import { patientLoanDoc } from '@/models/patientLoanSchema';
import { osvDoc } from '@/models/OSVSchema';
import { companyConstantBank } from '@/models/CompanyConstants';
import { purchaseFinancingDoc } from '@/models/pharmacyFinancing';
import { patientrepaymentDoc } from '@/models/patientRepaymentSchema';

declare global {
  namespace Express {
    export interface Request {
      currentUser: IUser & Document;
    }    
  }

  namespace Models {
    export type companyConstant = Model<companyConstantBank>;
  }
  namespace Models {
    export type UserModel = Model<IUser & Document>;
  }
  
  namespace Models {
    export type patientLoanModel = Model<patientLoanDoc & Document>;
  }

  namespace Models {
    export type organizationModel = Model<Organization & Document>;
  }
  namespace Models {
    export type productModel = Model<product>;
  }
  namespace Models {
    export type productMappingModel = Model<productMapping>;
  }
  namespace Models {
    export type ClaimInvoiceModel = Model<ClaimInvoiceDoc>;
  }
  namespace Models {
    export type businessLogicsModel = Model<businessLogicDoc & Document>;
  }
  namespace Models {
    export type TransactionDataModel = Model<Document & TransactionDoc>
  }
  namespace Models {
    export type InsuranceMasterModel = Model<Document>
  }
  namespace Models {
    export type TPAMasterModel = Model<Document>
  }
  namespace Models {
    export type LTVMasterModel = Model<LTVDoc & Document>
  }
  namespace Models {
    export type incrementValueModel = Model<IncrementValueDoc & Document>
  }
  namespace Models {
    export type CitiesModel = Model<Document>;
  }
  namespace Models {
    export type SupplierInvoiceModel = Model<SupplierInvoiceDoc & Document>;
  }
  namespace Models {
    export type HVAssociationModel = Model<Document & HVAssociationDoc>;
  }
  namespace Models {
    export type DPAssociationModel = Model<Document & DPAssociationDoc>;
  }
  namespace Models {
    export type OSVModel = Model<osvDoc & Document>;
  }
  namespace Models {
    export type PharmacyModel = Model<purchaseFinancingDoc & Document>;
  }
  namespace Models {
    export type patientrepaymentModel = Model<patientrepaymentDoc & Document>;
  }
}
