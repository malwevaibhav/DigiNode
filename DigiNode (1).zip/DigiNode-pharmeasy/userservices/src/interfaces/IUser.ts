import { StringNullableChain } from 'lodash';
import { ObjectId } from 'mongoose';

export interface IUser {
  _id: string,
  name: string,
  email: string,
  password: string,
  salt: string,
  accessControl: number,
  organizationId: ObjectId,
  role: string,
  testUser: boolean,
  passwordUpdatedOn: Date,
  CINNumber: string,
  GSTNumber: string,
  PANNumber: string,
  hospitalName: string,
  dateOfRegistration: Date,
  address: string,
  mobileNumber: number
  isSplit: Boolean,
  aggregatorSplit: number,
  hospitalSplit: number,
  aggregatorROI: number,
  hospitalROI: number,
  HospitalId: ObjectId,
  AvailableLimit: number,
  UtilizedAmount: number,
  Repayment: number,
  ExistingCreditLimit: number,
  ROIForAggregator: number,
  LenderTenure: number,
  LenderROI: number,
  isActive: boolean,
  LStatus: any,
  LenderLTV: any,
  LenderId: any,
  aggregatorId: any,
  LTV: any,
  SanctionLimit: number,
  AggregetorROI: any,
  //Vendor
  RateOfDeduction: number,
  NoOfDaysCreditPeriod: number,
  companyType: string
  authorizedPerson: string
  //supplier
  Tenure: number,
  ROI: number,
  PFFees: number,
  PFAmount: number,
  PFRemaining: number,
  PFDeducted: number,
  AdditionalInterest: number,
  UWName: string,
  UWId: ObjectId,
  Status: string;

}
export interface IFilterDTO {
  _id: string;
  pageNumber: number;
  pageSize: number;
  filters: Array<Object>;
  Status: string;
  isInsured: boolean;
  invoiceStatus: string;
  dateFrom: Date;
  dateTo: Date;
  organizationId: string;
  searchTerm: string;
  invoiceSubStatus: string;
}
export interface IOrgInputDTO {
  nameOfOrganization: string,
  typeOfOrganization: string,
  dateOfRegistration: Date,
  contactNumber: number,
  email: string,
  CINNumber: string
  contactPerson: string
  address: Array<object>,
  GSTNumber: string,
  PANNumber: string,
  NoOfClaimProcessedInAYear: number,
  TotalNoOfClaimProcessed: number,
  AverageTicketSizeOfTheClaims: number
  NoOfTPAsAssociated: number
  NoOfDirectInsuranceCompaniesAssociated: number,
  //
  GSTUrl: string,
  AddressDocUrl: string,
  NOCextUrl: string,
  TwoYearBankStUrl: string,
  TwoyearTTRUrl: string,
  ParriPassuUrl: string,
  FinancialStUrl: string,
  otherUrl: string,
  //
  NameOfDirector: string,
  ContactNumberOfDirector: string,
  DirectorEmail: string,
  DirectorPANNumber: string,
  AadharNumber: string,
  //
  NameOfTheBank: string,
  AccountNumber:  string,
  AccountName:  string,
  IFSCcode:  string,
  Branch:  string,
  escrowAccountName:  string,
  escrowAccountNumber:  string,
  escrowNameOfTheBank:  string,
  escrowIFSCcode:  string,
  escrowBranch:  string,
  //


}
export interface IUserInputDTO {
  name: string;
  email: string;
  password: string;
}
export interface IPatientLoanDTO {
  _id: string;
  invoiceId: number;
  invoiceStatus: string;
  organizationId: ObjectId;
  isInsured: Boolean;
  patientName: string;
  borrowerName: string;
  relation: string;
  dateOfBirth: Date;
  contactNumber: string;
  altContactNumber: string,
  PANNumber: string,
  aadhaarNumber: string,
  emailId: string;
  occupation: string;
  permanentAddress: string;
  currentAddress: string;
  companyName: string;
  totalIncome: number;
  loanAmount: number;
  PF_Amount: number;
  GST_Amount: number;
  Disbursed_Amount: number;
  Disbursement_Date: Date;
  interest_Amount: number;
  deduction_Amount: number;
  EMI_Amount: number;
  EMI_Tenure: number;
  referenceName: string;
  contactNoRefPerson: number;
  relationship: string;
  emailIdRefPerson: string;
  hospitalName: string;
  enterHospitalName:string;
  bankAssociated: string;
  branch: string;
  accountNumber: string;
  IFSCCode: string;
  accountType: string;
  hospitalAccount:string;
  hospitalBeneficiaryName:string;
  hospitalAggregatorName:string;
  hospitalBankName:string;
  hospitalBankIfsc:string;
  hospitalBankBranch:string;
  scheme: number;
  interest: number;
  processingFees: number;
  uploadAadharFront: string;
  uploadAadharBack: string;
  uploadPAN: string;
  recommendationLetter: string;
  uploadProof: string;
  uploadCancelledCheque: string;
  uploadIncomeProof: string;
  uploadHospitalBill: string;
  uploadBankStatement: string;
  uploadInsurancePolicy: string;
  uploadOtherDoc: string;
  uploadConsentDoc: string;
  permanentPinCode: number;
  permanentCity: string;
  permanentState: string;
  permanentDistrict: string;
  currentDistrict: string;
  currentPinCode: number;
  Amount_to_be_Repaid: number;
  currentCity: string;
  currentState: string;
  UWName: string;
  UWId: string;
  caseId: string;
  //digio
  digio_doc_id: string;
  txn_id: string;
  message: string;
  error_code: string;
  agreementDocUrl: string;
  invoiceSubStatus: string;
  lenderApprovedAmount: number;
  lenderComment: string;
  UWApprovedAmount: number;
  UWComment: string;
  settlementLetter: string;
  settlementAmount: number;
  settlementDate: Date;
  settlementcomment:string
  // insurance
  insuranceco: string;
  inhouse_tpa: Boolean;
  tpa: string;
  uhid: string;
  policy_no: string;
  sum_insured: number;
  is_corporate: Boolean;
  policy_startdt: Date;
  policy_enddt: Date;
  gender: string;
  loan_id: string,
  cibil_score:any,
  treatmentDetails: string,
  approvalLetter: string,

  //Percentage
  digiPercentage:number,
  lenderPercentage:number,
  hospitalPercentage:number
}
export interface IProductDTO {
  productCode: string,
  productName: string,
  // tenure: string,
  // hasEMI: Boolean,
  interestMaster: Array<Object>,
  moduleName: string
}
export interface IProductMappingDTO {
  organizationId: ObjectId,
  organizationName: string,
  productId: ObjectId,
  productName: string,
  // ROI: number,
}
export interface IHospitalDTO {
  hospitalName: string,
  CINNumber: string,
  GSTNumber: string,
  PANNumber: string,
  dateOfRegistration: Date,
  email: string,
  password: string,
  name: string,
  address: string,
  mobileNumber: number
  isSplit: Boolean,
  aggregatorSplit: number,
  hospitalSplit: number,
  aggregatorROI: number,
  hospitalROI: number,
}
export interface IVendorDTO {
  name: string,
  address: Array<Object>,
  mobileNumber: number,
  GSTNumber: string,
  PANNumber: string,
  email: string,
  VendorType: string,
  bankName: string,
  AccountNumber: string,
  IFSCcode: string,
  authorisedPersonName: string,
  contactDetailsForAuthPerson: number,
  PANNumberForAuthPerson: string,
  relationShip: string,
  RateOfDeduction: number,
  NoOfDaysCreditPeriod: number,
  HospitalName: string,
  HospitalId: ObjectId,
  KycDocument: string,
  Other: string,
  ParriPassu: string,
  LastTwoYrBank: string,
  LastAudFin: string,
  LastTwoFin: string,
  RegCert: string,
  GstCert: string,
  AddrProof: string,
  companyType: string
  authorizedPerson: string
}
export interface ISupplierInvoiceDTO {
  _id: string,
  InvoiceAmount: number,
  InvoiceNumber: number,
  venderDocURL: string,
  Description: string,
  InvoiceDate: Date,
  DescriptionArr: string,
  NameOfVendor: string,
  Status: string,
  HospitalComment: string,
  hDueDate: Date,
  GRNDate: Date,
  GRNNo: number,
  GRNValue: number,
  GRNNotes: string,
  GRNDocuments: string,
  AmountReceived: number,
  LoanID: number,
  ReceivedNEFT_RTG: string,
  PaymentReceivedDate: Date,
  flag: string,
  HospitalId: string
}
export interface purchaseFinancingDTO {
  _id: string,
  InvoiceAmount: number,
  InvoiceNumber: number,
  venderDocURL: string,
  Description: string,
  InvoiceDate: Date,
  DescriptionArr: string,
  PmanufactureName: string,
  PmanufactureId: string,
  Status: string,
  distributorComment: string,
  hDueDate: Date,
  GRNDate: Date,
  GRNNo: number,
  GRNValue: number,
  GRNNotes: string,
  GRNDocuments: string,
  AmountReceived: number,
  LoanID: number,
  ReceivedNEFT_RTG: string,
  PaymentReceivedDate: Date,
  flag: string,
  distributorId: string,
  distributorName: string
}

export interface IHospitalSupplierDTO {
  name: string,
  address: string,
  mobileNumber: number,
  GSTNumber: string,
  PANNumber: string,
  email: string,
  VendorType: string,
  bankName: string,
  AccountNumber: string,
  IFSCcode: string,
  authorisedPersonName: string,
  contactDetailsForAuthPerson: number,
  PANNumberForAuthPerson: string,
  relationShip: string,
  Type: string
}


export interface TpaInvoiceDTO {
  nameOfInsurer: String,
  InsuranceCompanyId: ObjectId,
  TPAName: string,
  TPACode: string
}
export interface HVAssociationDTO {
  _id: ObjectId,
  hospitalName: String,
  hospitalId: ObjectId,
  vendorId: ObjectId,
  vendorName: String,
  AvailableLimit: Number,
  Repayment: Number,
  UtilizedAmount: Number
}
export interface DPAssociationDTO {
  _id: ObjectId,
  distributorName: String,
  distributorId: ObjectId,
  PmanufactureId: ObjectId,
  PmanufactureName: String,
  AvailableLimit: Number,
  Repayment: Number,
  UtilizedAmount: Number,
  distributorLimit: Number
}
export interface IPharmacyDTO {
  _id: string,
  InvoiceAmount: number,
  InvoiceNumber: number,
  venderDocURL: string,
  Description: string,
  InvoiceDate: Date,
  DescriptionArr: string,
  NameOfVendor: string,
  Status: string,
  DistributorComment: string,
  DIDueDate: Date,
  GRNDate: Date,
  GRNNo: number,
  GRNValue: number,
  GRNNotes: string,
  GRNDocuments: string,
  AmountReceived: number,
  LoanID: number,
  ReceivedNEFT_RTG: string,
  PaymentReceivedDate: Date,
  flag: string,
  distributorId: string,
  hospitalAccount:string,
  hospitalBeneficiaryName:string,
  hospitalAggregatorName:string,
  hospitalBankName:string,
  hospitalBankIfsc:string,
  hospitalBankBranch:string
}