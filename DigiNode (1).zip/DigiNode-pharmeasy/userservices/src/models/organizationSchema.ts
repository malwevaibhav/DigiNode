import mongoose from 'mongoose';

const OrganizationSchema = new mongoose.Schema({
    nameOfOrganization: {
        type: String,
    },
    typeOfOrganization: {
        type: String,
    },
    lenderType: {
        type: String,
        enum: ["Offline", "Online-A", "Online-B"]
    },
    dateOfRegistration: {
        type: Date,
    },
    contactNumber: {
        type: Number,
    },
    email: {
        type: String,
    },
    claimFinancing: {
        type: Boolean,
        required: true
    },
    supplierFinancing: {
        type: Boolean,
        required: true
    },
    patientFinancing: {
        type: Boolean,
        required: true
    },
    merchantFinancing: {
        type: Boolean,
        required: true
    },
    employeeManagement: {
        type: Boolean,
        required: true
    },
    purchaseFinancing: {
        type: Boolean,
        required: true
    },
    PFFees: {
        type: Number
    },
    PFRemaining: {
        type: Number
    },
    PFDeducted: {
        type: Number
    },
    AdditionalInterest: {
        type: Number
    },
    LenderId: {
        type: mongoose.Schema.Types.ObjectId,
    },
    LenderName: {
        type: String
    },
    LTV: {
        type: Number
    },
    isSplit: {
        type: Boolean
    },
    CINNumber: {
        type: String
    },
    contactPerson: {
        type: String
    },
    address: [{ street: String, state: String, city: String, pinCode: Number, country: String }],
    GSTNumber: {
        type: String
    },
    PANNumber: {
        type: String
    },
    NoOfClaimProcessedInAYear: {
        type: Number
    },
    TotalNoOfClaimProcessed: {
        type: Number
    },
    AverageTicketSizeOfTheClaims: {
        type: Number
    },
    NoOfTPAsAssociated: {
        type: Number
    },
    NoOfDirectInsuranceCompaniesAssociated: {
        type: Number
    },
    //
    GSTUrl: {
        type: String
    },
    AddressDocUrl: {
        type: String
    },
    NOCextUrl: {
        type: String
    },
    TwoYearBankStUrl: {
        type: String
    },
    TwoyearTTRUrl: {
        type: String
    },
    ParriPassuUrl: {
        type: String
    },
    FinancialStUrl: {
        type: String
    },
    otherUrl: {
        type: String
    },
    //
    NameOfDirector: {
        type: String,
    },
    ContactNumberOfDirector: {
        type: String
    },
    DirectorEmail: {
        type: String
    },
    DirectorPANNumber: {
        type: String
    },
    AadharNumber: {
        type: String
    },
    //
    NameOfTheBank: {
        type: String
    },
    AccountNumber: {
        type: String
    },
    AccountName: {
        type: String
    },
    IFSCcode: {
        type: String
    },
    Branch: {
        type: String
    },
    escrowAccountName: {
        type: String
    },
    escrowAccountNumber: {
        type: String
    },
    escrowNameOfTheBank: {
        type: String
    },
    escrowIFSCcode: {
        type: String
    },
    escrowBranch: {
        type: String
    },
    //
    LenderTenure: {
        type: Number
    },
    LenderROI: {
        type: Number
    },
    LComment: {
        type: String
    },
    LenderLTV: {
        type: Number
    },
    ExistingCreditLimit: {
        type: Number
    },
    //
    Repayment: {
        type: Number
    },
    UtilizedAmount: {
        type: Number
    },
    AvailableLimit: {
        type: Number
    },
    //
    aggregatorId: {
        type: mongoose.Schema.Types.ObjectId,
    },
    UWName: {
        type: String
    },
    UWId: {
        type: mongoose.Schema.Types.ObjectId,
    },
    schemas: [
        {
            scheme: Number,
            interest: Number,
            processingFees: Number
        }
    ],
    hospitals: [
        {
            hospitalId:mongoose.Schema.Types.ObjectId,
            hospitalName:String
        }
    ],
    digiPercentage:Number,
    lenderPercentage:Number,
    hospitalPercentage:Number,
    isActive: Boolean,
    isDeleted: Boolean,
    updatedAt: Date,
    createdAt: Date,
});

export default mongoose.model<mongoose.Document>('OrganizationSchema', OrganizationSchema);

export interface Organization extends mongoose.Document {
    email: string,
    nameOfOrganization: string,
    typeOfOrganization: string
    dateOfRegistration: Date,
    contactNumber: number,
    orgSidebar: boolean,
    testOrg: boolean,
    lenderType: string,
    isSplit: boolean,
    UtilizedAmount: number,
    Repayment: number,
    AvailableLimit: number,
    ExistingCreditLimit: number,
    LenderId: any,
    LenderName: string,
    LenderLTV: number,
    aggregatorId: any,
    LTV: number,
    LenderROI: number,
    LenderTenure: number,
    PFFees: number,
    PFRemaining: number,
    PFDeducted: number,
    AdditionalInterest: number,
    UWName: string,
    UWId: any,
    schemas:Array<Object>,
    hospitals:Array<Object>,
    digiPercentage:number,
    lenderPercentage:number,
    hospitalPercentage:number
}