
import mongoose from 'mongoose';

const HVAssociationSchema = new mongoose.Schema({

    hospitalId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Users'
    },
    hospitalName: {
        type: String
    },
    vendorId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Users'
    },
    vendorName: {
        type: String
    },
    isDeleted: {
        type: Boolean,
        default: false
    },
    AvailableLimit: {
        type: Number,
        default: 0
    },
    UtilizedAmount: {
        type: Number,
        default: 0
    },
    Repayment: {
        type: Number,
        default: 0
    },
    creditLimit: {
        type: Number,
        default: 0
    }
}, { timestamps: true });


export default mongoose.model<mongoose.Document>('HVAssociation', HVAssociationSchema);

export interface HVAssociationDoc extends mongoose.Document {
    hospitalName: string,
    hospitalId: any,
    vendorId: any,
    vendorName: string,
    AvailableLimit: number,
    Repayment: number,
    UtilizedAmount: number,
    creditLimit: number
}

