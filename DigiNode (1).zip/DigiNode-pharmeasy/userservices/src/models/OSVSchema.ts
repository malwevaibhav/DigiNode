import mongoose from 'mongoose';
const OSVSchema = new mongoose.Schema(
    {
        osvEmpName: {
            type: String,
        },
        osvEmpId: {
            type: String,
        },
        osvEmpOrg: {
            type: String,
        },
        updatedBy: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'users',
        },
    },
    {
        timestamps: true,
    },
);
export default mongoose.model<mongoose.Document>('osvdetail', OSVSchema);

export interface osvDoc extends mongoose.Document {
    osvEmpName: string,
    osvEmpId: string,
    osvEmpOrg: string
}