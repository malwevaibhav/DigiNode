import mongoose from 'mongoose';
const patientRepaymentSchema = new mongoose.Schema(
    {
        invoiceId: {
            type: Number,
        },
        patientName: {
            type: String,
        },
        patientMobileNo: {
            type: String,
        },
        Disbursement_Date:{
            type:Date
        },
        TotalAmount:{
            type:Number
        },
        remaining_Amount:{
            type:Number
        },
        Repayment_Received_Amt:{
            type:Number
        },
        Repayment_Received_Date:{
            type:Date
        },
        InvoiceStatus:{
            type: String,
        },
        InvoiceSubStatus:{
            type: String,
        },
        settlement_letter:{
            type:String
        },
        settlement_comment:{
            type:String
        },
        createdBy:{
            type: mongoose.Schema.Types.ObjectId,
            ref: 'users',
        },
        updatedBy: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'users',
        },
    },
    {
        timestamps: true,
    },
);
export default mongoose.model<mongoose.Document>('patientrepayment', patientRepaymentSchema);

export interface patientrepaymentDoc extends mongoose.Document {
    invoiceId:number,
    patientName:string,
    patientMobileNo:string,
    Disbursement_Date:Date,
    TotalAmount:number,
    remaining_Amount:number,
    Repayment_Received_Amt:number,
    Repayment_Received_Date:Date,
    InvoiceStatus:string,
    InvoiceSubStatus:string,
    settlement_letter:string
    settlement_comment:string
}