import mongoose from 'mongoose';

const DPAssociationSchema = new mongoose.Schema(
  {
    distributorId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Users',
    },
    distributorName: {
      type: String,
    },
    PmanufactureId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Users',
    },
    PmanufactureName: {
      type: String,
    },
    isDeleted: {
      type: Boolean,
      default: false,
    },
    AvailableLimit: {
      type: Number,
    },
    UtilizedAmount: {
      type: Number,
    },
    Repayment: {
      type: Number,
    },
    creditLimit: {
      type: Number,
    },
    distributorLimit: {
      type: Number,
    },

    Hospital: {
      type: String,
    },
    Aggregator: {
      type: String,
    },
  },
  { timestamps: true },
);

export interface DPAssociationDoc extends mongoose.Document {
  distributorName: string;
  distributorId: string;
  PmanufactureId: any;
  PmanufactureName: string;
  AvailableLimit: number;
  Repayment: number;
  UtilizedAmount: number;
  creditLimit: number;
  distributorLimit: Number;
  Hospital: Array<string>;
  Aggregator: any;
}
export default mongoose.model<mongoose.Document>('DPAssociation', DPAssociationSchema);
