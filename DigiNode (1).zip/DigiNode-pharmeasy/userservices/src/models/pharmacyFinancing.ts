import mongoose from 'mongoose';
const AutoIncrement = require('mongoose-sequence')(mongoose);
const purchaseFinancingSchema = new mongoose.Schema({

    InvoiceAmount: {
        type: Number
    },
    NameOfVendor: {
        type: String
    },

    InvoiceNumber: {
        type: Number
    },
    flag: {
        type: String
    },
    DIRejectedDate: {
        type: Date
    },
    venderDocURL: {
        type: String
    },
    InvoiceDate: {
        type: Date,
        default: Date.now
    },
    Status: {
        type: String
    },
    distributorId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Users'
    },
    // VendorId: {
    //     type: mongoose.Schema.Types.ObjectId,
    //     ref: 'Users'
    // },
    PmanufactureId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Users'
    },
    LenderId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Users'
    },
    distributorName: {
        type: String
    },
    PmanufactureName: {
        type: String
    },
    /////////////////////////////////////////////////////////////////Date////////////////////////////////////////////////////////////////////////////////////////////////////////////
    DIResponseDate: {
        type: Date
    },
    ///not in project
    DIRepaidDate: {
        type: Date
    },
    LResponseDate: {
        type: Date
    },
    LRejectDate: {
        type: Date
    },
    DIDueDate: {
        type: Date
    },
    RepaymentDueDate: {
        type: String
    },
    OverdueNoOfDays: {
        type: Number
    },
    TotalDeduction: {
        type: Number
    },
    OverdueCharges: {
        type: Number
    },
    BalanceAmount: {
        type: Number
    },
    RemainingAmount: {
        type: Number
    },
    AmtToTransfer: {
        type: Number
    },
    PastRecoveryAmount: {
        type: Number
    },
    ///overpaid full paid
    SettleStatus: {
        type: String
    },
    DistributorComment: {
        type: String
    },
    LenderComment: {
        type: String
    },
    ROI: {
        type: Number
    },
    Tenure: {
        type: String
    },
    LTV: {
        type: Number
    },
    RateOfDeduction: {
        type: Number
    },
    NoOfDaysCreditPeriod: {
        type: Number
    },
    amountToBeDisbursed: {
        type: Number
    },
    LTVAmount: {
        type: Number
    },
    Description: {
        type: String
    },
    ApprovedAmount: {
        type: Number
    },
    AmountPaid: {
        type: Number
    },
    upfrontInterest: {
        type: Number
    },
    NEFT_RTG: {
        type: String
    },
    PaymentDate: {
        type: Date
    },
    AmountReceived: {
        type: Number
    },
    ReceivedNEFT_RTG: {
        type: String
    },
    PaymentReceivedDate: {
        type: Date
    },
    AdditionalInterest: {
        type: Number
    },
    GRNDate: {
        type: Date
    },
    GRNNo: {
        type: Number
    },
    GRNValue: {
        type: Number
    },
    GRNNotes: {
        type: String
    },
    GRNDocuments: {
        type: String
    },
    LateRecoveryAmount: {
        type: Number
    },
    RecoveryInvoiceNumber: {
        type: Number
    },
    DescriptionArr: [{
        type: Array
    }],
    PastRecoveryDetails: {
        type: String
    }
},
    { timestamps: true },
);
purchaseFinancingSchema.plugin(AutoIncrement, {
    inc_field: "LoanID",
    start_seq: 204001,
    id: 'purchaseFinancingCounter'
});
export default mongoose.model<mongoose.Document>('purchaseFinancing', purchaseFinancingSchema);

export interface purchaseFinancingDoc extends mongoose.Document {
    InvoiceDate: Date,
    LenderId: any,
    Status: string,
    distributorId: any,
    hDueDate: Date,
    LTVAmount: number,
    BalanceAmount: number,
    AmountReceived: number,
    VendorId: any,
    PmanufactureId: any,
    PmanufactureName: string,
    NoOfDaysCreditPeriod: number,
    LoanID: number,
    InvoiceNumber: number,
    amountToBeDisbursed: number,
    upfrontInterest: number,
    distributorName:string,
    RemainingAmount:number

}