import { ObjectId } from 'mongodb';
import mongoose from 'mongoose';
const AutoIncrement = require('mongoose-sequence')(mongoose);

const loansSchema = new mongoose.Schema(
  {
    //org
    organizationId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'organizationschemas',
    },
    organizationName: {
      type: String
    },
    uploadedViaExcel: {
      type: Boolean
    },
    //invoice Type/Status
    isInsured: {
      type: Boolean,
    },
    invoiceStatus: {
      type: String,
      enum: ['Pending', 'InProcess', 'Approved', 'Disbursed', 'Partially Repaid', 'Closed', 'Rejected', 'Withdraw','Repayment Done'],
      default: 'Pending',
    },
    invoiceSubStatus: {
      type: String,
      enum: ['Pending at DSPL',
        'Pending at Claim Processing Team',
        'Pending for Final Approval Amount',
        'Pending at Lender',
        'Pending Agreement Signing',
        'Pending E-Nach',
        'Upload Final Bill',
        'Pending Disbursement',
        'Rejected by DSPL',
        'Rejected by Under-Writing Partner',
        'Rejected by Lender',
        'Additional Information requested by Lender',
        'Additional Information requested by DSPL',
        'Additional Information requested by Under-Writing Partner',
        'Final Bill Uploaded',
        'Disbursed',
        'Fully Repayment',
        'Partially Repayment',
        'Short Settlement'
      ],
    },
    digiComment: {
      type: String,
    },
    loan_id: {
      type: String,
      // unique: true,
      // sparse:true
 
    },
    cibil_score: {
      type: String,
      // unique: true,
      // sparse:true
 
    },
    treatmentDetails: {
      type: String
    },
    lenderComment: {
      type: String,
    },
    // patient
    patientName: {
      type: String,
    },
    //borrower
    borrowerName: {
      type: String,
    },
    relation: {
      type: String,
    },
    altContactNumber: {
      type: String
    },
    PANNumber: {
      type: String
    },
    aadhaarNumber: {
      type: String
    },
    dateOfBirth: {
      type: Date,
    },
    emailId: {
      type: String,
    },
    contactNumber: {
      type: String,
    },
    currentAddress: {
      type: String,
    },
    permanentAddress: {
      type: String,
    },
    //occupaption details
    occupation: {
      type: String,
    },
    companyName: {
      type: String,
    },
    totalIncome: {
      type: Number,
    },
    //loan details
    loanAmount: {
      type: Number,
    },
    scheme: {
      type: Number,
      default: 0
    },
    interest: {
      type: Number,
      default: 0
    },
    processingFees: {
      type: Number,
      default: 0
    },
    //borrower's bank details
    accountNumber: {
      type: String,
    },
    bankAssociated: {
      type: String,
    },
    branch: {
      type: String,
    },
    IFSCCode: {
      type: String,
    },
    accountType: {
      type: String
    },
    accountHolderName: {
      type: String
    },
    //reference person
    referenceName: {
      type: String,
    },
    contactNoRefPerson: {
      type: String,
    },
    relationship: {
      type: String,
    },
    emailIdRefPerson: {
      type: String,
    },
    // hospital
    // upload document
    hospitalName: {
      type: String,
    },
    enterHospitalName: {
      type: String,
    },
    uploadAadharFront: {
      type: String,
    },
    uploadAadharBack: {
      type: String,
    },
    uploadPAN: {
      type: String,
    },
    uploadHospitalBill: {
      type: String,
    },
    uploadCancelledCheque: {
      type: String,
    },
    //relationship proof
    uploadProof: {
      type: String,
    },
    recommendationLetter: {
      type: String
    },
    uploadIncomeProof: {
      type: String,
    },
    uploadBankStatement: {
      type: String,
    },
    uploadInsurancePolicy: {
      type: String,
    },
    uploadOtherDoc: {
      type: String,
    },
    uploadConsentDoc: {
      type: String
    },
    createdAt: {
      type: Date,
    },
    updatedAt: {
      type: Date,
    },
    isDeleted: {
      type: Boolean,
    },
    isActive: {
      type: Boolean,
    },
    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'users',
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'users',
    },

    // Disbursement data
    lenderStatus: {
      type: String,
    },
    Down_Payment_Amount: {
      type: Number,
    },
    Subvention_Amount: {
      type: Number,
    },
    PF_Amount: {
      type: Number,
      default: 0
    },
    Franking_Amount: {
      type: Number,
    },
    interest_Amount: {
      type: Number,
      default: 0
    },
    GST_Amount: {
      type: Number,
      default: 0
    },
    deduction_Amount: {
      type: Number,
      default: 0
    },
    EMI_Tenure: {
      type: Number,
      default: 0
    },
    EMI_Amount: {
      type: Number,
      default: 0
    },
    Approval_Date: {
      type: Date,
    },
    Disbursed_Amount: {
      type: Number,
      default: 0
    },
    Disbursement_Date: {
      type: Date,
    },
    TotalDisbursementAmount: {
      type: Number
    },
    Unique_Ref_No: {
      type: String,
    },
    Cash_Out_Flow_Amount: {
      type: Number,
    },
    invoiceId: {
      type: Number,
      index: { unique: true },
    },

    permanentPinCode: {
      type: Number,
    },
    permanentCity: {
      type: String,
    },
    permanentState: {
      type: String,
    },
    permanentDistrict: {
      type: String
    },
    currentDistrict: {
      type: String
    },
    currentPinCode: {
      type: Number,
    },
    currentCity: {
      type: String,
    },
    currentState: {
      type: String,
    },
    UWPartnerApproved: {
      type: Boolean,
    },
    caseId: {
      type: String
    },
    UWApprovedAmount: {
      type: Number
    },
    UWComment: {
      type: String
    },
    UWName: {
      type: String
    },
    UWId: {
      type: String
    },
    DSPLAssignee: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'users'
    },
    mandate_id: {
      type: String
    },
    mandate_txn_id: {
      type: String
    },
    mandate_status: {
      type: String
    },
    agreementDocUrl: {
      type: String
    },
    agreementESignedOn: {
      type: Date
    },
    LenderId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'users'
    },
    finalApprovedAmount: {
      type: Number
    },
    lenderApprovedAmount: {
      type: Number
    },
    lenderResponseDate: {
      type: Date
    },
    agreementDocId: {
      type: String
    },
    // Settlement
    settlementDate: {
      type: Date
    },
    settlementAmount: {
      type: Number
    },
    settlementLetter: {
      type: String,
    },
    settlementcomment: {
      type: String,
    },
    approvalLetter: {
      type: String
    },
    mandateUMRN: {
      type: String
    },
    mandateDebitId: {
      type: String
    },
    debitTxnId: {
      type: String
    },
    // insurance details 
    insuranceco: {
      type: String
    },
    inhouse_tpa: {
      type: Boolean
    },
    tpa: {
      type: String
    },
    uhid: {
      type: String
    },
    policy_no: {
      type: String
    },
    sum_insured: {
      type: Number
    },
    is_corporate: {
      type: Boolean
    },
    policy_startdt: {
      type: Date
    },
    policy_enddt: {
      type: Date
    },
    gender: {
      type: String
    },
    digiPercentage: {
      type: Number
    },
    lenderPercentage: {
      type: Number
    },
    hospitalPercentage: {
      type: Number
    },
    recommendedAmount: {
      type: Number
    },
    Amount_to_be_Repaid: {
      type: Number
    },
    KYCRequestId: {
      type: String
    },
    KYCActionId: {
      type: String
    },
    agreementTemplateId: {
      type: String
    },
    UTRNumber: {
      type: String
    },
    uploadFinalBill: {
      type: String
    },
    uploadCibil: {
      type: String
    },
    hospitalAccount: {
      type: String
    },
    hospitalBankName: {
      type: String
    },
    hospitalBankIfsc: {
      type: String
    },
    hospitalBankBranch: {
      type: String
    },
    hospitalBeneficiaryName: {
      type: String
    },
    hospitalAggregatorName: {
      type: String
    },
    mandateDetailsId: {
      type: mongoose.Schema.Types.ObjectId,
      ref:'mandatedetails'
    },
    date: {
      type: String,

      default: new Date().toUTCString().slice(5, 16)
    }
  },
  {
    timestamps: true,
  },
);
loansSchema.plugin(AutoIncrement, {
  inc_field: 'invoiceId',
  start_seq: 203001,
});

export default mongoose.model<mongoose.Document>('patientloans', loansSchema);

export interface patientLoanDoc extends mongoose.Document {
  accountNumber: string,
  contactNumber: string,
  emailId: string,
  patientName: string,
  borrowerName: string,
  invoiceId: number,
  mandate_id: string,
  mandateDetailsId:ObjectId
  loanAmount: number,
  bankAssociated: string,
  IFSCCode: string,
  accountType: string,
  agreementDocUrl: string,
  invoiceSubStatus: string,
  invoiceStatus: string,
  enterHospitalName:string,
  lenderApprovedAmount: number,
  mandateUMRN: string,
  finalApprovedAmount: number,
  uploadHospitalBill: string,
  UWApprovedAmount: number,
  recommendedAmount: number,
  accountHolderName: string,
  KYCRequestId: string,
  KYCActionId: string,
  agreementTemplateId: string,
  dateOfBirth: Date,
  PANNumber: string,
  Tenure: number,
  loan_id: any,
  cibil_score:any,
  currentAddress: string,
  currentCity: string,
  currentState: string,
  interest: number,
  processingFees: number,
  TotalDisbursementAmount: number,
  UTRNumber: string,
  scheme: number,
  date: string,
  uploadFinalBill: string,
  uploadAadharFront:string,
  uploadPAN:string,
  uploadCibil:string,
  hospitalAccount:string,
  hospitalBankName:string,
  hospitalBankIfsc:string,
  hospitalBeneficiaryName:string,
  hospitalAggregatorName:string,
  hospitalBankBranch:string
  settlementcomment:string
}