import { Router } from 'express';
import auth from './routes/auth';
import user from './routes/user';
import agendash from './routes/agendash';
import patient from './routes/practoRoute';
import aggregatorRoutes from './routes/aggregatorRoutes';
import lenderRoutes from './routes/lenderRoutes';
import hospitalRoutes from './routes/hospitalRoutes';
import vendorRoutes from './routes/vendorRoutes';
import supplierLenderRoutes from './routes/supplierLenderRoutes';
import hospitalSupplierRoutes from './routes/hospitalSupplierRoutes';
import insuranceRoutes from './routes/insuranceRoutes';
import tpaRoutes from './routes/tpaRoutes';
import patientLenderRoutes from './routes/patientLenderRoutes';
import pharmacyRoutes from './routes/pharmacyRoutes';
import pharmacyLender from './routes/pharmacyLenderRoutes';
import pharmacyDistributorRoutes from './routes/pharmaDistributorRoutes';

// guaranteed to get dependencies
export default () => {
	const app = Router();
	auth(app);
	user(app);
	agendash(app);
	patient(app);
	aggregatorRoutes(app);
	lenderRoutes(app);
	hospitalRoutes(app);
	hospitalSupplierRoutes(app);
	vendorRoutes(app);
	supplierLenderRoutes(app);
	insuranceRoutes(app);
	tpaRoutes(app);
	patientLenderRoutes(app);
	pharmacyRoutes(app);
	pharmacyLender(app);
	pharmacyDistributorRoutes(app)

	return app
}


