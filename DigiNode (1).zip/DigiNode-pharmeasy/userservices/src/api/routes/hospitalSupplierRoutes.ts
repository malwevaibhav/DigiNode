

import { Router, Request, Response, NextFunction } from 'express';
import { Container } from 'typedi';
import { IUser, IFilterDTO, IHospitalSupplierDTO, ISupplierInvoiceDTO } from '../../interfaces/IUser';
import { Logger, loggers } from 'winston';
import { celebrate, errors, Joi } from 'celebrate';
import DateExtension from '@joi/date';
const JoiDate = Joi.extend(DateExtension);
import HospitalSupplierService from '../../services/hospitalSupplierService';
import middlewares from '../middlewares';
import hospitalService from '@/services/hospitalService';
import MailJetService from '../../loaders/mailjet';

import util from 'util'
// const util = require('util')
const gc = require('../GCP/gcp')
const bucket = gc.bucket('digisparsh_images')

var multer = require('multer');
var path = require('path')

const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'upload/')
    },
    filename: function (req, file, cb) {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9)
        cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname))
    }
})

const storage_V2 = multer.memoryStorage()
const uploadBuffer = multer({
    storage: storage_V2,
    limits: { fieldSize: 10 * 1024 * 1024 },
},

)

const uploadImage = (file) => new Promise((resolve, reject) => {
    const { originalname, buffer } = file
    const date1 = Date.now().toString()

    const blob = bucket.file(originalname.replace(/ /g, "_"))
    const blobStream = blob.createWriteStream({
        resumable: false
    })
    let tempName = blob.name.split('.')
    if (tempName && tempName?.length) {

        blob.name = tempName[0] + date1 + '.' + tempName[tempName?.length - 1]
    }

    var blobb = blobStream.on('finish', () => {
        const publicUrl = util.format(
            `https://storage.googleapis.com/${bucket.name}/${blob.name}`
        )
        console.log(publicUrl)
        resolve(publicUrl)

    })
        .on('error', (err) => {
            reject(`Unable to upload image, something went wrong=>${err}`)
        })
        .end(buffer)

})

const route = Router();

export default (app: Router) => {
    app.use('/Shospital', route);
    route.get('/getDashboardForHospital',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Hospital'),
        middlewares.requiredProduct('supplierFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('supplier/getDashboardForHospital: %o');
            try {
                const hospitalServiceInstance = Container.get(HospitalSupplierService);
                const { data } = await hospitalServiceInstance.getDashboardForHospital(req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.get('/getDashboardData',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Hospital'),
        middlewares.requiredProduct('supplierFinancing'),
        celebrate({
            query: {
                dateFrom: JoiDate.date().allow(null),
                dateTo: JoiDate.date().allow(null),
            },
        }),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('supplier/Supplier Hospital getDashboardData: %o', req.query);
            try {
                const HospitalSupplierServiceInstance = Container.get(HospitalSupplierService);

                const { data } = await HospitalSupplierServiceInstance.getDashboardData(req, res, req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.get('/getInvoiceGraphToHospital',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Hospital'),
        middlewares.requiredProduct('supplierFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('supplier/getInvoiceGraphToHospital: %o');
            try {
                const hospitalServiceInstance = Container.get(HospitalSupplierService);
                const { data } = await hospitalServiceInstance.getInvoiceGraphToHospital(req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.get('/getLApprovedVendorToHospital',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Hospital'),
        middlewares.requiredProduct('supplierFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('supplier/getLApprovedVendorToHospital: %o');
            try {
                const hospitalServiceInstance = Container.get(HospitalSupplierService);
                const { data } = await hospitalServiceInstance.getLApprovedVendorToHospital(req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.get('/getFundedInvoiceGraphToHospital',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Hospital'),
        middlewares.requiredProduct('supplierFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('supplier/getFundedInvoiceGraphToHospital: %o');
            try {
                const hospitalServiceInstance = Container.get(HospitalSupplierService);
                const { data } = await hospitalServiceInstance.getFundedInvoiceGraphToHospital(req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.get('/getPendingVendorToHospital',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Hospital'),
        middlewares.requiredProduct('supplierFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('supplier/getPendingVendorToHospital: %o');
            try {
                const hospitalServiceInstance = Container.get(HospitalSupplierService);
                const { data } = await hospitalServiceInstance.getPendingVendorToHospital(req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.get('/getHospitalGraphOne',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Hospital'),
        middlewares.requiredProduct('supplierFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('supplier/getHospitalGraphOne: %o');
            try {
                const hospitalServiceInstance = Container.get(HospitalSupplierService);
                const { data } = await hospitalServiceInstance.getHospitalGraphOne(req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.get('/getLastPieGraphForHospital',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Hospital'),
        middlewares.requiredProduct('supplierFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('supplier/getLastPieGraphForHospital: %o');
            try {
                const hospitalServiceInstance = Container.get(HospitalSupplierService);
                const { data } = await hospitalServiceInstance.getLastPieGraphForHospital(req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.get('/getSecondPieGraphForHospital',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Hospital'),
        middlewares.requiredProduct('supplierFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('supplier/getSecondPieGraphForHospital: %o');
            try {
                const hospitalServiceInstance = Container.get(HospitalSupplierService);
                const { data } = await hospitalServiceInstance.getSecondPieGraphForHospital(req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.get('/getLApprovedInvoiceGraphToHospital',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Hospital'),
        middlewares.requiredProduct('supplierFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('supplier/getLApprovedInvoiceGraphToHospital: %o');
            try {
                const hospitalServiceInstance = Container.get(HospitalSupplierService);
                const { data } = await hospitalServiceInstance.getLApprovedInvoiceGraphToHospital(req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.get('/getHApprovedVendorToHospital',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Hospital'),
        middlewares.requiredProduct('supplierFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('supplier/getHApprovedVendorToHospital: %o');
            try {
                const hospitalServiceInstance = Container.get(HospitalSupplierService);
                const { data } = await hospitalServiceInstance.getHApprovedVendorToHospital(req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.get('/getHApprovedToHospital',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Hospital'),
        middlewares.requiredProduct('supplierFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('supplier/getHApprovedToHospital: %o');
            try {
                const hospitalServiceInstance = Container.get(HospitalSupplierService);
                const { data } = await hospitalServiceInstance.getHApprovedToHospital(req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );

    //invoices
    route.get('/getInvoicesToHospital',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Hospital'),
        middlewares.requiredProduct('supplierFinancing'),
        celebrate({
            query: {
                pageNumber: Joi.number().positive(),
                pageSize: Joi.number().positive(),
                filters: Joi.array(),
                Status: Joi.string(),
                searchTerm: Joi.string()
            },
        }),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('supplier/getInvoicesToHospital: %o', req.query);
            try {
                const hospitalServiceInstance = Container.get(HospitalSupplierService);
                const { data } = await hospitalServiceInstance.getInvoicesToHospital(
                    req.query as unknown as IFilterDTO,
                    req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.put('/deleteInvoicesToHospital',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Hospital'),
        middlewares.requiredProduct('supplierFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('supplier/deleteInvoicesToHospital: %o', req.query);
            try {
                const adminServiceInstance = Container.get(HospitalSupplierService);
                const { data } = await adminServiceInstance.deleteInvoicesToHospital(
                    req.currentUser as unknown as IUser,
                    req.query as unknown as IFilterDTO
                );
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.get('/getInvoiceByIdToHospital',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Hospital'),
        middlewares.requiredProduct('supplierFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('supplier/getInvoiceByIdToHospital: %o', req.query);
            try {
                const hospitalServiceInstance = Container.get(HospitalSupplierService);
                const { data } = await hospitalServiceInstance.getInvoiceByIdToHospital(req.query as unknown as IFilterDTO);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );

    //profile
    route.get('/getHospitalProfileToHospital',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Hospital'),
        middlewares.requiredProduct('supplierFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('supplier/getHospitalProfileToHospital: %o', req.query);
            try {
                const hospitalServiceInstance = Container.get(HospitalSupplierService);
                const { data } = await hospitalServiceInstance.getHospitalProfileToHospital(req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.put('/EditHospitalProfileByHospital',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Hospital'),
        middlewares.requiredProduct('supplierFinancing'),
        celebrate({
            body: {
                name: Joi.string(),
                address: Joi.array().items(
                    Joi.object().keys({
                        street: Joi.string(),
                        state: Joi.string(),
                        city: Joi.string(),
                        pinCode: Joi.number(),
                        country: Joi.string(),
                    }),
                ),
                HospitalType: Joi.string(),
                mobileNumber: Joi.number(),
                GSTNumber: Joi.string(),
                PANNumber: Joi.string(),
                email: Joi.string(),
                bankName: Joi.string(),
                AccountNumber: Joi.string(),
                IFSCcode: Joi.string(),
                authorisedPersonName: Joi.string(),
                contactDetailsForAuthPerson: Joi.number(),
                PANNumberForAuthPerson: Joi.string(),
                relationShip: Joi.string(),
                Type: Joi.string(),
            }
        }),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('supplier/EditHospitalProfileByHospital: %o', req.body);
            try {
                const hospitalServiceInstance = Container.get(HospitalSupplierService);
                const { data } = await hospitalServiceInstance.EditHospitalProfileByHospital(req.currentUser as IUser, req.body as IHospitalSupplierDTO);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.put('/editSupplierInvoiceByHospital',
        uploadBuffer.fields([{ name: "GRNDocuments" }]),
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Hospital'),
        middlewares.requiredProduct('supplierFinancing'),
        // celebrate({
        //     body: Joi.object({
        //         _id: Joi.string(),
        //         Status: Joi.boolean().allow(null),
        //         HospitalComment: Joi.string().allow(null),
        //         hDueDate: JoiDate.date(),
        //         GRNDate: JoiDate.date(),
        //         GRNNo: Joi.number(),
        //         GRNValue: Joi.number(),
        //         LoanID: Joi.number(),
        //         GRNNotes: Joi.string(),
        //         GRNDocuments: Joi.string()
        //     }),
        // }),
        async (req: Request, res: Response, next: NextFunction) => {
            let files = req['files'] as { [fieldname: string]: Express.Multer.File[] };
            const logger: Logger = Container.get('logger');
            logger.debug('supplier/editSupplierInvoiceByHospital: %o', req.body);
            try {

                if (files.GRNDocuments) {
                    req.body.GRNDocuments = await uploadImage(files.GRNDocuments[0])
                    req.body.GRNDocuments = req.body.GRNDocuments.split('?')[0];
                }

                const hospitalServiceInstance = Container.get(HospitalSupplierService);
                const { data } = await hospitalServiceInstance.editSupplierInvoiceByHospital(
                    req.currentUser as IUser,
                    req.body as ISupplierInvoiceDTO,
                );

                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.put(
        '/postHRepaidToHospital',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Hospital'),
        middlewares.requiredProduct('supplierFinancing'),
        celebrate({
            body: Joi.object({
                _id: Joi.string(),
                AmountReceived: Joi.number(),
                ReceivedNEFT_RTG: Joi.number(),
                PaymentReceivedDate: JoiDate.date()
            }),
        }),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('supplier/postHRepaidToHospital: %o', req.body);
            try {
                const hospitalServiceInstance = Container.get(HospitalSupplierService);
                const { data } = await hospitalServiceInstance.postHRepaidToHospital(
                    req.currentUser as IUser,
                    req.body as ISupplierInvoiceDTO,
                );
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.get(
        '/getAllVendorToHospital',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Hospital'),
        middlewares.requiredProduct('supplierFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('supplier/getAllVendorToHospital: %o', req.query);
            try {
                const HospitalSupplierServiceInstance = Container.get(HospitalSupplierService);
                const { data } = await HospitalSupplierServiceInstance.getAllVendorToHospital(req);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        }
    );
    route.post(
        '/postVendorLimit',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Hospital'),
        middlewares.requiredProduct('supplierFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('supplier/postVendorLimit: %o', req.body);
            try {
                const HospitalSupplierServiceInstance = Container.get(HospitalSupplierService);
                const { data } = await HospitalSupplierServiceInstance.postVendorLimit(req);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        }
    );
    route.post('/repaymentByHospital',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Hospital'),
        middlewares.requiredProduct('supplierFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('supplier/repaymentByHospital: %o', req.body);
            try {
                const HospitalSupplierServiceInstance = Container.get(HospitalSupplierService);
                const { data } = await HospitalSupplierServiceInstance.repaymentByHospital(
                    req.currentUser as IUser,
                    req.body as ISupplierInvoiceDTO);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        }
    );
    route.use(errors());
}