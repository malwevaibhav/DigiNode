import { Router, Request, Response, NextFunction } from 'express';
import { Container } from 'typedi';
import { Logger, loggers } from 'winston';
import { celebrate, errors, Joi } from 'celebrate';
import { IUser, IUserInputDTO, IFilterDTO } from '../../interfaces/IUser';

import DateExtension from '@joi/date';
const JoiDate = Joi.extend(DateExtension);
import lenderService from '../../services/lenderService';
import middlewares from '../middlewares';

const route = Router();

export default (app: Router) => {
    app.use('/lender', route);
    route.get('/getDashboardForLender',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Lender'),
        middlewares.requiredProduct('claimFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('claim/getDashboardForLender: %o', req.query);
            try {
                const lenderServiceInstance = Container.get(lenderService);
                const { data } = await lenderServiceInstance.getDashboardForLender(req, res, req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.get('/getDashboardData',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Lender'),
        middlewares.requiredProduct('claimFinancing'),
        celebrate({
            query: {
                dateFrom: JoiDate.date().allow(null),
                dateTo: JoiDate.date().allow(null),
            },
        }),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('claim/Lender getDashboardData: %o', req.query);
            try {
                const lenderServiceInstance = Container.get(lenderService);

                const { data } = await lenderServiceInstance.getDashboardData(req, res, req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.get('/getInvoiceGraphToLender',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Lender'),
        middlewares.requiredProduct('claimFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('claim/getInvoiceGraphToLender: %o', req.query);
            try {
                const lenderServiceInstance = Container.get(lenderService);
                const { data } = await lenderServiceInstance.getInvoiceGraphToLender(req, res, req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.get('/getLenderGraphAmount',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Lender'),
        middlewares.requiredProduct('claimFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('claim/getLenderGraphAmount: %o', req.query);
            try {
                const lenderServiceInstance = Container.get(lenderService);
                const { data } = await lenderServiceInstance.getLenderGraphAmount(req, res, req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.get('/getLenderGraphOne',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Lender'),
        middlewares.requiredProduct('claimFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('claim/getLenderGraphOne: %o', req.query);
            try {
                const lenderServiceInstance = Container.get(lenderService);
                const { data } = await lenderServiceInstance.getLenderGraphOne(req, res, req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.get('/getSecondPieGraphForLender',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Lender'),
        middlewares.requiredProduct('claimFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('claim/getSecondPieGraphForLender: %o', req.query);
            try {
                const lenderServiceInstance = Container.get(lenderService);
                const { data } = await lenderServiceInstance.getSecondPieGraphForLender(req, res, req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.get('/getAllInvoicesToLender',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Lender'),
        middlewares.requiredProduct('claimFinancing'),
        celebrate({
            query: {
                pageNumber: Joi.number().positive(),
                pageSize: Joi.number().positive(),
                filters: Joi.array(),
                Status: Joi.string(),
                searchTerm: Joi.string()
            },
        }),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('claim/getAllInvoicesToLender: %o', req.query);
            try {
                const lenderServiceInstance = Container.get(lenderService);
                const { data } = await lenderServiceInstance.getAllInvoicesToLender(
                    req.query as unknown as IFilterDTO,
                    req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.put(
        '/deleteAllInvoicesToLender',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Lender'),
        middlewares.requiredProduct('claimFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
          const logger: Logger = Container.get('logger');
          logger.debug('claim/deleteAllInvoicesToLender: %o', req.query);
          try {
            const adminServiceInstance = Container.get(lenderService);
            const { data } = await adminServiceInstance.deleteAllInvoicesToLender(
              req.currentUser as unknown as IUser,
              req.query as unknown as IFilterDTO
              );
            return res.status(201).json({ data });
          } catch (e) {
            logger.error('🔥 error: %o', e);
            return next(e);
          }
        },
      );
    route.get('/getInvoiceByIdToLender',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Lender'),
        middlewares.requiredProduct('claimFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('claim/getInvoiceByIdToLender: %o', req.query);
            try {
                const lenderServiceInstance = Container.get(lenderService);
                const { data } = await lenderServiceInstance.getInvoiceByIdToLender(req, req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.get('/getHospitalToLender',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Lender'),
        middlewares.requiredProduct('claimFinancing'),
        celebrate({
            query: {
                pageNumber: Joi.number().positive().allow(null),
                pageSize: Joi.number().positive().allow(null),
                filters: Joi.array().allow(null),
            },
        }),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('claim/claim/getHospitalToLender: %o', req.query);
            try {
                const lenderServiceInstance = Container.get(lenderService);
                const { data } = await lenderServiceInstance.getHospitalToLender(
                    req.query as unknown as IFilterDTO,
                    req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.get('/getHospitalByIdToLender',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Lender'),
        middlewares.requiredProduct('claimFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('claim/claim/getHospitalByIdToLender: %o', req.query);
            try {
                const lenderServiceInstance = Container.get(lenderService);
                const { data } = await lenderServiceInstance.getHospitalByIdToLender(req, req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.get('/getByIdToLender',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Lender'),
        middlewares.requiredProduct('claimFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('claim/claim/getByIdToLender: %o', req.query);
            try {
                const lenderServiceInstance = Container.get(lenderService);
                const { data } = await lenderServiceInstance.getByIdToLender(req, req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.put('/editLenderProfile',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Lender'),
        middlewares.requiredProduct('claimFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('claim/claim/editLenderProfile: %o', req.query);
            try {
                const lenderServiceInstance = Container.get(lenderService);
                const { data } = await lenderServiceInstance.editLenderProfile(req, req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.put('/updatePassword',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Lender'),
        middlewares.requiredProduct('claimFinancing'),
        celebrate({
            body: Joi.object({
                password: Joi.string().required(),
            }),
        }),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('claim/get updatePassword: %o', req.body, req.query);
            try {
                const lenderServiceInstance = Container.get(lenderService);
                const { data } = await lenderServiceInstance.updatePassword(req, req.body as IUserInputDTO, req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        }
    );
    route.get('/getTransactionDataforLender',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Lender'),
        middlewares.requiredProduct('claimFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('claim/getTransactionDataforLender: %o', req.query);
            try {
                const lenderServiceInstance = Container.get(lenderService);
                const { data } = await lenderServiceInstance.getTransactionDataforLender(req, req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.put('/postCreditLimitFromLender',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Lender'),
        middlewares.requiredProduct('claimFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('claim/claim/postCreditLimitFromLender: %o', req.body, req.query);
            try {
                const lenderServiceInstance = Container.get(lenderService);
                const { data } = await lenderServiceInstance.postCreditLimitFromLender(req, req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        }
    );
    route.post('/calculateInterestfromLender',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Lender'),
        middlewares.requiredProduct('claimFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('claim/get calculateInterestfromLender: %o', req.body, req.query);
            try {
                const lenderServiceInstance = Container.get(lenderService);
                const { data } = await lenderServiceInstance.calculateInterestfromLender(req, req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        }
    );
    route.put('/postFromLender',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Lender'),
        middlewares.requiredProduct('claimFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('claim/get postFromLender: %o', req.body, req.query);
            try {
                const lenderServiceInstance = Container.get(lenderService);
                const { data } = await lenderServiceInstance.postFromLender(req, req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        }
    );
    route.put('/postRejectedFromLender',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Lender'),
        middlewares.requiredProduct('claimFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('claim/get postRejectedFromLender: %o', req.body, req.query);
            try {
                const lenderServiceInstance = Container.get(lenderService);
                const { data } = await lenderServiceInstance.postRejectedFromLender(req, req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        }
    );
    route.put('/fundedFromLenderDisbursed',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Lender'),
        middlewares.requiredProduct('claimFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('claim/get fundedFromLenderDisbursed: %o', req.body, req.query);
            try {
                const lenderServiceInstance = Container.get(lenderService);
                const { data } = await lenderServiceInstance.fundedFromLenderDisbursed(req, req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        }
    );
    route.put('/postRepaidFromLender',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Lender'),
        middlewares.requiredProduct('claimFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('claim/get postRepaidFromLender: %o', req.body, req.query);
            try {
                const lenderServiceInstance = Container.get(lenderService);
                const { data } = await lenderServiceInstance.postRepaidFromLender(req, req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        }
    );
    route.put('/repaymentConfirmation',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Lender'),
        middlewares.requiredProduct('claimFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('claim/get repaymentConfirmation: %o', req.body, req.query);
            try {
                const lenderServiceInstance = Container.get(lenderService);
                const { data } = await lenderServiceInstance.repaymentConfirmation(req, req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        }
    );
    route.post('/repaymentByLender',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Lender'),
        middlewares.requiredProduct('claimFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('claim/get repaymentByLender: %o', req.body, req.query);
            try {
                const lenderServiceInstance = Container.get(lenderService);
                const { data } = await lenderServiceInstance.repaymentByLender(req);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        }
    );

    
}