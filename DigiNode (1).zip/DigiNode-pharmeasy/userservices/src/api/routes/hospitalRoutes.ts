import { Router, Request, Response, NextFunction, response } from 'express';
import { Container } from 'typedi';
import { Logger, loggers } from 'winston';
import { celebrate, errors, Joi } from 'celebrate';
import { IFilterDTO, IOrgInputDTO, IUser, IUserInputDTO } from '../../interfaces/IUser';

import DateExtension from '@joi/date';
const JoiDate = Joi.extend(DateExtension);
import hospitalService from '../../services/hospitalService';
import middlewares from '../middlewares';

import util from 'util'
// const util = require('util')
const gc = require('../GCP/gcp')
const bucket = gc.bucket('digisparsh_images')

var multer = require('multer');
var path = require('path')


const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'upload/')
    },
    filename: function (req, file, cb) {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9)
        cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname))
    }
})

const storage_V2 = multer.memoryStorage()
const uploadBuffer = multer({
    storage: storage_V2,
    limits: { fieldSize: 10 * 1024 * 1024 },
},

)

const uploadImage = (file) => new Promise((resolve, reject) => {
    const { originalname, buffer } = file
    const date1 = Date.now().toString()

    const blob = bucket.file(originalname.replace(/ /g, "_"))
    const blobStream = blob.createWriteStream({
        resumable: false
    })
    let tempName = blob.name.split('.')
    if (tempName && tempName?.length) {

        blob.name = tempName[0] + date1 + '.' + tempName[tempName?.length - 1]
    }

    var blobb = blobStream.on('finish', () => {
        const publicUrl = util.format(
            `https://storage.googleapis.com/${bucket.name}/${blob.name}`
        )
        console.log(publicUrl)
        resolve(publicUrl);
    })
        .on('error', (err) => {
            reject(`Unable to upload image, something went wrong=>${err}`)
        })
        .end(buffer);
    return blobb;
})


const route = Router();

export default (app: Router) => {
    app.use('/hospital', route);
    route.get('/getDashboardForHospital',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Hospital'),
        middlewares.requiredProduct('claimFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('claim/getDashboardForHospital: %o', req.query);
            try {
                const hospitalServiceInstance = Container.get(hospitalService);
                const { data } = await hospitalServiceInstance.getDashboardForHospital(req, res, req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.get('/getDashboardData',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Hospital'),
        middlewares.requiredProduct('claimFinancing'),
        celebrate({
            query: {
                dateFrom: JoiDate.date().allow(null),
                dateTo: JoiDate.date().allow(null),
            },
        }),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('claim/Hospital getDashboardData: %o', req.query);
            try {
                const hospitalServiceInstance = Container.get(hospitalService);

                const { data } = await hospitalServiceInstance.getDashboardData(req, res, req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.get('/getInvoiceGraphToHospital',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Hospital'),
        middlewares.requiredProduct('claimFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('claim/getInvoiceGraphToHospital: %o', req.query);
            try {
                const hospitalServiceInstance = Container.get(hospitalService);
                const { data } = await hospitalServiceInstance.getInvoiceGraphToHospital(req, res, req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.get('/getHospitalGraphAmount',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Hospital'),
        middlewares.requiredProduct('claimFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('claim/getHospitalGraphAmount: %o', req.query);
            try {
                const hospitalServiceInstance = Container.get(hospitalService);
                const { data } = await hospitalServiceInstance.getHospitalGraphAmount(req, res, req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.get('/getHospitalGraphOne',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Hospital'),
        middlewares.requiredProduct('claimFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('claim/getHospitalGraphOne: %o', req.query);
            try {
                const hospitalServiceInstance = Container.get(hospitalService);
                const { data } = await hospitalServiceInstance.getHospitalGraphOne(req, res, req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.get('/getSecondPieGraphForHospital',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Hospital'),
        middlewares.requiredProduct('claimFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('claim/getSecondPieGraphForHospital: %o', req.query);
            try {
                const hospitalServiceInstance = Container.get(hospitalService);
                const { data } = await hospitalServiceInstance.getSecondPieGraphForHospital(req, res, req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.get('/getFundedInvoiceToHospital',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Hospital'),
        middlewares.requiredProduct('claimFinancing'),
        celebrate({
            query: {
                pageNumber: Joi.number().positive().allow(null),
                pageSize: Joi.number().positive().allow(null),
                filters: Joi.array().allow(null),
            },
        }),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('claim/getFundedInvoiceToHospital: %o', req.query);
            try {
                const hospitalServiceInstance = Container.get(hospitalService);
                const { data } = await hospitalServiceInstance.getFundedInvoiceToHospital(
                    req.query as unknown as IFilterDTO,
                    req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.post('/buildupdatetorepaument',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Hospital'),
        middlewares.requiredProduct('claimFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('claim/buildupdatetorepaument: %o', req.body);
            try {
                const hospitalServiceInstance = Container.get(hospitalService);
                const { data } = await hospitalServiceInstance.bulkUpdateRepayment(req, res, req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.get('/getByIdToHospital',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Hospital'),
        middlewares.requiredProduct('claimFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('claim/getByIdToHospital: %o', req.query);
            try {
                const hospitalServiceInstance = Container.get(hospitalService);
                const { data } = await hospitalServiceInstance.getByIdToHospital(req, res, req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.put('/editHospitalPersonalInfo',
        uploadBuffer.fields([
            { name: "GSTUrl" },
            { name: "AddressDocUrl" },
            { name: "FinancialStUrl" },
            { name: "NOCextUrl" },
            { name: "TwoYearBankStUrl" },
            { name: "TwoyearTTRUrl" },
            { name: "otherUrl" },
            { name: "ParriPassuUrl" },]),
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Hospital'),
        middlewares.requiredProduct('claimFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            let files = req['files'] as { [fieldname: string]: Express.Multer.File[] };
            const logger: Logger = Container.get('logger');
            logger.debug('claim/editHospitalPersonalInfo: %o', req.body);
            try {

                if (files?.GSTUrl) {
                    req.body.GSTUrl = await uploadImage(files.GSTUrl[0])
                    req.body.GSTUrl = req.body.GSTUrl.split('?')[0];
                }
                if (files?.AddressDocUrl) {
                    req.body.AddressDocUrl = await uploadImage(files.AddressDocUrl[0])
                    req.body.AddressDocUrl = req.body.AddressDocUrl.split('?')[0];
                }
                if (files?.FinancialStUrl) {
                    req.body.FinancialStUrl = await uploadImage(files.FinancialStUrl[0])
                    req.body.FinancialStUrl = req.body.FinancialStUrl.split('?')[0];
                }
                if (files?.NOCextUrl) {
                    req.body.NOCextUrl = await uploadImage(files.NOCextUrl[0])
                    req.body.NOCextUrl = req.body.NOCextUrl.split('?')[0];
                }
                if (files?.TwoYearBankStUrl) {
                    req.body.TwoYearBankStUrl = await uploadImage(files.TwoYearBankStUrl[0])
                    req.body.TwoYearBankStUrl = req.body.TwoYearBankStUrl.split('?')[0];
                }
                if (files?.TwoyearTTRUrl) {
                    req.body.TwoyearTTRUrl = await uploadImage(files.TwoyearTTRUrl[0])
                    req.body.TwoyearTTRUrl = req.body.TwoyearTTRUrl.split('?')[0];
                }
                if (files?.otherUrl) {
                    req.body.otherUrl = await uploadImage(files.otherUrl[0])
                    req.body.otherUrl = req.body.otherUrl.split('?')[0];
                }
                if (files?.ParriPassuUrl) {
                    req.body.ParriPassuUrl = await uploadImage(files.ParriPassuUrl[0])
                    req.body.ParriPassuUrl = req.body.ParriPassuUrl.split('?')[0];
                }


                const hospitalServiceInstance = Container.get(hospitalService);
                const { data } = await hospitalServiceInstance.editHospitalPersonalInfo(req.body as IOrgInputDTO, req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.get('/getAllInvoicesToHospital',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Hospital'),
        middlewares.requiredProduct('claimFinancing'),
        celebrate({
            query: {
                pageNumber: Joi.number().positive(),
                pageSize: Joi.number().positive(),
                filters: Joi.array(),
                Status: Joi.string(),
                searchTerm: Joi.string()
            },
        }),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('claim/getAllInvoicesToHospital: %o', req.query);
            try {
                const hospitalServiceInstance = Container.get(hospitalService);
                const { data } = await hospitalServiceInstance.getAllInvoicesToHospital(
                    req.query as unknown as IFilterDTO,
                    req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.get('/getInvoiceByIdToHospital',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Hospital'),
        middlewares.requiredProduct('claimFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('claim/claim/getInvoiceByIdToHospital: %o', req.body);
            try {
                const hospitalServiceInstance = Container.get(hospitalService);
                const { data } = await hospitalServiceInstance.getInvoiceByIdToHospital(req, res, req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.put('/deleteAllInvoicesToHospital',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Hospital'),
        middlewares.requiredProduct('claimFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('claim/deleteAllInvoicesToHospital: %o', req.query);
            try {
                const adminServiceInstance = Container.get(hospitalService);
                const { data } = await adminServiceInstance.deleteAllInvoicesToHospital(
                    req.currentUser as unknown as IUser,
                    req.query as unknown as IFilterDTO
                );
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );

    route.put('/updatePassword',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Hospital'),
        middlewares.requiredProduct('claimFinancing'),
        celebrate({
            body: Joi.object({
                password: Joi.string().required(),
            }),
        }),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('claim/get updatePassword: %o', req.body, req.query);
            try {
                const hospitalServiceInstance = Container.get(hospitalService);
                const { data } = await hospitalServiceInstance.updatePassword(req, req.body as IUserInputDTO, req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        }
    );
    // get TPA with Insurer
    route.get('/getTPAwithInsurer',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Hospital'),
        middlewares.requiredProduct('claimFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('claim/TPA with Insurer : %o', req.body);
            try {
                const hospitalServiceInstance = Container.get(hospitalService);
                const { data } = await hospitalServiceInstance.getTPAwithInsurer(req);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        });
    // get Insurance
    route.get('/getInsurance',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Hospital'),
        middlewares.requiredProduct('claimFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('claim/get insurance : %o', req.body);
            try {
                const hospitalServiceInstance = Container.get(hospitalService);
                const { data } = await hospitalServiceInstance.getInsurance(req);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        });
    // route.post('/invoiceUpload',
    //     uploadBuffer.fields([
    //         { name: 'insuranceApprovalLetter' },
    //         { name: 'invoiceDocumentUrl' },
    //         { name: "otherDocsUrl" }
    //     ]),
    //     middlewares.isAuth,
    //     middlewares.attachCurrentUser,
    //     middlewares.requiredOrg('Hospital'),
    //     middlewares.requiredProduct('claimFinancing'),
    //     async (req: Request, res: Response, next: NextFunction) => {
    //         let files = req['files'] as { [fieldname: string]: Express.Multer.File[] };
    //         const logger: Logger = Container.get('logger');
    //         logger.debug('claim/invoiceUpload: %o', req.body);
    //         try {

    //             if (files.insuranceApprovalLetter) {
    //                 req.body.insuranceApprovalLetter = await uploadImage(files.insuranceApprovalLetter[0])
    //                 req.body.insuranceApprovalLetter = req.body.insuranceApprovalLetter.split('?')[0];
    //             }
    //             if (files.invoiceDocumentUrl) {
    //                 req.body.invoiceDocumentUrl = await uploadImage(files.invoiceDocumentUrl[0])
    //                 req.body.invoiceDocumentUrl = req.body.invoiceDocumentUrl.split('?')[0];
    //             }
    //             if (files.otherDocsUrl.length <= 5) {
    //                 for await (const iterator of files.otherDocsUrl) {
    //                     req.body.otherDocsUrl = await uploadImage(iterator)
    //                     req.body.otherDocsUrl = req.body.otherDocsUrl.split('?')[0];
    //                     // console.log(iterator);

    //                 }

    //             }

    //             const hospitalServiceInstance = Container.get(hospitalService);
    //             const { data } = await hospitalServiceInstance.invoiceUpload(req, res, req.currentUser as IUser);
    //             return res.status(201).json({ data });
    //         } catch (e) {
    //             logger.error('🔥 error: %o', e);
    //             return next(e);
    //         }
    //     },
    // );

    route.post('/invoiceUpload',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Hospital'),
        middlewares.requiredProduct('claimFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('claim/invoiceUpload: %o', req.body);
            try {
                const hospitalServiceInstance = Container.get(hospitalService);
                const { data } = await hospitalServiceInstance.invoiceUpload(req, res, req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );

    route.post('/insuranceApprovalLetter',
        uploadBuffer.fields([{ name: "insuranceApprovalLetter" }]),
        async (req: Request, res: Response, next: NextFunction) => {
            let { insuranceApprovalLetter } = req.body;
            let files = req['files'] as { [fieldname: string]: Express.Multer.File[] };
            const logger: Logger = Container.get('logger');
            logger.debug('claim/invoiceUpload: %o', req.body);


            if (files.insuranceApprovalLetter) {
                insuranceApprovalLetter = await uploadImage(files.insuranceApprovalLetter[0]);
                console.log("HERE - ", insuranceApprovalLetter);

                // insuranceApprovalLetter = insuranceApprovalLetter.split('?')[0];
            }
            return res.status(200).json({
                status: true,
                data: insuranceApprovalLetter
            });

        })

    route.post('/invoiceDocumentUrl',
        uploadBuffer.fields([{ name: "invoiceDocumentUrl" }]),
        async (req: Request, res: Response, next: NextFunction) => {
            let { invoiceDocumentUrl } = req.body;
            let files = req['files'] as { [fieldname: string]: Express.Multer.File[] };
            const logger: Logger = Container.get('logger');
            logger.debug('claim/invoiceUpload: %o', req.body);


            if (files.invoiceDocumentUrl) {
                invoiceDocumentUrl = await uploadImage(files.invoiceDocumentUrl[0]);
                console.log("HERE - ", invoiceDocumentUrl);

                // insuranceApprovalLetter = insuranceApprovalLetter.split('?')[0];
            }
            return res.status(200).json({
                status: true,
                data: invoiceDocumentUrl
            });

        })

    route.post('/otherDocsUrl',
        uploadBuffer.fields([{ name: "otherDocsUrl" }]),
        async (req: Request, res: Response, next: NextFunction) => {
            let { otherDocsUrl } = req.body;
            let files = req['files'] as { [fieldname: string]: Express.Multer.File[] };
            const logger: Logger = Container.get('logger');
            logger.debug('claim/invoiceUpload: %o', req.body);


            const jai = []
            if (files.otherDocsUrl.length <= 5) {
                for await (const iterator of files.otherDocsUrl) {
                    let hh = await uploadImage(iterator)
                    jai.push(hh)
                    // console.log(iterator);
                }
            }

            return res.status(200).json({
                status: true,
                data: jai
            });

        })


    route.post('/repaymentByHospital',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Hospital'),
        middlewares.requiredProduct('claimFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('claim/repaymentByHospital : %o', req.body);
            try {
                const hospitalServiceInstance = Container.get(hospitalService);
                const { data } = await hospitalServiceInstance.repaymentByHospital(req);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        });

    route.use(errors());
}