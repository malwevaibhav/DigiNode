import { Router, Request, Response, NextFunction } from 'express';
import { Container } from 'typedi';
import { Logger, loggers } from 'winston';
import { celebrate, errors, Joi } from 'celebrate';
import { IUser, IUserInputDTO, IFilterDTO } from '../../interfaces/IUser';

import DateExtension from '@joi/date';
const JoiDate = Joi.extend(DateExtension);

import middlewares from '../middlewares';
import pharmacyLenderService from '../../services/pharmacyLenderService';
const route = Router();

export default (app: Router) => {
    app.use('/PFLender', route);
    route.get('/getDashboardForSupplierLender',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Lender'),
        middlewares.requiredProduct('purchaseFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('purchaseFinancing/getDashboardForLender: %o', req.query);
            try {
                const lenderServiceInstance = Container.get(pharmacyLenderService);
                const { data } = await lenderServiceInstance.getDashboardForSupplierLender(req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.get('/getDashboardData',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Lender'),
        middlewares.requiredProduct('purchaseFinancing'),
        celebrate({
            query: {
                dateFrom: JoiDate.date().allow(null),
                dateTo: JoiDate.date().allow(null),
            },
        }),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('purchaseFinancing/Supplier Lender getDashboardData: %o', req.query);
            try {
                const supplierLenderServiceInstance = Container.get(pharmacyLenderService);

                const { data } = await supplierLenderServiceInstance.getDashboardData(req, res, req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );

    route.get('/getFundedInvoiceGraphToSupplierLender',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Lender'),
        middlewares.requiredProduct('purchaseFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('purchaseFinancing/getDashboardForLender: %o', req.query);
            try {
                const lenderServiceInstance = Container.get(pharmacyLenderService);
                const { data } = await lenderServiceInstance.getFundedInvoiceGraphToSupplierLender(req.currentUser as IUser);
                return res.status(200).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.get('/getLApprovedInvoiceGraphToLender',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Lender'),
        middlewares.requiredProduct('purchaseFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('purchaseFinancing/getDashboardForLender: %o', req.query);
            try {
                const lenderServiceInstance = Container.get(pharmacyLenderService);
                const { data } = await lenderServiceInstance.getLApprovedInvoiceGraphToLender(req.currentUser as IUser);
                return res.status(200).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.get('/getInvoiceGraphToLender',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Lender'),
        middlewares.requiredProduct('purchaseFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('purchaseFinancing/getDashboardForLender: %o', req.query);
            try {
                const lenderServiceInstance = Container.get(pharmacyLenderService);
                const { data } = await lenderServiceInstance.getInvoiceGraphToLender(req.currentUser as IUser);
                return res.status(200).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.get('/getLenderGraphOne',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Lender'),
        middlewares.requiredProduct('purchaseFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('purchaseFinancing/getLenderGraphOne: %o', req.query);
            try {
                const lenderServiceInstance = Container.get(pharmacyLenderService);
                const { data } = await lenderServiceInstance.getLenderGraphOne(req.currentUser as IUser);
                return res.status(200).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.get('/getLastPieGraphForLender',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Lender'),
        middlewares.requiredProduct('purchaseFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('purchaseFinancing/getLenderGraphOne: %o', req.query);
            try {
                const lenderServiceInstance = Container.get(pharmacyLenderService);
                const { data } = await lenderServiceInstance.getLastPieGraphForLender(req.currentUser as IUser);
                return res.status(200).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.get('/getSecondPieGraphForLender',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Lender'),
        middlewares.requiredProduct('purchaseFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('purchaseFinancing/getLenderGraphOne: %o', req.query);
            try {
                const lenderServiceInstance = Container.get(pharmacyLenderService);
                const { data } = await lenderServiceInstance.getSecondPieGraphForLender(req.currentUser as IUser);
                return res.status(200).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.get('/getAllInvoicesToLender',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Lender'),
        middlewares.requiredProduct('purchaseFinancing'),
        celebrate({
            query: {
                pageNumber: Joi.number().positive(),
                pageSize: Joi.number().positive(),
                filters: Joi.array(),
                Status: Joi.string(),
                searchTerm: Joi.string()
            },
        }),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('purchaseFinancing/getAllInvoicesToLender: %o', req.query);
            try {
                const lenderServiceInstance = Container.get(pharmacyLenderService);
                const { data } = await lenderServiceInstance.getAllInvoicesToLender(
                    req.query as unknown as IFilterDTO,
                    req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.put(
        '/deleteAllInvoicesToLender',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Lender'),
        middlewares.requiredProduct('purchaseFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('purchaseFinancing/deleteAllInvoicesToLender: %o', req.query);
            try {
                const adminServiceInstance = Container.get(pharmacyLenderService);
                const { data } = await adminServiceInstance.deleteAllInvoicesToLender(
                    req.currentUser as unknown as IUser,
                    req.query as unknown as IFilterDTO
                );
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.get('/getInvoiceByIdToLender',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Lender'),
        middlewares.requiredProduct('purchaseFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('purchaseFinancing/getInvoiceByIdToLender: %o', req.query);
            try {
                const lenderServiceInstance = Container.get(pharmacyLenderService);
                const { data } = await lenderServiceInstance.getInvoiceByIdToLender(req, req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.get('/getHospitalToLender',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Lender'),
        middlewares.requiredProduct('purchaseFinancing'),
        celebrate({
            query: {
                pageNumber: Joi.number().positive().allow(null),
                pageSize: Joi.number().positive().allow(null),
                filters: Joi.array().allow(null),
            },
        }),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('purchaseFinancing/purchaseFinancing/getHospitalToLender: %o', req.query);
            try {
                const lenderServiceInstance = Container.get(pharmacyLenderService);
                const { data } = await lenderServiceInstance.getHospitalToLender(
                    req.query as unknown as IFilterDTO,
                    req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.get('/getHospitalByIdToLender',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Lender'),
        middlewares.requiredProduct('purchaseFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('purchaseFinancing/purchaseFinancing/getHospitalByIdToLender: %o', req.query);
            try {
                const lenderServiceInstance = Container.get(pharmacyLenderService);
                const { data } = await lenderServiceInstance.getHospitalByIdToLender(req, req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
        route.put('/postCreditLimitFromLender',
            middlewares.isAuth,
            middlewares.attachCurrentUser,
            middlewares.requiredOrg('Lender'),
            middlewares.requiredProduct('purchaseFinancing'),
            async (req: Request, res: Response, next: NextFunction) => {
                const logger: Logger = Container.get('logger');
                logger.debug('purchaseFinancing/purchaseFinancing/postCreditLimitFromLender: %o', req.body, req.query);
                try {
                    const lenderServiceInstance = Container.get(pharmacyLenderService);
                    const { data } = await lenderServiceInstance.postCreditLimitFromLender(req, req.currentUser as IUser);
                    return res.status(201).json({ data });
                } catch (e) {
                    logger.error('🔥 error: %o', e);
                    return next(e);
                }
            }
        )
    );
    route.get('/getByIdToLender',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Lender'),
        middlewares.requiredProduct('purchaseFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('purchaseFinancing/purchaseFinancing/getByIdToLender: %o', req.query);
            try {
                const lenderServiceInstance = Container.get(pharmacyLenderService);
                const { data } = await lenderServiceInstance.getByIdToLender(req, req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );

    route.put('/editLenderProfile',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Lender'),
        middlewares.requiredProduct('purchaseFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('purchaseFinancing/purchaseFinancing/editLenderProfile: %o', req.query);
            try {
                const lenderServiceInstance = Container.get(pharmacyLenderService);
                const { data } = await lenderServiceInstance.editLenderProfile(req, req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.put('/updatePassword',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Lender'),
        middlewares.requiredProduct('purchaseFinancing'),
        celebrate({
            body: Joi.object({
                password: Joi.string().required(),
            }),
        }),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('purchaseFinancing/get updatePassword: %o', req.body, req.query);
            try {
                const lenderServiceInstance = Container.get(pharmacyLenderService);
                const { data } = await lenderServiceInstance.updatePassword(req, req.body as IUserInputDTO, req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        }
    );
    route.post('/postLApprovedToLender',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Lender'),
        middlewares.requiredProduct('purchaseFinancing'),
        celebrate({
            body: Joi.object({
                _id: Joi.string().required(),
                LenderComment: Joi.string().allow("", null),
            }),
        }),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('purchaseFinancing/postLApprovedToLender: %o', req.body, req.query);
            try {
                const body = {
                    _id: req.body._id,
                    LenderComment: req.body.LenderComment,
                }
                const lenderServiceInstance = Container.get(pharmacyLenderService);
                const { data } = await lenderServiceInstance.postLApprovedToLender(body, req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        }
    );
    route.post('/postLRejectedToLender',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Lender'),
        middlewares.requiredProduct('purchaseFinancing'),
        celebrate({
            body: Joi.object({
                _id: Joi.string().required(),
                LenderComment: Joi.string().allow("", null),
            }),
        }),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('purchaseFinancing/get updatePassword: %o', req.body, req.query);
            try {
                const body = {
                    _id: req.body._id,
                    LenderComment: req.body.LenderComment,
                }
                const lenderServiceInstance = Container.get(pharmacyLenderService);
                const { data } = await lenderServiceInstance.postLRejectedToLender(body, req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        }
    );
    route.post('/postFundedToLender',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Lender'),
        middlewares.requiredProduct('purchaseFinancing'),
        // celebrate({
        //     body: Joi.object({
        //         PaymentDate:Joi.string().required(),
        //         InvoiceNumber: Joi.number().required(),
        //         AmountPaid: Joi.number().required(),
        //         NEFT_RTG: Joi.any(),
        //     }),
        //     query:Joi.object({
        //         _id:Joi.string().required(),
        //     })
        // }),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('purchaseFinancing/get updatePassword: %o', req.body, req.query);
            try {

                const userDetails = req.currentUser;
                const body = {
                    _id: req.query._id,
                    PaymentDate: req.body.PaymentDate,
                    InvoiceNumber: req.body.InvoiceNumber,
                    AmountPaid: req.body.AmountPaid,
                    NEFT_RTG: req.body.NEFT_RTG,
                }
                const lenderServiceInstance = Container.get(pharmacyLenderService);
                const { data } = await lenderServiceInstance.postFundedToLender(body, userDetails as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        }
    );
    route.post('/postRepaidToLender',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Lender'),
        middlewares.requiredProduct('purchaseFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('purchaseFinancing/postRepaidToLender: %o', req.body, req.query);
            try {
                const userDetails = req.currentUser;
                const body = {
                    _id: req.body._id,
                    ReceivedNEFT_RTG: req.body.ReceivedNEFT_RTG,
                    PaymentReceivedDate: req.body.PaymentReceivedDate,
                    InvoiceNumber: req.body.InvoiceNumber,
                    AmountReceived: req.body.AmountReceived,
                }
                
                const lenderServiceInstance = Container.get(pharmacyLenderService);
                const { data } = await lenderServiceInstance.postRepaidToLender(body, userDetails as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        }
    );
    route.put('/postPastRecoveryAmountDetailsToLender',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Lender'),
        middlewares.requiredProduct('purchaseFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('purchaseFinancing/postPastRecoveryAmountDetailsToLender: %o', req.body, req.query);
            try {
                const userDetails = req.currentUser;
                const body = {
                    _id: req.query._id,
                    PastRecoveryDetails: req.body.PastRecoveryDetails,
                    PastRecoveryNumber: req.body.PastRecoveryNumber,
                    PastRecovery: req.body.PastRecovery
                }
                const lenderServiceInstance = Container.get(pharmacyLenderService);
                const { data } = await lenderServiceInstance.postPastRecoveryAmountDetailsToLender(body, userDetails as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        }
    );
}