

import { Router, Request, Response, NextFunction } from 'express';
import { Container } from 'typedi';
import { IUser, IFilterDTO, IHospitalSupplierDTO, ISupplierInvoiceDTO,purchaseFinancingDTO } from '../../interfaces/IUser';
import { Logger, loggers } from 'winston';
import { celebrate, errors, Joi } from 'celebrate';
import DateExtension from '@joi/date';
const JoiDate = Joi.extend(DateExtension);
import distributorPharmacyService from '../../services/distributorPharmacyService';
import middlewares from '../middlewares';
// import hospitalService from '@/services/hospitalService';
// import MailJetService from '../../loaders/mailjet';
import util from 'util'
// const util = require('util')
const gc = require('../GCP/gcp')
const bucket = gc.bucket('digisparsh_images')

var multer = require('multer');
var path = require('path')

const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'upload/')
    },
    filename: function (req, file, cb) {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9)
        cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname))
    }
})

const storage_V2 = multer.memoryStorage()
const uploadBuffer = multer({
    storage: storage_V2,
    limits: { fieldSize: 10 * 1024 * 1024 },
},

)

const uploadImage = (file) => new Promise((resolve, reject) => {
    const { originalname, buffer } = file
    const date1 = Date.now().toString()

    const blob = bucket.file(originalname.replace(/ /g, "_"))
    const blobStream = blob.createWriteStream({
        resumable: false
    })
    let tempName = blob.name.split('.')
    if (tempName && tempName?.length) {

        blob.name = tempName[0] + date1 + '.' + tempName[tempName?.length - 1]
    }

    var blobb = blobStream.on('finish', () => {
        const publicUrl = util.format(
            `https://storage.googleapis.com/${bucket.name}/${blob.name}`
        )
        console.log(publicUrl)
        resolve(publicUrl)

    })
        .on('error', (err) => {
            reject(`Unable to upload image, something went wrong=>${err}`)
        })
        .end(buffer)

})

const route = Router();

export default (app: Router) => {
    app.use('/pharmacy', route);
    route.get('/getDashboardForDistributor',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Distributor'),
        middlewares.requiredProduct('purchaseFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('pharmacy/getDashboardForDistributor: %o');
            try {
                const hospitalServiceInstance = Container.get(distributorPharmacyService);
                const { data } = await hospitalServiceInstance.getDashboardForDistributor(req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.get('/getDashboardData',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Distributor'),
        middlewares.requiredProduct('purchaseFinancing'),
        celebrate({
            query: {
                dateFrom: JoiDate.date().allow(null),
                dateTo: JoiDate.date().allow(null),
            },
        }),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('pharmacy/Supplier Distributor getDashboardData: %o', req.query);
            try {
                const HospitalSupplierServiceInstance = Container.get(distributorPharmacyService);

                const { data } = await HospitalSupplierServiceInstance.getDashboardData(req, res, req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.get('/getInvoiceGraphToDistributor',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Distributor'),
        middlewares.requiredProduct('purchaseFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('pharmacy/getInvoiceGraphToDistributor: %o');
            try {
                const hospitalServiceInstance = Container.get(distributorPharmacyService);
                const { data } = await hospitalServiceInstance.getInvoiceGraphToDistributor(req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.get('/getLApprovedVendorToDistributor',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Distributor'),
        middlewares.requiredProduct('purchaseFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('pharmacy/getLApprovedVendorToDistributor: %o');
            try {
                const hospitalServiceInstance = Container.get(distributorPharmacyService);
                const { data } = await hospitalServiceInstance.getLApprovedVendorToDistributor(req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.get('/getFundedInvoiceGraphToDistributor',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Distributor'),
        middlewares.requiredProduct('purchaseFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('pharmacy/getFundedInvoiceGraphToDistributor: %o');
            try {
                const hospitalServiceInstance = Container.get(distributorPharmacyService);
                const { data } = await hospitalServiceInstance.getFundedInvoiceGraphToDistributor(req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.get('/getPendingVendorToDistributor',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Distributor'),
        middlewares.requiredProduct('purchaseFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('pharmacy/getPendingVendorToDistributor: %o');
            try {
                const hospitalServiceInstance = Container.get(distributorPharmacyService);
                const { data } = await hospitalServiceInstance.getPendingVendorToDistributor(req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.get('/getDistributorGraphOne',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Distributor'),
        middlewares.requiredProduct('purchaseFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('pharmacy/getDistributorGraphOne: %o');
            try {
                const hospitalServiceInstance = Container.get(distributorPharmacyService);
                const { data } = await hospitalServiceInstance.getDistributorGraphOne(req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.get('/getLastPieGraphForDistributor',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Distributor'),
        middlewares.requiredProduct('purchaseFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('pharmacy/getLastPieGraphForDistributor: %o');
            try {
                const hospitalServiceInstance = Container.get(distributorPharmacyService);
                const { data } = await hospitalServiceInstance.getHospitalProfileToDistributor(req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.get('/getSecondPieGraphForDistributor',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Distributor'),
        middlewares.requiredProduct('purchaseFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('pharmacy/getSecondPieGraphForDistributor: %o');
            try {
                const hospitalServiceInstance = Container.get(distributorPharmacyService);
                const { data } = await hospitalServiceInstance.getSecondPieGraphForHospital(req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.get('/getLApprovedInvoiceGraphToDistributor',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Distributor'),
        middlewares.requiredProduct('purchaseFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('pharmacy/getLApprovedInvoiceGraphToDistributor: %o');
            try {
                const hospitalServiceInstance = Container.get(distributorPharmacyService);
                const { data } = await hospitalServiceInstance.getLApprovedInvoiceGraphToHospital(req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.get('/getHApprovedVendorToDistributor',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Distributor'),
        middlewares.requiredProduct('purchaseFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('pharmacy/getHApprovedVendorToDistributor: %o');
            try {
                const hospitalServiceInstance = Container.get(distributorPharmacyService);
                const { data } = await hospitalServiceInstance.getHApprovedVendorToHospital(req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.get('/getHApprovedToDistributor',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Distributor'),
        middlewares.requiredProduct('purchaseFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('pharmacy/getHApprovedToDistributor: %o');
            try {
                const hospitalServiceInstance = Container.get(distributorPharmacyService);
                const { data } = await hospitalServiceInstance.getHApprovedToHospital(req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );

    //invoices
    route.get('/getInvoicesToDistributor',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Distributor'),
        middlewares.requiredProduct('purchaseFinancing'),
        celebrate({
            query: {
                pageNumber: Joi.number().positive(),
                pageSize: Joi.number().positive(),
                filters: Joi.array(),
                Status: Joi.string(),
                searchTerm: Joi.string()
            },
        }),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('pharmacy/getInvoicesToDistributor: %o', req.query);
            try {
                const hospitalServiceInstance = Container.get(distributorPharmacyService);
                const { data } = await hospitalServiceInstance.getInvoicesToDistributor(
                    req.query as unknown as IFilterDTO,
                    req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.put('/deleteInvoicesToDistributor',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Distributor'),
        middlewares.requiredProduct('purchaseFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('pharmacy/deleteInvoicesToDistributor: %o', req.query);
            try {
                const adminServiceInstance = Container.get(distributorPharmacyService);
                const { data } = await adminServiceInstance.deleteInvoicesToDistributor(
                    req.currentUser as unknown as IUser,
                    req.query as unknown as IFilterDTO
                );
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    // route.get('/getInvoiceByIdToDistributor',
    //     middlewares.isAuth,
    //     middlewares.attachCurrentUser,
    //     middlewares.requiredOrg('Distributor'),
    //     middlewares.requiredProduct('purchaseFinancing'),
    //     async (req: Request, res: Response, next: NextFunction) => {
    //         const logger: Logger = Container.get('logger');
    //         logger.debug('pharmacy/getInvoiceByIdToDistributor: %o', req.query);
    //         try {
    //             const hospitalServiceInstance = Container.get(distributorPharmacyService);
    //             const { data } = await hospitalServiceInstance.getInvoiceByIdToDistributor(req.query as unknown as IFilterDTO);
    //             return res.status(201).json({ data });
    //         } catch (e) {
    //             logger.error('🔥 error: %o', e);
    //             return next(e);
    //         }
    //     },
    // );

    //profile
    route.get('/getHospitalProfileToDistributor',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Distributor'),
        middlewares.requiredProduct('purchaseFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('pharmacy/getHospitalProfileToDistributor: %o', req.query);
            try {
                const hospitalServiceInstance = Container.get(distributorPharmacyService);
                const { data } = await hospitalServiceInstance.getHospitalProfileToDistributor(req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.put('/EditHospitalProfileByDistributor',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Distributor'),
        middlewares.requiredProduct('purchaseFinancing'),
        celebrate({
            body: {
                name: Joi.string(),
                address: Joi.array().items(
                    Joi.object().keys({
                        street: Joi.string(),
                        state: Joi.string(),
                        city: Joi.string(),
                        pinCode: Joi.number(),
                        country: Joi.string(),
                    }),
                ),
                HospitalType: Joi.string(),
                mobileNumber: Joi.number(),
                GSTNumber: Joi.string(),
                PANNumber: Joi.string(),
                email: Joi.string(),
                bankName: Joi.string(),
                AccountNumber: Joi.string(),
                IFSCcode: Joi.string(),
                authorisedPersonName: Joi.string(),
                contactDetailsForAuthPerson: Joi.number(),
                PANNumberForAuthPerson: Joi.string(),
                relationShip: Joi.string(),
                Type: Joi.string(),
            }
        }),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('pharmacy/EditHospitalProfileByDistributor: %o', req.body);
            try {
                const hospitalServiceInstance = Container.get(distributorPharmacyService);
                const { data } = await hospitalServiceInstance.EditHospitalProfileByDistributor(req.currentUser as IUser, req.body as IHospitalSupplierDTO);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.put('/editPFInvoiceByDistributor',
        uploadBuffer.fields([{ name: "GRNDocuments" }]),
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Distributor'),
        middlewares.requiredProduct('purchaseFinancing'),
        // celebrate({
        //     body: Joi.object({
        //         _id: Joi.string(),
        //         Status: Joi.boolean().allow(null),
        //         HospitalComment: Joi.string().allow(null),
        //         hDueDate: JoiDate.date(),
        //         GRNDate: JoiDate.date(),
        //         GRNNo: Joi.number(),
        //         GRNValue: Joi.number(),
        //         LoanID: Joi.number(),
        //         GRNNotes: Joi.string(),
        //         GRNDocuments: Joi.string()
        //     }),
        // }),
        async (req: Request, res: Response, next: NextFunction) => {
            let files = req['files'] as { [fieldname: string]: Express.Multer.File[] };
            const logger: Logger = Container.get('logger');
            logger.debug('pharmacy/editPFInvoiceByDistributor: %o', req.body);
            try {

                if (files.GRNDocuments) {
                    req.body.GRNDocuments = await uploadImage(files.GRNDocuments[0])
                    req.body.GRNDocuments = req.body.GRNDocuments.split('?')[0];
                }

                const hospitalServiceInstance = Container.get(distributorPharmacyService);
                const { data } = await hospitalServiceInstance.editPFInvoiceByDistributor(
                    req.currentUser as IUser,
                    req.body as purchaseFinancingDTO,
                );

                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.put(
        '/postHRepaidToDistributor',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Distributor'),
        middlewares.requiredProduct('purchaseFinancing'),
        celebrate({
            body: Joi.object({
                _id: Joi.string(),
                AmountReceived: Joi.number(),
                ReceivedNEFT_RTG: Joi.number(),
                PaymentReceivedDate: JoiDate.date()
            }),
        }),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('pharmacy/postHRepaidToDistributor: %o', req.body);
            try {
                const hospitalServiceInstance = Container.get(distributorPharmacyService);
                const { data } = await hospitalServiceInstance.postHRepaidToDistributor(
                    req.currentUser as IUser,
                    req.body as purchaseFinancingDTO,
                );
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.get(
        '/getAllVendorToDistributor',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Distributor'),
        middlewares.requiredProduct('purchaseFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('pharmacy/getAllVendorToDistributor: %o', req.query);
            try {
                const HospitalSupplierServiceInstance = Container.get(distributorPharmacyService);
                const { data } = await HospitalSupplierServiceInstance.getAllVendorToDistributor(req);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        }
    );
    // route.post(
    //     '/postVendorLimit',
    //     middlewares.isAuth,
    //     middlewares.attachCurrentUser,
    //     middlewares.requiredOrg('Distributor'),
    //     middlewares.requiredProduct('purchaseFinancing'),
    //     async (req: Request, res: Response, next: NextFunction) => {
    //         const logger: Logger = Container.get('logger');
    //         logger.debug('pharmacy/postVendorLimit: %o', req.body);
    //         try {
    //             const HospitalSupplierServiceInstance = Container.get(distributorPharmacyService);
    //             // const { data } = await HospitalSupplierServiceInstance.postVendorLimit(req);
    //             return res.status(201).json({ data });
    //         } catch (e) {
    //             logger.error('🔥 error: %o', e);
    //             return next(e);
    //         }
    //     }
    // );
    route.post('/repaymentByDistributor',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        middlewares.requiredOrg('Distributor'),
        middlewares.requiredProduct('purchaseFinancing'),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('pharmacy/repaymentByDistributor: %o', req.body);
            try {
                const HospitalSupplierServiceInstance = Container.get(distributorPharmacyService);
                const { data } = await HospitalSupplierServiceInstance.repaymentByDistributor(
                    req.currentUser as IUser,
                    req.body as purchaseFinancingDTO);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        }
    );
    route.get('/getAllInvoicesToDistributor',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Distributor'),
    middlewares.requiredProduct('purchaseFinancing'),
    // celebrate({
    //     query: {
    //         pageNumber: Joi.number().positive(),
    //         pageSize: Joi.number().positive(),
    //         filters: Joi.array(),
    //         Status: Joi.string(),
    //         searchTerm: Joi.string()
    //     },
    // }),
    async (req: Request, res: Response, next: NextFunction) => {
        const logger: Logger = Container.get('logger');
        logger.debug('claim/getAllInvoicesToHospital: %o', req.query);
        try {
            const hospitalServiceInstance = Container.get(distributorPharmacyService);
            const { data } = await hospitalServiceInstance.getAllInvoicesToDistributor(
                req.query as unknown as IFilterDTO,
                req.currentUser as IUser);
            return res.status(201).json({ data });
        } catch (e) {
            logger.error('🔥 error: %o', e);
            return next(e);
        }
    },
);
route.get('/getInvoiceByIdToDistributor',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Distributor'),
    middlewares.requiredProduct('purchaseFinancing'),
    async (req: Request, res: Response, next: NextFunction) => {
        const logger: Logger = Container.get('logger');
        logger.debug('claim/claim/getInvoiceByIdToHospital: %o', req.body);
        try {
            const hospitalServiceInstance = Container.get(distributorPharmacyService);
            const { data } = await hospitalServiceInstance.getInvoiceByIdToDistributor(req, res, req.currentUser as IUser);
            return res.status(201).json({ data });                  
        } catch (e) {
            logger.error('🔥 error: %o', e);
            return next(e);
        }
    },
);
    route.use(errors());
}