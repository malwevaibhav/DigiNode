import { Router, Request, Response, NextFunction } from 'express';
import { Container } from 'typedi';
import { IUser, IFilterDTO, IVendorDTO, ISupplierInvoiceDTO } from '../../interfaces/IUser';
import { Logger, loggers } from 'winston';
import { celebrate, errors, Joi } from 'celebrate';
import DateExtension from '@joi/date';
const JoiDate = Joi.extend(DateExtension);
import vendorService from '../../services/vendorService';
import middlewares from '../middlewares';

import util from 'util'
// const util = require('util')
const gc = require('../GCP/gcp')
const bucket = gc.bucket('digisparsh_images')



var multer = require('multer');
var path = require('path')
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'upload/')
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9)
    cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname))
  }
})

const storage_V2 = multer.memoryStorage()
const uploadBuffer = multer({
  storage: storage_V2,
  limits: { fieldSize: 10 * 1024 * 1024 },
},

)


const uploadImage = (file) => new Promise((resolve, reject) => {
  const { originalname, buffer } = file
  const date1 = Date.now().toString()

  const blob = bucket.file(originalname.replace(/ /g, "_"))
  const blobStream = blob.createWriteStream({
    resumable: false
  })
  let tempName = blob.name.split('.')
  if (tempName && tempName?.length) {

    blob.name = tempName[0] + date1 + '.' + tempName[tempName?.length - 1]
  }

  var blobb = blobStream.on('finish', () => {
    const publicUrl = util.format(
      `https://storage.googleapis.com/${bucket.name}/${blob.name}`
    )
    console.log(publicUrl)
    resolve(publicUrl)

  })
    .on('error', (err) => {
      reject(`Unable to upload image, something went wrong=>${err}`)
    })
    .end(buffer)

})


const route = Router();



export default (app: Router) => {
  app.use('/vendor', route);
  route.get(
    '/getDashboardForVendor',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Vendor'),
    middlewares.requiredProduct('supplierFinancing'),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('getDashboardForVendor: %o', req.query);
      try {
        const vendorServiceInstance = Container.get(vendorService);
        const { data } = await vendorServiceInstance.getDashboardForVendor(req.currentUser as IUser);
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
  route.get('/getDashboardData',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Vendor'),
    middlewares.requiredProduct('supplierFinancing'),
    celebrate({
      query: {
        dateFrom: JoiDate.date().allow(null),
        dateTo: JoiDate.date().allow(null),
      },
    }),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('Vendor getDashboardData: %o', req.query);
      try {
        const vendorServiceInstance = Container.get(vendorService);

        const { data } = await vendorServiceInstance.getDashboardData(req, res, req.currentUser as IUser);
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
  route.get(
    '/getInvoiceGraphToVendor',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Vendor'),
    middlewares.requiredProduct('supplierFinancing'),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('getInvoiceGraphToVendor: %o', req.query);
      try {
        const vendorServiceInstance = Container.get(vendorService);
        const { data } = await vendorServiceInstance.getInvoiceGraphToVendor(req.currentUser as IUser);
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
  route.get(
    '/getLApprovedInvoiceGraphToVendor',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Vendor'),
    middlewares.requiredProduct('supplierFinancing'),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('getLApprovedInvoiceGraphToVendor: %o', req.query);
      try {
        const vendorServiceInstance = Container.get(vendorService);
        const { data } = await vendorServiceInstance.getLApprovedInvoiceGraphToVendor(req.currentUser as IUser);
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
  route.get(
    '/getFundedInvoiceGraphToVendor',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Vendor'),
    middlewares.requiredProduct('supplierFinancing'),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('getFundedInvoiceGraphToVendor: %o', req.query);
      try {
        const vendorServiceInstance = Container.get(vendorService);
        const { data } = await vendorServiceInstance.getFundedInvoiceGraphToVendor(req.currentUser as IUser);
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
  route.get(
    '/getVendorGraphOne',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Vendor'),
    middlewares.requiredProduct('supplierFinancing'),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('getVendorGraphOne: %o', req.query);
      try {
        const vendorServiceInstance = Container.get(vendorService);
        const { data } = await vendorServiceInstance.getVendorGraphOne(req.currentUser as IUser);
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
  route.get(
    '/getLastPieGraphForVendor',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Vendor'),
    middlewares.requiredProduct('supplierFinancing'),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('getLastPieGraphForVendor: %o', req.query);
      try {
        const vendorServiceInstance = Container.get(vendorService);
        const { data } = await vendorServiceInstance.getLastPieGraphForVendor(req.currentUser as IUser);
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
  route.get(
    '/getSecondPieGraphForVendor',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Vendor'),
    middlewares.requiredProduct('supplierFinancing'),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('getSecondPieGraphForVendor: %o', req.query);
      try {
        const vendorServiceInstance = Container.get(vendorService);
        const { data } = await vendorServiceInstance.getSecondPieGraphForVendor(req.currentUser as IUser);
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
  route.get(
    '/getApprovedInvoiceForVendor',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Vendor'),
    middlewares.requiredProduct('supplierFinancing'),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('getApprovedInvoiceForVendor: %o', req.query);
      try {
        const vendorServiceInstance = Container.get(vendorService);
        const { data } = await vendorServiceInstance.getApprovedInvoiceForVendor(req.currentUser as IUser);
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
  //get Invoice to Vendor
  route.get(
    '/getInvoicesToVendor',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Vendor'),
    middlewares.requiredProduct('supplierFinancing'),
    celebrate({
      query: {
        pageNumber: Joi.number().positive(),
        pageSize: Joi.number().positive(),
        filters: Joi.array(),
        Status: Joi.string(),
        searchTerm: Joi.string()
      },
    }),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('getInvoicesToVendor: %o', req.query);
      try {
        const vendorServiceInstance = Container.get(vendorService);
        const { data } = await vendorServiceInstance.getInvoicesToVendor(
          req.query as unknown as IFilterDTO,
          req.currentUser as IUser,
        );
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
  route.get(
    '/getInvoiceByIdToVendor',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Vendor'),
    middlewares.requiredProduct('supplierFinancing'),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('getInvoiceByIdToVendor: %o', req.query);
      try {
        const vendorServiceInstance = Container.get(vendorService);
        const { data } = await vendorServiceInstance.getInvoiceByIdToVendor(req.query as unknown as IFilterDTO);
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
  //edit vendor profile
  route.get(
    '/getVendorProfileToVendor',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Vendor'),
    middlewares.requiredProduct('supplierFinancing'),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('getVendorProfileToVendor: %o');
      try {
        const vendorServiceInstance = Container.get(vendorService);
        const { data } = await vendorServiceInstance.getVendorProfileToVendor(req.currentUser as IUser);
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
  route.put(
    '/EditVendorProfileByVendor',
    uploadBuffer.fields([
      { name: "ParriPassu" },
      { name: "LastTwoYrBank" },
      { name: "LastAudFin" },
      { name: "LastTwoFin" },
      { name: "RegCert" },
      { name: "GstCert" },
      { name: "AddrProof" },
      { name: "Other" },
    ]),
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Vendor'),
    middlewares.requiredProduct('supplierFinancing'),
    // celebrate({
    //   body: {
    //     name: Joi.string(),
    //     address: Joi.array().items(
    //       Joi.object().keys({
    //         street: Joi.string(),
    //         state: Joi.string(),
    //         city: Joi.string(),
    //         pinCode: Joi.number(),
    //         country: Joi.string(),
    //       }),
    //     ),
    //     mobileNumber: Joi.number(),
    //     GSTNumber: Joi.string(),
    //     PANNumber: Joi.string(),
    //     email: Joi.string(),
    //     VendorType: Joi.string(),
    //     bankName: Joi.string(),
    //     AccountNumber: Joi.string(),
    //     IFSCcode: Joi.any(),
    //     authorisedPersonName: Joi.string(),
    //     contactDetailsForAuthPerson: Joi.number(),
    //     PANNumberForAuthPerson: Joi.string(),
    //     relationShip: Joi.string(),
    //     RateOfDeduction: Joi.number(),
    //     NoOfDaysCreditPeriod: Joi.number(),
    //     HospitalName: Joi.string(),
    //     HospitalId: Joi.string(),
    //     KycDocument: Joi.string(),
    //     Other: Joi.string(),
    //     ParriPassu: Joi.string(),
    //     LastTwoYrBank: Joi.string(),
    //     LastAudFin: Joi.string(),
    //     LastTwoFin: Joi.string(),
    //     RegCert: Joi.string(),
    //     GstCert: Joi.string(),
    //     AddrProof: Joi.string(),

    //     authorizedPerson: Joi.string()
    //   },
    // }),
    async (req: Request, res: Response, next: NextFunction) => {
      let files = req['files'] as { [fieldname: string]: Express.Multer.File[] };
      const logger: Logger = Container.get('logger');
      logger.debug('EditVendorProfileByVendor: %o', req.body);
      try {

        if (files?.ParriPassu) {
          req.body.ParriPassu = await uploadImage(files.ParriPassu[0])
          req.body.ParriPassu = req.body.ParriPassu.split('?')[0];
        }

        if (files?.LastTwoYrBank) {
          req.body.LastTwoYrBank = await uploadImage(files.LastTwoYrBank[0])
          req.body.LastTwoYrBank = req.body.LastTwoYrBank.split('?')[0];
        }
        if (files?.LastAudFin) {
          req.body.LastAudFin = await uploadImage(files.LastAudFin[0])
          req.body.LastAudFin = req.body.LastAudFin.split('?')[0];
        }
        if (files?.LastTwoFin) {
          req.body.LastTwoFin = await uploadImage(files.LastTwoFin[0])
          req.body.LastTwoFin = req.body.LastTwoFin.split('?')[0];
        }
        if (files?.RegCert) {
          req.body.RegCert = await uploadImage(files.RegCert[0])
          req.body.RegCert = req.body.RegCert.split('?')[0];
        }
        if (files?.GstCert) {
          req.body.GstCert = await uploadImage(files.GstCert[0])
          req.body.GstCert = req.body.GstCert.split('?')[0];
        }
        if (files?.AddrProof) {
          req.body.AddrProof = await uploadImage(files.AddrProof[0])
          req.body.AddrProof = req.body.AddrProof.split('?')[0];
        }
        if (files?.Other) {
          req.body.Other = await uploadImage(files.Other[0])
          req.body.Other = req.body.Other.split('?')[0];
        }
        const vendorServiceInstance = Container.get(vendorService);
        const { data } = await vendorServiceInstance.EditVendorProfileByVendor(
          req.currentUser as IUser,
          req.body as IVendorDTO,
        );
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
  //upload invoice
  route.post(
    '/invoiceUploadToVendorWithDetails',
    uploadBuffer.fields([{ name: "venderDocURL" }]),
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Vendor'),
    middlewares.requiredProduct('supplierFinancing'),
    // celebrate({
    //   body: {
    //     InvoiceAmount: Joi.number(),
    //     InvoiceNumber: Joi.number(),
    //     venderDocURL: Joi.string(),
    //     Description: Joi.string(),
    //     InvoiceDate: JoiDate.date(),
    //     DescriptionArr: Joi.string(),
    //     NameOfVendor: Joi.string(),
    //   },
    // }),
    async (req: Request, res: Response, next: NextFunction) => {
      let files = req['files'] as { [fieldname: string]: Express.Multer.File[] };
      const logger: Logger = Container.get('logger');
      logger.debug('invoiceUploadToVendorWithDetails: %o', req.body);
      try {

        if (files.venderDocURL) {
          req.body.venderDocURL = await uploadImage(files.venderDocURL[0])
          req.body.venderDocURL = req.body.venderDocURL.split('?')[0];
        }
        const vendorServiceInstance = Container.get(vendorService);
        const { data } = await vendorServiceInstance.invoiceUploadToVendorWithDetails(
          req.currentUser as IUser,
          req.body as ISupplierInvoiceDTO,
        );
        return res.status(201).json({ data });
      } catch (e) {
        console.log('hit', e);

        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
  route.get(
    '/getAllHospitalToVendor',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Vendor'),
    middlewares.requiredProduct('supplierFinancing'),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('vendor/getAllHospital: %o', req.body);
      try {
        const vendorServiceInstance = Container.get(vendorService);
        const { data } = await vendorServiceInstance.getAllHospitalToVendor(req);
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    }
  )
  route.use(errors());
};
