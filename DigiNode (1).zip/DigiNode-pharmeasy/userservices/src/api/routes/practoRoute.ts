import { Router, Request, Response, NextFunction } from 'express';
import { Container } from 'typedi';
import { IPatientLoanDTO, IUser, IFilterDTO } from '../../interfaces/IUser';
import { Logger, loggers } from 'winston';
import { celebrate, errors, Joi } from 'celebrate';
import DateExtension from '@joi/date';
const JoiDate = Joi.extend(DateExtension);
import practoService from '../../services/practoService';
import middlewares from '../middlewares';
import { PDFDocument, rgb, StandardFonts } from 'pdf-lib';
import { limits } from 'argon2';
import util from 'util'
// const util = require('util')
const gc = require('../GCP/gcp')
const bucket = gc.bucket('digisparsh_images')
// const { format } = util




var multer = require('multer');
var path = require('path')
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/')
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9)
    cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname))
  }
})
const upload = multer({
  storage: storage,
  limits: { fieldSize: 10 * 1024 * 1024 }
})

// This is for google cloud platform!!
const storage_V2 = multer.memoryStorage()
const uploadBuffer = multer({
  storage: storage_V2,
  limits: { fieldSize: 10 * 1024 * 1024 },
},

)
var fs = require('fs');

const { BlobServiceClient } = require("@azure/storage-blob");
const containerName = "uatcontainer";
const sasToken = "sv=2021-06-08&ss=bfqt&srt=sco&sp=rwdlacupiytfx&se=2024-02-20T16:47:15Z&st=2023-02-20T08:47:15Z&spr=https&sig=BDmeVstReLGKpmVAufC%2FKQd2afDfAPdO4LzQgdB1SXo%3D";
const storageAccountName = "uatresource";
const key = "uaEjdcwzjVO7U7qv/JFnOnsEXUxQHQ46zI4x+onZBXL9UPCLEfEk+xd0sMB0ZWmZGuRLXdxjDzBIUba3A5CUrw==";

const createBlobInContainer = async (containerClient, filename, mimetype) => {
  const blobClient = containerClient.getBlockBlobClient(filename);
  const options = { blobHTTPHeaders: { blobContentType: mimetype } };
  var a = await blobClient.uploadData(
    fs.readFileSync("uploads/" + filename),
    options
  );
  return blobClient.url;
};

const uploadFileToBlob = async (filename, mimetype) => {
  if (!filename || !mimetype) return [];
  const blobService = new BlobServiceClient(
    `https://${storageAccountName}.blob.core.windows.net/?${sasToken}`
  );
  const containerClient = blobService.getContainerClient(containerName);
  var response = await createBlobInContainer(containerClient, filename, mimetype);
  return response;
};

const isImageFile=(file)=> {
  const imageMimeTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/bmp','image/jpg'];
  return imageMimeTypes.includes(file.mimetype);
}
const uploadImage = (file) => new Promise((resolve, reject) => {
  const { originalname, buffer } = file

  const blob = bucket.file(Date.now().toString()+originalname.replace(/ /g, "_"))
  const blobStream = blob.createWriteStream({
    resumable: false
  })

  var blobb = blobStream.on('finish', () => {
    const publicUrl = util.format(
      `https://storage.googleapis.com/${bucket.name}/${blob.name}`
    )
    console.log(publicUrl)
    resolve(publicUrl)

  })
    .on('error', (err) => {
      reject(`Unable to upload image, something went wrong=>${err}`)
    })
    .end(buffer)

})


const imageToPDF = async (imageFile) => {
  const imageBytes = Uint8Array.from(imageFile.buffer)
  // const imageBytes1 = fs.readFileSync(imageFile.buffer)
  const pdfDoc = await PDFDocument.create()
  var image
  if (imageFile.mimetype == 'image/png') {
    image = await pdfDoc.embedPng(imageBytes)
  }
  else {
    image = await pdfDoc.embedJpg(imageBytes)
  }

  const page = pdfDoc.addPage();
  var scale = page.getWidth() * 0.8 / image.width
  const jpgDims = image.scale(scale)

  page.drawImage(image, {
    x: page.getWidth() / 2 - jpgDims.width / 2,
    y: page.getHeight() / 2 - jpgDims.height / 2,
    width: jpgDims.width,
    height: jpgDims.height,
  })

  const pdfBytes = await pdfDoc.save()
  return pdfBytes
  var pdfFilePath = imageFile.path.split('.')[0]
  var pdfFileName = imageFile.filename.split('.')[0] + 'PDF.pdf'
  fs.writeFileSync(pdfFilePath + 'PDF.pdf', pdfBytes)
  pdfFilePath = pdfFilePath + 'PDF.pdf'
  var pdfFile = { pdfFilePath, pdfFileName }
  return pdfFile
}

const addWatermarkPDF = async (pdfFilePath, osvDetails) => {
  console.log(typeof pdfFilePath.buffer)
  const existingPdfBytes = pdfFilePath.buffer
  const pdfDoc = await PDFDocument.load(existingPdfBytes as Uint8Array)
  const helveticaFont = await pdfDoc.embedFont(StandardFonts.Helvetica)

  const pages = pdfDoc.getPages()
  const firstPage = pages[0]
  const { width, height } = firstPage.getSize()

  firstPage.drawText(`Employee Name: ${osvDetails.osvEmpName}, Employee Id: ${osvDetails.osvEmpId} \n${new Date().toString().split('GMT')[0]} \n${osvDetails.osvEmpOrg}`, {
    x: 10,
    y: 60,
    size: 12,
    font: helveticaFont,
    color: rgb(0, 0, 0),
  })

  const pdfBytes = await pdfDoc.save()
  return pdfBytes;
  fs.writeFileSync(pdfFilePath, pdfBytes)

}
const addWatermarkPDFGCP = async (file, osvDetails) => {
  // console.log(typeof pdfFilePath.buffer)
  const existingPdfBytes = file.buffer
  const pdfDoc = await PDFDocument.load(existingPdfBytes as Uint8Array)
  const helveticaFont = await pdfDoc.embedFont(StandardFonts.Helvetica)

  const pages = pdfDoc.getPages()
  const firstPage = pages[0]
  const { width, height } = firstPage.getSize()

  firstPage.drawText(`Employee Name: ${osvDetails.osvEmpName}, Employee Id: ${osvDetails.osvEmpId} \n${new Date().toString().split('GMT')[0]} \n${osvDetails.osvEmpOrg}`, {
    x: 10,
    y: 60,
    size: 12,
    font: helveticaFont,
    color: rgb(0, 0, 0),
  })

  const pdfBytes = await pdfDoc.save()
  return pdfBytes;
  // fs.writeFileSync(pdfFilePath, pdfBytes)

}
const addWatermarkPDFGCPForImg = async (buffer, osvDetails) => {
  // console.log(typeof pdfFilePath.buffer)
  const existingPdfBytes = buffer
  const pdfDoc = await PDFDocument.load(existingPdfBytes as Uint8Array)
  const helveticaFont = await pdfDoc.embedFont(StandardFonts.Helvetica)

  const pages = pdfDoc.getPages()
  const firstPage = pages[0]
  const { width, height } = firstPage.getSize()

  firstPage.drawText(`Employee Name: ${osvDetails.osvEmpName}, Employee Id: ${osvDetails.osvEmpId} \n${new Date().toString().split('GMT')[0]} \n${osvDetails.osvEmpOrg}`, {
    x: 10,
    y: 60,
    size: 12,
    font: helveticaFont,
    color: rgb(0, 0, 0),
  })

  const pdfBytes = await pdfDoc.save()
  return pdfBytes;
  // fs.writeFileSync(pdfFilePath, pdfBytes)

}
// async function blobToArrayBuffer(blob) {
//   if ('arrayBuffer' in blob) return await blob.arrayBuffer();

//   return new Promise((resolve, reject) => {
//       const reader = new FileReader();
//       reader.onload = () => resolve(reader.result);
//       reader.onerror = () => reject();
//       reader.readAsArrayBuffer(blob);
//   });
// }
// const generateAgreementPdf = async (invoice, fileName) => {
//   const pdfDoc = await PDFDocument.create()
//   const helveticaFont = await pdfDoc.embedFont(StandardFonts.Helvetica)

//   const page = pdfDoc.addPage([550, 750])
//   const { width, height } = page.getSize()

//   page.drawText(`Sample Agreement Document for ${invoice.patientName}`, {
//     x: width / 3,
//     y: height / 2,
//     size: 12,
//     font: helveticaFont,
//     color: rgb(0, 0, 0),
//   })

//   const pdfBytes = await pdfDoc.save()
//   fs.writeFileSync(`uploads/${fileName}`, pdfBytes)
//   return fileName
// }

const route = Router();

export default (app: Router) => {
  app.use('/patient', route);
  route.get(
    '/getPractoDashboard',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    celebrate({
      query: {
        dateFrom: JoiDate.date().allow(null),
        dateTo: JoiDate.date().allow(null),
      },
    }),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('getPractoDashboard: %o', req.query);
      try {
        const practoServiceInstance = Container.get(practoService);
        // var dateFrom = new Date(req.query.dateFrom.toLocaleString());
        // var dateTo = new Date(req.query.dateTo.toLocaleString());

        const { data } = await practoServiceInstance.getPractoDashboard(req, res);
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );

  route.get(
    '/getAllInvoices',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    celebrate({
      query: {
        pageNumber: Joi.number().positive(),
        pageSize: Joi.number().positive(),
        filters: Joi.array(),
        isInsured: Joi.boolean(),
        invoiceStatus: Joi.string(),
        invoiceSubStatus: Joi.string(),
        dateFrom: JoiDate.date().format('YYYY-MM-DD'),
        dateTo: JoiDate.date().format('YYYY-MM-DD'),
        searchTerm: Joi.string()
      },
    }),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('getAllInvoices: %o', req.query);
      try {
        const practoServiceInstance = Container.get(practoService);
        const { data } = await practoServiceInstance.getAllInvoices(
          req.query as unknown as IFilterDTO,
          req.currentUser as IUser);
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
  route.get('/getInvoiceById', middlewares.isAuth, async (req: Request, res: Response, next: NextFunction) => {
    const logger: Logger = Container.get('logger');
    logger.debug('getInvoiceById: %o', req.body);
    try {
      const practoServiceInstance = Container.get(practoService);
      const { data } = await practoServiceInstance.getInvoiceById(req, res);
      return res.status(201).json({ data });
    } catch (e) {
      logger.error('🔥 error: %o', e);
      return next(e);
    }
  });
  route.post('/postPatientTermLoan',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    uploadBuffer.fields([
      { name: 'uploadAadharFront' },
      { name: 'uploadAadharBack' },
      { name: 'uploadPAN' },
      { name: 'uploadCancelledCheque' },
      { name: 'uploadInsurancePolicy' },
      { name: 'uploadHospitalBill' },
      { name: 'uploadProof' },
      { name: 'uploadIncomeProof' },
      { name: 'uploadBankStatement' },
      { name: 'uploadOtherDoc' },
      { name: 'uploadConsentDoc' },
      { name: 'recommendationLetter' },
      { name: 'uploadCibil' }
    ]),
    async (req: Request, res: Response, next: NextFunction) => {
      const files = req['files'] as { [fieldname: string]: Express.Multer.File[] };
      const logger: Logger = Container.get('logger');
      logger.debug('postPatientTermLoan: %o', req.body,req.headers.origin);
      try {
        const practoServiceInstance = Container.get(practoService);
        const osvDetails = await practoServiceInstance.getOSVDetails()

        if (files?.uploadAadharFront) {
          // if (files?.uploadAadharFront[0].mimetype == 'application/pdf') {
          //   const blob=await addWatermarkPDFGCP(files?.uploadAadharFront[0], osvDetails)
          //   // req.body.uploadAadharFront = await uploadFileToBlob(files?.uploadAadharFront[0].filename, 'application/pdf')
          //   let file= { originalname:files?.uploadAadharFront[0].originalname, buffer: blob}
          //   req.body.uploadAadharFront = await uploadImage(file)
          // }
          // else {
          //   var pdfFile = await imageToPDF(files?.uploadAadharFront[0])
          //   // await addWatermarkPDF(pdfFile.pdfFilePath, osvDetails);
          //   const blob=await addWatermarkPDFGCPForImg(pdfFile, osvDetails)
          //   // req.body.uploadAadharFront = await uploadFileToBlob(files?.uploadAadharFront[0].filename, 'application/pdf')
          //   let file= { originalname:files?.uploadAadharFront[0].originalname.split('.')[0]+".pdf", buffer: blob}
          //   req.body.uploadAadharFront = await uploadImage(file)
          //   // req.body.uploadAadharFront = await uploadFileToBlob(pdfFile.pdfFileName, 'application/pdf')
          // }
          if(isImageFile(files?.uploadAadharFront[0])){
            req.body.uploadAadharFront = await uploadImage(files.uploadAadharFront[0])
            req.body.uploadAadharFront = req.body.uploadAadharFront.split('?')[0];
          }else{

            return res.status(400).json({massage:"please select image file"})
          }
          
        }
        if (files?.uploadAadharBack) {
          // if (files?.uploadAadharBack[0].mimetype == 'application/pdf') {
          //   const blob=await addWatermarkPDFGCP(files?.uploadAadharBack[0], osvDetails)
          //   let file= { originalname:files?.uploadAadharBack[0].originalname, buffer: blob}
          //   req.body.uploadAadharBack = await uploadImage(file)

          // }
          // else {
          //   var pdfFile = await imageToPDF(files?.uploadAadharBack[0])
          //   // await addWatermarkPDF(pdfFile.pdfFilePath, osvDetails);
          //   const blob=await addWatermarkPDFGCPForImg(pdfFile, osvDetails)
          //   // req.body.uploadAadharFront = await uploadFileToBlob(files?.uploadAadharFront[0].filename, 'application/pdf')
          //   let file= { originalname:files?.uploadAadharBack[0].originalname.split('.')[0]+".pdf", buffer: blob}
          //   req.body.uploadAadharBack = await uploadImage(file)
          // }
          if(isImageFile(files?.uploadAadharBack[0])){
            req.body.uploadAadharBack = await uploadImage(files.uploadAadharBack[0])
            req.body.uploadAadharBack = req.body.uploadAadharBack.split('?')[0];
           
          }else{

            return res.status(400).json({massage:"please select image file"})
          }
         
        }
        if (files?.uploadPAN) {
          // var filePath = files?.uploadPAN[0].path
          // if (files?.uploadPAN[0].mimetype == 'application/pdf') {
          //   const blob=await addWatermarkPDFGCP(files?.uploadPAN[0], osvDetails)
          //   let file= { originalname:files?.uploadPAN[0].originalname, buffer: blob}
          //   // await addWatermarkPDF(files?.uploadPAN[0].path, osvDetails)
          //   req.body.uploadPAN = await uploadImage(file)
          // }
          // else {
          //   var pdfFile = await imageToPDF(files?.uploadPAN[0])
          //   // await addWatermarkPDF(pdfFile.pdfFilePath, osvDetails);
          //   const blob=await addWatermarkPDFGCPForImg(pdfFile, osvDetails)
          //   // req.body.uploadAadharFront = await uploadFileToBlob(files?.uploadAadharFront[0].filename, 'application/pdf')
          //   let file= { originalname:files?.uploadPAN[0].originalname.split('.')[0]+".pdf", buffer: blob}
          //   req.body.uploadPAN = await uploadImage(file)
          // }
          if(isImageFile(files?.uploadPAN[0])){
            req.body.uploadPAN = await uploadImage(files.uploadPAN[0])
            req.body.uploadPAN = req.body.uploadPAN.split('?')[0];
          }else{

            return res.status(400).json({massage:"please select image file"})
          }
     

          
        }
        // if (files?.uploadAadharFront) {
        //   req.body.uploadAadharFront = await uploadFileToBlob(files?.uploadAadharFront[0].filename, files?.uploadAadharFront[0].mimetype)
        //   req.body.uploadAadharFront = req.body.uploadAadharFront.split('?')[0];
        // }
        // if (files?.uploadAadharBack) {
        //   req.body.uploadAadharBack = await uploadFileToBlob(files?.uploadAadharBack[0].filename, files?.uploadAadharBack[0].mimetype)
        //   req.body.uploadAadharBack = req.body.uploadAadharBack.split('?')[0];
        // }
        // if (files?.uploadPAN) {
        //   req.body.uploadPAN = await uploadFileToBlob(files?.uploadPAN[0].filename, files?.uploadPAN[0].mimetype)
        //   req.body.uploadPAN = req.body.uploadPAN.split('?')[0];
        // }
        if (files?.uploadProof) {

          // if (files?.uploadProof[0].mimetype == 'application/pdf') {
          //   const blob=await addWatermarkPDFGCP(files?.uploadProof[0], osvDetails)
          //   // req.body.uploadAadharFront = await uploadFileToBlob(files?.uploadAadharFront[0].filename, 'application/pdf')
          //   let file= { originalname:files?.uploadProof[0].originalname, buffer: blob}
          //   // req.body.uploadAadharBack = await uploadFileToBlob(files?.uploadAadharBack[0].filename, 'application/pdf')
          //   req.body.uploadProof = await uploadImage(file)

          // }
          // else {
          //   var pdfFile = await imageToPDF(files?.uploadPAN[0])
          //   // await addWatermarkPDF(pdfFile.pdfFilePath, osvDetails);
          //   const blob=await addWatermarkPDFGCPForImg(pdfFile, osvDetails)
          //   // req.body.uploadAadharFront = await uploadFileToBlob(files?.uploadAadharFront[0].filename, 'application/pdf')
          //   let file= { originalname:files?.uploadPAN[0].originalname.split('.')[0]+".pdf", buffer: blob}
          //   req.body.uploadPAN = await uploadImage(file)
          // }
          req.body.uploadProof = await uploadImage(files.uploadProof[0])
          req.body.uploadProof = req.body.uploadProof.split('?')[0];
        }
        if (files?.recommendationLetter) {
          // if (files?.recommendationLetter[0].mimetype == 'application/pdf') {
          //   const blob=await addWatermarkPDFGCP(files?.recommendationLetter[0], osvDetails)
          //   // req.body.uploadAadharFront = await uploadFileToBlob(files?.uploadAadharFront[0].filename, 'application/pdf')
          //   let file= { originalname:files?.recommendationLetter[0].originalname, buffer: blob}
          //   // req.body.uploadAadharBack = await uploadFileToBlob(files?.uploadAadharBack[0].filename, 'application/pdf')
          //   req.body.recommendationLetter = await uploadImage(file)

          // }
          // else {
          //   var pdfFile = await imageToPDF(files?.recommendationLetter[0])
          //   // await addWatermarkPDF(pdfFile.pdfFilePath, osvDetails);
          //   const blob=await addWatermarkPDFGCPForImg(pdfFile, osvDetails)
          //   // req.body.uploadAadharFront = await uploadFileToBlob(files?.uploadAadharFront[0].filename, 'application/pdf')
          //   let file= { originalname:files?.recommendationLetter[0].originalname.split('.')[0]+".pdf", buffer: blob}
          //   req.body.recommendationLetter = await uploadImage(file)
          // }
          req.body.recommendationLetter = await uploadImage(files.recommendationLetter[0])
          req.body.recommendationLetter = req.body.recommendationLetter.split('?')[0];
        }
        if (files?.uploadCancelledCheque) {
        //   if (files?.uploadCancelledCheque[0].mimetype == 'application/pdf') {
        //     const blob=await addWatermarkPDFGCP(files?.uploadCancelledCheque[0], osvDetails)
        //     // req.body.uploadAadharFront = await uploadFileToBlob(files?.uploadAadharFront[0].filename, 'application/pdf')
        //     let file= { originalname:files?.uploadCancelledCheque[0].originalname, buffer: blob}
        //     // req.body.uploadAadharBack = await uploadFileToBlob(files?.uploadAadharBack[0].filename, 'application/pdf')
        //     req.body.uploadCancelledCheque = await uploadImage(file)

        //   }
        //   else {
        //     var pdfFile = await imageToPDF(files?.uploadCancelledCheque[0])
        //     // await addWatermarkPDF(pdfFile.pdfFilePath, osvDetails);
        //     const blob=await addWatermarkPDFGCPForImg(pdfFile, osvDetails)
        //     // req.body.uploadAadharFront = await uploadFileToBlob(files?.uploadAadharFront[0].filename, 'application/pdf')
        //     let file= { originalname:files?.uploadCancelledCheque[0].originalname.split('.')[0]+".pdf", buffer: blob}
        //     req.body.uploadCancelledCheque = await uploadImage(file)
        // }
        req.body.uploadCancelledCheque = await uploadImage(files.uploadCancelledCheque[0])
        req.body.uploadCancelledCheque = req.body.uploadCancelledCheque.split('?')[0];
      }
        if (files?.uploadIncomeProof) {
          // if (files?.uploadIncomeProof[0].mimetype == 'application/pdf') {
          //   const blob=await addWatermarkPDFGCP(files?.uploadIncomeProof[0], osvDetails)
          //   // req.body.uploadAadharFront = await uploadFileToBlob(files?.uploadAadharFront[0].filename, 'application/pdf')
          //   let file= { originalname:files?.uploadIncomeProof[0].originalname, buffer: blob}
          //   // req.body.uploadAadharBack = await uploadFileToBlob(files?.uploadAadharBack[0].filename, 'application/pdf')
          //   req.body.uploadIncomeProof = await uploadImage(file)

          // }
          // else {
          //   var pdfFile = await imageToPDF(files?.uploadIncomeProof[0])
          //   // await addWatermarkPDF(pdfFile.pdfFilePath, osvDetails);
          //   const blob=await addWatermarkPDFGCPForImg(pdfFile, osvDetails)
          //   // req.body.uploadAadharFront = await uploadFileToBlob(files?.uploadAadharFront[0].filename, 'application/pdf')
          //   let file= { originalname:files?.uploadIncomeProof[0].originalname.split('.')[0]+".pdf", buffer: blob}
          //   req.body.uploadIncomeProof = await uploadImage(file)
          // }
          req.body.uploadIncomeProof = await uploadImage(files.uploadIncomeProof[0])
          req.body.uploadIncomeProof = req.body.uploadIncomeProof.split('?')[0];
        }
        if (files?.uploadHospitalBill) {
          // if (files?.uploadHospitalBill[0].mimetype == 'application/pdf') {
          //   const blob=await addWatermarkPDFGCP(files?.uploadHospitalBill[0], osvDetails)
          //   // req.body.uploadAadharFront = await uploadFileToBlob(files?.uploadAadharFront[0].filename, 'application/pdf')
          //   let file= { originalname:files?.uploadHospitalBill[0].originalname, buffer: blob}
          //   // req.body.uploadAadharBack = await uploadFileToBlob(files?.uploadAadharBack[0].filename, 'application/pdf')
          //   req.body.uploadHospitalBill = await uploadImage(file)

          // }
          // else {
          //   var pdfFile = await imageToPDF(files?.uploadHospitalBill[0])
          //   // await addWatermarkPDF(pdfFile.pdfFilePath, osvDetails);
          //   const blob=await addWatermarkPDFGCPForImg(pdfFile, osvDetails)
          //   // req.body.uploadAadharFront = await uploadFileToBlob(files?.uploadAadharFront[0].filename, 'application/pdf')
          //   let file= { originalname:files?.uploadHospitalBill[0].originalname.split('.')[0]+".pdf", buffer: blob}
          //   req.body.uploadHospitalBill = await uploadImage(file)
          // }
          req.body.uploadHospitalBill = await uploadImage(files.uploadHospitalBill[0])
          req.body.uploadHospitalBill = req.body.uploadHospitalBill.split('?')[0];
        }
        if (files?.uploadBankStatement) {
          // if (files?.uploadBankStatement[0].mimetype == 'application/pdf') {
          //   const blob=await addWatermarkPDFGCP(files?.uploadBankStatement[0], osvDetails)
          //   // req.body.uploadAadharFront = await uploadFileToBlob(files?.uploadAadharFront[0].filename, 'application/pdf')
          //   let file= { originalname:files?.uploadBankStatement[0].originalname, buffer: blob}
          //   // req.body.uploadAadharBack = await uploadFileToBlob(files?.uploadAadharBack[0].filename, 'application/pdf')
          //   req.body.uploadBankStatement = await uploadImage(file)

          // }
          // else {
          //   var pdfFile = await imageToPDF(files?.uploadBankStatement[0])
          //   // await addWatermarkPDF(pdfFile.pdfFilePath, osvDetails);
          //   const blob=await addWatermarkPDFGCPForImg(pdfFile, osvDetails)
          //   // req.body.uploadAadharFront = await uploadFileToBlob(files?.uploadAadharFront[0].filename, 'application/pdf')
          //   let file= { originalname:files?.uploadBankStatement[0].originalname.split('.')[0]+".pdf", buffer: blob}
          //   req.body.uploadBankStatement = await uploadImage(file)
          // }
          req.body.uploadBankStatement = await uploadImage(files.uploadBankStatement[0])
          req.body.uploadBankStatement = req.body.uploadBankStatement.split('?')[0];
        }
        if (files?.uploadInsurancePolicy) {
          // if (files?.uploadInsurancePolicy[0].mimetype == 'application/pdf') {
          //   const blob=await addWatermarkPDFGCP(files?.uploadInsurancePolicy[0], osvDetails)
          //   // req.body.uploadAadharFront = await uploadFileToBlob(files?.uploadAadharFront[0].filename, 'application/pdf')
          //   let file= { originalname:files?.uploadInsurancePolicy[0].originalname, buffer: blob}
          //   // req.body.uploadAadharBack = await uploadFileToBlob(files?.uploadAadharBack[0].filename, 'application/pdf')
          //   req.body.uploadInsurancePolicy = await uploadImage(file)

          // }
          // else {
          //   var pdfFile = await imageToPDF(files?.uploadInsurancePolicy[0])
          //   // await addWatermarkPDF(pdfFile.pdfFilePath, osvDetails);
          //   const blob=await addWatermarkPDFGCPForImg(pdfFile, osvDetails)
          //   // req.body.uploadAadharFront = await uploadFileToBlob(files?.uploadAadharFront[0].filename, 'application/pdf')
          //   let file= { originalname:files?.uploadInsurancePolicy[0].originalname.split('.')[0]+".pdf", buffer: blob}
          //   req.body.uploadInsurancePolicy = await uploadImage(file)
          // }
          req.body.uploadInsurancePolicy = await uploadImage(files.uploadInsurancePolicy[0])
          req.body.uploadInsurancePolicy = req.body.uploadInsurancePolicy.split('?')[0];
        }
        if (files?.uploadOtherDoc) {
          // if (files?.uploadOtherDoc[0].mimetype == 'application/pdf') {
          //   const blob=await addWatermarkPDFGCP(files?.uploadOtherDoc[0], osvDetails)
          //   // req.body.uploadAadharFront = await uploadFileToBlob(files?.uploadAadharFront[0].filename, 'application/pdf')
          //   let file= { originalname:files?.uploadOtherDoc[0].originalname, buffer: blob}
          //   // req.body.uploadAadharBack = await uploadFileToBlob(files?.uploadAadharBack[0].filename, 'application/pdf')
          //   req.body.uploadOtherDoc = await uploadImage(file)

          // }
          // else {
          //   var pdfFile = await imageToPDF(files?.uploadOtherDoc[0])
          //   // await addWatermarkPDF(pdfFile.pdfFilePath, osvDetails);
          //   const blob=await addWatermarkPDFGCPForImg(pdfFile, osvDetails)
          //   // req.body.uploadAadharFront = await uploadFileToBlob(files?.uploadAadharFront[0].filename, 'application/pdf')
          //   let file= { originalname:files?.uploadOtherDoc[0].originalname.split('.')[0]+".pdf", buffer: blob}
          //   req.body.uploadOtherDoc = await uploadImage(file)
          // }
          req.body.uploadOtherDoc = await uploadImage(files.uploadOtherDoc[0])
          req.body.uploadOtherDoc = req.body.uploadOtherDoc.split('?')[0];
        }
        if (files?.uploadConsentDoc) {
          // if (files?.uploadConsentDoc[0].mimetype == 'application/pdf') {
          //   const blob=await addWatermarkPDFGCP(files?.uploadConsentDoc[0], osvDetails)
          //   // req.body.uploadAadharFront = await uploadFileToBlob(files?.uploadAadharFront[0].filename, 'application/pdf')
          //   let file= { originalname:files?.uploadConsentDoc[0].originalname, buffer: blob}
          //   // req.body.uploadAadharBack = await uploadFileToBlob(files?.uploadAadharBack[0].filename, 'application/pdf')
          //   req.body.uploadConsentDoc = await uploadImage(file)

          // }
          // else {
          //   var pdfFile = await imageToPDF(files?.uploadConsentDoc[0])
          //   // await addWatermarkPDF(pdfFile.pdfFilePath, osvDetails);
          //   const blob=await addWatermarkPDFGCPForImg(pdfFile, osvDetails)
          //   // req.body.uploadAadharFront = await uploadFileToBlob(files?.uploadAadharFront[0].filename, 'application/pdf')
          //   let file= { originalname:files?.uploadConsentDoc[0].originalname.split('.')[0]+".pdf", buffer: blob}
          //   req.body.uploadConsentDoc = await uploadImage(file)
          // }
          req.body.uploadConsentDoc = await uploadImage(files.uploadConsentDoc[0])
          req.body.uploadConsentDoc = req.body.uploadConsentDoc.split('?')[0];
        }
        if (files?.uploadCibil) {
          // if (files?.uploadCibil[0].mimetype == 'application/pdf') {
          //   const blob=await addWatermarkPDFGCP(files?.uploadCibil[0], osvDetails)
          //   // req.body.uploadAadharFront = await uploadFileToBlob(files?.uploadAadharFront[0].filename, 'application/pdf')
          //   let file= { originalname:files?.uploadCibil[0].originalname, buffer: blob}
          //   // req.body.uploadAadharBack = await uploadFileToBlob(files?.uploadAadharBack[0].filename, 'application/pdf')
          //   req.body.uploadCibil = await uploadImage(file)

          // }
          // else {
          //   var pdfFile = await imageToPDF(files?.uploadCibil[0])
          //   // await addWatermarkPDF(pdfFile.pdfFilePath, osvDetails);
          //   const blob=await addWatermarkPDFGCPForImg(pdfFile, osvDetails)
          //   // req.body.uploadAadharFront = await uploadFileToBlob(files?.uploadAadharFront[0].filename, 'application/pdf')
          //   let file= { originalname:files?.uploadCibil[0].originalname.split('.')[0]+".pdf", buffer: blob}
          //   req.body.uploadCibil = await uploadImage(file)
          // }
          req.body.uploadCibil = await uploadImage(files.uploadCibil[0])
          req.body.uploadCibil = req.body.uploadCibil.split('?')[0];
        }

        const { responseCode, data } = await practoServiceInstance.postPatientTermLoan(
          req,
          req.currentUser as IUser,
          req.body as IPatientLoanDTO,
        );
        return res.status(responseCode).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
  route.post('/editInvoice',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    uploadBuffer.fields([
      { name: 'uploadAadharFront' },
      { name: 'uploadAadharBack' },
      { name: 'uploadPAN' },
      { name: 'uploadCancelledCheque' },
      { name: 'uploadInsurancePolicy' },
      { name: 'uploadHospitalBill' },
      { name: 'uploadProof' },
      { name: 'uploadIncomeProof' },
      { name: 'uploadBankStatement' },
      { name: 'uploadOtherDoc' },
      { name: 'uploadConsentDoc' },
      { name: 'recommendationLetter' },
      { name: 'uploadCibil' }
    ]),
    async (req: Request, res: Response, next: NextFunction) => {
      const files = req['files'] as { [fieldname: string]: Express.Multer.File[] };
      const logger: Logger = Container.get('logger');
      logger.debug('editInvoice: %o', req.body);
      try {
        const practoServiceInstance = Container.get(practoService);
        const osvDetails = await practoServiceInstance.getOSVDetails()

        if (files?.uploadAadharFront) {
          // if (files?.uploadAadharFront[0].mimetype == 'application/pdf') {
          //   const blob=await addWatermarkPDFGCP(files?.uploadAadharFront[0], osvDetails)
          //   // req.body.uploadAadharFront = await uploadFileToBlob(files?.uploadAadharFront[0].filename, 'application/pdf')
          //   let file= { originalname:files?.uploadAadharFront[0].originalname, buffer: blob}
          //   req.body.uploadAadharFront = await uploadImage(file)
          // }
          // else {
          //   var pdfFile = await imageToPDF(files?.uploadAadharFront[0])
          //   // await addWatermarkPDF(pdfFile.pdfFilePath, osvDetails);
          //   const blob=await addWatermarkPDFGCPForImg(pdfFile, osvDetails)
          //   // req.body.uploadAadharFront = await uploadFileToBlob(files?.uploadAadharFront[0].filename, 'application/pdf')
          //   let file= { originalname:files?.uploadAadharFront[0].originalname.split('.')[0]+".pdf", buffer: blob}
          //   req.body.uploadAadharFront = await uploadImage(file)
          //   // req.body.uploadAadharFront = await uploadFileToBlob(pdfFile.pdfFileName, 'application/pdf')
          // }
          if(isImageFile(files?.uploadAadharFront[0])){
            req.body.uploadAadharFront = await uploadImage(files.uploadAadharFront[0])
            req.body.uploadAadharFront = req.body.uploadAadharFront.split('?')[0];
          }else{

            return res.status(400).json({massage:"please select image file"})
          }
          
          
        }
        if (files?.uploadAadharBack) {
          // if (files?.uploadAadharBack[0].mimetype == 'application/pdf') {
          //   const blob=await addWatermarkPDFGCP(files?.uploadAadharBack[0], osvDetails)
          //   let file= { originalname:files?.uploadAadharBack[0].originalname, buffer: blob}
          //   req.body.uploadAadharBack = await uploadImage(file)

          // }
          // else {
          //   var pdfFile = await imageToPDF(files?.uploadAadharBack[0])
          //   // await addWatermarkPDF(pdfFile.pdfFilePath, osvDetails);
          //   const blob=await addWatermarkPDFGCPForImg(pdfFile, osvDetails)
          //   // req.body.uploadAadharFront = await uploadFileToBlob(files?.uploadAadharFront[0].filename, 'application/pdf')
          //   let file= { originalname:files?.uploadAadharBack[0].originalname.split('.')[0]+".pdf", buffer: blob}
          //   req.body.uploadAadharBack = await uploadImage(file)
          // }
          if(isImageFile(files?.uploadAadharFront[0])){
            req.body.uploadAadharBack = await uploadImage(files.uploadAadharBack[0])
            req.body.uploadAadharBack = req.body.uploadAadharBack.split('?')[0];
           
          }else{

            return res.status(400).json({massage:"please select image file"})
          }
        }
        if (files?.uploadPAN) {
          // var filePath = files?.uploadPAN[0].path
          // if (files?.uploadPAN[0].mimetype == 'application/pdf') {
          //   const blob=await addWatermarkPDFGCP(files?.uploadPAN[0], osvDetails)
          //   let file= { originalname:files?.uploadPAN[0].originalname, buffer: blob}
          //   // await addWatermarkPDF(files?.uploadPAN[0].path, osvDetails)
          //   req.body.uploadPAN = await uploadImage(file)
          // }
          // else {
          //   var pdfFile = await imageToPDF(files?.uploadPAN[0])
          //   // await addWatermarkPDF(pdfFile.pdfFilePath, osvDetails);
          //   const blob=await addWatermarkPDFGCPForImg(pdfFile, osvDetails)
          //   // req.body.uploadAadharFront = await uploadFileToBlob(files?.uploadAadharFront[0].filename, 'application/pdf')
          //   let file= { originalname:files?.uploadPAN[0].originalname.split('.')[0]+".pdf", buffer: blob}
          //   req.body.uploadPAN = await uploadImage(file)
          // }
          if(isImageFile(files?.uploadAadharFront[0])){
            req.body.uploadPAN = await uploadImage(files.uploadPAN[0])
            req.body.uploadPAN = req.body.uploadPAN.split('?')[0];
          }else{

            return res.status(400).json({massage:"please select image file"})
          }
        }
        // if (files?.uploadAadharFront) {
        //   req.body.uploadAadharFront = await uploadFileToBlob(files?.uploadAadharFront[0].filename, files?.uploadAadharFront[0].mimetype)
        //   req.body.uploadAadharFront = req.body.uploadAadharFront.split('?')[0];
        // }
        // if (files?.uploadAadharBack) {
        //   req.body.uploadAadharBack = await uploadFileToBlob(files?.uploadAadharBack[0].filename, files?.uploadAadharBack[0].mimetype)
        //   req.body.uploadAadharBack = req.body.uploadAadharBack.split('?')[0];
        // }
        // if (files?.uploadPAN) {
        //   req.body.uploadPAN = await uploadFileToBlob(files?.uploadPAN[0].filename, files?.uploadPAN[0].mimetype)
        //   req.body.uploadPAN = req.body.uploadPAN.split('?')[0];
        // }
        if (files?.uploadProof) {

          // if (files?.uploadProof[0].mimetype == 'application/pdf') {
          //   const blob=await addWatermarkPDFGCP(files?.uploadProof[0], osvDetails)
          //   // req.body.uploadAadharFront = await uploadFileToBlob(files?.uploadAadharFront[0].filename, 'application/pdf')
          //   let file= { originalname:files?.uploadProof[0].originalname, buffer: blob}
          //   // req.body.uploadAadharBack = await uploadFileToBlob(files?.uploadAadharBack[0].filename, 'application/pdf')
          //   req.body.uploadProof = await uploadImage(file)

          // }
          // else {
          //   var pdfFile = await imageToPDF(files?.uploadPAN[0])
          //   // await addWatermarkPDF(pdfFile.pdfFilePath, osvDetails);
          //   const blob=await addWatermarkPDFGCPForImg(pdfFile, osvDetails)
          //   // req.body.uploadAadharFront = await uploadFileToBlob(files?.uploadAadharFront[0].filename, 'application/pdf')
          //   let file= { originalname:files?.uploadPAN[0].originalname.split('.')[0]+".pdf", buffer: blob}
          //   req.body.uploadPAN = await uploadImage(file)
          // }
          req.body.uploadProof = await uploadImage(files.uploadProof[0])
          req.body.uploadProof = req.body.uploadProof.split('?')[0];
        }
        if (files?.recommendationLetter) {
          // if (files?.recommendationLetter[0].mimetype == 'application/pdf') {
          //   const blob=await addWatermarkPDFGCP(files?.recommendationLetter[0], osvDetails)
          //   // req.body.uploadAadharFront = await uploadFileToBlob(files?.uploadAadharFront[0].filename, 'application/pdf')
          //   let file= { originalname:files?.recommendationLetter[0].originalname, buffer: blob}
          //   // req.body.uploadAadharBack = await uploadFileToBlob(files?.uploadAadharBack[0].filename, 'application/pdf')
          //   req.body.recommendationLetter = await uploadImage(file)

          // }
          // else {
          //   var pdfFile = await imageToPDF(files?.recommendationLetter[0])
          //   // await addWatermarkPDF(pdfFile.pdfFilePath, osvDetails);
          //   const blob=await addWatermarkPDFGCPForImg(pdfFile, osvDetails)
          //   // req.body.uploadAadharFront = await uploadFileToBlob(files?.uploadAadharFront[0].filename, 'application/pdf')
          //   let file= { originalname:files?.recommendationLetter[0].originalname.split('.')[0]+".pdf", buffer: blob}
          //   req.body.recommendationLetter = await uploadImage(file)
          // }
          req.body.recommendationLetter = await uploadImage(files.recommendationLetter[0])
          req.body.recommendationLetter = req.body.recommendationLetter.split('?')[0];
        }
        if (files?.uploadCancelledCheque) {
        //   if (files?.uploadCancelledCheque[0].mimetype == 'application/pdf') {
        //     const blob=await addWatermarkPDFGCP(files?.uploadCancelledCheque[0], osvDetails)
        //     // req.body.uploadAadharFront = await uploadFileToBlob(files?.uploadAadharFront[0].filename, 'application/pdf')
        //     let file= { originalname:files?.uploadCancelledCheque[0].originalname, buffer: blob}
        //     // req.body.uploadAadharBack = await uploadFileToBlob(files?.uploadAadharBack[0].filename, 'application/pdf')
        //     req.body.uploadCancelledCheque = await uploadImage(file)

        //   }
        //   else {
        //     var pdfFile = await imageToPDF(files?.uploadCancelledCheque[0])
        //     // await addWatermarkPDF(pdfFile.pdfFilePath, osvDetails);
        //     const blob=await addWatermarkPDFGCPForImg(pdfFile, osvDetails)
        //     // req.body.uploadAadharFront = await uploadFileToBlob(files?.uploadAadharFront[0].filename, 'application/pdf')
        //     let file= { originalname:files?.uploadCancelledCheque[0].originalname.split('.')[0]+".pdf", buffer: blob}
        //     req.body.uploadCancelledCheque = await uploadImage(file)
        // }
        req.body.uploadCancelledCheque = await uploadImage(files.uploadCancelledCheque[0])
        req.body.uploadCancelledCheque = req.body.uploadCancelledCheque.split('?')[0];
      }
        if (files?.uploadIncomeProof) {
          // if (files?.uploadIncomeProof[0].mimetype == 'application/pdf') {
          //   const blob=await addWatermarkPDFGCP(files?.uploadIncomeProof[0], osvDetails)
          //   // req.body.uploadAadharFront = await uploadFileToBlob(files?.uploadAadharFront[0].filename, 'application/pdf')
          //   let file= { originalname:files?.uploadIncomeProof[0].originalname, buffer: blob}
          //   // req.body.uploadAadharBack = await uploadFileToBlob(files?.uploadAadharBack[0].filename, 'application/pdf')
          //   req.body.uploadIncomeProof = await uploadImage(file)

          // }
          // else {
          //   var pdfFile = await imageToPDF(files?.uploadIncomeProof[0])
          //   // await addWatermarkPDF(pdfFile.pdfFilePath, osvDetails);
          //   const blob=await addWatermarkPDFGCPForImg(pdfFile, osvDetails)
          //   // req.body.uploadAadharFront = await uploadFileToBlob(files?.uploadAadharFront[0].filename, 'application/pdf')
          //   let file= { originalname:files?.uploadIncomeProof[0].originalname.split('.')[0]+".pdf", buffer: blob}
          //   req.body.uploadIncomeProof = await uploadImage(file)
          // }
          req.body.uploadIncomeProof = await uploadImage(files.uploadIncomeProof[0])
          req.body.uploadIncomeProof = req.body.uploadIncomeProof.split('?')[0];
        }
        if (files?.uploadHospitalBill) {
          // if (files?.uploadHospitalBill[0].mimetype == 'application/pdf') {
          //   const blob=await addWatermarkPDFGCP(files?.uploadHospitalBill[0], osvDetails)
          //   // req.body.uploadAadharFront = await uploadFileToBlob(files?.uploadAadharFront[0].filename, 'application/pdf')
          //   let file= { originalname:files?.uploadHospitalBill[0].originalname, buffer: blob}
          //   // req.body.uploadAadharBack = await uploadFileToBlob(files?.uploadAadharBack[0].filename, 'application/pdf')
          //   req.body.uploadHospitalBill = await uploadImage(file)

          // }
          // else {
          //   var pdfFile = await imageToPDF(files?.uploadHospitalBill[0])
          //   // await addWatermarkPDF(pdfFile.pdfFilePath, osvDetails);
          //   const blob=await addWatermarkPDFGCPForImg(pdfFile, osvDetails)
          //   // req.body.uploadAadharFront = await uploadFileToBlob(files?.uploadAadharFront[0].filename, 'application/pdf')
          //   let file= { originalname:files?.uploadHospitalBill[0].originalname.split('.')[0]+".pdf", buffer: blob}
          //   req.body.uploadHospitalBill = await uploadImage(file)
          // }
          req.body.uploadHospitalBill = await uploadImage(files.uploadHospitalBill[0])
          req.body.uploadHospitalBill = req.body.uploadHospitalBill.split('?')[0];
        }
        if (files?.uploadBankStatement) {
          // if (files?.uploadBankStatement[0].mimetype == 'application/pdf') {
          //   const blob=await addWatermarkPDFGCP(files?.uploadBankStatement[0], osvDetails)
          //   // req.body.uploadAadharFront = await uploadFileToBlob(files?.uploadAadharFront[0].filename, 'application/pdf')
          //   let file= { originalname:files?.uploadBankStatement[0].originalname, buffer: blob}
          //   // req.body.uploadAadharBack = await uploadFileToBlob(files?.uploadAadharBack[0].filename, 'application/pdf')
          //   req.body.uploadBankStatement = await uploadImage(file)

          // }
          // else {
          //   var pdfFile = await imageToPDF(files?.uploadBankStatement[0])
          //   // await addWatermarkPDF(pdfFile.pdfFilePath, osvDetails);
          //   const blob=await addWatermarkPDFGCPForImg(pdfFile, osvDetails)
          //   // req.body.uploadAadharFront = await uploadFileToBlob(files?.uploadAadharFront[0].filename, 'application/pdf')
          //   let file= { originalname:files?.uploadBankStatement[0].originalname.split('.')[0]+".pdf", buffer: blob}
          //   req.body.uploadBankStatement = await uploadImage(file)
          // }
          req.body.uploadBankStatement = await uploadImage(files.uploadBankStatement[0])
          req.body.uploadBankStatement = req.body.uploadBankStatement.split('?')[0];
        }
        if (files?.uploadInsurancePolicy) {
          // if (files?.uploadInsurancePolicy[0].mimetype == 'application/pdf') {
          //   const blob=await addWatermarkPDFGCP(files?.uploadInsurancePolicy[0], osvDetails)
          //   // req.body.uploadAadharFront = await uploadFileToBlob(files?.uploadAadharFront[0].filename, 'application/pdf')
          //   let file= { originalname:files?.uploadInsurancePolicy[0].originalname, buffer: blob}
          //   // req.body.uploadAadharBack = await uploadFileToBlob(files?.uploadAadharBack[0].filename, 'application/pdf')
          //   req.body.uploadInsurancePolicy = await uploadImage(file)

          // }
          // else {
          //   var pdfFile = await imageToPDF(files?.uploadInsurancePolicy[0])
          //   // await addWatermarkPDF(pdfFile.pdfFilePath, osvDetails);
          //   const blob=await addWatermarkPDFGCPForImg(pdfFile, osvDetails)
          //   // req.body.uploadAadharFront = await uploadFileToBlob(files?.uploadAadharFront[0].filename, 'application/pdf')
          //   let file= { originalname:files?.uploadInsurancePolicy[0].originalname.split('.')[0]+".pdf", buffer: blob}
          //   req.body.uploadInsurancePolicy = await uploadImage(file)
          // }
          req.body.uploadInsurancePolicy = await uploadImage(files.uploadInsurancePolicy[0])
          req.body.uploadInsurancePolicy = req.body.uploadInsurancePolicy.split('?')[0];
        }
        if (files?.uploadOtherDoc) {
          // if (files?.uploadOtherDoc[0].mimetype == 'application/pdf') {
          //   const blob=await addWatermarkPDFGCP(files?.uploadOtherDoc[0], osvDetails)
          //   // req.body.uploadAadharFront = await uploadFileToBlob(files?.uploadAadharFront[0].filename, 'application/pdf')
          //   let file= { originalname:files?.uploadOtherDoc[0].originalname, buffer: blob}
          //   // req.body.uploadAadharBack = await uploadFileToBlob(files?.uploadAadharBack[0].filename, 'application/pdf')
          //   req.body.uploadOtherDoc = await uploadImage(file)

          // }
          // else {
          //   var pdfFile = await imageToPDF(files?.uploadOtherDoc[0])
          //   // await addWatermarkPDF(pdfFile.pdfFilePath, osvDetails);
          //   const blob=await addWatermarkPDFGCPForImg(pdfFile, osvDetails)
          //   // req.body.uploadAadharFront = await uploadFileToBlob(files?.uploadAadharFront[0].filename, 'application/pdf')
          //   let file= { originalname:files?.uploadOtherDoc[0].originalname.split('.')[0]+".pdf", buffer: blob}
          //   req.body.uploadOtherDoc = await uploadImage(file)
          // }
          req.body.uploadOtherDoc = await uploadImage(files.uploadOtherDoc[0])
          req.body.uploadOtherDoc = req.body.uploadOtherDoc.split('?')[0];
        }
        if (files?.uploadConsentDoc) {
          // if (files?.uploadConsentDoc[0].mimetype == 'application/pdf') {
          //   const blob=await addWatermarkPDFGCP(files?.uploadConsentDoc[0], osvDetails)
          //   // req.body.uploadAadharFront = await uploadFileToBlob(files?.uploadAadharFront[0].filename, 'application/pdf')
          //   let file= { originalname:files?.uploadConsentDoc[0].originalname, buffer: blob}
          //   // req.body.uploadAadharBack = await uploadFileToBlob(files?.uploadAadharBack[0].filename, 'application/pdf')
          //   req.body.uploadConsentDoc = await uploadImage(file)

          // }
          // else {
          //   var pdfFile = await imageToPDF(files?.uploadConsentDoc[0])
          //   // await addWatermarkPDF(pdfFile.pdfFilePath, osvDetails);
          //   const blob=await addWatermarkPDFGCPForImg(pdfFile, osvDetails)
          //   // req.body.uploadAadharFront = await uploadFileToBlob(files?.uploadAadharFront[0].filename, 'application/pdf')
          //   let file= { originalname:files?.uploadConsentDoc[0].originalname.split('.')[0]+".pdf", buffer: blob}
          //   req.body.uploadConsentDoc = await uploadImage(file)
          // }
          req.body.uploadConsentDoc = await uploadImage(files.uploadConsentDoc[0])
          req.body.uploadConsentDoc = req.body.uploadConsentDoc.split('?')[0];
        }
        if (files?.uploadCibil) {
          // if (files?.uploadCibil[0].mimetype == 'application/pdf') {
          //   const blob=await addWatermarkPDFGCP(files?.uploadCibil[0], osvDetails)
          //   // req.body.uploadAadharFront = await uploadFileToBlob(files?.uploadAadharFront[0].filename, 'application/pdf')
          //   let file= { originalname:files?.uploadCibil[0].originalname, buffer: blob}
          //   // req.body.uploadAadharBack = await uploadFileToBlob(files?.uploadAadharBack[0].filename, 'application/pdf')
          //   req.body.uploadCibil = await uploadImage(file)

          // }
          // else {
          //   var pdfFile = await imageToPDF(files?.uploadCibil[0])
          //   // await addWatermarkPDF(pdfFile.pdfFilePath, osvDetails);
          //   const blob=await addWatermarkPDFGCPForImg(pdfFile, osvDetails)
          //   // req.body.uploadAadharFront = await uploadFileToBlob(files?.uploadAadharFront[0].filename, 'application/pdf')
          //   let file= { originalname:files?.uploadCibil[0].originalname.split('.')[0]+".pdf", buffer: blob}
          //   req.body.uploadCibil = await uploadImage(file)
          // }
          req.body.uploadCibil = await uploadImage(files.uploadCibil[0])
          req.body.uploadCibil = req.body.uploadCibil.split('?')[0];
        }

        const { data } = await practoServiceInstance.editInvoice(
          req,
          req.currentUser as IUser,
          req.body as IPatientLoanDTO,
        );
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
  route.get(
    '/getProductByOrg',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('getProductByOrg: %o', req.body);
      try {
        const practoServiceInstance = Container.get(practoService);
        const { data } = await practoServiceInstance.getProductByOrg(req, res);
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
  route.get('/downloadConsentLetter',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('downloadConsentLetter: %o');
      try {
        const data = { success: true, consentDocUrl: process.env.consentDocUrl }
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
  route.get('/getAddressByPIN',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    celebrate({
      query: {
        pincode: Joi.string().required()
      },
    }),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('getAddressByPIN: %o', req.query);
      try {
        const practoServiceInstance = Container.get(practoService);
        const { success, message } = await practoServiceInstance.getAddressByPIN(req);
        return res.status(201).json({ success, message });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
  route.get('/getAllBanks',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    async (req: any, res: any, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('getAllBanks: %o', req.body);
      try {
        const practoServiceInstance = Container.get(practoService);
        const data = await practoServiceInstance.getAllBanks();
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    }
  );
  route.put('/updatePatientInvoice',                   //GCP Change
    // uploadBuffer.single('approvalLetter'),
    uploadBuffer.fields([
      { name: 'approvalLetter' },

    ]),
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    async (req: Request, res: Response, next: NextFunction) => {
      const files = req['files'] as { [fieldname: string]: Express.Multer.File[] };
      const logger: Logger = Container.get('logger');
      logger.debug('updatePatientInvoice: %o', req.body);
      try {
        const practoServiceInstance = Container.get(practoService);
        const osvDetails = await practoServiceInstance.getOSVDetails()

        if (files?.approvalLetter) {
          if (files?.approvalLetter[0].mimetype == 'application/pdf') {
            const blob=await addWatermarkPDFGCP(files?.approvalLetter[0], osvDetails)
            // req.body.uploadAadharFront = await uploadFileToBlob(files?.uploadAadharFront[0].filename, 'application/pdf')
            let file= { originalname:files?.approvalLetter[0].originalname, buffer: blob}
            req.body.approvalLetter = await uploadImage(file)
          }
          else {
            var pdfFile = await imageToPDF(files?.approvalLetter[0])
            // await addWatermarkPDF(pdfFile.pdfFilePath, osvDetails);
            const blob=await addWatermarkPDFGCPForImg(pdfFile, osvDetails)
            // req.body.approvalLetter = await uploadFileToBlob(files?.approvalLetter[0].filename, 'application/pdf')
            let file= { originalname:files?.approvalLetter[0].originalname.split('.')[0]+".pdf", buffer: blob}
            req.body.approvalLetter = await uploadImage(file)
            // req.body.approvalLetter = await uploadFileToBlob(pdfFile.pdfFileName, 'application/pdf')
          }
        }
     
        const { data } = await practoServiceInstance.updatePatientInvoice(
          req.currentUser as IUser,
          req.body as IPatientLoanDTO,
        );
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
  route.put('/updatePatientInvoice1',                  //GCP Change
    uploadBuffer.fields([
      { name: 'approvalLetter' },
      { name: 'finalBill' },

    ]),
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    async (req: Request, res: Response, next: NextFunction) => {
      const files = req['files'] as { [fieldname: string]: Express.Multer.File[] };
      const logger: Logger = Container.get('logger');
      logger.debug('updatePatientInvoice: %o', req.body);
      try {
        if (files?.approvalLetter) {
          req.body.approvalLetter = await uploadImage(files?.approvalLetter[0])
          req.body.approvalLetter = req.body.approvalLetter.split('?')[0];
        }
        if (files?.finalBill) {
          req.body.finalBill = await uploadImage(files?.finalBill[0])
          req.body.finalBill = req.body.finalBill.split('?')[0];
        }
        // if (files.approvalLetter) {
        //   req.body.approvalLetter = await uploadFileToBlob(files.approvalLetter[0].filename, files.approvalLetter[0].mimetype)
        //   req.body.approvalLetter = req.body.approvalLetter.split('?')[0];
        // }
        // if (files.finalBill) {
        //   req.body.uploadHospitalBill = await uploadFileToBlob(files.finalBill[0].filename, files.finalBill[0].mimetype)
        //   req.body.uploadHospitalBill = req.body.uploadHospitalBill.split('?')[0];
        // }
        const practoServiceInstance = Container.get(practoService);
        const { data } = await practoServiceInstance.updatePatientInvoice1(
          req.currentUser as IUser,
          req.body as IPatientLoanDTO,
        );
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );

  route.post('/uploadFinalBill',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    uploadBuffer.fields([{ name: "finalBill" }]),
    async (req: Request, res: Response, next: NextFunction) => {
      let files = req['files'] as { [fieldname: string]: Express.Multer.File[] };
      //let files = req.file
      const logger: Logger = Container.get('logger');
      logger.debug('uploadFinalBill: %o', req.query);
      try {
        console.log(req.files, "gdfdfgdfgdf");

        if (files.finalBill) {
          req.body.finalBill = await uploadImage(files.finalBill[0])
          req.body.finalBill = req.body.finalBill.split('?')[0];
        }
        // if (req.file) {
        //   req.body.uploadHospitalBill = await gc(req.file)
        //   req.body.uploadHospitalBill = req.body.uploadHospitalBill.split('?')[0];
        // }
        const practoServiceInstance = Container.get(practoService);
        const { success, message } = await practoServiceInstance.uploadFinalBill(
          req.currentUser as IUser,
          req.body as IPatientLoanDTO,
          req.body.finalBill
        );
        return res.status(201).json({ success, message });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
  route.post('/updateSettlement',                                //GCP Change
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    uploadBuffer.fields([
      { name: 'settlementLetter' }
    ]),
    async (req: Request, res: Response, next: NextFunction) => {
      const files = req['files'] as { [fieldname: string]: Express.Multer.File[] };
      const logger: Logger = Container.get('logger');
      logger.debug('updateSettlement: %o', req.body);
      try {

        if (files?.settlementLetter) {
          req.body.settlementLetter = await uploadImage(files?.settlementLetter[0])
          req.body.settlementLetter = req.body.settlementLetter.split('?')[0];
        }

        // req.body.settlementLetter = await uploadFileToBlob(req.file.filename, req.file.mimetype)
        // req.body.settlementLetter = req.body.settlementLetter.split('?')[0]

        const practoServiceInstance = Container.get(practoService);
        const { success, message } = await practoServiceInstance.updateSettlement(req.body as IPatientLoanDTO);
        return res.status(201).json({ success, message });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    }
  );
  route.get('/getOrgById',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    async (req: any, res: any, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('getOrgById: %o', req.query);
      try {
        const practoServiceInstance = Container.get(practoService);
        const data = await practoServiceInstance.getOrgById(req);
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    }
  )


  route.post('/gcpFileUpload',
    uploadBuffer.single('file'), async (req: any, res: any, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('gcpFileUpload: %o', req.query);

      try {
        const filedata = await gc(req.file);
        return res.status(200).json({ filedata })
      } catch (error) {
        logger.error('🔥 error: %o', error);
        return next(error);
      }
    })
  // agreement & mandate
  route.post('/createMandateForm',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    celebrate({
      body: Joi.object({
        _id: Joi.string().required()
      }),
    }),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('createMandateForm: %o', req.query);
      try {
        const practoServiceInstance = Container.get(practoService);
        const { success, message } = await practoServiceInstance.createMandateForm(req.body as IFilterDTO);
        return res.status(201).json({ success, message });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
  route.get('/sendAgreementPdf',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    celebrate({
      query: {
        _id: Joi.string().required()
      }
    }),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('sendAgreementPdf: %o', req.query);
      try {
        const practoServiceInstance = Container.get(practoService);
        const { success, message } = await practoServiceInstance.sendAgreementPdf(req.query as unknown as IFilterDTO)
        return res.status(201).json({ success, message });

      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
  route.post('/verifyBankAccount',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    celebrate({
      body: {
        _id: Joi.string().required(),
        borrowerName: Joi.string()
      }
    }),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('verifyBankAccount: %o', req.body);
      try {
        const practoServiceInstance = Container.get(practoService);
        const { success, message } = await practoServiceInstance.verifyBankAccount(req.body as IPatientLoanDTO)
        return res.status(201).json({ success, message });

      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );

route.get('/gcpFile',async(req:Request,res:Response)=>{

  
})

  route.use(errors());
};
