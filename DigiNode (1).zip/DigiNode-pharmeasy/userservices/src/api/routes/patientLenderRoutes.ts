import { Router, Request, Response, NextFunction } from 'express';
import { Container } from 'typedi';
import { IPatientLoanDTO, IUser, IFilterDTO } from '../../interfaces/IUser';
import { Logger, loggers } from 'winston';
import { celebrate, errors, Joi } from 'celebrate';
import DateExtension from '@joi/date';
const JoiDate = Joi.extend(DateExtension);
import patientLenderService from '../../services/patientLenderService';
import middlewares from '../middlewares';
import multer from 'multer';
import excelToJson from 'convert-excel-to-json';
import path from 'path';
import fs from 'fs';

const storage = multer.diskStorage({
    destination: './upload/',
    filename: function (req, file, cb) {
        cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
    },
});

const multerUpload = multer({
    storage: storage,
    limits: { fieldSize: 10 * 1024 * 1024 }
});


const route = Router();

export default (app: Router) => {
    app.use('/patient/Lender', route);
    route.get('/getDashboard',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        celebrate({
            query: {
                dateFrom: JoiDate.date().allow(null),
                dateTo: JoiDate.date().allow(null),
            },
        }),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('/patient/Lender/getDashboard: %o', req.query);
            try {
                const patientLenderServiceInstance = Container.get(patientLenderService);
                const { data } = await patientLenderServiceInstance.getDashboard(req, res);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.get('/getAllOrg',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        celebrate({
            query: {
                pageNumber: Joi.number().positive(),
                pageSize: Joi.number().positive(),
                searchTerm: Joi.string()
            },
        }),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('getAllOrg: %o', req.query);
            try {
                const patientLenderServiceInstance = Container.get(patientLenderService);
                const { data } = await patientLenderServiceInstance.getAllOrg(
                    req.query as unknown as IFilterDTO,
                    req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.get('/getAllInvoices',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        celebrate({
            query: {
                pageNumber: Joi.number().positive(),
                pageSize: Joi.number().positive(),
                filters: Joi.array(),
                isInsured: Joi.boolean(),
                invoiceStatus: Joi.string(),
                invoiceSubStatus: Joi.string(),
                dateFrom: JoiDate.date().format('YYYY-MM-DD'),
                dateTo: JoiDate.date().format('YYYY-MM-DD'),
                searchTerm: Joi.string(),
                organizationId: Joi.string()
            },
        }),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('getAllInvoices: %o', req.query);
            try {
                const patientLenderServiceInstance = Container.get(patientLenderService);
                const { data } = await patientLenderServiceInstance.getAllInvoices(
                    req.query as unknown as IFilterDTO,
                    req.currentUser as IUser);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.get('/getInvoiceById',
        middlewares.isAuth,
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('getInvoiceById: %o', req.body);
            try {
                const patientLenderServiceInstance = Container.get(patientLenderService);
                const { data } = await patientLenderServiceInstance.getInvoiceById(req, res);
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        }
    );
    route.put('/updatePatientInvoice',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        // celebrate({
        //     body: Joi.object({
        //         _id: Joi.string().required(),
        //         invoiceStatus: Joi.string().required().valid('Approved', 'Rejected', 'Request Additional Information'),
        //         lenderApprovedAmount: Joi.when('invoiceStatus', { is: 'Approved', then: Joi.number().required() }),
        //         lenderComment: Joi.when('invoiceStatus', {
        //             switch: [
        //                 { is: 'Rejected', then: Joi.string().required() },
        //                 { is: 'Request Additional Information', then: Joi.string().required() },
        //             ]
        //         }),
        //         loan_id: Joi.when('invoiceStatus', { not: 'Request Additional Information', then: Joi.string().required() }),
        //     }),
        // }),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('patientLender/updatePatientInvoice: %o', req.body);
            try {
                const patientLenderServiceInstance = Container.get(patientLenderService);
                const { data } = await patientLenderServiceInstance.updatePatientInvoice(
                    req.currentUser as IUser,
                    req.body as IPatientLoanDTO,
                );
                return res.status(201).json({ data });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.post('/updatePatientInvoiceByExcel',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        async (req: any, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('updatePatientInvoiceByExcel: %o');
            try {
                var dirPath;
                var updatedCount = 0;
                var failedCount = 0;
                var failedInvoiceIds = [];
                multerUpload.fields([{ name: 'uploadFile' }])(req, res, err => {
                    dirPath = './upload/' + req.files['uploadFile'][0].filename;

                    const excelData = excelToJson({
                        sourceFile: './upload/' + req.files['uploadFile'][0].filename,
                        sheets: [
                            {
                                name: 'Sheet1',
                                header: { rows: 1, },
                                columnToKey: { '*': '{{columnHeader}}' },
                            },
                        ],
                    });

                    if (!excelData.Sheet1.length) {
                        return res.status(400).json({
                            success: false,
                            error: 'Blank sheet not uploaded',
                        });
                    }

                    async function readExcel() {
                        try {
                            for (var i = 0; i < excelData.Sheet1.length; i++) {
                                logger.debug(excelData.Sheet1[i].invoiceId);

                                let invoiceId = excelData.Sheet1[i].invoiceId;
                                var emailId = excelData.Sheet1[i].emailId;
                                var contactNumber = excelData.Sheet1[i].contactNumber;
                                var lenderApprovedAmount = excelData.Sheet1[i]['Approved Amount'];
                                var lenderComment = excelData.Sheet1[i]['Comment'];
                                var invoiceSubStatus = excelData.Sheet1[i]['Status'];

                                if (invoiceSubStatus != 'Approved' && invoiceSubStatus != 'Rejected' && invoiceSubStatus != 'Request Additional Information') {
                                    failedCount++;
                                    failedInvoiceIds.push(`${invoiceId}:Invalid sub status ${invoiceSubStatus}`)
                                    continue;
                                }

                                if (!lenderApprovedAmount && !lenderComment) {
                                    failedCount++;
                                    failedInvoiceIds.push(`${invoiceId}:Incomplete data`)
                                    continue;
                                }

                                const usrObj: any = {
                                    invoiceId,
                                    emailId,
                                    contactNumber,
                                    lenderApprovedAmount,
                                    lenderComment,
                                    invoiceSubStatus,
                                };
                                if (invoiceSubStatus = 'Approved') {
                                    usrObj.invoiceSubStatus = 'Pending at Claim Processing Team';
                                    usrObj.invoiceStatus = 'InProcess'
                                }
                                else if (invoiceSubStatus = 'Rejected') {
                                    usrObj.invoiceSubStatus = 'Rejected by Lender';
                                    usrObj.invoiceStatus = 'Rejected'
                                }
                                else if (invoiceSubStatus = 'Request Additional Information') {
                                    usrObj.invoiceSubStatus = 'Additional Information requested by Lender';
                                    usrObj.invoiceStatus = 'Rejected'
                                }

                                const patientLenderServiceInstance = Container.get(patientLenderService);
                                const { success } = await patientLenderServiceInstance.updateInvoiceById(
                                    req.currentUser as IUser, usrObj as IPatientLoanDTO
                                );
                                logger.debug(success);
                                if (success) { updatedCount++; }
                                else { failedCount++; failedInvoiceIds.push(`${invoiceId}:Can not Update Invoice`) }
                            }
                            fs.unlinkSync('./upload/' + req.files['uploadFile'][0].filename);
                            var message = `${updatedCount} Invoice(s) updated, ${failedCount} failed`
                            if (failedCount != 0) { message = message + ` \n Failed Invoice Ids: ${failedInvoiceIds}` }
                            return res.status(200).json({ success: true, message: message });
                        } catch (error) {
                            return res.status(400).send({
                                success: false,
                                error,
                            });
                        }
                    }
                    readExcel();
                });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        }
    );
    route.put('/updateDisbursement',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        celebrate({
            body: Joi.object({
                _id: Joi.string().required(),
                invoiceSubStatus: Joi.string().required().valid('Disbursed', 'To be Disbursed'),
                Disbursed_Amount: Joi.number().required(),
                Disbursement_Date: JoiDate.date().format('YYYY-MM-DD').required(),
                UTRNumber: Joi.string().allow(null),
            }),
        }),
        async (req: Request, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('patientLender/updateDisbursement: %o', req.body);
            try {
                const patientLenderServiceInstance = Container.get(patientLenderService);
                const { success, message } = await patientLenderServiceInstance.updateDisbursement(
                    req.currentUser as IUser,
                    req.body as IPatientLoanDTO,
                );
                return res.status(201).json({ success, message });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        },
    );
    route.post('/updateDisbursementByExcel',
        middlewares.isAuth,
        middlewares.attachCurrentUser,
        async (req: any, res: Response, next: NextFunction) => {
            const logger: Logger = Container.get('logger');
            logger.debug('updateDisbursementByExcel: %o');
            try {
                var dirPath;
                var updatedCount = 0;
                var failedCount = 0;
                var failedInvoiceIds = [];
                multerUpload.fields([{ name: 'uploadFile' }])(req, res, err => {
                    dirPath = './upload/' + req.files['uploadFile'][0].filename;

                    const excelData = excelToJson({
                        sourceFile: './upload/' + req.files['uploadFile'][0].filename,
                        sheets: [
                            {
                                name: 'Sheet1',
                                header: { rows: 1, },
                                columnToKey: { '*': '{{columnHeader}}' },
                            },
                        ],
                    });

                    if (!excelData.Sheet1.length) {
                        return res.status(400).json({
                            success: false,
                            error: 'Blank sheet not uploaded',
                        });
                    }

                    async function readExcel() {
                        try {
                            for (var i = 0; i < excelData.Sheet1.length; i++) {
                                logger.debug(excelData.Sheet1[i].invoiceId);
                                if(excelData.Sheet1[i]['SubStatus'] == 'Disbursement Done' || excelData.Sheet1[i]['SubStatus'] == 'Done'){
                                    var invoiceStatus = 'Disbursed';
                                    var invoiceSubStatus = 'Disbursement Done'
                                  }
                                let invoiceId = excelData.Sheet1[i].invoiceId;
                                var contactNumber = excelData.Sheet1[i].contactNumber;
                                var Disbursement_Date = excelData.Sheet1[i]['Disbursement Date'];
                                var Disbursed_Amount = excelData.Sheet1[i]['Disbursement Amount'];
                                

                                // if (invoiceStatus != 'Disbursed' && invoiceStatus != "Approved" && invoiceStatus != "Rejected" && 
                                // invoiceStatus != "Pending" &&
                                // invoiceStatus != "Withdraw") {
                                //     failedCount++;
                                //     failedInvoiceIds.push(`${invoiceId}:Invalid sub status (${invoiceSubStatus})`)
                                //     continue;
                                // }
                                if (!Disbursement_Date || !Disbursed_Amount) {
                                    failedCount++;
                                    failedInvoiceIds.push(`${invoiceId}:Disbursement details missing`)
                                    continue;
                                }

                                const usrObj = {
                                    invoiceId,
                                    contactNumber,
                                    Disbursement_Date,
                                    Disbursed_Amount,
                                    invoiceStatus,
                                    invoiceSubStatus
                                };

                                const patientLenderServiceInstance = Container.get(patientLenderService);
                                const { success } = await patientLenderServiceInstance.
                                updateDisbursementById(
                                    req.currentUser as IUser, usrObj as IPatientLoanDTO
                                );
                                logger.debug(success);
                                if (success) { updatedCount++; }
                                else { failedCount++; failedInvoiceIds.push(`${invoiceId}:Can not Update Invoice`) }
                            }
                            fs.unlinkSync('./upload/' + req.files['uploadFile'][0].filename);
                            var message = `${updatedCount} Invoice(s) updated, ${failedCount} failed`
                            if (failedCount != 0) { message = message + ` \n Failed Invoice Ids: ${failedInvoiceIds}` }
                            return res.status(200).json({ success: true, message: message });
                        } catch (error) {
                            return res.status(400).send({
                                success: false,
                                error,
                            });
                        }
                    }
                    readExcel();
                });
            } catch (e) {
                logger.error('🔥 error: %o', e);
                return next(e);
            }
        }
    );
    route.use(errors());
};
