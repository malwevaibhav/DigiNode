import { Router, Request, Response, NextFunction, response } from 'express';
import { Container } from 'typedi';
import { IPatientLoanDTO, IUser, IFilterDTO, IPharmacyDTO, IVendorDTO ,purchaseFinancingDTO} from '../../interfaces/IUser';
import { Logger, loggers } from 'winston';
import { celebrate, errors, Joi } from 'celebrate';
import DateExtension from '@joi/date';
const JoiDate = Joi.extend(DateExtension);
import middlewares from '../middlewares';
import { PDFDocument, rgb, StandardFonts } from 'pdf-lib';
import { limits } from 'argon2';
import util from 'util';
import pharmaVendorService from '../../services/pharmaVendorService';
// const util = require('util')
const gc = require('../GCP/gcp');
const bucket = gc.bucket('digisparsh_images');

var multer = require('multer');
var path = require('path');
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/');
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
    cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
  },
});
const upload = multer({
  storage: storage,
  limits: { fieldSize: 10 * 1024 * 1024 },
});

// This is for google cloud platform!!
const storage_V2 = multer.memoryStorage();
const uploadBuffer = multer({
  storage: storage_V2,
  limits: { fieldSize: 10 * 1024 * 1024 },
});
var fs = require('fs');

const { BlobServiceClient } = require('@azure/storage-blob');
const containerName = 'uatcontainer';
const sasToken =
  'sv=2021-06-08&ss=bfqt&srt=sco&sp=rwdlacupiytfx&se=2024-02-20T16:47:15Z&st=2023-02-20T08:47:15Z&spr=https&sig=BDmeVstReLGKpmVAufC%2FKQd2afDfAPdO4LzQgdB1SXo%3D';
const storageAccountName = 'uatresource';
const key = 'uaEjdcwzjVO7U7qv/JFnOnsEXUxQHQ46zI4x+onZBXL9UPCLEfEk+xd0sMB0ZWmZGuRLXdxjDzBIUba3A5CUrw==';

const createBlobInContainer = async (containerClient, filename, mimetype) => {
  const blobClient = containerClient.getBlockBlobClient(filename);
  const options = { blobHTTPHeaders: { blobContentType: mimetype } };
  var a = await blobClient.uploadData(fs.readFileSync('uploads/' + filename), options);
  return blobClient.url;
};

const uploadFileToBlob = async (filename, mimetype) => {
  if (!filename || !mimetype) return [];
  const blobService = new BlobServiceClient(`https://${storageAccountName}.blob.core.windows.net/?${sasToken}`);
  const containerClient = blobService.getContainerClient(containerName);
  var response = await createBlobInContainer(containerClient, filename, mimetype);
  return response;
};

const uploadImage = file =>
  new Promise((resolve, reject) => {
    const { originalname, buffer } = file;

    const blob = bucket.file(originalname.replace(/ /g, '_'));
    const blobStream = blob.createWriteStream({
      resumable: false,
    });

    var blobb = blobStream.on('finish', () => {
  const publicUrl = util.format(`https://storage.googleapis.com/${bucket.name}/${blob.name}`);
        console.log(publicUrl);
        resolve(publicUrl);
      })
      .on('error', err => {
        reject(`Unable to upload image, something went wrong=>${err}`);
      })
      .end(buffer);
  });

const imageToPDF = async imageFile => {
  const imageBytes = fs.readFileSync(imageFile.buffer);
  const pdfDoc = await PDFDocument.create();
  var image;
  if (path.extname(imageFile.path) == '.png') {
    image = await pdfDoc.embedPng(imageBytes);
  } else {
    image = await pdfDoc.embedJpg(imageBytes);
  }

  const page = pdfDoc.addPage();
  var scale = (page.getWidth() * 0.8) / image.width;
  const jpgDims = image.scale(scale);

  page.drawImage(image, {
    x: page.getWidth() / 2 - jpgDims.width / 2,
    y: page.getHeight() / 2 - jpgDims.height / 2,
    width: jpgDims.width,
    height: jpgDims.height,
  });

  const pdfBytes = await pdfDoc.save();
  var pdfFilePath = imageFile.path.split('.')[0];
  var pdfFileName = imageFile.filename.split('.')[0] + 'PDF.pdf';
  fs.writeFileSync(pdfFilePath + 'PDF.pdf', pdfBytes);
  pdfFilePath = pdfFilePath + 'PDF.pdf';
  var pdfFile = { pdfFilePath, pdfFileName };
  return pdfFile;
};

const addWatermarkPDF = async (pdfFilePath, osvDetails) => {
  console.log(typeof pdfFilePath.buffer);
  const existingPdfBytes = pdfFilePath.buffer;
  const pdfDoc = await PDFDocument.load(existingPdfBytes as Uint8Array);
  const helveticaFont = await pdfDoc.embedFont(StandardFonts.Helvetica);

  const pages = pdfDoc.getPages();
  const firstPage = pages[0];
  const { width, height } = firstPage.getSize();

  firstPage.drawText(
    `Employee Name: ${osvDetails.osvEmpName}, Employee Id: ${osvDetails.osvEmpId} \n${
      new Date().toString().split('GMT')[0]
    } \n${osvDetails.osvEmpOrg}`,
    {
      x: 10,
      y: 60,
      size: 12,
      font: helveticaFont,
      color: rgb(0, 0, 0),
    },
  );

  const pdfBytes = await pdfDoc.save();
  return pdfBytes;
  fs.writeFileSync(pdfFilePath, pdfBytes);
};

const route = Router();
export default (app: Router) => {
  app.use('/pharmacy', route);

  route.get('/me', async (req: Request, res: Response, next: NextFunction) => {
    return res.status(200).json('Route is working');
  });
  route.get(
    '/getDashboardForVendor',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Pmanufacture'),
    middlewares.requiredProduct('purchaseFinancing'),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('getDashboardForVendor: %o', req.query);
      try {
        const vendorServiceInstance = Container.get(pharmaVendorService);
        const { data } = await vendorServiceInstance.getDashboardForVendor(req.currentUser as IUser);
        console.log(data,"gdgd");
        
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
  route.get('/getDashboardData',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Pmanufacture'),
    middlewares.requiredProduct('purchaseFinancing'),
    celebrate({
      query: {
        dateFrom: JoiDate.date().allow(null),
        dateTo: JoiDate.date().allow(null),
      },
    }),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('Pmanufacture getDashboardData: %o', req.query);
      try {
        const vendorServiceInstance = Container.get(pharmaVendorService);

        const { data } = await vendorServiceInstance.getDashboardData(req, res, req.currentUser as IUser);
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
  route.get(
    '/getInvoiceGraphToVendor',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Pmanufacture'),
    middlewares.requiredProduct('purchaseFinancing'),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('getInvoiceGraphToVendor: %o', req.query);
      try {
        const vendorServiceInstance = Container.get(pharmaVendorService);
        const { data } = await vendorServiceInstance.getInvoiceGraphToVendor(req.currentUser as IUser);
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
  route.get(
    '/getLApprovedInvoiceGraphToVendor',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Pmanufacture'),
    middlewares.requiredProduct('purchaseFinancing'),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('getLApprovedInvoiceGraphToVendor: %o', req.query);
      try {
        const vendorServiceInstance = Container.get(pharmaVendorService);
        const { data } = await vendorServiceInstance.getLApprovedInvoiceGraphToVendor(req.currentUser as IUser);
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
  route.get(
    '/getFundedInvoiceGraphToVendor',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Pmanufacture'),
    middlewares.requiredProduct('purchaseFinancing'),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('getFundedInvoiceGraphToVendor: %o', req.query);
      try {
        const vendorServiceInstance = Container.get(pharmaVendorService);
        const { data } = await vendorServiceInstance.getFundedInvoiceGraphToVendor(req.currentUser as IUser);
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
  route.get(
    '/getVendorGraphOne',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Pmanufacture'),
    middlewares.requiredProduct('purchaseFinancing'),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('getVendorGraphOne: %o', req.query);
      try {
        const vendorServiceInstance = Container.get(pharmaVendorService);
        const { data } = await vendorServiceInstance.getVendorGraphOne(req.currentUser as IUser);
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
  route.get(
    '/getLastPieGraphForVendor',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Pmanufacture'),
    middlewares.requiredProduct('purchaseFinancing'),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('getLastPieGraphForVendor: %o', req.query);
      try {
        const vendorServiceInstance = Container.get(pharmaVendorService);
        const { data } = await vendorServiceInstance.getLastPieGraphForVendor(req.currentUser as IUser);
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
  route.get(
    '/getSecondPieGraphForVendor',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Pmanufacture'),
    middlewares.requiredProduct('purchaseFinancing'),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('getSecondPieGraphForVendor: %o', req.query);
      try {
        const vendorServiceInstance = Container.get(pharmaVendorService);
        const { data } = await vendorServiceInstance.getSecondPieGraphForVendor(req.currentUser as IUser);
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
  route.get(
    '/getInvoicesToVendor',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Pmanufacture'),
    middlewares.requiredProduct('purchaseFinancing'),
    celebrate({
      query: {
        pageNumber: Joi.number().positive(),
        pageSize: Joi.number().positive(),
        filters: Joi.array(),
        Status: Joi.string(),
        searchTerm: Joi.string()
      },
    }),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('getInvoicesToVendor: %o', req.query);
      try {
        const vendorServiceInstance = Container.get(pharmaVendorService);
        const { data } = await vendorServiceInstance.getInvoicesToVendor(
          req.query as unknown as IFilterDTO,
          req.currentUser as IUser,
        );
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
  route.get(
    '/getInvoiceByIdToVendor',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Pmanufacture'),
    middlewares.requiredProduct('purchaseFinancing'),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('getInvoiceByIdToVendor: %o', req.query);
      try {
        const vendorServiceInstance = Container.get(pharmaVendorService);
        const { data } = await vendorServiceInstance.getInvoiceByIdToVendor(req.query as unknown as IFilterDTO);
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
  //edit vendor profile
  route.get(
    '/getVendorProfileToVendor',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Pmanufacture'),
    middlewares.requiredProduct('purchaseFinancing'),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('getVendorProfileToVendor: %o');
      try {
        const vendorServiceInstance = Container.get(pharmaVendorService);
        const { data } = await vendorServiceInstance.getVendorProfileToVendor(req.currentUser as IUser);
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
  route.put(
    '/EditVendorProfileByVendor',
    uploadBuffer.fields([
      { name: "ParriPassu" },
      { name: "LastTwoYrBank" },
      { name: "LastAudFin" },
      { name: "LastTwoFin" },
      { name: "RegCert" },
      { name: "GstCert" },
      { name: "AddrProof" },
      { name: "Other" },
    ]),
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Pmanufacture'),
    middlewares.requiredProduct('purchaseFinancing'),
    // celebrate({
    //   body: {
    //     name: Joi.string(),
    //     address: Joi.array().items(
    //       Joi.object().keys({
    //         street: Joi.string(),
    //         state: Joi.string(),
    //         city: Joi.string(),
    //         pinCode: Joi.number(),
    //         country: Joi.string(),
    //       }),
    //     ),
    //     mobileNumber: Joi.number(),
    //     GSTNumber: Joi.string(),
    //     PANNumber: Joi.string(),
    //     email: Joi.string(),
    //     VendorType: Joi.string(),
    //     bankName: Joi.string(),
    //     AccountNumber: Joi.string(),
    //     IFSCcode: Joi.any(),
    //     authorisedPersonName: Joi.string(),
    //     contactDetailsForAuthPerson: Joi.number(),
    //     PANNumberForAuthPerson: Joi.string(),
    //     relationShip: Joi.string(),
    //     RateOfDeduction: Joi.number(),
    //     NoOfDaysCreditPeriod: Joi.number(),
    //     HospitalName: Joi.string(),
    //     HospitalId: Joi.string(),
    //     KycDocument: Joi.string(),
    //     Other: Joi.string(),
    //     ParriPassu: Joi.string(),
    //     LastTwoYrBank: Joi.string(),
    //     LastAudFin: Joi.string(),
    //     LastTwoFin: Joi.string(),
    //     RegCert: Joi.string(),
    //     GstCert: Joi.string(),
    //     AddrProof: Joi.string(),

    //     authorizedPerson: Joi.string()
    //   },
    // }),
    async (req: Request, res: Response, next: NextFunction) => {
      let files = req['files'] as { [fieldname: string]: Express.Multer.File[] };
      const logger: Logger = Container.get('logger');
      logger.debug('EditVendorProfileByVendor: %o', req.body);
      try {

        if (files?.ParriPassu) {
          req.body.ParriPassu = await uploadImage(files.ParriPassu[0])
          req.body.ParriPassu = req.body.ParriPassu.split('?')[0];
        }

        if (files?.LastTwoYrBank) {
          req.body.LastTwoYrBank = await uploadImage(files.LastTwoYrBank[0])
          req.body.LastTwoYrBank = req.body.LastTwoYrBank.split('?')[0];
        }
        if (files?.LastAudFin) {
          req.body.LastAudFin = await uploadImage(files.LastAudFin[0])
          req.body.LastAudFin = req.body.LastAudFin.split('?')[0];
        }
        if (files?.LastTwoFin) {
          req.body.LastTwoFin = await uploadImage(files.LastTwoFin[0])
          req.body.LastTwoFin = req.body.LastTwoFin.split('?')[0];
        }
        if (files?.RegCert) {
          req.body.RegCert = await uploadImage(files.RegCert[0])
          req.body.RegCert = req.body.RegCert.split('?')[0];
        }
        if (files?.GstCert) {
          req.body.GstCert = await uploadImage(files.GstCert[0])
          req.body.GstCert = req.body.GstCert.split('?')[0];
        }
        if (files?.AddrProof) {
          req.body.AddrProof = await uploadImage(files.AddrProof[0])
          req.body.AddrProof = req.body.AddrProof.split('?')[0];
        }
        if (files?.Other) {
          req.body.Other = await uploadImage(files.Other[0])
          req.body.Other = req.body.Other.split('?')[0];
        }
        const vendorServiceInstance = Container.get(pharmaVendorService);
        const { data } = await vendorServiceInstance.EditVendorProfileByVendor(
          req.currentUser as IUser,
          req.body as IVendorDTO,
        );
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
  route.get(
    '/getAllHospitalToVendor',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Pmanufacture'),
    middlewares.requiredProduct('purchaseFinancing'),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('getAllHospital: %o', req.body);
      try {
        const vendorServiceInstance = Container.get(pharmaVendorService);
        const { data } = await vendorServiceInstance.getAllHospitalToVendor(req);
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    }
  )
  route.post( '/invoiceUploadToVendorWithDetails',
    uploadBuffer.fields([{ name: 'venderDocURL' }]),
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Pmanufacture'),
    middlewares.requiredProduct('purchaseFinancing'),
    // celebrate({
    //   body: {
    //     InvoiceAmount: Joi.number(),
    //     InvoiceNumber: Joi.number(),
    //     venderDocURL: Joi.string(),
    //     Description: Joi.string(),
    //     InvoiceDate: JoiDate.date(),
    //     DescriptionArr: Joi.string(),
    //     NameOfVendor: Joi.string(),
    //   },
    // }),
    async (req: Request, res: Response, next: NextFunction) => {
      let files = req['files'] as { [fieldname: string]: Express.Multer.File[] };
      const logger: Logger = Container.get('logger');
      logger.debug('invoiceUploadToVendorWithDetails: %o', req.body);
      try {
        if (files.venderDocURL) {
          req.body.venderDocURL = await uploadImage(files.venderDocURL[0]);
          req.body.venderDocURL = req.body.venderDocURL.split('?')[0];
        }
        const pharmaVendor = Container.get(pharmaVendorService);
        const { data } = await pharmaVendor.invoiceUploadToVendorWithDetails(
          req.currentUser as IUser,
          req.body as purchaseFinancingDTO,
        );
        return res.status(201).json({ data });
      } catch (e) {
        console.log('hit', e);

        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
  route.get(
    '/getAllDistributorToPmanufacture',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    middlewares.requiredOrg('Pmanufacture'),
    middlewares.requiredProduct('purchaseFinancing'),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('getAllHospitalToVendor: %o', req.body);
      try {
        const vendorServiceInstance = Container.get(pharmaVendorService);
        const { data } = await vendorServiceInstance.getAllDistributorToPmanufacture(req);
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
};
