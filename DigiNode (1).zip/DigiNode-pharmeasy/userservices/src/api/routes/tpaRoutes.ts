import { Router, Request, Response, NextFunction } from 'express';
import { Container } from 'typedi';
import { IUser, IFilterDTO, IVendorDTO, ISupplierInvoiceDTO } from '../../interfaces/IUser';
import { Logger, loggers } from 'winston';
import { celebrate, errors, Joi } from 'celebrate';
import DateExtension from '@joi/date';
const JoiDate = Joi.extend(DateExtension);
import { TpaInvoiceDTO } from '../../interfaces/IUser';
import tpaService from '../../services/tpaService';
import middlewares from '../middlewares';

const route = Router();

export default (app: Router) => {
  app.use('/tpa', route);

  route.get('/getTPA',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    celebrate({
        query: {
            pageNumber: Joi.number().positive(),
            pageSize:Joi.number().positive(),
            searchTerm: Joi.string(),
          },
        }),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('getTPA: %o', req.query);
      try {
        var body = req.query;
        const tpaServiceInstance = Container.get(tpaService);
        const { data } = await tpaServiceInstance.getTPA(body as any);
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );

  route.put('/deleteTPA',
    celebrate({
      query: {
        _id: Joi.string().required(),
      },
    }),
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('deleteTPA: %o', req.query);
      try {
        let id = req.query._id;
        const tpaServiceInstance = Container.get(tpaService);
        const { data } = await tpaServiceInstance.deleteTPA(id);
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );

  route.post('/addTPAwithInsurer',
    middlewares.isAuth,
    middlewares.attachCurrentUser,
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('addTPAwithInsurer: %o', req.body);
      try {
        let TpaInvoiceDTO = req.body;
        const tpaServiceInstance = Container.get(tpaService);
        const { data } = await tpaServiceInstance.addTPAwithInsurer(
          req.currentUser as IUser,
          req.body as TpaInvoiceDTO,
        );
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );

  route.get('/getTPAwithInsurer', async (req: Request, res: Response, next: NextFunction) => {
    const logger: Logger = Container.get('logger');
    logger.debug('getTPAwithInsurer: %o', req.query);
    try {
      var body = req.query;
      const tpaServiceInstance = Container.get(tpaService);
      const { data } = await tpaServiceInstance.getTPAwithInsurer(body);
      return res.status(201).json({ data });
    } catch (e) {
      logger.error('🔥 error: %o', e);
      return next(e);
    }
  });

  route.put(
    '/updateTPAwithInsurer',
    // middlewares.isAuth,
    // middlewares.attachCurrentUser,
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get('logger');
      logger.debug('updateTPAwithInsurer: %o', req.query);
      try {
        const insuranceServiceInstance = Container.get(tpaService);
        const { data } = await insuranceServiceInstance.updateTPAwithInsurer(req, res);
        return res.status(201).json({ data });
      } catch (e) {
        logger.error('🔥 error: %o', e);
        return next(e);
      }
    },
  );
};
