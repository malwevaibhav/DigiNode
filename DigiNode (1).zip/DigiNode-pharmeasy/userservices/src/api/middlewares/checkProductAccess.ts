import { Container } from 'typedi';
import mongoose from 'mongoose';
import { Organization } from '../../models/organizationSchema';
import { IUser } from '../../interfaces/IUser';

/**
 * Attach user to req.currentUser
 * @param {*} req Express req Object
 * @param {*} res  Express res Object
 * @param {*} next  Express next Function
 */

export default requiredProduct =>  {
  return async (req, res, next) =>  {

    const OrganizationModel = Container.get('organizationModel') as mongoose.Model<Organization & mongoose.Document>;
    const organizationRecord = await OrganizationModel.findOne({ _id: req.currentUser.organizationId });

    const UserModel = Container.get('userModel') as mongoose.Model<IUser & mongoose.Document>;
    const userRecord = await UserModel.findById(req.token._id);

    if(userRecord[requiredProduct] === true && organizationRecord[requiredProduct] === true) {
      return next();
    } else {
      console.log('requiredProduct Unauthorized');
      return res.status(401).end();
    }
  };
};
