import { Service, Inject } from 'typedi';
import { Request, Response } from 'express';
import { IUser, IFilterDTO, TpaInvoiceDTO } from '@/interfaces/IUser';
import { Types } from 'mongoose';
import moment from 'moment';
@Service()
export default class TPAMasterService {
  constructor(
    @Inject('TPAMasterModel') private TPAMasterModel: Models.TPAMasterModel,
    @Inject('logger') private logger,
  ) {}

  public async getTPA(body: any): Promise<{ data: any }> {
    try {
      var pageNumber = 1;
      var pageSize = 0;
      if (body.pageNumber) {
        var pageNumber = parseInt(body.pageNumber.toString());
      }
      if (body.pageSize) {
        var pageSize = parseInt(body.pageSize.toString());
      }
      var searchFilters = [];
      searchFilters.push({ isDeleted: false });
      if (body.searchTerm != undefined) {
        searchFilters.push({
          $or: [
            { TPACode: { $regex: body.searchTerm, $options: 'i' } },
            { TPAName: { $regex: body.searchTerm, $options: 'i' } },
            { nameOfInsurer: { $regex: body.searchTerm, $options: 'i' } }
          ]
        })
      }

      var userCount = await this.TPAMasterModel.find({$and: searchFilters}).count();
      var numberOfPages = pageSize === 0 ? 1 : Math.ceil(userCount / pageSize);
      var TPAlist = await this.TPAMasterModel.find({$and: searchFilters})
        .sort({ createdAt: -1 })
        .skip((pageNumber - 1) * pageSize)
        .limit(pageSize);
      return {
        data: {
          success: true,
          message: TPAlist,
          numberOfPages
        },
      };
    } catch (error) {
      console.log('signup error:', error);
      return { data: { success: false, error: error } };
    }
  }

  public async deleteTPA(id): Promise<{ data: any }> {
    try {
      const ID = id;
      const deleteUser = await this.TPAMasterModel.findByIdAndUpdate({ _id: ID }, {$set:{isDeleted: true}});
      return { data: { success: true, message: 'Delete User Successfully',deleteUser } };
    } catch (error) {
      console.log('error:', error);
      return {
        data: {
          success: false,
          error,
        },
      };
    }
  }

  public async addTPAwithInsurer(currentUser: IUser, TpaInvoiceDTO: TpaInvoiceDTO): Promise<{ data: any }> {
    try {
      const { nameOfInsurer, InsuranceCompanyId, TPAName, TPACode } = TpaInvoiceDTO;
      const userDetails = currentUser;
      const usrObj = { nameOfInsurer, InsuranceCompanyId, TPAName, TPACode };
      const newUser = new this.TPAMasterModel(usrObj);
      var saveUser = await newUser.save();
      return {
        data: {
          success: true,
          message: saveUser,
        },
      };
    } catch (error) {
      console.log(' error:', error);
      return { data: { success: false, error: error } };
    }
  }

  public async getTPAwithInsurer(id): Promise<{ data: any }> {
    try {
      const ID = id;
      const TPA = await this.TPAMasterModel.find({ InsuranceCompanyId: ID });

      return {
        data: {
          success: true,
          message: TPA,
        },
      };
    } catch (error) {
      console.log('signup error:', error);
      return { data: { success: false, error: error } };
    }
  }

  public async updateTPAwithInsurer(req: Request, res: Response): Promise<{ data: any }> {
    try {
      const TPAID = req.query._id;
      const { nameOfInsurer, InsuranceCompanyId, TPAName, TPACode } = req.body;

      let data: any = {};
      if (TPAName) {
        data.TPAName = TPAName;
      }
      if (TPACode) {
        data.TPACode = TPACode;
      }

      if (nameOfInsurer) {
        data.nameOfInsurer = nameOfInsurer;
      }
      if (InsuranceCompanyId) {
        data.InsuranceCompanyId = InsuranceCompanyId;
      }

      const updateTPA = await this.TPAMasterModel.updateOne(
        { _id: TPAID },
        { $set: data },
        { useFindAndModify: false },
      );

      let dataTPAModel: any = {};

      if (nameOfInsurer) {
        dataTPAModel.nameOfInsurer = nameOfInsurer;
      }

      const updateInsurer = await this.TPAMasterModel.updateOne(
        { _id: InsuranceCompanyId },
        { $set: dataTPAModel },
        { useFindAndModify: false },
      );

      return {
        data: {
          success: true,
          message: 'Data Update Succefully',
        },
      };
    } catch (err) {
      return { data: 'Error: ' + err };
    }
  }
}
