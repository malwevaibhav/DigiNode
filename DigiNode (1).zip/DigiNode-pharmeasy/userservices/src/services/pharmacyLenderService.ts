import { errors } from 'celebrate';
import { Service, Inject } from 'typedi';
import { Request, Response, query } from 'express';
import { EventDispatcher, EventDispatcherInterface } from '../decorators/eventDispatcher';
import { IUser, IUserInputDTO, IFilterDTO } from '../interfaces/IUser';
import argon2 from 'argon2';
import MailerService from './mailer';
import { randomBytes } from 'crypto';
import events from '../subscribers/events';
import { Types } from 'mongoose';
import moment from 'moment';
@Service()
export default class supplierLenderService {
  constructor(
    @Inject('userModel') private userModel: Models.UserModel,
    @Inject('organizationModel') private organizationModel: Models.organizationModel,
    // @Inject('DPAssociationModel') private DPAssociationModel: Models.DPAssociationModel,
    @Inject('DPAssociationModel') private DPAssociationModel: Models.DPAssociationModel,
    // @Inject('PharmacyModel') private PharmacyModel: Models.SupplierInvoiceModel,
    @Inject('PharmacyModel') private PharmacyModel: Models.PharmacyModel,
    @Inject('businessLogics') private businessLogicsModel: Models.businessLogicsModel,
    @Inject('TransactionDataModel') private TransactionData: Models.TransactionDataModel,
    @Inject('logger') private logger,
    @EventDispatcher() private eventDispatcher: EventDispatcherInterface,
    private mailer: MailerService,
  ) { }

  public async getDashboardForSupplierLender(currentUser: IUser): Promise<{ data: any }> {
    try {
      const userDetails = currentUser;

      const hosdatas: any = await this.organizationModel.find({
        $and: [{ LenderId: userDetails.organizationId }, { typeOfOrganization: 'Hospital' }],
      });
      var AllVendor = 0;
      for (var hospital of hosdatas) {
        const vendatas: any = await this.DPAssociationModel.find({ hospitalId: hospital._id });
        AllVendor = AllVendor + vendatas.length
      }

      var TotalRepaymentsLimit = 0;
      var TotalinvoicesCount = 0;
      var TotalInvoicesAmount = 0;
      var TotalfundedCount = 0;
      var TotalRepaidCount = 0;
      var TotalPendingCount = 0;
      var TotalPendingAmount = 0;
      var TotalRejctedAmount = 0;
      var TotalrejctedCount = 0;
      var TotalfundedPaidAmount = 0;
      if (hosdatas) {
        var AllHospital = hosdatas.length;
      }

      var TotalPendingInvoiceAmount = 0;

      const everyData = await this.PharmacyModel.aggregate([
        {
          $facet: {
            invoicedataSum: [
              {
                $match: {
                  $and: [
                    { LenderId: userDetails.organizationId },
                    {
                      $or: [
                        { Status: "Pending" },
                        { Status: "DSPL Approved" },
                        { Status: "DSPL Rejected" },
                        { Status: "Hospital Approved" },
                        { Status: "Hospital Rejected" },
                        { Status: "Lender Approved" },
                        { Status: "Lender Rejected" },
                        { Status: "Disbursed" },
                        { Status: "Fully Repaid" },
                        { Status: "Hospital Repaid" },
                        { Status: "Partially Repaid" }
                      ],
                    },
                  ],
                },
              },
              { $group: { _id: '$_v', total: { $sum: '$LTVAmount' } } },
            ],
            invoicedataCount: [
              {
                $match: {
                  $and: [
                    { LenderId: userDetails.organizationId },
                    {
                      $or: [
                        { Status: "Pending" },
                        { Status: "DSPL Approved" },
                        { Status: "DSPL Rejected" },
                        { Status: "Hospital Approved" },
                        { Status: "Hospital Rejected" },
                        { Status: "Lender Approved" },
                        { Status: "Lender Rejected" },
                        { Status: "Disbursed" },
                        { Status: "Fully Repaid" },
                        { Status: "Hospital Repaid" },
                        { Status: "Partially Repaid" }
                      ],
                    },
                  ],
                },
              },
              { $count: 'total' },
            ],
            fundedSum: [
              {
                $match: {
                  $and: [
                    { LenderId: userDetails.organizationId },
                    { $or: [{ Status: "Disbursed" }, { Status: "Fully Repaid" }, { Status: "Hospital Repaid" }, { Status: "Partially Repaid" }] },
                  ],
                },
              },
              { $group: { _id: '$_v', total: { $sum: '$LTVAmount' } } },
            ],
            fundedCount: [
              {
                $match: {
                  $and: [
                    { LenderId: userDetails.organizationId },
                    { $or: [{ Status: "Disbursed" }, { Status: "Fully Repaid" }, { Status: "Hospital Repaid" }, { Status: "Partially Repaid" }] },
                  ],
                },
              },
              { $count: 'total' },
            ],
            repaidSum: [
              {
                $match: {
                  $and: [
                    { LenderId: userDetails.organizationId },
                    { Status: "Fully Repaid" },
                  ],
                },
              },
              { $group: { _id: '$_v', total: { $sum: '$LTVAmount' } } },
            ],
            repaidCount: [
              {
                $match: {
                  $and: [
                    { LenderId: userDetails.organizationId },
                    { Status: "Fully Repaid" },
                  ],
                },
              },
              { $count: 'total' },
            ],
          },
        },
      ]);

      if (everyData[0].invoicedataSum[0] != undefined) {
        TotalInvoicesAmount += everyData[0].invoicedataSum[0].total;
      } else {
        TotalInvoicesAmount += 0;
      }
      if (everyData[0].invoicedataCount[0] != undefined) {
        TotalinvoicesCount += everyData[0].invoicedataCount[0].total;
      } else {
        TotalinvoicesCount += 0;
      }
      if (everyData[0].fundedSum[0] != undefined) {
        TotalfundedPaidAmount += everyData[0].fundedSum[0].total;
      } else {
        TotalfundedPaidAmount += 0;
      }
      if (everyData[0].fundedCount[0] != undefined) {
        TotalfundedCount += everyData[0].fundedCount[0].total;
      } else {
        TotalfundedCount += 0;
      }
      if (everyData[0].repaidSum[0] != undefined) {
        TotalRepaymentsLimit += everyData[0].repaidSum[0].total;
      } else {
        TotalRepaymentsLimit += 0;
      }
      if (everyData[0].repaidCount[0] != undefined) {
        TotalRepaidCount += everyData[0].repaidCount[0].total;
      } else {
        TotalRepaidCount += 0;
      }


      return {
        data: {
          success: true,
          TotalVendor: AllVendor,
          TotalHospital: AllHospital,
          TotalRepaymentsLimit: TotalRepaymentsLimit,
          TotalinvoicesCount: TotalinvoicesCount,
          TotalInvoicesAmount: TotalInvoicesAmount,
          TotalRepaidCount: TotalRepaidCount,
          TotalfundedCount: TotalfundedCount,
          TotalfundedPaidAmount: TotalfundedPaidAmount,
        },
      };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  public async getDashboardData(req: Request, res: Response, currentUser: IUser): Promise<{ data: any }> {
    try {
      var searchFilters = [];
      searchFilters.push({ isDeleted: false });
      searchFilters.push({ LenderId: currentUser.organizationId });

      if (req.query.dateFrom != undefined || null && req.query.dateTo != undefined || null) {
        searchFilters.push({ createdAt: { $gte: req.query.dateFrom, $lte: req.query.dateTo } });
      }
      var dashboardData = await this.PharmacyModel.aggregate([
        {
          $facet: {
            totalCount: [{ $match: { $and: searchFilters } }, { $count: 'total' }],
            totalAmount: [
              { $match: { $and: searchFilters } },
              { $group: { _id: '$_v', total: { $sum: '$LTVAmount' } } },
            ],

            totalInProcessCount: [{
              $match: {
                $and: [{ $and: searchFilters }, {
                  $or: [
                    { Status: "Pending" },
                    { Status: "Hospital Approved" },
                    { Status: "Lender Approved" },
                    { Status: "DSPL Approved" }
                  ],
                },],
              },
            },
            { $count: 'total' },
            ],

            totalInProcessAmount: [{
              $match: {
                $and: [{ $and: searchFilters }, {
                  $or: [
                    { Status: "Pending" },
                    { Status: "Hospital Approved" },
                    { Status: "Lender Approved" },
                    { Status: "DSPL Approved" }
                  ],
                },],
              },
            },
            { $group: { _id: '$_v', total: { $sum: '$LTVAmount' } } },
            ],

            totalFundedCount: [{
              $match: {
                $and: [{ $and: searchFilters }, {
                  $or: [
                    { Status: "Disbursed" },
                    { Status: "Fully Repaid" },
                    { Status: "Hospital Repaid" },
                    { Status: "Partially Repaid" }
                  ],
                },],
              }
            }, { $count: 'total' }],

            totalFundedAmount: [{
              $match: {
                $and: [{ $and: searchFilters }, {
                  $or: [
                    { Status: "Disbursed" },
                    { Status: "Fully Repaid" },
                    { Status: "Hospital Repaid" },
                    { Status: "Partially Repaid" }
                  ],
                },],
              }
            },
            { $group: { _id: '$_v', total: { $sum: '$LTVAmount' } } },
            ],

            totalRepaidCount: [{ $match: { Status: 'Fully Repaid', $and: searchFilters } }, { $count: 'total' }],

            totalRepaidAmount: [
              { $match: { Status: 'Fully Repaid', $and: searchFilters } },
              { $group: { _id: '$_v', total: { $sum: '$LTVAmount' } } },
            ],

            totalRejectedCount: [{
              $match: {
                $and: [{ $and: searchFilters }, {
                  $or: [
                    { Status: "Hospital Rejected" },
                    { Status: "Lender Rejected" },
                    { Status: "DSPL Rejected" }
                  ],
                },],
              },
            }, { $count: 'total' }
            ],

            totalRejectedAmount: [{
              $match: {
                $and: [{ $and: searchFilters }, {
                  $or: [
                    { Status: "Hospital Rejected" },
                    { Status: "Lender Rejected" },
                    { Status: "DSPL Rejected" }
                  ],
                },],
              },
            },
            { $group: { _id: '$_v', total: { $sum: '$LTVAmount' } } },
            ]
          },
        },
      ]);

      var totalCount = 0;
      var totalAmount = 0;
      var totalInProcessCount = 0;
      var totalInProcessAmount = 0;
      var totalRejectedCount = 0;
      var totalRejectedAmount = 0;
      var totalFundedCount = 0;
      var totalFundedAmount = 0;
      var totalRepaidCount = 0;
      var totalRepaidAmount = 0;

      if (dashboardData[0].totalCount[0] != undefined) { totalCount = dashboardData[0].totalCount[0].total; } else { totalCount = 0; }
      if (dashboardData[0].totalAmount[0] != undefined) { totalAmount = dashboardData[0].totalAmount[0].total; } else { totalAmount = 0; }

      if (dashboardData[0].totalInProcessCount[0] != undefined) { totalInProcessCount = dashboardData[0].totalInProcessCount[0].total; } else { totalInProcessCount = 0; }
      if (dashboardData[0].totalInProcessAmount[0] != undefined) { totalInProcessAmount = dashboardData[0].totalInProcessAmount[0].total; } else { totalInProcessAmount = 0; }

      if (dashboardData[0].totalFundedCount[0] != undefined) { totalFundedCount = dashboardData[0].totalFundedCount[0].total; } else { totalFundedCount = 0; }
      if (dashboardData[0].totalFundedAmount[0] != undefined) { totalFundedAmount = dashboardData[0].totalFundedAmount[0].total; } else { totalFundedAmount = 0; }

      if (dashboardData[0].totalRepaidCount[0] != undefined) { totalRepaidCount = dashboardData[0].totalRepaidCount[0].total; } else { totalRepaidCount = 0; }
      if (dashboardData[0].totalRepaidAmount[0] != undefined) { totalRepaidAmount = dashboardData[0].totalRepaidAmount[0].total; } else { totalRepaidAmount = 0; }

      if (dashboardData[0].totalRejectedCount[0] != undefined) { totalRejectedCount = dashboardData[0].totalRejectedCount[0].total; } else { totalRejectedCount = 0; }
      if (dashboardData[0].totalRejectedAmount[0] != undefined) { totalRejectedAmount = dashboardData[0].totalRejectedAmount[0].total; } else { totalRejectedAmount = 0; }

      var data = {
        totalCount: totalCount,
        totalAmount: totalAmount,
        totalInProcessCount: totalInProcessCount,
        totalInProcessAmount: totalInProcessAmount,
        totalFundedCount: totalFundedCount,
        totalFundedAmount: totalFundedAmount,
        totalRepaidCount: totalRepaidCount,
        totalRepaidAmount: totalRepaidAmount,
        totalRejectedCount: totalRejectedCount,
        totalRejectedAmount: totalRejectedAmount
      }
      return { data };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  public async getFundedInvoiceGraphToSupplierLender(currentUser: IUser): Promise<{ data: any }> {
    try {
      const userDetails = currentUser;

      var sum1 = 0;
      var sum2 = 0;
      var sum3 = 0;
      var sum4 = 0;
      var sum5 = 0;
      var sum6 = 0;
      var forcalc = new Date();
      var thismonth = forcalc.getMonth() + 1;
      var t = forcalc.getFullYear();
      var this1 = new Date(t, thismonth - 1, 1);

      var month1 = forcalc.getMonth();
      if (month1 < 0) {
        month1 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month1);
      var a = forcalc.getFullYear();
      var d1m1 = new Date(a, month1 - 1, 1);
      var laster1 = new Date(a, month1, 0);
      laster1.setHours(23, 59, 59, 0);
      if (month1 <= 0) {
        month1 += 12;
        a = a - 1
      }

      var month2 = forcalc.getMonth() - 1;
      if (month2 < 0) {
        month2 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month2);
      var b = forcalc.getFullYear();
      var d1m2 = new Date(b, month2 - 1, 1);
      var laster2 = new Date(b, month2, 0);
      laster2.setHours(23, 59, 59, 0);
      if (month2 <= 0) {
        month2 += 12;
        b = b - 1
      }

      var month3 = forcalc.getMonth() - 1;
      if (month3 < 0) {
        month3 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month3);
      var c = forcalc.getFullYear();
      var d1m3 = new Date(c, month3 - 1, 1);
      var laster3 = new Date(c, month3, 0);
      laster3.setHours(23, 59, 59, 0);
      if (month3 <= 0) {
        month3 += 12;
        c = c - 1
      }

      var month4 = forcalc.getMonth() - 1;
      if (month4 < 0) {
        month4 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month4);
      var d = forcalc.getFullYear();
      var d1m4 = new Date(d, month4 - 1, 1);
      var laster4 = new Date(d, month4, 0);
      laster4.setHours(23, 59, 59, 0);
      if (month4 <= 0) {
        month4 += 12;
        d = d - 1
      }

      var month5 = forcalc.getMonth() - 1;
      if (month5 < 0) {
        month5 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month5);
      var e = forcalc.getFullYear();
      var d1m5 = new Date(e, month5 - 1, 1);
      var laster5 = new Date(e, month5, 0);
      laster5.setHours(23, 59, 59, 0);
      if (month5 <= 0) {
        month5 += 12;
        e = e - 1
      }
      var todaydate = new Date();

      var countser2 = await this.PharmacyModel.aggregate([
        {
          $facet: {
            sumone: [

              {
                $match: {
                  $and: [
                    { LenderId: userDetails.organizationId },
                    { PaymentDate: { $gte: this1, $lte: todaydate } },
                    { $or: [{ Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Fully Repaid" }, { Status: "Partially Repaid" }] },
                  ],
                },
              },
              { $group: { _id: '$_v', total: { $sum: '$LTVAmount' } } },
            ],
            sumtwo: [
              {
                $match: {
                  $and: [
                    { LenderId: userDetails.organizationId },
                    { PaymentDate: { $gte: d1m1, $lte: laster1 } },
                    { $or: [{ Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Fully Repaid" }, { Status: "Partially Repaid" }] },
                  ],
                },
              },
              { $group: { _id: '$_v', total: { $sum: '$LTVAmount' } } },
            ],
            sumthree: [
              {
                $match: {
                  $and: [
                    { LenderId: userDetails.organizationId },
                    { PaymentDate: { $gte: d1m2, $lte: laster2 } },
                    { $or: [{ Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Fully Repaid" }, { Status: "Partially Repaid" }] },
                  ],
                },
              },
              { $group: { _id: '$_v', total: { $sum: '$LTVAmount' } } },
            ],
            sumfour: [
              {
                $match: {
                  $and: [
                    { LenderId: userDetails.organizationId },
                    { PaymentDate: { $gte: d1m3, $lte: laster3 } },
                    { $or: [{ Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Fully Repaid" }, { Status: "Partially Repaid" }] },
                  ],
                },
              },
              { $group: { _id: '$_v', total: { $sum: '$LTVAmount' } } },
            ],
            sumfive: [
              {
                $match: {
                  $and: [
                    { LenderId: userDetails.organizationId },
                    { PaymentDate: { $gte: d1m4, $lte: laster4 } },
                    { $or: [{ Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Fully Repaid" }, { Status: "Partially Repaid" }] },
                  ],
                },
              },
              { $group: { _id: '$_v', total: { $sum: '$LTVAmount' } } },
            ],
            sumsix: [
              {
                $match: {
                  $and: [
                    { LenderId: userDetails.organizationId },
                    { PaymentDate: { $gte: d1m5, $lte: laster5 } },
                    { $or: [{ Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Fully Repaid" }, { Status: "Partially Repaid" }] },
                  ],
                },
              },
              { $group: { _id: '$_v', total: { $sum: '$LTVAmount' } } },
            ],
          },
        },
      ]);

      if (countser2[0].sumone[0] != undefined) {
        sum1 = countser2[0].sumone[0].total;
      } else {
        sum1 = 0;
      }
      if (countser2[0].sumtwo[0] != undefined) {
        sum2 = countser2[0].sumtwo[0].total;
      } else {
        sum2 = 0;
      }
      if (countser2[0].sumthree[0] != undefined) {
        sum3 = countser2[0].sumthree[0].total;
      } else {
        sum3 = 0;
      }
      if (countser2[0].sumfour[0] != undefined) {
        sum4 = countser2[0].sumfour[0].total;
      } else {
        sum4 = 0;
      }
      if (countser2[0].sumfive[0] != undefined) {
        sum5 = countser2[0].sumfive[0].total;
      } else {
        sum5 = 0;
      }
      if (countser2[0].sumsix[0] != undefined) {
        sum6 = countser2[0].sumsix[0].total;
      } else {
        sum6 = 0;
      }

      return {
        data: {
          success: true,
          message: [
            [sum1, thismonth, t],
            [sum2, month1, a],
            [sum3, month2, b],
            [sum4, month3, c],
            [sum5, month4, d],
            [sum6, month5, e],
          ],
        },
      };
    } catch (e) {
      this.logger.errors(e);
      throw e;
    }
  }
  public async getLApprovedInvoiceGraphToLender(currentUser: IUser): Promise<{ data: any }> {
    try {
      const userDetails = currentUser;

      var sum1 = 0;
      var sum2 = 0;
      var sum3 = 0;
      var sum4 = 0;
      var sum5 = 0;
      var sum6 = 0;
      var forcalc = new Date();
      var thismonth = forcalc.getMonth() + 1;
      var t = forcalc.getFullYear();
      var this1 = new Date(t, thismonth - 1, 1);

      var month1 = forcalc.getMonth();
      if (month1 < 0) {
        month1 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month1);
      var a = forcalc.getFullYear();
      var d1m1 = new Date(a, month1 - 1, 1);
      var laster1 = new Date(a, month1, 0);
      laster1.setHours(23, 59, 59, 0);
      if (month1 <= 0) {
        month1 += 12;
        a = a - 1
      }

      var month2 = forcalc.getMonth() - 1;
      if (month2 < 0) {
        month2 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month2);
      var b = forcalc.getFullYear();
      var d1m2 = new Date(b, month2 - 1, 1);
      var laster2 = new Date(b, month2, 0);
      laster2.setHours(23, 59, 59, 0);
      if (month2 <= 0) {
        month2 += 12;
        b = b - 1
      }

      var month3 = forcalc.getMonth() - 1;
      if (month3 < 0) {
        month3 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month3);
      var c = forcalc.getFullYear();
      var d1m3 = new Date(c, month3 - 1, 1);
      var laster3 = new Date(c, month3, 0);
      laster3.setHours(23, 59, 59, 0);
      if (month3 <= 0) {
        month3 += 12;
        c = c - 1
      }

      var month4 = forcalc.getMonth() - 1;
      if (month4 < 0) {
        month4 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month4);
      var d = forcalc.getFullYear();
      var d1m4 = new Date(d, month4 - 1, 1);
      var laster4 = new Date(d, month4, 0);
      laster4.setHours(23, 59, 59, 0);
      if (month4 <= 0) {
        month4 += 12;
        d = d - 1
      }

      var month5 = forcalc.getMonth() - 1;
      if (month5 < 0) {
        month5 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month5);
      var e = forcalc.getFullYear();
      var d1m5 = new Date(e, month5 - 1, 1);
      var laster5 = new Date(e, month5, 0);
      laster5.setHours(23, 59, 59, 0);
      if (month5 <= 0) {
        month5 += 12;
        e = e - 1
      }


      var todaydate = new Date();

      var countser2 = await this.PharmacyModel.aggregate([
        {
          $facet: {
            sumone: [
              {
                $match: {
                  $and: [
                    { LenderId: userDetails.organizationId },
                    { InvoiceDate: { $gte: this1, $lte: todaydate } },
                    {
                      $or: [{ Status: "Lender Approved" }, { Status: "Fully Repaid" }, { Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Partially Repaid" }],
                    },
                  ],
                },
              },
              { $group: { _id: '$_v', total: { $sum: '$LTVAmount' } } },
            ],
            sumtwo: [
              {
                $match: {
                  $and: [
                    { LenderId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m1, $lte: laster1 } },
                    {
                      $or: [{ Status: "Lender Approved" }, { Status: "Fully Repaid" }, { Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Partially Repaid" }],
                    },
                  ],
                },
              },
              { $group: { _id: '$_v', total: { $sum: '$LTVAmount' } } },
            ],
            sumthree: [
              {
                $match: {
                  $and: [
                    { LenderId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m2, $lte: laster2 } },
                    {
                      $or: [{ Status: "Lender Approved" }, { Status: "Fully Repaid" }, { Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Partially Repaid" }],
                    },
                  ],
                },
              },
              { $group: { _id: '$_v', total: { $sum: '$LTVAmount' } } },
            ],
            sumfour: [
              {
                $match: {
                  $and: [
                    { LenderId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m3, $lte: laster3 } },
                    {
                      $or: [{ Status: "Lender Approved" }, { Status: "Fully Repaid" }, { Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Partially Repaid" }],
                    },
                  ],
                },
              },
              { $group: { _id: '$_v', total: { $sum: '$LTVAmount' } } },
            ],
            sumfive: [
              {
                $match: {
                  $and: [
                    { LenderId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m4, $lte: laster4 } },
                    {
                      $or: [{ Status: "Lender Approved" }, { Status: "Fully Repaid" }, { Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Partially Repaid" }],
                    },
                  ],
                },
              },
              { $group: { _id: '$_v', total: { $sum: '$LTVAmount' } } },
            ],
            sumsix: [
              {
                $match: {
                  $and: [
                    { LenderId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m5, $lte: laster5 } },
                    {
                      $or: [{ Status: "Lender Approved" }, { Status: "Fully Repaid" }, { Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Partially Repaid" }],
                    },
                  ],
                },
              },
              { $group: { _id: '$_v', total: { $sum: '$LTVAmount' } } },
            ],
          },
        },
      ]);

      if (countser2[0].sumone[0] != undefined) {
        sum1 = countser2[0].sumone[0].total;
      } else {
        sum1 = 0;
      }
      if (countser2[0].sumtwo[0] != undefined) {
        sum2 = countser2[0].sumtwo[0].total;
      } else {
        sum2 = 0;
      }
      if (countser2[0].sumthree[0] != undefined) {
        sum3 = countser2[0].sumthree[0].total;
      } else {
        sum3 = 0;
      }
      if (countser2[0].sumfour[0] != undefined) {
        sum4 = countser2[0].sumfour[0].total;
      } else {
        sum4 = 0;
      }
      if (countser2[0].sumfive[0] != undefined) {
        sum5 = countser2[0].sumfive[0].total;
      } else {
        sum5 = 0;
      }
      if (countser2[0].sumsix[0] != undefined) {
        sum6 = countser2[0].sumsix[0].total;
      } else {
        sum6 = 0;
      }

      return {
        data: {
          success: true,
          message: [
            [sum1, thismonth, t],
            [sum2, month1, a],
            [sum3, month2, b],
            [sum4, month3, c],
            [sum5, month4, d],
            [sum6, month5, e],
          ],
        },
      };
    } catch (e) {
      this.logger.errors(e);
      throw e;
    }
  }
  public async getInvoiceGraphToLender(currentUser: IUser): Promise<{ data: any }> {
    try {
      const userDetails = currentUser;

      var sum1 = 0;
      var sum2 = 0;
      var sum3 = 0;
      var sum4 = 0;
      var sum5 = 0;
      var sum6 = 0;
      var forcalc = new Date();
      var thismonth = forcalc.getMonth() + 1;
      var t = forcalc.getFullYear();
      var this1 = new Date(t, thismonth - 1, 1);

      var month1 = forcalc.getMonth();
      if (month1 < 0) {
        month1 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month1);
      var a = forcalc.getFullYear();
      var d1m1 = new Date(a, month1 - 1, 1);
      var laster1 = new Date(a, month1, 0);
      laster1.setHours(23, 59, 59, 0);
      if (month1 <= 0) {
        month1 += 12;
        a = a - 1
      }

      var month2 = forcalc.getMonth() - 1;
      if (month2 < 0) {
        month2 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month2);
      var b = forcalc.getFullYear();
      var d1m2 = new Date(b, month2 - 1, 1);
      var laster2 = new Date(b, month2, 0);
      laster2.setHours(23, 59, 59, 0);
      if (month2 <= 0) {
        month2 += 12;
        b = b - 1
      }

      var month3 = forcalc.getMonth() - 1;
      if (month3 < 0) {
        month3 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month3);
      var c = forcalc.getFullYear();
      var d1m3 = new Date(c, month3 - 1, 1);
      var laster3 = new Date(c, month3, 0);
      laster3.setHours(23, 59, 59, 0);
      if (month3 <= 0) {
        month3 += 12;
        c = c - 1
      }

      var month4 = forcalc.getMonth() - 1;
      if (month4 < 0) {
        month4 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month4);
      var d = forcalc.getFullYear();
      var d1m4 = new Date(d, month4 - 1, 1);
      var laster4 = new Date(d, month4, 0);
      laster4.setHours(23, 59, 59, 0);
      if (month4 <= 0) {
        month4 += 12;
        d = d - 1
      }

      var month5 = forcalc.getMonth() - 1;
      if (month5 < 0) {
        month5 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month5);
      var e = forcalc.getFullYear();
      var d1m5 = new Date(e, month5 - 1, 1);
      var laster5 = new Date(e, month5, 0);
      laster5.setHours(23, 59, 59, 0);
      if (month5 <= 0) {
        month5 += 12;
        e = e - 1
      }


      var todaydate = new Date();

      var countser2 = await this.PharmacyModel.aggregate([
        {
          $facet: {
            sumone: [
              {
                $match: {
                  $and: [
                    { LenderId: userDetails.organizationId },
                    { PaymentDate: { $gte: this1, $lte: todaydate } },
                    { $or: [{ Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Fully Repaid" }, { Status: "Partially Repaid" }] },
                  ],
                },
              },
              { $group: { _id: '$_v', total: { $sum: '$LTVAmount' } } },
            ],
            sumtwo: [
              {
                $match: {
                  $and: [
                    { LenderId: userDetails.organizationId },
                    { PaymentDate: { $gte: d1m1, $lte: laster1 } },
                    { $or: [{ Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Fully Repaid" }, { Status: "Partially Repaid" }] },
                  ],
                },
              },
              { $group: { _id: '$_v', total: { $sum: '$LTVAmount' } } },
            ],
            sumthree: [
              {
                $match: {
                  $and: [
                    { LenderId: userDetails.organizationId },
                    { PaymentDate: { $gte: d1m2, $lte: laster2 } },
                    { $or: [{ Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Fully Repaid" }, { Status: "Partially Repaid" }] },
                  ],
                },
              },
              { $group: { _id: '$_v', total: { $sum: '$LTVAmount' } } },
            ],
            sumfour: [
              {
                $match: {
                  $and: [
                    { LenderId: userDetails.organizationId },
                    { PaymentDate: { $gte: d1m3, $lte: laster3 } },
                    { $or: [{ Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Fully Repaid" }, { Status: "Partially Repaid" }] },
                  ],
                },
              },
              { $group: { _id: '$_v', total: { $sum: '$LTVAmount' } } },
            ],
            sumfive: [
              {
                $match: {
                  $and: [
                    { LenderId: userDetails.organizationId },
                    { PaymentDate: { $gte: d1m4, $lte: laster4 } },
                    { $or: [{ Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Fully Repaid" }, { Status: "Partially Repaid" }] },
                  ],
                },
              },
              { $group: { _id: '$_v', total: { $sum: '$LTVAmount' } } },
            ],
            sumsix: [
              {
                $match: {
                  $and: [
                    { LenderId: userDetails.organizationId },
                    { PaymentDate: { $gte: d1m5, $lte: laster5 } },
                    { $or: [{ Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Fully Repaid" }, { Status: "Partially Repaid" }] },
                  ],
                },
              },
              { $group: { _id: '$_v', total: { $sum: '$LTVAmount' } } },
            ],
          },
        },
      ]);

      if (countser2[0].sumone[0] != undefined) {
        sum1 = countser2[0].sumone[0].total;
      } else {
        sum1 = 0;
      }
      if (countser2[0].sumtwo[0] != undefined) {
        sum2 = countser2[0].sumtwo[0].total;
      } else {
        sum2 = 0;
      }
      if (countser2[0].sumthree[0] != undefined) {
        sum3 = countser2[0].sumthree[0].total;
      } else {
        sum3 = 0;
      }
      if (countser2[0].sumfour[0] != undefined) {
        sum4 = countser2[0].sumfour[0].total;
      } else {
        sum4 = 0;
      }
      if (countser2[0].sumfive[0] != undefined) {
        sum5 = countser2[0].sumfive[0].total;
      } else {
        sum5 = 0;
      }
      if (countser2[0].sumsix[0] != undefined) {
        sum6 = countser2[0].sumsix[0].total;
      } else {
        sum6 = 0;
      }

      return {
        data: {
          success: true,
          message: [
            [sum1, thismonth, t],
            [sum2, month1, a],
            [sum3, month2, b],
            [sum4, month3, c],
            [sum5, month4, d],
            [sum6, month5, e],
          ],
        },
      };
    } catch (e) {
      this.logger.errors(e);
      throw e;
    }
  }
  public async getLenderGraphOne(currentUser: IUser): Promise<{ data: any }> {
    try {
      const userDetails = currentUser;

      var sum1 = 0;
      var sum2 = 0;
      var sum3 = 0;
      var sum4 = 0;
      var sum5 = 0;
      var sum6 = 0;

      var InProcesssum1 = 0;
      var InProcesssum2 = 0;
      var InProcesssum3 = 0;
      var InProcesssum4 = 0;
      var InProcesssum5 = 0;
      var InProcesssum6 = 0;

      var Disbursedsum1 = 0;
      var Disbursedsum2 = 0;
      var Disbursedsum3 = 0;
      var Disbursedsum4 = 0;
      var Disbursedsum5 = 0;
      var Disbursedsum6 = 0;

      var Repaidsum1 = 0;
      var Repaidsum2 = 0;
      var Repaidsum3 = 0;
      var Repaidsum4 = 0;
      var Repaidsum5 = 0;
      var Repaidsum6 = 0;

      var Rejectedsum1 = 0;
      var Rejectedsum2 = 0;
      var Rejectedsum3 = 0;
      var Rejectedsum4 = 0;
      var Rejectedsum5 = 0;
      var Rejectedsum6 = 0;

      var forcalc = new Date();
      var thismonth = forcalc.getMonth() + 1;
      var t = forcalc.getFullYear();
      var this1 = new Date(t, thismonth - 1, 1);

      var month1 = forcalc.getMonth();
      if (month1 <= 0) {
        month1 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month1);
      var a = forcalc.getFullYear();
      var d1m1 = new Date(a, month1 - 1, 1);
      var laster1 = new Date(a, month1, 0);
      laster1.setHours(23, 59, 59, 0);
      if (month1 <= 0) {
        month1 += 12;
        a = a - 1
      }

      var month2 = forcalc.getMonth() - 1;
      if (month2 <= 0) {
        month2 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month2);
      var b = forcalc.getFullYear();
      var d1m2 = new Date(b, month2 - 1, 1);
      var laster2 = new Date(b, month2, 0);
      laster2.setHours(23, 59, 59, 0);
      if (month2 <= 0) {
        month2 += 12;
        b = b - 1
      }

      var month3 = forcalc.getMonth() - 1;
      if (month3 <= 0) {
        month3 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month3);
      var c = forcalc.getFullYear();
      var d1m3 = new Date(c, month3 - 1, 1);
      var laster3 = new Date(c, month3, 0);
      laster3.setHours(23, 59, 59, 0);
      if (month3 <= 0) {
        month3 += 12;
        c = c - 1
      }

      var month4 = forcalc.getMonth() - 1;
      if (month4 <= 0) {
        month4 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month4);
      var d = forcalc.getFullYear();
      var d1m4 = new Date(d, month4 - 1, 1);
      var laster4 = new Date(d, month4, 0);
      laster4.setHours(23, 59, 59, 0);
      if (month4 <= 0) {
        month4 += 12;
        d = d - 1
      }

      var month5 = forcalc.getMonth() - 1;
      if (month5 <= 0) {
        month5 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month5);
      var e = forcalc.getFullYear();
      var d1m5 = new Date(e, month5 - 1, 1);
      var laster5 = new Date(e, month5, 0);
      laster5.setHours(23, 59, 59, 0);
      if (month5 <= 0) {
        month5 += 12;
        e = e - 1
      }


      var todaydate = new Date();

      var countone = await this.PharmacyModel.aggregate([
        {
          $facet: {
            sumone: [
              {
                $match: {
                  $and: [
                    { LenderId: userDetails.organizationId },
                    { InvoiceDate: { $gte: this1, $lte: todaydate } },
                    { $or: [{ Status: "Hospital Approved" }, { Status: "Lender Approved" }] },
                  ],
                },
              },
              { $count: 'total' },
            ],
            sumtwo: [
              {
                $match: {
                  $and: [
                    { LenderId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m1, $lte: laster1 } },
                    { $or: [{ Status: "Hospital Approved" }, { Status: "Lender Approved" }] },
                  ],
                },
              },
              { $count: 'total' },
            ],
            sumthree: [
              {
                $match: {
                  $and: [
                    { LenderId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m2, $lte: laster2 } },
                    { $or: [{ Status: "Hospital Approved" }, { Status: "Lender Approved" }] },
                  ],
                },
              },
              { $count: 'total' },
            ],
            sumfour: [
              {
                $match: {
                  $and: [
                    { LenderId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m3, $lte: laster3 } },
                    { $or: [{ Status: "Hospital Approved" }, { Status: "Lender Approved" }] },
                  ],
                },
              },
              { $count: 'total' },
            ],
            sumfive: [
              {
                $match: {
                  $and: [
                    { LenderId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m4, $lte: laster4 } },
                    { $or: [{ Status: "Hospital Approved" }, { Status: "Lender Approved" }] },
                  ],
                },
              },
              { $count: 'total' },
            ],
            sumsix: [
              {
                $match: {
                  $and: [
                    { LenderId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m5, $lte: laster5 } },
                    { $or: [{ Status: "Hospital Approved" }, { Status: "Lender Approved" }] },
                  ],
                },
              },
              { $count: 'total' },
            ],

            InProsumone: [
              {
                $match: {
                  $and: [
                    { LenderId: userDetails.organizationId },
                    { InvoiceDate: { $gte: this1, $lte: todaydate } },
                    {
                      $or: [
                        { Status: "Disbursed" },
                        { Status: "Lender Rejected" },
                        { Status: "Hospital Approved" },
                        { Status: "Lender Approved" },
                        { Status: "Hospital Repaid" },
                        { Status: "Fully Repaid" },
                        { Status: "Partially Repaid" }
                      ],
                    },
                  ],
                },
              },
              { $count: 'total' },
            ],
            InProsumtwo: [
              {
                $match: {
                  $and: [
                    { LenderId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m1, $lte: laster1 } },
                    {
                      $or: [
                        { Status: "Disbursed" },
                        { Status: "Lender Rejected" },
                        { Status: "Hospital Approved" },
                        { Status: "Lender Approved" },
                        { Status: "Hospital Repaid" },
                        { Status: "Fully Repaid" },
                        { Status: "Partially Repaid" }
                      ],
                    },
                  ],
                },
              },
              { $count: 'total' },
            ],
            InProsumthree: [
              {
                $match: {
                  $and: [
                    { LenderId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m2, $lte: laster2 } },
                    {
                      $or: [
                        { Status: "Disbursed" },
                        { Status: "Lender Rejected" },
                        { Status: "Hospital Approved" },
                        { Status: "Lender Approved" },
                        { Status: "Hospital Repaid" },
                        { Status: "Fully Repaid" },
                        { Status: "Partially Repaid" }
                      ],
                    },
                  ],
                },
              },
              { $count: 'total' },
            ],
            InProsumfour: [
              {
                $match: {
                  $and: [
                    { LenderId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m3, $lte: laster3 } },
                    {
                      $or: [
                        { Status: "Disbursed" },
                        { Status: "Lender Rejected" },
                        { Status: "Hospital Approved" },
                        { Status: "Lender Approved" },
                        { Status: "Hospital Repaid" },
                        { Status: "Fully Repaid" },
                        { Status: "Partially Repaid" }
                      ],
                    },
                  ],
                },
              },
              { $count: 'total' },
            ],
            InProsumfive: [
              {
                $match: {
                  $and: [
                    { LenderId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m4, $lte: laster4 } },
                    {
                      $or: [
                        { Status: "Disbursed" },
                        { Status: "Lender Rejected" },
                        { Status: "Hospital Approved" },
                        { Status: "Lender Approved" },
                        { Status: "Hospital Repaid" },
                        { Status: "Fully Repaid" },
                        { Status: "Partially Repaid" }
                      ],
                    },
                  ],
                },
              },
              { $count: 'total' },
            ],
            InProsumsix: [
              {
                $match: {
                  $and: [
                    { LenderId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m5, $lte: laster5 } },
                    {
                      $or: [
                        { Status: "Disbursed" },
                        { Status: "Lender Rejected" },
                        { Status: "Hospital Approved" },
                        { Status: "Lender Approved" },
                        { Status: "Hospital Repaid" },
                        { Status: "Fully Repaid" },
                        { Status: "Partially Repaid" }
                      ],
                    },
                  ],
                },
              },
              { $count: 'total' },
            ],

            Disbursedsumone: [
              {
                $match: {
                  $and: [
                    { LenderId: userDetails.organizationId },
                    { InvoiceDate: { $gte: this1, $lte: todaydate } },
                    { $or: [{ Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Fully Repaid" }, { Status: "Partially Repaid" }] },
                  ],
                },
              },
              { $count: 'total' },
            ],
            Disbursedsumtwo: [
              {
                $match: {
                  $and: [
                    { LenderId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m1, $lte: laster1 } },
                    { $or: [{ Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Fully Repaid" }, { Status: "Partially Repaid" }] },
                  ],
                },
              },
              { $count: 'total' },
            ],
            Disbursedsumthree: [
              {
                $match: {
                  $and: [
                    { LenderId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m2, $lte: laster2 } },
                    { $or: [{ Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Fully Repaid" }, { Status: "Partially Repaid" }] },
                  ],
                },
              },
              { $count: 'total' },
            ],
            Disbursedsumfour: [
              {
                $match: {
                  $and: [
                    { LenderId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m3, $lte: laster3 } },
                    { $or: [{ Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Fully Repaid" }, { Status: "Partially Repaid" }] },
                  ],
                },
              },
              { $count: 'total' },
            ],
            Disbursedsumfive: [
              {
                $match: {
                  $and: [
                    { LenderId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m4, $lte: laster4 } },
                    { $or: [{ Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Fully Repaid" }, { Status: "Partially Repaid" }] },
                  ],
                },
              },
              { $count: 'total' },
            ],
            Disbursedsumsix: [
              {
                $match: {
                  $and: [
                    { LenderId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m5, $lte: laster5 } },
                    { $or: [{ Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Fully Repaid" }, { Status: "Partially Repaid" }] },
                  ],
                },
              },
              { $count: 'total' },
            ],

            Repaidsumone: [
              {
                $match: {
                  $and: [
                    { LenderId: userDetails.organizationId },
                    { InvoiceDate: { $gte: this1, $lte: todaydate } },
                    { Status: "Fully Repaid" },
                  ],
                },
              },
              { $count: 'total' },
            ],
            Repaidsumtwo: [
              {
                $match: {
                  $and: [
                    { LenderId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m1, $lte: laster1 } },
                    { Status: "Fully Repaid" },
                  ],
                },
              },
              { $count: 'total' },
            ],
            Repaidsumthree: [
              {
                $match: {
                  $and: [
                    { LenderId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m2, $lte: laster2 } },
                    { Status: "Fully Repaid" },
                  ],
                },
              },
              { $count: 'total' },
            ],
            Repaidsumfour: [
              {
                $match: {
                  $and: [
                    { LenderId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m3, $lte: laster3 } },
                    { Status: "Fully Repaid" },
                  ],
                },
              },
              { $count: 'total' },
            ],
            Repaidsumfive: [
              {
                $match: {
                  $and: [
                    { LenderId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m4, $lte: laster4 } },
                    { Status: "Fully Repaid" },
                  ],
                },
              },
              { $count: 'total' },
            ],
            Repaidsumsix: [
              {
                $match: {
                  $and: [
                    { LenderId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m5, $lte: laster5 } },
                    { Status: "Fully Repaid" },
                  ],
                },
              },
              { $count: 'total' },
            ],

            Rejectedsumone: [
              {
                $match: {
                  $and: [
                    { LenderId: userDetails.organizationId },
                    { InvoiceDate: { $gte: this1, $lte: todaydate } },
                    { Status: "Lender Rejected" },
                  ],
                },
              },
              { $count: 'total' },
            ],
            Rejectedsumtwo: [
              {
                $match: {
                  $and: [
                    { LenderId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m1, $lte: laster1 } },
                    { Status: "Lender Rejected" },
                  ],
                },
              },
              { $count: 'total' },
            ],
            Rejectedsumthree: [
              {
                $match: {
                  $and: [
                    { LenderId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m2, $lte: laster2 } },
                    { Status: "Lender Rejected" },
                  ],
                },
              },
              { $count: 'total' },
            ],
            Rejectedsumfour: [
              {
                $match: {
                  $and: [
                    { LenderId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m3, $lte: laster3 } },
                    { Status: "Lender Rejected" },
                  ],
                },
              },
              { $count: 'total' },
            ],
            Rejectedsumfive: [
              {
                $match: {
                  $and: [
                    { LenderId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m4, $lte: laster4 } },
                    { Status: "Lender Rejected" },
                  ],
                },
              },
              { $count: 'total' },
            ],
            Rejectedsumsix: [
              {
                $match: {
                  $and: [
                    { LenderId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m5, $lte: laster5 } },
                    { Status: "Lender Rejected" },
                  ],
                },
              },
              { $count: 'total' },
            ],
          },
        },
      ]);

      if (countone[0].sumone[0] != undefined) {
        sum1 = countone[0].sumone[0].total;
      } else {
        sum1 = 0;
      }
      if (countone[0].sumtwo[0] != undefined) {
        sum2 = countone[0].sumtwo[0].total;
      } else {
        sum2 = 0;
      }
      if (countone[0].sumthree[0] != undefined) {
        sum3 = countone[0].sumthree[0].total;
      } else {
        sum3 = 0;
      }
      if (countone[0].sumfour[0] != undefined) {
        sum4 = countone[0].sumfour[0].total;
      } else {
        sum4 = 0;
      }
      if (countone[0].sumfive[0] != undefined) {
        sum5 = countone[0].sumfive[0].total;
      } else {
        sum5 = 0;
      }
      if (countone[0].sumsix[0] != undefined) {
        sum6 = countone[0].sumsix[0].total;
      } else {
        sum6 = 0;
      }

      if (countone[0].InProsumone[0] != undefined) {
        InProcesssum1 = countone[0].InProsumone[0].total;
      } else {
        InProcesssum1 = 0;
      }
      if (countone[0].InProsumtwo[0] != undefined) {
        InProcesssum2 = countone[0].InProsumtwo[0].total;
      } else {
        InProcesssum2 = 0;
      }
      if (countone[0].InProsumthree[0] != undefined) {
        InProcesssum3 = countone[0].InProsumthree[0].total;
      } else {
        InProcesssum3 = 0;
      }
      if (countone[0].InProsumfour[0] != undefined) {
        InProcesssum4 = countone[0].InProsumfour[0].total;
      } else {
        InProcesssum4 = 0;
      }
      if (countone[0].InProsumfive[0] != undefined) {
        InProcesssum5 = countone[0].InProsumfive[0].total;
      } else {
        InProcesssum5 = 0;
      }
      if (countone[0].InProsumsix[0] != undefined) {
        InProcesssum6 = countone[0].InProsumsix[0].total;
      } else {
        InProcesssum6 = 0;
      }

      if (countone[0].Disbursedsumone[0] != undefined) {
        Disbursedsum1 = countone[0].Disbursedsumone[0].total;
      } else {
        Disbursedsum1 = 0;
      }
      if (countone[0].Disbursedsumtwo[0] != undefined) {
        Disbursedsum2 = countone[0].Disbursedsumtwo[0].total;
      } else {
        Disbursedsum2 = 0;
      }
      if (countone[0].Disbursedsumthree[0] != undefined) {
        Disbursedsum3 = countone[0].Disbursedsumthree[0].total;
      } else {
        Disbursedsum3 = 0;
      }
      if (countone[0].Disbursedsumfour[0] != undefined) {
        Disbursedsum4 = countone[0].Disbursedsumfour[0].total;
      } else {
        Disbursedsum4 = 0;
      }
      if (countone[0].Disbursedsumfive[0] != undefined) {
        Disbursedsum5 = countone[0].Disbursedsumfive[0].total;
      } else {
        Disbursedsum5 = 0;
      }
      if (countone[0].Disbursedsumsix[0] != undefined) {
        Disbursedsum6 = countone[0].Disbursedsumsix[0].total;
      } else {
        Disbursedsum6 = 0;
      }

      if (countone[0].Repaidsumone[0] != undefined) {
        Repaidsum1 = countone[0].Repaidsumone[0].total;
      } else {
        Repaidsum1 = 0;
      }
      if (countone[0].Repaidsumtwo[0] != undefined) {
        Repaidsum2 = countone[0].Repaidsumtwo[0].total;
      } else {
        Repaidsum2 = 0;
      }
      if (countone[0].Repaidsumthree[0] != undefined) {
        Repaidsum3 = countone[0].Repaidsumthree[0].total;
      } else {
        Repaidsum3 = 0;
      }
      if (countone[0].Repaidsumfour[0] != undefined) {
        Repaidsum4 = countone[0].Repaidsumfour[0].total;
      } else {
        Repaidsum4 = 0;
      }
      if (countone[0].Repaidsumfive[0] != undefined) {
        Repaidsum5 = countone[0].Repaidsumfive[0].total;
      } else {
        Repaidsum5 = 0;
      }
      if (countone[0].Repaidsumsix[0] != undefined) {
        Repaidsum6 = countone[0].Repaidsumsix[0].total;
      } else {
        Repaidsum6 = 0;
      }

      if (countone[0].Rejectedsumone[0] != undefined) {
        Rejectedsum1 = countone[0].Rejectedsumone[0].total;
      } else {
        Rejectedsum1 = 0;
      }
      if (countone[0].Rejectedsumtwo[0] != undefined) {
        Rejectedsum2 = countone[0].Rejectedsumtwo[0].total;
      } else {
        Rejectedsum2 = 0;
      }
      if (countone[0].Rejectedsumthree[0] != undefined) {
        Rejectedsum3 = countone[0].Rejectedsumthree[0].total;
      } else {
        Rejectedsum3 = 0;
      }
      if (countone[0].Rejectedsumfour[0] != undefined) {
        Rejectedsum4 = countone[0].Rejectedsumfour[0].total;
      } else {
        Rejectedsum4 = 0;
      }
      if (countone[0].Rejectedsumfive[0] != undefined) {
        Rejectedsum5 = countone[0].Rejectedsumfive[0].total;
      } else {
        Rejectedsum5 = 0;
      }
      if (countone[0].Rejectedsumsix[0] != undefined) {
        Rejectedsum6 = countone[0].Rejectedsumsix[0].total;
      } else {
        Rejectedsum6 = 0;
      }

      return {
        data: {
          success: true,

          monthsAndYears: [
            [thismonth, t],
            [month1, a],
            [month2, b],
            [month3, c],
            [month4, d],
            [month5, e],
          ],
          All: [InProcesssum1, InProcesssum2, InProcesssum3, InProcesssum4, InProcesssum5, InProcesssum6],
          AllHApproved: [sum1, sum2, sum3, sum4, sum5, sum6],
          Disbursed: [Disbursedsum1, Disbursedsum2, Disbursedsum3, Disbursedsum4, Disbursedsum5, Disbursedsum6],
          Repaid: [Repaidsum1, Repaidsum2, Repaidsum3, Repaidsum4, Repaidsum5, Repaidsum6],
          Rejected: [Rejectedsum1, Rejectedsum2, Rejectedsum3, Rejectedsum4, Rejectedsum5, Rejectedsum6],
        },
      };
    } catch (e) {
      this.logger.errors(e);
      throw e;
    }
  }
  public async getLastPieGraphForLender(currentUser: IUser): Promise<{ data: any }> {
    try {
      const userDetails = currentUser;

      var FundedSum = 0;
      var UnderPaidsum = 0;
      var OverPaidsum = 0;
      var FullPaidsum = 0;

      var forcalc = new Date();
      var thismonth = forcalc.getMonth() + 1;
      var t = forcalc.getFullYear();
      var this1 = new Date(t, thismonth - 1, 1);

      var month1 = forcalc.getMonth();
      if (month1 < 0) {
        month1 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month1);
      var a = forcalc.getFullYear();
      var d1m1 = new Date(a, month1 - 1, 1);
      var laster1 = new Date(a, month1, 0);
      laster1.setHours(23, 59, 59, 0);
      if (month1 <= 0) {
        month1 += 12;
        a = a - 1
      }

      var month2 = forcalc.getMonth() - 1;
      if (month2 < 0) {
        month2 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month2);
      var b = forcalc.getFullYear();
      var d1m2 = new Date(b, month2 - 1, 1);
      var laster2 = new Date(b, month2, 0);
      laster2.setHours(23, 59, 59, 0);
      if (month2 <= 0) {
        month2 += 12;
        b = b - 1
      }

      var month3 = forcalc.getMonth() - 1;
      if (month3 < 0) {
        month3 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month3);
      var c = forcalc.getFullYear();
      var d1m3 = new Date(c, month3 - 1, 1);
      var laster3 = new Date(c, month3, 0);
      laster3.setHours(23, 59, 59, 0);
      if (month3 <= 0) {
        month3 += 12;
        c = c - 1
      }

      var month4 = forcalc.getMonth() - 1;
      if (month4 < 0) {
        month4 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month4);
      var d = forcalc.getFullYear();
      var d1m4 = new Date(d, month4 - 1, 1);
      var laster4 = new Date(d, month4, 0);
      laster4.setHours(23, 59, 59, 0);
      if (month4 <= 0) {
        month4 += 12;
        d = d - 1
      }

      var month5 = forcalc.getMonth() - 1;
      if (month5 < 0) {
        month5 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month5);
      var e = forcalc.getFullYear();
      var d1m5 = new Date(e, month5 - 1, 1);
      var laster5 = new Date(e, month5, 0);
      laster5.setHours(23, 59, 59, 0);
      if (month5 <= 0) {
        month5 += 12;
        e = e - 1
      }


      var todaydate = new Date();

      var countone = await this.PharmacyModel.aggregate([
        {
          $facet: {
            sumone: [
              {
                $match: {
                  $and: [
                    { LenderId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m5, $lte: todaydate } },
                    { $or: [{ Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Fully Repaid" }, { Status: "Partially Repaid" }] },
                  ],
                },
              },
              { $count: 'total' },
            ],
            sumtwo: [
              {
                $match: {
                  $and: [
                    { LenderId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m5, $lte: todaydate } },
                    { Status: "Fully Repaid" },
                    { SettleStatus: 'UnderPaid' },
                  ],
                },
              },
              { $count: 'total' },
            ],
            sumthree: [
              {
                $match: {
                  $and: [
                    { LenderId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m5, $lte: todaydate } },
                    { Status: "Fully Repaid" },
                    { SettleStatus: 'FullPaid' },
                  ],
                },
              },
              { $count: 'total' },
            ],
            sumfour: [
              {
                $match: {
                  $and: [
                    { LenderId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m5, $lte: todaydate } },
                    { Status: "Fully Repaid" },
                    { SettleStatus: 'OverPaid' },
                  ],
                },
              },
              { $count: 'total' },
            ],
          },
        },
      ]);

      if (countone[0].sumone[0] != undefined) {
        FundedSum = countone[0].sumone[0].total;
      } else {
        FundedSum = 0;
      }
      if (countone[0].sumtwo[0] != undefined) {
        UnderPaidsum = countone[0].sumtwo[0].total;
      } else {
        UnderPaidsum = 0;
      }
      if (countone[0].sumthree[0] != undefined) {
        FullPaidsum = countone[0].sumthree[0].total;
      } else {
        FullPaidsum = 0;
      }
      if (countone[0].sumfour[0] != undefined) {
        OverPaidsum = countone[0].sumfour[0].total;
      } else {
        OverPaidsum = 0;
      }

      return {
        data: {
          success: true,
          TotalFunded: FundedSum,
          UnderPaid: UnderPaidsum,
          OverPaid: OverPaidsum,
          FullPaid: FullPaidsum,
        },
      };
    } catch (e) {
      this.logger.errors(e);
      throw e;
    }
  }
  public async getSecondPieGraphForLender(currentUser: IUser): Promise<{ data: any }> {
    try {
      const userDetails = currentUser;

      var forcalc = new Date();
      var thismonth = forcalc.getMonth() + 1;
      var t = forcalc.getFullYear();
      var this1 = new Date(t, thismonth - 1, 1);

      var month1 = forcalc.getMonth();
      if (month1 < 0) {
        month1 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month1);
      var a = forcalc.getFullYear();
      var d1m1 = new Date(a, month1 - 1, 1);
      var laster1 = new Date(a, month1, 0);
      laster1.setHours(23, 59, 59, 0);
      if (month1 <= 0) {
        month1 += 12;
        a = a - 1
      }

      var month2 = forcalc.getMonth() - 1;
      if (month2 < 0) {
        month2 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month2);
      var b = forcalc.getFullYear();
      var d1m2 = new Date(b, month2 - 1, 1);
      var laster2 = new Date(b, month2, 0);
      laster2.setHours(23, 59, 59, 0);
      if (month2 <= 0) {
        month2 += 12;
        b = b - 1
      }

      var month3 = forcalc.getMonth() - 1;
      if (month3 < 0) {
        month3 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month3);
      var c = forcalc.getFullYear();
      var d1m3 = new Date(c, month3 - 1, 1);
      var laster3 = new Date(c, month3, 0);
      laster3.setHours(23, 59, 59, 0);
      if (month3 <= 0) {
        month3 += 12;
        c = c - 1
      }

      var month4 = forcalc.getMonth() - 1;
      if (month4 < 0) {
        month4 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month4);
      var d = forcalc.getFullYear();
      var d1m4 = new Date(d, month4 - 1, 1);
      var laster4 = new Date(d, month4, 0);
      laster4.setHours(23, 59, 59, 0);
      if (month4 <= 0) {
        month4 += 12;
        d = d - 1
      }

      var month5 = forcalc.getMonth() - 1;
      if (month5 < 0) {
        month5 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month5);
      var e = forcalc.getFullYear();
      var d1m5 = new Date(e, month5 - 1, 1);
      var laster5 = new Date(e, month5, 0);
      laster5.setHours(23, 59, 59, 0);
      if (month5 <= 0) {
        month5 += 12;
        e = e - 1
      }


      var todaydate = new Date();

      var TotalSum;
      var Fundedsum;
      var countone = await this.PharmacyModel.aggregate([
        {
          $facet: {
            sumone: [
              {
                $match: {
                  $and: [
                    { LenderId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m5, $lte: todaydate } },
                    {
                      $or: [
                        { Status: "Hospital Approved" },
                        { Status: "Lender Approved" },
                        { Status: "Disbursed" },
                        { Status: "Fully Repaid" },
                        { Status: "Lender Rejected" },
                        { Status: "Hospital Repaid" },
                        { Status: "Partially Repaid" }
                      ],
                    },
                  ],
                },
              },
              { $count: 'total' },
            ],
            sumtwo: [
              {
                $match: {
                  $and: [
                    { LenderId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m5, $lte: todaydate } },
                    { $or: [{ Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Fully Repaid" }, { Status: "Partially Repaid" }] },
                  ],
                },
              },
              { $count: 'total' },
            ],
          },
        },
      ]);

      if (countone[0].sumone[0] != undefined) {
        TotalSum = countone[0].sumone[0].total;
      } else {
        TotalSum = 0;
      }
      if (countone[0].sumtwo[0] != undefined) {
        Fundedsum = countone[0].sumtwo[0].total;
      } else {
        Fundedsum = 0;
      }

      return {
        data: {
          success: true,
          TotalHApproved: TotalSum,
          TotalFunded: Fundedsum,
        },
      };
    } catch (e) {
      this.logger.errors(e);
      throw e;
    }
  }
  public async getAllInvoicesToLender(IFilterDTO: IFilterDTO, currentUser: IUser): Promise<{ data: any }> {
    try {
      //pagination
      var pageNumber = 1;
      var pageSize = 0;
      if (IFilterDTO.pageNumber) {
        var pageNumber = parseInt(IFilterDTO.pageNumber.toString());
      }
      if (IFilterDTO.pageSize) {
        var pageSize = parseInt(IFilterDTO.pageSize.toString());
      }
      //filters
      var searchFilters = [];
      // searchFilters.push({ isDeleted: false });
      // searchFilters.push({ LenderId: currentUser._id });
      if (currentUser.accessControl == 0) {
        searchFilters.push({ uploadedBy: currentUser._id });
      }
      else if (currentUser.accessControl == 1) {
        searchFilters.push({ LenderId: currentUser.organizationId });
      }
      else {
        searchFilters.push({ $or: [{ LenderId: currentUser._id }, { LenderId: currentUser.organizationId }] });
      }

      if (IFilterDTO.Status != undefined) {
        searchFilters.push({ Status: IFilterDTO.Status });
      }
      if (IFilterDTO.searchTerm != undefined) {
        searchFilters.push({
          $or: [
            { hospitalName: { $regex: IFilterDTO.searchTerm, $options: 'i' } },
            { vendorName: { $regex: IFilterDTO.searchTerm, $options: 'i' } },
            {
              "$expr": {
                "$regexMatch": {
                  "input": { "$toString": "$LoanID" },
                  "regex": IFilterDTO.searchTerm
                }
              }
            }
          ]
        })
      }
      var totalAmount = 0;
      var totalCount = 0;
      //mongo query
      var userCount = await this.PharmacyModel.find({ $and: searchFilters }).countDocuments();
      var numberOfPages = pageSize === 0 ? 1 : Math.ceil(userCount / pageSize);
      var invoice = await this.PharmacyModel.aggregate([{
        $facet: {
          totalAmount: [{ $match: { $and: searchFilters } }, { $group: { _id: '$_v', total: { $sum: '$LTVAmount' } } }],
          totalCount: [{ $match: { $and: searchFilters } }, { $count: 'total' }]
        }
      }
      ]);
      if (invoice[0].totalAmount[0] != undefined) {
        totalAmount = invoice[0].totalAmount[0].total
      }
      if (invoice[0].totalCount[0] != undefined) {
        totalCount = invoice[0].totalCount[0].total
      }
      //   var invoices: any = await this.PharmacyModel.find({ $and: searchFilters })
      //     .sort({ updatedAt: -1 })
      //     .skip((pageNumber - 1) * pageSize)
      //     .limit(pageSize);
      
      var invoices = await this.PharmacyModel.aggregate([
        { $match: { $and: searchFilters } },
        { $sort: { updatedAt: -1 } },
        { $skip: (pageNumber - 1) * pageSize },
        { $limit: pageSize ? pageSize : Number.MAX_SAFE_INTEGER },
        {
          $lookup: { from: 'users', localField: 'distributorId', foreignField: 'organizationId', as: 'distributor' },
        },
        {
          $lookup: {
            from: 'users',
            localField: 'PmanufactureId',
            foreignField: 'organizationId',
            as: 'PmanufactureId',
          },
        },
      ]);
   
      var data = { invoices, numberOfPages, totalAmount, totalCount };
      return { data };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  public async deleteAllInvoicesToLender(currentUser: IUser, IFilterDTO: IFilterDTO): Promise<{ data: any }> {
    try {
      const id = IFilterDTO._id;
      var invoice = await this.PharmacyModel.findOne({ _id: id })
      if (invoice.Status != "Pending") {
        return { data: { success: false, message: "Cannot delete Invoice To Lender" } }
      }

      var deleteInvoice = await this.PharmacyModel.findByIdAndUpdate({ _id: id }, { $set: { isDeleted: true, updatedBy: currentUser._id } });
      //pending invoice      
      if (deleteInvoice) {
        var data = { success: true, message: "Invoice To Lender deleted Successfully" };
        return { data };
      }

    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  public async getHospitalToLender(IFilterDTO: IFilterDTO, currentUser: IUser): Promise<{ data: any }> {
    try {
      //pagination
      var pageNumber = 1;
      var pageSize = 0;
      if (IFilterDTO.pageNumber) {
        var pageNumber = IFilterDTO.pageNumber;
      }
      if (IFilterDTO.pageSize) {
        var pageSize = IFilterDTO.pageSize;
      }
      //search
      // var filters = IFilterDTO.filters || [];
      var searchFilters = [];
      searchFilters.push({ LenderId: currentUser.organizationId, isDeleted: false });

      // for (var element of filters) {
      //   searchFilters.push({ [element.searchField]: { $regex: element.searchTerm, $options: 'i' } });
      // }
      var userCount = await this.organizationModel.find({ $and: searchFilters }).countDocuments();
      var numberOfPages = pageSize === 0 ? 1 : Math.ceil(userCount / pageSize);
      var users = await this.organizationModel
        .find({ $and: searchFilters })
        .sort({ updatedAt: -1 })
        .skip((pageNumber - 1) * pageSize)
        .limit(pageSize);

      return { data: { success: true, message: users, numberOfPages } };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  public async getInvoiceByIdToLender(req: Request, currentUser: IUser): Promise<{ data: any }> {
    try {
      const Id = req.query;
      const userDetails = currentUser;
      const invoices = await this.PharmacyModel.findOne({ _id: Id });
      var repaymentData;
      if (invoices) {
        repaymentData = await this.TransactionData.find({ invoiceId: invoices._id })
      }
      return { data: { success: true, message: invoices, repaymentData } };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  public async getHospitalByIdToLender(req: Request, currentUser: IUser): Promise<{ data: any }> {
    try {
      const ID = req.query._id;
      const userDetails = currentUser;
      var BusinessLogic = {};
      const hospital = await this.organizationModel.findOne({ _id: ID });
      if (hospital && hospital.isSplit != undefined) {
        if (hospital.isSplit == true) {
          BusinessLogic = await this.businessLogicsModel.findOne({ hospitalId: ID });
        }
      }
      return {
        data: {
          success: true,
          data: BusinessLogic,
          message: hospital,
        },
      };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  public async postCreditLimitFromLender(req, currentUser: IUser): Promise<{ data: any }> {
    try {
      const hospitalId = req.query._id;
      const {
        ExistingCreditLimit,
        LTV,
        LenderTenure,
        LenderROI,
        LComment,
        LStatus,
      } = req.body;

      const orgDetail = await this.organizationModel.findOne({ _id: hospitalId });

      let org_Detail: any = {};

      if (ExistingCreditLimit) {
        org_Detail.ExistingCreditLimit = ExistingCreditLimit;
      }
      if (LTV) {
        org_Detail.LenderLTV = LTV;
      }
      if (LenderTenure) {
        org_Detail.LenderTenure = LenderTenure;
      }
      if (LenderROI) {
        org_Detail.LenderROI = LenderROI;
      }
      if (LComment) {
        org_Detail.LComment = LComment;
      }
      if (LStatus) {
        org_Detail.LStatus = LStatus;
      }

      var Rep = 0;
      var UTL = 0;
      if (orgDetail.Repayment != undefined) {
        Rep = orgDetail.Repayment;
      }
      if (orgDetail.UtilizedAmount != undefined) {
        UTL = orgDetail.UtilizedAmount;
      }

      if (ExistingCreditLimit != undefined) {
        org_Detail.AvailableLimit = ExistingCreditLimit - UTL + Rep;
      }

      org_Detail.Repayment = 0;
      org_Detail.UtilizedAmount = 0;

      const orgData = await this.organizationModel.findByIdAndUpdate(
        { _id: hospitalId },
        { $set: org_Detail },
        { new: true }
      );

      return {
        data: {
          success: true,
          message: "Successfully Update",
          UserData: orgData,
        }
      };

    } catch (error) {
      this.logger.error(error);
      return {
        data: { success: false, error: error }
      }
    }
  }
  public async getByIdToLender(req: Request, currentUser: IUser): Promise<{ data: any }> {
    try {
      const lender = await this.organizationModel.findOne({ _id: currentUser.organizationId });
      return {
        data: {
          success: true,
          message: lender,
        },
      };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  public async editLenderProfile(req: Request, currentUser: IUser): Promise<{ data: any }> {
    try {
      const { nameOfOrganization, contactNumber, address, AadharNumber, AccountName, AccountNumber, NameOfTheBank, IFSCcode, Branch } =
        req.body;

      const editLender = await this.organizationModel.findOne({ _id: currentUser.organizationId });

      if (!editLender) {
        return {
          data: {
            success: false,
            message: 'Invalid Id!',
          },
        };
      }
      let Lenderdata: any = {};

      if (contactNumber) {
        Lenderdata.contactNumber = contactNumber;
      }
      if (address) {
        Lenderdata.address = address;
      }
      if (AccountName) {
        Lenderdata.AccountName = AccountName;
      }
      if (AccountNumber) {
        Lenderdata.AccountNumber = AccountNumber;
      }
      if (NameOfTheBank) {
        Lenderdata.NameOfTheBank = NameOfTheBank;
      }
      if (IFSCcode) {
        Lenderdata.IFSCcode = IFSCcode;
      }
      if (Branch) {
        Lenderdata.Branch = Branch;
      }
      if (nameOfOrganization) {
        Lenderdata.nameOfOrganization = nameOfOrganization;
      }

      if (AadharNumber) {
        Lenderdata.AadharNumber = AadharNumber;
      }
      Lenderdata.updatedBy = currentUser._id;

      if (AccountNumber) {
        const accountNumbers = await this.organizationModel.find({ AccountNumber: AccountNumber });
        for (var doc of accountNumbers) {
          if (!(doc._id.equals(currentUser.organizationId))) {
            return {
              data: {
                message: 'Account Number already exist',
              },
            };
          }
        }
      }

      const lenderList = await this.organizationModel.updateOne(
        { _id: currentUser.organizationId },
        { $set: Lenderdata },
        { useFindAndModify: false },
      );
      return {
        data: {
          success: true,
          message: 'Lender Profile Updated Successfully',
          editLender,
        },
      };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  public async updatePassword(req, userInputDTO: IUserInputDTO, currentUser: IUser): Promise<{ data: any }> {
    try {
      const id = currentUser._id;
      const userDetails = await this.userModel.findOne({ _id: id });
      if (!userDetails) {
        return {
          data: {
            success: false,
            message: 'user not found',
          },
        };
      }
      const salt = randomBytes(32);
      this.logger.silly('Hashing password');
      const hashedPassword = await argon2.hash(userInputDTO.password, { salt });

      this.logger.silly('updating password');
      let passwordData: any = {};

      passwordData.updatedAt = new Date().toUTCString();
      passwordData.updatedBy = currentUser._id;
      passwordData.salt = salt.toString('hex');
      passwordData.password = hashedPassword;
      passwordData.passwordUpdateOn = new Date().toUTCString();

      const userRecord = await this.userModel.findByIdAndUpdate(
        { _id: id },
        { $set: passwordData },
        { useFindAndModify: false, new: true },
      );
      if (!userRecord) {
        throw new Error('password cannot be updated');
      }

      const user = userRecord.toObject();
      Reflect.deleteProperty(user, 'password');
      Reflect.deleteProperty(user, 'salt');
      var data = { success: true };
      return { data };
    } catch (error) {
      this.logger.error(error);
      return {
        data: { success: false, error: error },
      };
    }
  }
  public async postLApprovedToLender(body: any, currentUser: IUser): Promise<{ data: any }> {
    try {
      const vendorDetail = await this.PharmacyModel.findOne({ _id: body._id })
      if (!vendorDetail) {
        return {
          data: {
            success: false,
            message: 'Not a valid Vendor ID'
          }
        }
      }
      let anchorDetails: any = {};
      anchorDetails.LResponseDate = new Date()
      anchorDetails.Status = "Lender Approved"
      if (body.LenderComment) {
        anchorDetails.LenderComment = body.LenderComment
      }
      const invoices = await this.PharmacyModel.updateOne({ _id: body._id }, { $set: anchorDetails }, { useFindAndModify: false });
      return {
        data: {
          success: true,
          message: 'Succesfully Updated',
          invoices
        }
      }
    } catch (e) {
      console.error(e);

      throw e
    }

  }
  public async postLRejectedToLender(body: any, currentUser: IUser): Promise<{ data: any }> {
    try {
      const vendorDetail = await this.PharmacyModel.findOne({ _id: body._id })
      if (!vendorDetail) {
        return {
          data: {
            success: false,
            message: 'Not a valid Vendor ID'
          }
        }
      }
      let anchorDetails: any = {};
      anchorDetails.LResponseDate = new Date()
      anchorDetails.Status = "Lender Rejected"
      if (body.LenderComment) {
        anchorDetails.LenderComment = body.LenderComment
      }
      const invoices = await this.PharmacyModel.updateOne({ _id: body._id }, { $set: anchorDetails }, { useFindAndModify: false });
      return {
        data: {
          success: true,
          message: 'Succesfully Updated',
          invoices
        }
      }
    } catch (e) {
      console.error(e);

      throw e
    }

  }
  public async  postFundedToLender(body: any, currentUser: IUser): Promise<{ data: any }> {
    try {
      const invoiceDetail = await this.PharmacyModel.findOne({ _id: body._id })
      if (!invoiceDetail) {
        return {
          data: {
            success: false,
            message: 'Not a valid invoice ID'
          }
        }
      }

      var date1 = new Date(body.PaymentDate);
      var finalDate1 = new Date(date1.setDate(date1.getDate()));
      body.PaymentDate = new Date(finalDate1);

      let anchorDetails: any = {};
      anchorDetails.Status = "Disbursed"
      if (body.InvoiceNumber) {
        anchorDetails.InvoiceNumber = body.InvoiceNumber
      }
      if (body.AmountPaid) {
        anchorDetails.AmountPaid = body.AmountPaid
      }
      if (body.PaymentDate) {
        anchorDetails.PaymentDate = body.PaymentDate
      }
      if (body.NEFT_RTG) {
        anchorDetails.NEFT_RTG = body.NEFT_RTG
      }

      const associationDetails = await this.DPAssociationModel.findOne({
        $and: [{ PmanufactureId: invoiceDetail.PmanufactureId }, { distributorId: invoiceDetail.distributorId }]
      });

      if (associationDetails.UtilizedAmount != undefined) {
        var utilizedLimit = associationDetails.UtilizedAmount;
      }
      else {
        utilizedLimit = 0;
      }
      var date = new Date(anchorDetails.PaymentDate);
      var repiad = new Date(date.setDate(date.getDate() + invoiceDetail.NoOfDaysCreditPeriod));

      if (repiad != undefined) { anchorDetails.RepaymentDueDate = repiad }

      //var AvailableLimit = hospitalDetails.AvailableLimit;
      var UtilizedAmount = utilizedLimit + invoiceDetail.LTVAmount;

      if (associationDetails.Repayment != undefined) {
        var AvailableLimit = associationDetails.creditLimit - UtilizedAmount + associationDetails.Repayment;
      }
      else {
        AvailableLimit = associationDetails.AvailableLimit - UtilizedAmount;
      }

      const updateAssociation = await this.DPAssociationModel.updateOne(
        { _id: associationDetails._id }, {
        $set: {
          UtilizedAmount: UtilizedAmount, AvailableLimit: AvailableLimit,
        },
      }
      );
      const invoices = await this.PharmacyModel.updateOne({ _id: body._id }, { $set: anchorDetails }, { useFindAndModify: false });

      /// transaction log

      const transaction = await this.TransactionData.create({
        invoiceId: body._id,
        LoanID: invoiceDetail.LoanID,
        distributorId: invoiceDetail.distributorId,
        PmanufactureId: invoiceDetail.PmanufactureId,
        lenderId: invoiceDetail.LenderId,
        InvoiceNumber: invoiceDetail.InvoiceNumber,
        AmountDisbursed: anchorDetails.AmountPaid,
        transactionDate: anchorDetails.PaymentDate,
        NEFT_RTG: anchorDetails.NEFT_RTG,
        AmountToBePaid: invoiceDetail.LTVAmount,
        Interest: invoiceDetail.upfrontInterest,
        SettleStatus: anchorDetails.Status,
        // AdditionalDays: AdditionalDays,
        // AdditionalInterest: AdditionalInterest,
        RemainingAmount: invoiceDetail.LTVAmount,
        // AmountReceived: AmountReceived,
        createdBy: currentUser._id
      })
      ///
      return {
        data: {
          success: true,
          message: 'Succesfully Updated',
          invoices
        }
      }
    } catch (e) {
      console.error(e);

      throw e
    }

  }
  public async postRepaidToLender(body: any, currentUser: IUser): Promise<{ data: any }> {
    try {
      let { AmountReceived, InvoiceNumber, PaymentReceivedDate, ReceivedNEFT_RTG,_id } = body;
      
      const invoiceDetail = await this.PharmacyModel.findOne({ $and: [{ _id:_id }, { $or: [{ Status: "Disbursed" }, { Status: "Distributor Repaid" }] }] });
      // const invoiceDetail = await this.PharmacyModel.findOne({ _id: _id }, { $or: [{ Status: "Disbursed" }, { Status: "Distributor Repaid" }] } );
      if (!invoiceDetail) {
        return {
          data: {
            message: "Not a valid Invoice ID",
          }
        };
      }
      const repaymentData = await this.TransactionData.find({ invoiceId: invoiceDetail._id })
      var totalRepayment = 0;
      for (let e of repaymentData) {
        if (e.SettleStatus !== "Disbursed") {
          totalRepayment = totalRepayment + e.AmountReceived
        }
      }
      var InvoiceDate = invoiceDetail.InvoiceDate.toLocaleDateString();
      let anchorDetails: any = {};
      anchorDetails.Status = "Fully Repaid";
      AmountReceived = totalRepayment;
      anchorDetails.AmountReceived = totalRepayment;
      if (PaymentReceivedDate) {
        anchorDetails.PaymentReceivedDate = PaymentReceivedDate;
      }
      if (ReceivedNEFT_RTG) {
        anchorDetails.ReceivedNEFT_RTG = ReceivedNEFT_RTG;
      }
      const hospitalDetails = await this.organizationModel.findOne({ _id: invoiceDetail.distributorId });
      const associationDetails = await this.DPAssociationModel.findOne({
        $and: [{ PmanufactureId: invoiceDetail.PmanufactureId }, { distributorId: invoiceDetail.distributorId }]
      });
      var date2 = new Date(invoiceDetail.hDueDate).getTime();
      var date1 = new Date(PaymentReceivedDate).getTime();
      var OverdueNoOfDays = Math.floor((date1 - date2) / (1000 * 60 * 60 * 24))
      if (OverdueNoOfDays >= 0) { anchorDetails.OverdueNoOfDays = OverdueNoOfDays }
      else {
        anchorDetails.OverdueNoOfDays = 0;
      }
      var AdditionalInterest = 0;
      var OverdueCharges = 0;
      if (OverdueNoOfDays > 0) {

        AdditionalInterest = 200
        if (AdditionalInterest != undefined) { anchorDetails.AdditionalInterest = AdditionalInterest }

        OverdueCharges = Math.round((invoiceDetail.LTVAmount * hospitalDetails.LenderROI * OverdueNoOfDays) / (30 * 100))
        if (OverdueCharges != undefined) { anchorDetails.OverdueCharges = OverdueCharges }
      }
      else {
        AdditionalInterest = 0;
        if (AdditionalInterest != undefined) { anchorDetails.AdditionalInterest = AdditionalInterest }
        OverdueCharges = 0;
        if (OverdueCharges != undefined) { anchorDetails.OverdueCharges = OverdueCharges }
      }

      var TotalDeduction = (invoiceDetail.LTVAmount + AdditionalInterest + OverdueCharges);
      if (TotalDeduction != undefined) { anchorDetails.TotalDeduction = TotalDeduction }


      var BalanceAmount = TotalDeduction;
      if (BalanceAmount != undefined) {
        anchorDetails.BalanceAmount = BalanceAmount
      }
      anchorDetails.PastRecoveryAmount = 0;

      var AmtToTransfer = BalanceAmount - AmountReceived;
      if (AmtToTransfer != undefined) {

        anchorDetails.AmtToTransfer = AmtToTransfer
      }

      if (BalanceAmount == AmountReceived) {

        anchorDetails.SettleStatus = "FullPaid";

      } else if (BalanceAmount < AmountReceived) {
        anchorDetails.SettleStatus = "OverPaid";
      }
      else {
        anchorDetails.SettleStatus = "UnderPaid";
      }


      if (associationDetails.Repayment != undefined) {
        var RepaymentLimit = associationDetails.Repayment;

        var RepaymentAmount = RepaymentLimit + invoiceDetail.LTVAmount;
      }
      else {
        RepaymentAmount = invoiceDetail.LTVAmount;
      }

      var AvailableLimit = associationDetails.creditLimit - associationDetails.UtilizedAmount + RepaymentAmount;
      const updateAssociation = await this.DPAssociationModel.updateOne(
        { _id: associationDetails._id },
        {
          $set: {
            Repayment: RepaymentAmount,
            AvailableLimit: AvailableLimit,
          }
        }
      );
      const updateInvoice = await this.PharmacyModel.updateOne(
        { _id: body._id },
        { $set: anchorDetails },
        { useFindAndModify: false }
      );
      return { data: { success: true, message: "Successfully Repaid" } };
    } catch (e) {
      console.error(e);
      return {
        data: { success: false, message: e }
      }
    }
  }
  public async postPastRecoveryAmountDetailsToLender(body: any, currentUser: IUser): Promise<{ data: any }> {
    try {
      let { PastRecovery, PastRecoveryNumber, PastRecoveryDetails } = body;
      const ID = body._id;

      const invoiceDetail = await this.PharmacyModel.findOne({
        $and: [{ _id: ID }, { Status: "Fully Repaid" }],
      });
      const invoiceToUpdate = await this.PharmacyModel.findOne({
        $and: [{ claimId: PastRecoveryNumber }, { Status: "Fully Repaid" }],
      });
      if (!invoiceDetail) {
        return {
          data: {
            message: "Not a valid Invoice ID",
          }
        };
      }
      let prevDetails: any = {};
      if (invoiceToUpdate) {
        if (PastRecovery != undefined) {
          var UpdtBalanceAmount =
            invoiceToUpdate.BalanceAmount - PastRecovery;
          if (UpdtBalanceAmount != undefined) {
            prevDetails.BalanceAmount = UpdtBalanceAmount;
          }
          prevDetails.LateRecovery = PastRecovery;

          var UpdtAmtToTransfer =
            invoiceToUpdate.AmountReceived - UpdtBalanceAmount;
          if (UpdtAmtToTransfer != undefined) {
            prevDetails.RemainingAmount = UpdtAmtToTransfer;
          }

          if (UpdtBalanceAmount == invoiceToUpdate.AmountReceived) {
            prevDetails.SettleStatus = "FullPaid";
          } else if (UpdtBalanceAmount < invoiceToUpdate.AmountReceived) {
            prevDetails.SettleStatus = "OverPaid";
          } else {
            prevDetails.SettleStatus = "UnderPaid";
          }
        }
      }

      let anchorDetails: any = {};
      if (PastRecoveryDetails) {
        anchorDetails.PastRecoveryDetails = PastRecoveryDetails;
      }
      if (invoiceDetail) {
        if (PastRecovery != undefined) {
          anchorDetails.PastRecovery = PastRecovery;
          anchorDetails.PastRecoveryNumber = PastRecoveryNumber;
        }
      }
      const addedUser = await this.PharmacyModel.updateOne(
        { _id: ID },
        { $set: anchorDetails },
        { useFindAndModify: false }
      );

      const updatePrevInvoice = await this.PharmacyModel.updateOne(
        {
          $and: [{ claimId: PastRecoveryNumber }, { Status: "Fully Repaid" }],
        },
        { $set: prevDetails },
        { useFindAndModify: false }
      );

      return { data: { success: true, message: "Successfully Repaid" } };
    } catch (e) {
      console.error(e);
      return {
        data: { success: false, message: e }
      }
    }
  }
}
