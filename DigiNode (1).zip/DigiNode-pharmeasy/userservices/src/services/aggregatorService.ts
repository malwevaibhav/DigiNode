import { Service, Inject } from 'typedi';
import { Request, Response } from 'express';
import { EventDispatcher, EventDispatcherInterface } from '../decorators/eventDispatcher';
import { IUser, IUserInputDTO, IFilterDTO } from '../interfaces/IUser';
import argon2 from 'argon2';
import MailerService from './mailer';
import { randomBytes } from 'crypto';
import events from '../subscribers/events';
import { Types } from 'mongoose';
import moment from 'moment';
import MailJetService from '../loaders/mailjet';
@Service()
export default class aggregatorService {
    constructor(
        @Inject('userModel') private userModel: Models.UserModel,
        @Inject('ClaimInvoice') private Invoice: Models.ClaimInvoiceModel,
        @Inject('organizationModel') private organizationModel: Models.organizationModel,
        @Inject('businessLogics') private businessLogicsModel: Models.businessLogicsModel,
        @Inject('InsuranceMasterModel') private InsuranceModel: Models.InsuranceMasterModel,
        @Inject('TPAMasterModel') private TPAModel: Models.TPAMasterModel,
        @Inject('LTVMasterModel') private ltvModel: Models.LTVMasterModel,
        @Inject('Cities') private CitiesModel: Models.CitiesModel,
        @Inject('TransactionDataModel') private TransactionData: Models.TransactionDataModel,
        @Inject('logger') private logger,
        @EventDispatcher() private eventDispatcher: EventDispatcherInterface,
        private mailer: MailerService,
        private mailjet: MailJetService,
    ) { }

    public async getDashboardForAggregator(req: Request, res: Response, currentUser: IUser): Promise<{ data: any }> {
        try {
            const userDetails = currentUser;

            const hospitaldata = await this.organizationModel.find(
                { aggregatorId: currentUser.organizationId }
            );
            if (hospitaldata) {
                var len = hospitaldata.length;
            }
            var ExistingCreditLimit = 0;
            var AvailableLimit = 0;
            var UtilizedAmount = 0;
            var Repayment = 0;
            var Totalinvoices = 0;
            var TotalInvoicesClaimAmount = 0;
            var Totalpendinginvoices = 0;
            var TotalPendingClaimAmount = 0;
            var TotalRejectedinvoices = 0;
            var TotalRejectedClaimAmount = 0;
            var fundedInvoiceLength = 0;
            var TotalFundedClaimamount = 0;
            var repaidLenth = 0;

            for (let i = 0; i < len; i++) {
                if (hospitaldata) {
                    var Existing = hospitaldata[i].ExistingCreditLimit;
                    if (Existing) {
                        ExistingCreditLimit = ExistingCreditLimit + Existing;
                    }
                }
                if (hospitaldata) {
                    var Available = hospitaldata[i].AvailableLimit;
                    if (Available) {
                        AvailableLimit = AvailableLimit + Available;
                    }
                }
                if (hospitaldata) {
                    var Utilized = hospitaldata[i].UtilizedAmount;
                    if (Utilized) {
                        UtilizedAmount = UtilizedAmount + Utilized;
                    }
                }
                if (hospitaldata) {
                    var Repay = hospitaldata[i].Repayment;
                    if (Repay) {
                        Repayment = Repayment + Repay;
                    }
                }
                var countone = await this.Invoice.aggregate([
                    {
                        $facet: {
                            sumone: [
                                { $match: { hospitalId: hospitaldata[i]._id } },
                                { $count: "total" },
                            ],
                            sum1: [
                                { $match: { hospitalId: hospitaldata[i]._id } },
                                { $group: { _id: "$_v", total: { $sum: "$LenderApprovalAmount" } } },
                            ],
                            sumtwo: [
                                {
                                    $match: {
                                        $and: [
                                            { hospitalId: hospitaldata[i]._id },
                                            {
                                                $or: [
                                                    { Status: "Pending" },
                                                    { Status: "DSPL Approved" },
                                                    { Status: "Lender Approved" },
                                                    { Status: "Validated" },
                                                ],
                                            },
                                        ],
                                    },
                                },
                                { $count: "total" },
                            ],
                            sum2: [
                                {
                                    $match: {
                                        $and: [
                                            { hospitalId: hospitaldata[i]._id },
                                            {
                                                $or: [
                                                    { Status: "Pending" },
                                                    { Status: "DSPL Approved" },
                                                    { Status: "Lender Approved" },
                                                    { Status: "Validated" },
                                                ],
                                            },
                                        ],
                                    },
                                },
                                { $group: { _id: "$_v", total: { $sum: "$LenderApprovalAmount" } } },
                            ],
                            sumthree: [
                                {
                                    $match: {
                                        $and: [
                                            { hospitalId: hospitaldata[i]._id },
                                            {
                                                $or: [
                                                    { Status: "DSPL Rejected" },
                                                    { Status: "Lender Rejected" },
                                                    { Status: "VRejected" },
                                                ],
                                            },
                                        ],
                                    },
                                },
                                { $count: "total" },
                            ],
                            sum3: [
                                {
                                    $match: {
                                        $and: [
                                            { hospitalId: hospitaldata[i]._id },
                                            {
                                                $or: [
                                                    { Status: "DSPL Rejected" },
                                                    { Status: "Lender Rejected" },
                                                    { Status: "VRejected" },
                                                ],
                                            },
                                        ],
                                    },
                                },
                                { $group: { _id: "$_v", total: { $sum: "$LenderApprovalAmount" } } },
                            ],
                            sumfour: [
                                {
                                    $match: {
                                        $and: [
                                            { hospitalId: hospitaldata[i]._id },
                                            { $or: [{ Status: "Disbursed" }, { Status: "Fully Repaid" }, { Status: "Partially Repaid" }, { Status: "RepaymentConfirmed" }] },
                                        ],
                                    },
                                },
                                { $count: "total" },
                            ],
                            sum4: [
                                {
                                    $match: {
                                        $and: [
                                            { hospitalId: hospitaldata[i]._id },
                                            { $or: [{ Status: "Disbursed" }, { Status: "Fully Repaid" }, { Status: "Partially Repaid" }, { Status: "RepaymentConfirmed" }] },
                                        ],
                                    },
                                },
                                { $group: { _id: "$_v", total: { $sum: "$LenderApprovalAmount" } } },
                            ],
                            sumfive: [
                                {
                                    $match: {
                                        $and: [
                                            { hospitalId: hospitaldata[i]._id },
                                            { $or: [{ Status: "Fully Repaid" }, { Status: "RepaymentConfirmed" }] }
                                        ],
                                    },
                                },
                                { $count: "total" },
                            ],
                        },
                    },
                ]);

                if (countone[0].sumone[0] != undefined) {
                    Totalinvoices += countone[0].sumone[0].total;
                } else {
                    Totalinvoices += 0;
                }
                if (countone[0].sum1[0] != undefined) {
                    TotalInvoicesClaimAmount += countone[0].sum1[0].total;
                } else {
                    TotalInvoicesClaimAmount += 0;
                }
                if (countone[0].sumtwo[0] != undefined) {
                    Totalpendinginvoices += countone[0].sumtwo[0].total;
                } else {
                    Totalpendinginvoices += 0;
                }
                if (countone[0].sum2[0] != undefined) {
                    TotalPendingClaimAmount += countone[0].sum2[0].total;
                } else {
                    TotalPendingClaimAmount += 0;
                }
                if (countone[0].sumthree[0] != undefined) {
                    TotalRejectedinvoices += countone[0].sumthree[0].total;
                } else {
                    TotalRejectedinvoices += 0;
                }
                if (countone[0].sum3[0] != undefined) {
                    TotalRejectedClaimAmount += countone[0].sum3[0].total;
                } else {
                    TotalRejectedClaimAmount += 0;
                }
                if (countone[0].sumfour[0] != undefined) {
                    fundedInvoiceLength += countone[0].sumfour[0].total;
                } else {
                    fundedInvoiceLength += 0;
                }
                if (countone[0].sum4[0] != undefined) {
                    TotalFundedClaimamount += countone[0].sum4[0].total;
                } else {
                    TotalFundedClaimamount += 0;
                }
                if (countone[0].sumfive[0] != undefined) {
                    repaidLenth += countone[0].sumfive[0].total;
                } else {
                    repaidLenth += 0;
                }
            }
            var data = {
                success: true,
                Totalhospital: len,
                UtilizedAmount: UtilizedAmount,
                repaidInvoiceCount: repaidLenth,
                Repayment: Repayment,
                TotalAvailableLimit: AvailableLimit,
                CreditLimit: ExistingCreditLimit,
                Totalinvoices: Totalinvoices,
                TotalInvoicesClaimAmount: TotalInvoicesClaimAmount,
                Totalpendinginvoices: Totalpendinginvoices,
                TotalPendingClaimAmount: TotalPendingClaimAmount,
                TotalfundedInvoices: fundedInvoiceLength,
                TotalFundedClaimamount: TotalFundedClaimamount,
                TotalRejectedinvoices: TotalRejectedinvoices,
                TotalRejectedClaimAmount: TotalRejectedClaimAmount,
            }
            return { data };
        } catch (e) {
            this.logger.error(e);
            throw e;
        }
    }
    public async getDashboardData(req: Request, res: Response, currentUser: IUser): Promise<{ data: any }> {
        try {
            var searchFilters = [];
            searchFilters.push({ isDeleted: false });
            searchFilters.push({ $or: [{ aggregatorId: currentUser._id }, { aggregatorId: currentUser.organizationId }] });

            if (req.query.dateFrom != undefined || null && req.query.dateTo != undefined || null) {
                searchFilters.push({ createdAt: { $gte: req.query.dateFrom, $lte: req.query.dateTo } });
            }
            var dashboardData = await this.Invoice.aggregate([
                {
                    $facet: {
                        totalCount: [{ $match: { $and: searchFilters } }, { $count: 'total' }],
                        totalAmount: [
                            { $match: { $and: searchFilters } },
                            { $group: { _id: '$_v', total: { $sum: '$LenderApprovalAmount' } } },
                        ],

                        totalInProcessCount: [{
                            $match: {
                                $and: [{ $and: searchFilters }, {
                                    $or: [
                                        { Status: "Pending" },
                                        { Status: "DSPL Approved" },
                                        { Status: "Lender Approved" },
                                        { Status: "Validated" },
                                    ],
                                },],
                            },
                        },
                        { $count: 'total' },
                        ],

                        totalInProcessAmount: [{
                            $match: {
                                $and: [{ $and: searchFilters }, {
                                    $or: [
                                        { Status: "Pending" },
                                        { Status: "DSPL Approved" },
                                        { Status: "Lender Approved" },
                                        { Status: "Validated" },
                                    ],
                                },],
                            },
                        },
                        { $group: { _id: '$_v', total: { $sum: '$LenderApprovalAmount' } } },
                        ],

                        totalFundedCount: [{
                            $match: {
                                $and: [{ $and: searchFilters }, {
                                    $or: [
                                        { Status: "Disbursed" },
                                        { Status: "Fully Repaid" },
                                        { Status: "Partially Repaid" },
                                        { Status: "RepaymentConfirmed" }
                                    ],
                                },],
                            }
                        }, { $count: 'total' }],

                        totalFundedAmount: [{
                            $match: {
                                $and: [{ $and: searchFilters }, {
                                    $or: [
                                        { Status: "Disbursed" },
                                        { Status: "Fully Repaid" },
                                        { Status: "Partially Repaid" },
                                        { Status: "RepaymentConfirmed" }
                                    ],
                                },],
                            }
                        },
                        { $group: { _id: '$_v', total: { $sum: '$LenderApprovalAmount' } } },
                        ],

                        totalRepaidCount: [{
                            $match: {
                                $and: [{ $and: searchFilters }, {
                                    $or: [
                                        { Status: "Fully Repaid" },
                                        { Status: "RepaymentConfirmed" }
                                    ],
                                },],
                            }
                        }, { $count: 'total' }],

                        totalRepaidAmount: [
                            {
                                $match: {
                                    $and: [{ $and: searchFilters }, {
                                        $or: [
                                            { Status: "Fully Repaid" },
                                            { Status: "RepaymentConfirmed" }
                                        ],
                                    },],
                                }
                            },
                            { $group: { _id: '$_v', total: { $sum: '$LenderApprovalAmount' } } },
                        ],

                        totalRejectedCount: [{
                            $match: {
                                $and: [{ $and: searchFilters }, {
                                    $or: [
                                        { Status: "DSPL Rejected" },
                                        { Status: "Lender Rejected" }
                                    ],
                                },],
                            },
                        }, { $count: 'total' }
                        ],

                        totalRejectedAmount: [{
                            $match: {
                                $and: [{ $and: searchFilters }, {
                                    $or: [
                                        { Status: "DSPL Rejected" },
                                        { Status: "Lender Rejected" },
                                    ],
                                },],
                            },
                        },
                        { $group: { _id: '$_v', total: { $sum: '$LenderApprovalAmount' } } },
                        ]
                    },
                },
            ]);

            var totalCount = 0;
            var totalAmount = 0;
            var totalInProcessCount = 0;
            var totalInProcessAmount = 0;
            var totalRejectedCount = 0;
            var totalRejectedAmount = 0;
            var totalFundedCount = 0;
            var totalFundedAmount = 0;
            var totalRepaidCount = 0;
            var totalRepaidAmount = 0;

            if (dashboardData[0].totalCount[0] != undefined) { totalCount = dashboardData[0].totalCount[0].total; } else { totalCount = 0; }
            if (dashboardData[0].totalAmount[0] != undefined) { totalAmount = dashboardData[0].totalAmount[0].total; } else { totalAmount = 0; }

            if (dashboardData[0].totalInProcessCount[0] != undefined) { totalInProcessCount = dashboardData[0].totalInProcessCount[0].total; } else { totalInProcessCount = 0; }
            if (dashboardData[0].totalInProcessAmount[0] != undefined) { totalInProcessAmount = dashboardData[0].totalInProcessAmount[0].total; } else { totalInProcessAmount = 0; }

            if (dashboardData[0].totalFundedCount[0] != undefined) { totalFundedCount = dashboardData[0].totalFundedCount[0].total; } else { totalFundedCount = 0; }
            if (dashboardData[0].totalFundedAmount[0] != undefined) { totalFundedAmount = dashboardData[0].totalFundedAmount[0].total; } else { totalFundedAmount = 0; }

            if (dashboardData[0].totalRepaidCount[0] != undefined) { totalRepaidCount = dashboardData[0].totalRepaidCount[0].total; } else { totalRepaidCount = 0; }
            if (dashboardData[0].totalRepaidAmount[0] != undefined) { totalRepaidAmount = dashboardData[0].totalRepaidAmount[0].total; } else { totalRepaidAmount = 0; }

            if (dashboardData[0].totalRejectedCount[0] != undefined) { totalRejectedCount = dashboardData[0].totalRejectedCount[0].total; } else { totalRejectedCount = 0; }
            if (dashboardData[0].totalRejectedAmount[0] != undefined) { totalRejectedAmount = dashboardData[0].totalRejectedAmount[0].total; } else { totalRejectedAmount = 0; }

            var data = {
                totalCount: totalCount,
                totalAmount: totalAmount,
                totalInProcessCount: totalInProcessCount,
                totalInProcessAmount: totalInProcessAmount,
                totalFundedCount: totalFundedCount,
                totalFundedAmount: totalFundedAmount,
                totalRepaidCount: totalRepaidCount,
                totalRepaidAmount: totalRepaidAmount,
                totalRejectedCount: totalRejectedCount,
                totalRejectedAmount: totalRejectedAmount
            }
            return { data };
        } catch (e) {
            this.logger.error(e);
            throw e;
        }
    }
    public async getInvoiceGraphToAggregator(req: Request, res: Response, currentUser: IUser): Promise<{ data: any }> {
        try {
            const userDetails = currentUser;

            var countInvoice = 0;
            var countInProcess = 0;
            var countDisbursed = 0;
            var countRejected = 0;
            var countRepaid = 0;

            var forcalc = new Date();
            var thismonth = forcalc.getMonth() + 1;
            var t = forcalc.getFullYear();
            var this1 = new Date(t, thismonth - 1, 1);

            var month1 = forcalc.getMonth();
            if (month1 < 0) {
                month1 += 12;
                forcalc.setFullYear(forcalc.getFullYear() - 1);
            }
            forcalc.setMonth(month1);
            var a = forcalc.getFullYear();
            var d1m1 = new Date(a, month1 - 1, 1);
            var laster1 = new Date(a, month1, 0);
            laster1.setHours(23, 59, 59, 0);
            if (month1 <= 0) {
                month1 += 12;
                a = a - 1
            }

            var month2 = forcalc.getMonth() - 1;
            if (month2 < 0) {
                month2 += 12;
                forcalc.setFullYear(forcalc.getFullYear() - 1);
            }
            forcalc.setMonth(month2);
            var b = forcalc.getFullYear();
            var d1m2 = new Date(b, month2 - 1, 1);
            var laster2 = new Date(b, month2, 0);
            laster2.setHours(23, 59, 59, 0);
            if (month2 <= 0) {
                month2 += 12;
                b = b - 1
            }

            var month3 = forcalc.getMonth() - 1;
            if (month3 < 0) {
                month3 += 12;
                forcalc.setFullYear(forcalc.getFullYear() - 1);
            }
            forcalc.setMonth(month3);
            var c = forcalc.getFullYear();
            var d1m3 = new Date(c, month3 - 1, 1);
            var laster3 = new Date(c, month3, 0);
            laster3.setHours(23, 59, 59, 0);
            if (month3 <= 0) {
                month3 += 12;
                c = c - 1
            }

            var month4 = forcalc.getMonth() - 1;
            if (month4 < 0) {
                month4 += 12;
                forcalc.setFullYear(forcalc.getFullYear() - 1);
            }
            forcalc.setMonth(month4);
            var d = forcalc.getFullYear();
            var d1m4 = new Date(d, month4 - 1, 1);
            var laster4 = new Date(d, month4, 0);
            laster4.setHours(23, 59, 59, 0);
            if (month4 <= 0) {
                month4 += 12;
                d = d - 1
            }

            var month5 = forcalc.getMonth() - 1;
            if (month5 < 0) {
                month5 += 12;
                forcalc.setFullYear(forcalc.getFullYear() - 1);
            }
            forcalc.setMonth(month5);
            var e = forcalc.getFullYear();
            var d1m5 = new Date(e, month5 - 1, 1);
            var laster5 = new Date(e, month5, 0);
            laster5.setHours(23, 59, 59, 0);
            if (month5 <= 0) {
                month5 += 12;
                e = e - 1
            }

            var todaydate = new Date();

            var hospitaldata = await this.organizationModel.find({ $or: [{ aggregatorId: currentUser._id }, { aggregatorId: currentUser.organizationId }] });
            if (hospitaldata) {
                var len = hospitaldata.length;

                for (let i = 0; i < len; i++) {
                    var countone = await this.Invoice.aggregate([
                        {
                            $facet: {
                                sumone: [
                                    {
                                        $match: {
                                            $and: [
                                                { hospitalId: hospitaldata[i]._id },
                                                { createdAt: { $gte: d1m5, $lte: todaydate } },
                                            ],
                                        },
                                    },
                                    { $count: "total" },
                                ],
                                sumtwo: [
                                    {
                                        $match: {
                                            $and: [
                                                { hospitalId: hospitaldata[i]._id },
                                                { createdAt: { $gte: d1m5, $lte: todaydate } },
                                                {
                                                    $or: [
                                                        { Status: "Pending" },
                                                        { Status: "DSPL Approved" },
                                                        { Status: "Lender Approved" },
                                                        { Status: "Validated" },
                                                    ],
                                                },
                                            ],
                                        },
                                    },
                                    { $count: "total" },
                                ],
                                sumthree: [
                                    {
                                        $match: {
                                            $and: [
                                                { hospitalId: hospitaldata[i]._id },
                                                { createdAt: { $gte: d1m5, $lte: todaydate } },
                                                { $or: [{ Status: "Disbursed" }, { Status: "Fully Repaid" }, { Status: "Partially Repaid" }, { Status: "RepaymentConfirmed" }] },
                                            ],
                                        },
                                    },
                                    { $count: "total" },
                                ],
                                sumfour: [
                                    {
                                        $match: {
                                            $and: [
                                                { hospitalId: hospitaldata[i]._id },
                                                { createdAt: { $gte: d1m5, $lte: todaydate } },
                                                {
                                                    $or: [
                                                        { Status: "DSPL Rejected" },
                                                        { Status: "Lender Rejected" },
                                                        { Status: "VRejected" },
                                                    ],
                                                },
                                            ],
                                        },
                                    },
                                    { $count: "total" },
                                ],
                                sumfive: [
                                    {
                                        $match: {
                                            $and: [
                                                { hospitalId: hospitaldata[i]._id },
                                                { createdAt: { $gte: d1m5, $lte: todaydate } },
                                                { $or: [{ Status: "Fully Repaid" }, { Status: "RepaymentConfirmed" }] },
                                            ],
                                        },
                                    },
                                    { $count: "total" },
                                ],
                            },
                        },
                    ]);

                    if (countone[0].sumone[0] != undefined) {
                        countInvoice += countone[0].sumone[0].total;
                    } else {
                        countInvoice += 0;
                    }
                    if (countone[0].sumtwo[0] != undefined) {
                        countInProcess += countone[0].sumtwo[0].total;
                    } else {
                        countInProcess += 0;
                    }
                    if (countone[0].sumthree[0] != undefined) {
                        countDisbursed += countone[0].sumthree[0].total;
                    } else {
                        countDisbursed += 0;
                    }
                    if (countone[0].sumfour[0] != undefined) {
                        countRejected += countone[0].sumfour[0].total;
                    } else {
                        countRejected += 0;
                    }
                    if (countone[0].sumfive[0] != undefined) {
                        countRepaid += countone[0].sumfive[0].total;
                    } else {
                        countRepaid += 0;
                    }
                }
            }

            var data = {
                success: true,
                Totalinvoicescount: countInvoice,
                TotalcountInProcess: countInProcess,
                TotalcountDisbursed: countDisbursed,
                TotalcountRejected: countRejected,
                TotalcountRepaid: countRepaid,
            }
            return { data };
        } catch (e) {
            this.logger.error(e);
            throw e;
        }
    }
    public async getAggregatorGraphAmount(req: Request, res: Response, currentUser: IUser): Promise<{ data: any }> {
        try {

            const userDetails = currentUser;

            var sum1 = 0;
            var sum2 = 0;
            var sum3 = 0;
            var sum4 = 0;
            var sum5 = 0;
            var sum6 = 0;

            var InProcesssum1 = 0;
            var InProcesssum2 = 0;
            var InProcesssum3 = 0;
            var InProcesssum4 = 0;
            var InProcesssum5 = 0;
            var InProcesssum6 = 0;

            var Disbursedsum1 = 0;
            var Disbursedsum2 = 0;
            var Disbursedsum3 = 0;
            var Disbursedsum4 = 0;
            var Disbursedsum5 = 0;
            var Disbursedsum6 = 0;

            var Repaidsum1 = 0;
            var Repaidsum2 = 0;
            var Repaidsum3 = 0;
            var Repaidsum4 = 0;
            var Repaidsum5 = 0;
            var Repaidsum6 = 0;

            var Rejectedsum1 = 0;
            var Rejectedsum2 = 0;
            var Rejectedsum3 = 0;
            var Rejectedsum4 = 0;
            var Rejectedsum5 = 0;
            var Rejectedsum6 = 0;
            var forcalc = new Date();
            var thismonth = forcalc.getMonth() + 1;
            var t = forcalc.getFullYear();
            var this1 = new Date(t, thismonth - 1, 1);

            var month1 = forcalc.getMonth();
            if (month1 < 0) {
                month1 += 12;
                forcalc.setFullYear(forcalc.getFullYear() - 1);
            }
            forcalc.setMonth(month1);
            var a = forcalc.getFullYear();
            var d1m1 = new Date(a, month1 - 1, 1);
            var laster1 = new Date(a, month1, 0);
            laster1.setHours(23, 59, 59, 0);
            if (month1 <= 0) {
                month1 += 12;
                a = a - 1
            }
            var month2 = forcalc.getMonth() - 1;
            if (month2 < 0) {
                month2 += 12;
                forcalc.setFullYear(forcalc.getFullYear() - 1);
            }
            forcalc.setMonth(month2);
            var b = forcalc.getFullYear();
            var d1m2 = new Date(b, month2 - 1, 1);
            var laster2 = new Date(b, month2, 0);
            laster2.setHours(23, 59, 59, 0);
            if (month2 <= 0) {
                month2 += 12;
                b = b - 1
            }

            var month3 = forcalc.getMonth() - 1;
            if (month3 < 0) {
                month3 += 12;
                forcalc.setFullYear(forcalc.getFullYear() - 1);
            }
            forcalc.setMonth(month3);
            var c = forcalc.getFullYear();
            var d1m3 = new Date(c, month3 - 1, 1);
            var laster3 = new Date(c, month3, 0);
            laster3.setHours(23, 59, 59, 0);
            if (month3 <= 0) {
                month3 += 12;
                c = c - 1
            }

            var month4 = forcalc.getMonth() - 1;
            if (month4 < 0) {
                month4 += 12;
                forcalc.setFullYear(forcalc.getFullYear() - 1);
            }
            forcalc.setMonth(month4);
            var d = forcalc.getFullYear();
            var d1m4 = new Date(d, month4 - 1, 1);
            var laster4 = new Date(d, month4, 0);
            laster4.setHours(23, 59, 59, 0);
            if (month4 <= 0) {
                month4 += 12;
                d = d - 1
            }

            var month5 = forcalc.getMonth() - 1;
            if (month5 < 0) {
                month5 += 12;
                forcalc.setFullYear(forcalc.getFullYear() - 1);
            }
            forcalc.setMonth(month5);
            var e = forcalc.getFullYear();
            var d1m5 = new Date(e, month5 - 1, 1);
            var laster5 = new Date(e, month5, 0);
            laster5.setHours(23, 59, 59, 0);
            if (month5 <= 0) {
                month5 += 12;
                e = e - 1
            }

            var todaydate = new Date();

            var hospitaldata = await this.organizationModel.find({ aggregatorId: userDetails.organizationId });
            if (hospitaldata) {
                var len = hospitaldata.length;

                for (let i = 0; i < len; i++) {
                    var countone = await this.Invoice.aggregate([
                        {
                            $facet: {
                                sumone: [
                                    {
                                        $match: {
                                            $and: [
                                                { hospitalId: hospitaldata[i]._id },
                                                { createdAt: { $gte: this1, $lte: todaydate } },
                                            ],
                                        },
                                    },
                                    { $group: { _id: "$_v", total: { $sum: "$LenderApprovalAmount" } } },
                                ],
                                sumtwo: [
                                    {
                                        $match: {
                                            $and: [
                                                { hospitalId: hospitaldata[i]._id },
                                                { createdAt: { $gte: d1m1, $lte: laster1 } },
                                            ],
                                        },
                                    },
                                    { $group: { _id: "$_v", total: { $sum: "$LenderApprovalAmount" } } },
                                ],
                                sumthree: [
                                    {
                                        $match: {
                                            $and: [
                                                { hospitalId: hospitaldata[i]._id },
                                                { createdAt: { $gte: d1m2, $lte: laster2 } },
                                            ],
                                        },
                                    },
                                    { $group: { _id: "$_v", total: { $sum: "$LenderApprovalAmount" } } },
                                ],
                                sumfour: [
                                    {
                                        $match: {
                                            $and: [
                                                { hospitalId: hospitaldata[i]._id },
                                                { createdAt: { $gte: d1m3, $lte: laster3 } },
                                            ],
                                        },
                                    },
                                    { $group: { _id: "$_v", total: { $sum: "$LenderApprovalAmount" } } },
                                ],
                                sumfive: [
                                    {
                                        $match: {
                                            $and: [
                                                { hospitalId: hospitaldata[i]._id },
                                                { createdAt: { $gte: d1m4, $lte: laster4 } },
                                            ],
                                        },
                                    },
                                    { $group: { _id: "$_v", total: { $sum: "$LenderApprovalAmount" } } },
                                ],
                                sumsix: [
                                    {
                                        $match: {
                                            $and: [
                                                { hospitalId: hospitaldata[i]._id },
                                                { createdAt: { $gte: d1m5, $lte: laster5 } },
                                            ],
                                        },
                                    },
                                    { $group: { _id: "$_v", total: { $sum: "$LenderApprovalAmount" } } },
                                ],

                                InProsumone: [
                                    {
                                        $match: {
                                            $and: [
                                                { createdAt: { $gte: this1, $lte: todaydate } },
                                                { hospitalId: hospitaldata[i]._id },
                                                {
                                                    $or: [
                                                        { Status: "Pending" },
                                                        { Status: "Validated" },
                                                        { Status: "DSPL Approved" },
                                                        { Status: "Lender Approved" },
                                                    ],
                                                },
                                            ],
                                        },
                                    },
                                    { $group: { _id: "$_v", total: { $sum: "$LenderApprovalAmount" } } },
                                ],
                                InProsumtwo: [
                                    {
                                        $match: {
                                            $and: [
                                                { createdAt: { $gte: d1m1, $lte: laster1 } },
                                                { hospitalId: hospitaldata[i]._id },
                                                {
                                                    $or: [
                                                        { Status: "Pending" },
                                                        { Status: "Validated" },
                                                        { Status: "DSPL Approved" },
                                                        { Status: "Lender Approved" },
                                                    ],
                                                },
                                            ],
                                        },
                                    },
                                    { $group: { _id: "$_v", total: { $sum: "$LenderApprovalAmount" } } },
                                ],
                                InProsumthree: [
                                    {
                                        $match: {
                                            $and: [
                                                { createdAt: { $gte: d1m2, $lte: laster2 } },
                                                { hospitalId: hospitaldata[i]._id },
                                                {
                                                    $or: [
                                                        { Status: "Pending" },
                                                        { Status: "Validated" },
                                                        { Status: "DSPL Approved" },
                                                        { Status: "Lender Approved" },
                                                    ],
                                                },
                                            ],
                                        },
                                    },
                                    { $group: { _id: "$_v", total: { $sum: "$LenderApprovalAmount" } } },
                                ],
                                InProsumfour: [
                                    {
                                        $match: {
                                            $and: [
                                                { createdAt: { $gte: d1m3, $lte: laster3 } },
                                                { hospitalId: hospitaldata[i]._id },
                                                {
                                                    $or: [
                                                        { Status: "Pending" },
                                                        { Status: "Validated" },
                                                        { Status: "DSPL Approved" },
                                                        { Status: "Lender Approved" },
                                                    ],
                                                },
                                            ],
                                        },
                                    },
                                    { $group: { _id: "$_v", total: { $sum: "$LenderApprovalAmount" } } },
                                ],
                                InProsumfive: [
                                    {
                                        $match: {
                                            $and: [
                                                { createdAt: { $gte: d1m4, $lte: laster4 } },
                                                { hospitalId: hospitaldata[i]._id },
                                                {
                                                    $or: [
                                                        { Status: "Pending" },
                                                        { Status: "Validated" },
                                                        { Status: "DSPL Approved" },
                                                        { Status: "Lender Approved" },
                                                    ],
                                                },
                                            ],
                                        },
                                    },
                                    { $group: { _id: "$_v", total: { $sum: "$LenderApprovalAmount" } } },
                                ],
                                InProsumsix: [
                                    {
                                        $match: {
                                            $and: [
                                                { createdAt: { $gte: d1m5, $lte: laster5 } },
                                                { hospitalId: hospitaldata[i]._id },
                                                {
                                                    $or: [
                                                        { Status: "Pending" },
                                                        { Status: "Validated" },
                                                        { Status: "DSPL Approved" },
                                                        { Status: "Lender Approved" },
                                                    ],
                                                },
                                            ],
                                        },
                                    },
                                    { $group: { _id: "$_v", total: { $sum: "$LenderApprovalAmount" } } },
                                ],

                                Disbursedsumone: [
                                    {
                                        $match: {
                                            $and: [
                                                { createdAt: { $gte: this1, $lte: todaydate } },
                                                { hospitalId: hospitaldata[i]._id },
                                                { $or: [{ Status: "Disbursed" }, { Status: "Fully Repaid" }, { Status: "Partially Repaid" }, { Status: "RepaymentConfirmed" }] },
                                            ],
                                        },
                                    },
                                    { $group: { _id: "$_v", total: { $sum: "$LenderApprovalAmount" } } },
                                ],
                                Disbursedsumtwo: [
                                    {
                                        $match: {
                                            $and: [
                                                { createdAt: { $gte: d1m1, $lte: laster1 } },
                                                { hospitalId: hospitaldata[i]._id },
                                                { $or: [{ Status: "Disbursed" }, { Status: "Fully Repaid" }, { Status: "Partially Repaid" }, { Status: "RepaymentConfirmed" }] },
                                            ],
                                        },
                                    },
                                    { $group: { _id: "$_v", total: { $sum: "$LenderApprovalAmount" } } },
                                ],
                                Disbursedsumthree: [
                                    {
                                        $match: {
                                            $and: [
                                                { createdAt: { $gte: d1m2, $lte: laster2 } },
                                                { hospitalId: hospitaldata[i]._id },
                                                { $or: [{ Status: "Disbursed" }, { Status: "Fully Repaid" }, { Status: "Partially Repaid" }, { Status: "RepaymentConfirmed" }] },
                                            ],
                                        },
                                    },
                                    { $group: { _id: "$_v", total: { $sum: "$LenderApprovalAmount" } } },
                                ],
                                Disbursedsumfour: [
                                    {
                                        $match: {
                                            $and: [
                                                { createdAt: { $gte: d1m3, $lte: laster3 } },
                                                { hospitalId: hospitaldata[i]._id },
                                                { $or: [{ Status: "Disbursed" }, { Status: "Fully Repaid" }, { Status: "Partially Repaid" }, { Status: "RepaymentConfirmed" }] },
                                            ],
                                        },
                                    },
                                    { $group: { _id: "$_v", total: { $sum: "$LenderApprovalAmount" } } },
                                ],
                                Disbursedsumfive: [
                                    {
                                        $match: {
                                            $and: [
                                                { createdAt: { $gte: d1m4, $lte: laster4 } },
                                                { hospitalId: hospitaldata[i]._id },
                                                { $or: [{ Status: "Disbursed" }, { Status: "Fully Repaid" }, { Status: "Partially Repaid" }, { Status: "RepaymentConfirmed" }] },
                                            ],
                                        },
                                    },
                                    { $group: { _id: "$_v", total: { $sum: "$LenderApprovalAmount" } } },
                                ],
                                Disbursedsumsix: [
                                    {
                                        $match: {
                                            $and: [
                                                { createdAt: { $gte: d1m5, $lte: laster5 } },
                                                { hospitalId: hospitaldata[i]._id },
                                                { $or: [{ Status: "Disbursed" }, { Status: "Fully Repaid" }, { Status: "Partially Repaid" }, { Status: "RepaymentConfirmed" }] },
                                            ],
                                        },
                                    },
                                    { $group: { _id: "$_v", total: { $sum: "$LenderApprovalAmount" } } },
                                ],

                                Repaidsumone: [
                                    {
                                        $match: {
                                            $and: [
                                                { createdAt: { $gte: this1, $lte: todaydate } },
                                                { hospitalId: hospitaldata[i]._id },
                                                { $or: [{ Status: "Fully Repaid" }, { Status: "RepaymentConfirmed" }] },
                                            ],
                                        },
                                    },
                                    { $group: { _id: "$_v", total: { $sum: "$LenderApprovalAmount" } } },
                                ],
                                Repaidsumtwo: [
                                    {
                                        $match: {
                                            $and: [
                                                { createdAt: { $gte: d1m1, $lte: laster1 } },
                                                { hospitalId: hospitaldata[i]._id },
                                                { $or: [{ Status: "Fully Repaid" }, { Status: "RepaymentConfirmed" }] },
                                            ],
                                        },
                                    },
                                    { $group: { _id: "$_v", total: { $sum: "$LenderApprovalAmount" } } },
                                ],
                                Repaidsumthree: [
                                    {
                                        $match: {
                                            $and: [
                                                { createdAt: { $gte: d1m2, $lte: laster2 } },
                                                { hospitalId: hospitaldata[i]._id },
                                                { $or: [{ Status: "Fully Repaid" }, { Status: "RepaymentConfirmed" }] },
                                            ],
                                        },
                                    },
                                    { $group: { _id: "$_v", total: { $sum: "$LenderApprovalAmount" } } },
                                ],
                                Repaidsumfour: [
                                    {
                                        $match: {
                                            $and: [
                                                { createdAt: { $gte: d1m3, $lte: laster3 } },
                                                { hospitalId: hospitaldata[i]._id },
                                                { $or: [{ Status: "Fully Repaid" }, { Status: "RepaymentConfirmed" }] },
                                            ],
                                        },
                                    },
                                    { $group: { _id: "$_v", total: { $sum: "$LenderApprovalAmount" } } },
                                ],
                                Repaidsumfive: [
                                    {
                                        $match: {
                                            $and: [
                                                { createdAt: { $gte: d1m4, $lte: laster4 } },
                                                { hospitalId: hospitaldata[i]._id },
                                                { $or: [{ Status: "Fully Repaid" }, { Status: "RepaymentConfirmed" }] },
                                            ],
                                        },
                                    },
                                    { $group: { _id: "$_v", total: { $sum: "$LenderApprovalAmount" } } },
                                ],
                                Repaidsumsix: [
                                    {
                                        $match: {
                                            $and: [
                                                { createdAt: { $gte: d1m5, $lte: laster5 } },
                                                { hospitalId: hospitaldata[i]._id },
                                                { $or: [{ Status: "Fully Repaid" }, { Status: "RepaymentConfirmed" }] },
                                            ],
                                        },
                                    },
                                    { $group: { _id: "$_v", total: { $sum: "$LenderApprovalAmount" } } },
                                ],

                                Rejectedsumone: [
                                    {
                                        $match: {
                                            $and: [
                                                { createdAt: { $gte: this1, $lte: todaydate } },
                                                { hospitalId: hospitaldata[i]._id },
                                                {
                                                    $or: [
                                                        { Status: "VRejected" },
                                                        { Status: "DSPL Rejected" },
                                                        { Status: "Lender Rejected" },
                                                    ],
                                                },
                                            ],
                                        },
                                    },
                                    { $group: { _id: "$_v", total: { $sum: "$LenderApprovalAmount" } } },
                                ],
                                Rejectedsumtwo: [
                                    {
                                        $match: {
                                            $and: [
                                                { createdAt: { $gte: d1m1, $lte: laster1 } },
                                                { hospitalId: hospitaldata[i]._id },
                                                {
                                                    $or: [
                                                        { Status: "VRejected" },
                                                        { Status: "DSPL Rejected" },
                                                        { Status: "Lender Rejected" },
                                                    ],
                                                },
                                            ],
                                        },
                                    },
                                    { $group: { _id: "$_v", total: { $sum: "$LenderApprovalAmount" } } },
                                ],
                                Rejectedsumthree: [
                                    {
                                        $match: {
                                            $and: [
                                                { createdAt: { $gte: d1m2, $lte: laster2 } },
                                                { hospitalId: hospitaldata[i]._id },
                                                {
                                                    $or: [
                                                        { Status: "VRejected" },
                                                        { Status: "DSPL Rejected" },
                                                        { Status: "Lender Rejected" },
                                                    ],
                                                },
                                            ],
                                        },
                                    },
                                    { $group: { _id: "$_v", total: { $sum: "$LenderApprovalAmount" } } },
                                ],
                                Rejectedsumfour: [
                                    {
                                        $match: {
                                            $and: [
                                                { createdAt: { $gte: d1m3, $lte: laster3 } },
                                                { hospitalId: hospitaldata[i]._id },
                                                {
                                                    $or: [
                                                        { Status: "VRejected" },
                                                        { Status: "DSPL Rejected" },
                                                        { Status: "Lender Rejected" },
                                                    ],
                                                },
                                            ],
                                        },
                                    },
                                    { $group: { _id: "$_v", total: { $sum: "$LenderApprovalAmount" } } },
                                ],
                                Rejectedsumfive: [
                                    {
                                        $match: {
                                            $and: [
                                                { createdAt: { $gte: d1m4, $lte: laster4 } },
                                                { hospitalId: hospitaldata[i]._id },
                                                {
                                                    $or: [
                                                        { Status: "VRejected" },
                                                        { Status: "DSPL Rejected" },
                                                        { Status: "Lender Rejected" },
                                                    ],
                                                },
                                            ],
                                        },
                                    },
                                    { $group: { _id: "$_v", total: { $sum: "$LenderApprovalAmount" } } },
                                ],
                                Rejectedsumsix: [
                                    {
                                        $match: {
                                            $and: [
                                                { createdAt: { $gte: d1m5, $lte: laster5 } },
                                                { hospitalId: hospitaldata[i]._id },
                                                {
                                                    $or: [
                                                        { Status: "VRejected" },
                                                        { Status: "DSPL Rejected" },
                                                        { Status: "Lender Rejected" },
                                                    ],
                                                },
                                            ],
                                        },
                                    },
                                    { $group: { _id: "$_v", total: { $sum: "$LenderApprovalAmount" } } },
                                ],
                            },
                        },
                    ]);

                    if (countone[0].sumone[0] != undefined) {
                        sum1 += countone[0].sumone[0].total;
                    } else {
                        sum1 += 0;
                    }
                    if (countone[0].sumtwo[0] != undefined) {
                        sum2 += countone[0].sumtwo[0].total;
                    } else {
                        sum2 += 0;
                    }
                    if (countone[0].sumthree[0] != undefined) {
                        sum3 += countone[0].sumthree[0].total;
                    } else {
                        sum3 += 0;
                    }
                    if (countone[0].sumfour[0] != undefined) {
                        sum4 += countone[0].sumfour[0].total;
                    } else {
                        sum4 += 0;
                    }
                    if (countone[0].sumfive[0] != undefined) {
                        sum5 += countone[0].sumfive[0].total;
                    } else {
                        sum5 += 0;
                    }
                    if (countone[0].sumsix[0] != undefined) {
                        sum6 += countone[0].sumsix[0].total;
                    } else {
                        sum6 += 0;
                    }

                    if (countone[0].InProsumone[0] != undefined) {
                        InProcesssum1 += countone[0].InProsumone[0].total;
                    } else {
                        InProcesssum1 += 0;
                    }
                    if (countone[0].InProsumtwo[0] != undefined) {
                        InProcesssum2 += countone[0].InProsumtwo[0].total;
                    } else {
                        InProcesssum2 += 0;
                    }
                    if (countone[0].InProsumthree[0] != undefined) {
                        InProcesssum3 += countone[0].InProsumthree[0].total;
                    } else {
                        InProcesssum3 += 0;
                    }
                    if (countone[0].InProsumfour[0] != undefined) {
                        InProcesssum4 += countone[0].InProsumfour[0].total;
                    } else {
                        InProcesssum4 += 0;
                    }
                    if (countone[0].InProsumfive[0] != undefined) {
                        InProcesssum5 += countone[0].InProsumfive[0].total;
                    } else {
                        InProcesssum5 += 0;
                    }
                    if (countone[0].InProsumsix[0] != undefined) {
                        InProcesssum6 += countone[0].InProsumsix[0].total;
                    } else {
                        InProcesssum6 += 0;
                    }

                    if (countone[0].Disbursedsumone[0] != undefined) {
                        Disbursedsum1 += countone[0].Disbursedsumone[0].total;
                    } else {
                        Disbursedsum1 += 0;
                    }
                    if (countone[0].Disbursedsumtwo[0] != undefined) {
                        Disbursedsum2 += countone[0].Disbursedsumtwo[0].total;
                    } else {
                        Disbursedsum2 += 0;
                    }
                    if (countone[0].Disbursedsumthree[0] != undefined) {
                        Disbursedsum3 += countone[0].Disbursedsumthree[0].total;
                    } else {
                        Disbursedsum3 += 0;
                    }
                    if (countone[0].Disbursedsumfour[0] != undefined) {
                        Disbursedsum4 += countone[0].Disbursedsumfour[0].total;
                    } else {
                        Disbursedsum4 += 0;
                    }
                    if (countone[0].Disbursedsumfive[0] != undefined) {
                        Disbursedsum5 += countone[0].Disbursedsumfive[0].total;
                    } else {
                        Disbursedsum5 += 0;
                    }
                    if (countone[0].Disbursedsumsix[0] != undefined) {
                        Disbursedsum6 += countone[0].Disbursedsumsix[0].total;
                    } else {
                        Disbursedsum6 += 0;
                    }

                    if (countone[0].Repaidsumone[0] != undefined) {
                        Repaidsum1 += countone[0].Repaidsumone[0].total;
                    } else {
                        Repaidsum1 += 0;
                    }
                    if (countone[0].Repaidsumtwo[0] != undefined) {
                        Repaidsum2 += countone[0].Repaidsumtwo[0].total;
                    } else {
                        Repaidsum2 += 0;
                    }
                    if (countone[0].Repaidsumthree[0] != undefined) {
                        Repaidsum3 += countone[0].Repaidsumthree[0].total;
                    } else {
                        Repaidsum3 += 0;
                    }
                    if (countone[0].Repaidsumfour[0] != undefined) {
                        Repaidsum4 += countone[0].Repaidsumfour[0].total;
                    } else {
                        Repaidsum4 += 0;
                    }
                    if (countone[0].Repaidsumfive[0] != undefined) {
                        Repaidsum5 += countone[0].Repaidsumfive[0].total;
                    } else {
                        Repaidsum5 += 0;
                    }
                    if (countone[0].Repaidsumsix[0] != undefined) {
                        Repaidsum6 += countone[0].Repaidsumsix[0].total;
                    } else {
                        Repaidsum6 += 0;
                    }

                    if (countone[0].Rejectedsumone[0] != undefined) {
                        Rejectedsum1 += countone[0].Rejectedsumone[0].total;
                    } else {
                        Rejectedsum1 += 0;
                    }
                    if (countone[0].Rejectedsumtwo[0] != undefined) {
                        Rejectedsum2 += countone[0].Rejectedsumtwo[0].total;
                    } else {
                        Rejectedsum2 += 0;
                    }
                    if (countone[0].Rejectedsumthree[0] != undefined) {
                        Rejectedsum3 += countone[0].Rejectedsumthree[0].total;
                    } else {
                        Rejectedsum3 += 0;
                    }
                    if (countone[0].Rejectedsumfour[0] != undefined) {
                        Rejectedsum4 += countone[0].Rejectedsumfour[0].total;
                    } else {
                        Rejectedsum4 += 0;
                    }
                    if (countone[0].Rejectedsumfive[0] != undefined) {
                        Rejectedsum5 += countone[0].Rejectedsumfive[0].total;
                    } else {
                        Rejectedsum5 += 0;
                    }
                    if (countone[0].Rejectedsumsix[0] != undefined) {
                        Rejectedsum6 += countone[0].Rejectedsumsix[0].total;
                    } else {
                        Rejectedsum6 += 0;
                    }
                }
            }

            var data = {
                success: true,
                monthsAndYears: [
                    [thismonth, t],
                    [month1, a],
                    [month2, b],
                    [month3, c],
                    [month4, d],
                    [month5, e],
                ],
                All: [sum1, sum2, sum3, sum4, sum5, sum6],
                InProcess: [
                    InProcesssum1,
                    InProcesssum2,
                    InProcesssum3,
                    InProcesssum4,
                    InProcesssum5,
                    InProcesssum6,
                ],
                Disbursed: [
                    Disbursedsum1,
                    Disbursedsum2,
                    Disbursedsum3,
                    Disbursedsum4,
                    Disbursedsum5,
                    Disbursedsum6,
                ],
                Repaid: [
                    Repaidsum1,
                    Repaidsum2,
                    Repaidsum3,
                    Repaidsum4,
                    Repaidsum5,
                    Repaidsum6,
                ],
                Rejected: [
                    Rejectedsum1,
                    Rejectedsum2,
                    Rejectedsum3,
                    Rejectedsum4,
                    Rejectedsum5,
                    Rejectedsum6,
                ],

            }
            return { data };
        } catch (e) {
            this.logger.error(e);
            throw e;
        }
    }
    public async getAggregatorGraphOne(req: Request, res: Response, currentUser: IUser): Promise<{ data: any }> {
        try {
            const userDetails = currentUser;

            var sum1 = 0;
            var sum2 = 0;
            var sum3 = 0;
            var sum4 = 0;
            var sum5 = 0;
            var sum6 = 0;

            var InProcesssum1 = 0;
            var InProcesssum2 = 0;
            var InProcesssum3 = 0;
            var InProcesssum4 = 0;
            var InProcesssum5 = 0;
            var InProcesssum6 = 0;

            var Disbursedsum1 = 0;
            var Disbursedsum2 = 0;
            var Disbursedsum3 = 0;
            var Disbursedsum4 = 0;
            var Disbursedsum5 = 0;
            var Disbursedsum6 = 0;

            var Repaidsum1 = 0;
            var Repaidsum2 = 0;
            var Repaidsum3 = 0;
            var Repaidsum4 = 0;
            var Repaidsum5 = 0;
            var Repaidsum6 = 0;

            var Rejectedsum1 = 0;
            var Rejectedsum2 = 0;
            var Rejectedsum3 = 0;
            var Rejectedsum4 = 0;
            var Rejectedsum5 = 0;
            var Rejectedsum6 = 0;

            var forcalc = new Date();
            var thismonth = forcalc.getMonth() + 1;
            var t = forcalc.getFullYear();
            var this1 = new Date(t, thismonth - 1, 1);

            var month1 = forcalc.getMonth();
            if (month1 < 0) {
                month1 += 12;
                forcalc.setFullYear(forcalc.getFullYear() - 1);
            }
            forcalc.setMonth(month1);
            var a = forcalc.getFullYear();
            var d1m1 = new Date(a, month1 - 1, 1);
            var laster1 = new Date(a, month1, 0);
            laster1.setHours(23, 59, 59, 0);
            if (month1 <= 0) {
                month1 += 12;
                a = a - 1
            }
            var month2 = forcalc.getMonth() - 1;
            if (month2 < 0) {
                month2 += 12;
                forcalc.setFullYear(forcalc.getFullYear() - 1);
            }
            forcalc.setMonth(month2);
            var b = forcalc.getFullYear();
            var d1m2 = new Date(b, month2 - 1, 1);
            var laster2 = new Date(b, month2, 0);
            laster2.setHours(23, 59, 59, 0);
            if (month2 <= 0) {
                month2 += 12;
                b = b - 1
            }

            var month3 = forcalc.getMonth() - 1;
            if (month3 < 0) {
                month3 += 12;
                forcalc.setFullYear(forcalc.getFullYear() - 1);
            }
            forcalc.setMonth(month3);
            var c = forcalc.getFullYear();
            var d1m3 = new Date(c, month3 - 1, 1);
            var laster3 = new Date(c, month3, 0);
            laster3.setHours(23, 59, 59, 0);
            if (month3 <= 0) {
                month3 += 12;
                c = c - 1
            }

            var month4 = forcalc.getMonth() - 1;
            if (month4 < 0) {
                month4 += 12;
                forcalc.setFullYear(forcalc.getFullYear() - 1);
            }
            forcalc.setMonth(month4);
            var d = forcalc.getFullYear();
            var d1m4 = new Date(d, month4 - 1, 1);
            var laster4 = new Date(d, month4, 0);
            laster4.setHours(23, 59, 59, 0);
            if (month4 <= 0) {
                month4 += 12;
                d = d - 1
            }

            var month5 = forcalc.getMonth() - 1;
            if (month5 < 0) {
                month5 += 12;
                forcalc.setFullYear(forcalc.getFullYear() - 1);
            }
            forcalc.setMonth(month5);
            var e = forcalc.getFullYear();
            var d1m5 = new Date(e, month5 - 1, 1);
            var laster5 = new Date(e, month5, 0);
            laster5.setHours(23, 59, 59, 0);
            if (month5 <= 0) {
                month5 += 12;
                e = e - 1
            }

            var todaydate = new Date();

            var hospitaldata = await this.organizationModel.find({ aggregatorId: userDetails.organizationId });
            if (hospitaldata) {
                var hos = hospitaldata.length;
            }
            for (let i = 0; i < hos; i++) {
                var countone = await this.Invoice.aggregate([
                    {
                        $facet: {
                            sumone: [
                                {
                                    $match: {
                                        $and: [
                                            { hospitalId: hospitaldata[i]._id },
                                            { createdAt: { $gte: this1, $lte: todaydate } },
                                        ],
                                    },
                                },
                                { $count: "total" },
                            ],
                            sumtwo: [
                                {
                                    $match: {
                                        $and: [
                                            { hospitalId: hospitaldata[i]._id },
                                            { createdAt: { $gte: d1m1, $lte: laster1 } },
                                        ],
                                    },
                                },
                                { $count: "total" },
                            ],
                            sumthree: [
                                {
                                    $match: {
                                        $and: [
                                            { hospitalId: hospitaldata[i]._id },
                                            { createdAt: { $gte: d1m2, $lte: laster2 } },
                                        ],
                                    },
                                },
                                { $count: "total" },
                            ],
                            sumfour: [
                                {
                                    $match: {
                                        $and: [
                                            { hospitalId: hospitaldata[i]._id },
                                            { createdAt: { $gte: d1m3, $lte: laster3 } },
                                        ],
                                    },
                                },
                                { $count: "total" },
                            ],
                            sumfive: [
                                {
                                    $match: {
                                        $and: [
                                            { hospitalId: hospitaldata[i]._id },
                                            { createdAt: { $gte: d1m4, $lte: laster4 } },
                                        ],
                                    },
                                },
                                { $count: "total" },
                            ],
                            sumsix: [
                                {
                                    $match: {
                                        $and: [
                                            { hospitalId: hospitaldata[i]._id },
                                            { createdAt: { $gte: d1m5, $lte: laster5 } },
                                        ],
                                    },
                                },
                                { $count: "total" },
                            ],

                            InProsumone: [
                                {
                                    $match: {
                                        $and: [
                                            { createdAt: { $gte: this1, $lte: todaydate } },
                                            { hospitalId: hospitaldata[i]._id },
                                            {
                                                $or: [
                                                    { Status: "Pending" },
                                                    { Status: "Validated" },
                                                    { Status: "DSPL Approved" },
                                                    { Status: "Lender Approved" },
                                                ],
                                            },
                                        ],
                                    },
                                },
                                { $count: "total" },
                            ],
                            InProsumtwo: [
                                {
                                    $match: {
                                        $and: [
                                            { createdAt: { $gte: d1m1, $lte: laster1 } },
                                            { hospitalId: hospitaldata[i]._id },
                                            {
                                                $or: [
                                                    { Status: "Pending" },
                                                    { Status: "Validated" },
                                                    { Status: "DSPL Approved" },
                                                    { Status: "Lender Approved" },
                                                ],
                                            },
                                        ],
                                    },
                                },
                                { $count: "total" },
                            ],
                            InProsumthree: [
                                {
                                    $match: {
                                        $and: [
                                            { createdAt: { $gte: d1m2, $lte: laster2 } },
                                            { hospitalId: hospitaldata[i]._id },
                                            {
                                                $or: [
                                                    { Status: "Pending" },
                                                    { Status: "Validated" },
                                                    { Status: "DSPL Approved" },
                                                    { Status: "Lender Approved" },
                                                ],
                                            },
                                        ],
                                    },
                                },
                                { $count: "total" },
                            ],
                            InProsumfour: [
                                {
                                    $match: {
                                        $and: [
                                            { createdAt: { $gte: d1m3, $lte: laster3 } },
                                            { hospitalId: hospitaldata[i]._id },
                                            {
                                                $or: [
                                                    { Status: "Pending" },
                                                    { Status: "Validated" },
                                                    { Status: "DSPL Approved" },
                                                    { Status: "Lender Approved" },
                                                ],
                                            },
                                        ],
                                    },
                                },
                                { $count: "total" },
                            ],
                            InProsumfive: [
                                {
                                    $match: {
                                        $and: [
                                            { createdAt: { $gte: d1m4, $lte: laster4 } },
                                            { hospitalId: hospitaldata[i]._id },
                                            {
                                                $or: [
                                                    { Status: "Pending" },
                                                    { Status: "Validated" },
                                                    { Status: "DSPL Approved" },
                                                    { Status: "Lender Approved" },
                                                ],
                                            },
                                        ],
                                    },
                                },
                                { $count: "total" },
                            ],
                            InProsumsix: [
                                {
                                    $match: {
                                        $and: [
                                            { createdAt: { $gte: d1m5, $lte: laster5 } },
                                            { hospitalId: hospitaldata[i]._id },
                                            {
                                                $or: [
                                                    { Status: "Pending" },
                                                    { Status: "Validated" },
                                                    { Status: "DSPL Approved" },
                                                    { Status: "Lender Approved" },
                                                ],
                                            },
                                        ],
                                    },
                                },
                                { $count: "total" },
                            ],

                            Disbursedsumone: [
                                {
                                    $match: {
                                        $and: [
                                            { createdAt: { $gte: this1, $lte: todaydate } },
                                            { hospitalId: hospitaldata[i]._id },
                                            { $or: [{ Status: "Disbursed" }, { Status: "Fully Repaid" }, { Status: "Partially Repaid" }, { Status: "RepaymentConfirmed" }] },
                                        ],
                                    },
                                },
                                { $count: "total" },
                            ],
                            Disbursedsumtwo: [
                                {
                                    $match: {
                                        $and: [
                                            { createdAt: { $gte: d1m1, $lte: laster1 } },
                                            { hospitalId: hospitaldata[i]._id },
                                            { $or: [{ Status: "Disbursed" }, { Status: "Fully Repaid" }, { Status: "Partially Repaid" }, { Status: "RepaymentConfirmed" }] },
                                        ],
                                    },
                                },
                                { $count: "total" },
                            ],
                            Disbursedsumthree: [
                                {
                                    $match: {
                                        $and: [
                                            { createdAt: { $gte: d1m2, $lte: laster2 } },
                                            { hospitalId: hospitaldata[i]._id },
                                            { $or: [{ Status: "Disbursed" }, { Status: "Fully Repaid" }, { Status: "Partially Repaid" }, { Status: "RepaymentConfirmed" }] },
                                        ],
                                    },
                                },
                                { $count: "total" },
                            ],
                            Disbursedsumfour: [
                                {
                                    $match: {
                                        $and: [
                                            { createdAt: { $gte: d1m3, $lte: laster3 } },
                                            { hospitalId: hospitaldata[i]._id },
                                            { $or: [{ Status: "Disbursed" }, { Status: "Fully Repaid" }, { Status: "Partially Repaid" }, { Status: "RepaymentConfirmed" }] },
                                        ],
                                    },
                                },
                                { $count: "total" },
                            ],
                            Disbursedsumfive: [
                                {
                                    $match: {
                                        $and: [
                                            { createdAt: { $gte: d1m4, $lte: laster4 } },
                                            { hospitalId: hospitaldata[i]._id },
                                            { $or: [{ Status: "Disbursed" }, { Status: "Fully Repaid" }, { Status: "Partially Repaid" }, { Status: "RepaymentConfirmed" }] },
                                        ],
                                    },
                                },
                                { $count: "total" },
                            ],
                            Disbursedsumsix: [
                                {
                                    $match: {
                                        $and: [
                                            { createdAt: { $gte: d1m5, $lte: laster5 } },
                                            { hospitalId: hospitaldata[i]._id },
                                            { $or: [{ Status: "Disbursed" }, { Status: "Fully Repaid" }, { Status: "Partially Repaid" }, { Status: "RepaymentConfirmed" }] },
                                        ],
                                    },
                                },
                                { $count: "total" },
                            ],

                            Repaidsumone: [
                                {
                                    $match: {
                                        $and: [
                                            { createdAt: { $gte: this1, $lte: todaydate } },
                                            { hospitalId: hospitaldata[i]._id },
                                            { $or: [{ Status: "Fully Repaid" }, { Status: "RepaymentConfirmed" }] },
                                        ],
                                    },
                                },
                                { $count: "total" },
                            ],
                            Repaidsumtwo: [
                                {
                                    $match: {
                                        $and: [
                                            { createdAt: { $gte: d1m1, $lte: laster1 } },
                                            { hospitalId: hospitaldata[i]._id },
                                            { $or: [{ Status: "Fully Repaid" }, { Status: "RepaymentConfirmed" }] },
                                        ],
                                    },
                                },
                                { $count: "total" },
                            ],
                            Repaidsumthree: [
                                {
                                    $match: {
                                        $and: [
                                            { createdAt: { $gte: d1m2, $lte: laster2 } },
                                            { hospitalId: hospitaldata[i]._id },
                                            { $or: [{ Status: "Fully Repaid" }, { Status: "RepaymentConfirmed" }] },
                                        ],
                                    },
                                },
                                { $count: "total" },
                            ],
                            Repaidsumfour: [
                                {
                                    $match: {
                                        $and: [
                                            { createdAt: { $gte: d1m3, $lte: laster3 } },
                                            { hospitalId: hospitaldata[i]._id },
                                            { $or: [{ Status: "Fully Repaid" }, { Status: "RepaymentConfirmed" }] },
                                        ],
                                    },
                                },
                                { $count: "total" },
                            ],
                            Repaidsumfive: [
                                {
                                    $match: {
                                        $and: [
                                            { createdAt: { $gte: d1m4, $lte: laster4 } },
                                            { hospitalId: hospitaldata[i]._id },
                                            { $or: [{ Status: "Fully Repaid" }, { Status: "RepaymentConfirmed" }] },
                                        ],
                                    },
                                },
                                { $count: "total" },
                            ],
                            Repaidsumsix: [
                                {
                                    $match: {
                                        $and: [
                                            { createdAt: { $gte: d1m5, $lte: laster5 } },
                                            { hospitalId: hospitaldata[i]._id },
                                            { $or: [{ Status: "Fully Repaid" }, { Status: "RepaymentConfirmed" }] },
                                        ],
                                    },
                                },
                                { $count: "total" },
                            ],

                            Rejectedsumone: [
                                {
                                    $match: {
                                        $and: [
                                            { createdAt: { $gte: this1, $lte: todaydate } },
                                            { hospitalId: hospitaldata[i]._id },
                                            {
                                                $or: [
                                                    { Status: "VRejected" },
                                                    { Status: "DSPL Rejected" },
                                                    { Status: "Lender Rejected" },
                                                ],
                                            },
                                        ],
                                    },
                                },
                                { $count: "total" },
                            ],
                            Rejectedsumtwo: [
                                {
                                    $match: {
                                        $and: [
                                            { createdAt: { $gte: d1m1, $lte: laster1 } },
                                            { hospitalId: hospitaldata[i]._id },
                                            {
                                                $or: [
                                                    { Status: "VRejected" },
                                                    { Status: "DSPL Rejected" },
                                                    { Status: "Lender Rejected" },
                                                ],
                                            },
                                        ],
                                    },
                                },
                                { $count: "total" },
                            ],
                            Rejectedsumthree: [
                                {
                                    $match: {
                                        $and: [
                                            { createdAt: { $gte: d1m2, $lte: laster2 } },
                                            { hospitalId: hospitaldata[i]._id },
                                            {
                                                $or: [
                                                    { Status: "VRejected" },
                                                    { Status: "DSPL Rejected" },
                                                    { Status: "Lender Rejected" },
                                                ],
                                            },
                                        ],
                                    },
                                },
                                { $count: "total" },
                            ],
                            Rejectedsumfour: [
                                {
                                    $match: {
                                        $and: [
                                            { createdAt: { $gte: d1m3, $lte: laster3 } },
                                            { hospitalId: hospitaldata[i]._id },
                                            {
                                                $or: [
                                                    { Status: "VRejected" },
                                                    { Status: "DSPL Rejected" },
                                                    { Status: "Lender Rejected" },
                                                ],
                                            },
                                        ],
                                    },
                                },
                                { $count: "total" },
                            ],
                            Rejectedsumfive: [
                                {
                                    $match: {
                                        $and: [
                                            { createdAt: { $gte: d1m4, $lte: laster4 } },
                                            { hospitalId: hospitaldata[i]._id },
                                            {
                                                $or: [
                                                    { Status: "VRejected" },
                                                    { Status: "DSPL Rejected" },
                                                    { Status: "Lender Rejected" },
                                                ],
                                            },
                                        ],
                                    },
                                },
                                { $count: "total" },
                            ],
                            Rejectedsumsix: [
                                {
                                    $match: {
                                        $and: [
                                            { createdAt: { $gte: d1m5, $lte: laster5 } },
                                            { hospitalId: hospitaldata[i]._id },
                                            {
                                                $or: [
                                                    { Status: "VRejected" },
                                                    { Status: "DSPL Rejected" },
                                                    { Status: "Lender Rejected" },
                                                ],
                                            },
                                        ],
                                    },
                                },
                                { $count: "total" },
                            ],
                        },
                    },
                ]);

                if (countone[0].sumone[0] != undefined) {
                    sum1 += countone[0].sumone[0].total;
                } else {
                    sum1 += 0;
                }
                if (countone[0].sumtwo[0] != undefined) {
                    sum2 += countone[0].sumtwo[0].total;
                } else {
                    sum2 += 0;
                }
                if (countone[0].sumthree[0] != undefined) {
                    sum3 += countone[0].sumthree[0].total;
                } else {
                    sum3 += 0;
                }
                if (countone[0].sumfour[0] != undefined) {
                    sum4 += countone[0].sumfour[0].total;
                } else {
                    sum4 += 0;
                }
                if (countone[0].sumfive[0] != undefined) {
                    sum5 += countone[0].sumfive[0].total;
                } else {
                    sum5 += 0;
                }
                if (countone[0].sumsix[0] != undefined) {
                    sum6 += countone[0].sumsix[0].total;
                } else {
                    sum6 += 0;
                }

                if (countone[0].InProsumone[0] != undefined) {
                    InProcesssum1 += countone[0].InProsumone[0].total;
                } else {
                    InProcesssum1 += 0;
                }
                if (countone[0].InProsumtwo[0] != undefined) {
                    InProcesssum2 += countone[0].InProsumtwo[0].total;
                } else {
                    InProcesssum2 += 0;
                }
                if (countone[0].InProsumthree[0] != undefined) {
                    InProcesssum3 += countone[0].InProsumthree[0].total;
                } else {
                    InProcesssum3 += 0;
                }
                if (countone[0].InProsumfour[0] != undefined) {
                    InProcesssum4 += countone[0].InProsumfour[0].total;
                } else {
                    InProcesssum4 += 0;
                }
                if (countone[0].InProsumfive[0] != undefined) {
                    InProcesssum5 += countone[0].InProsumfive[0].total;
                } else {
                    InProcesssum5 += 0;
                }
                if (countone[0].InProsumsix[0] != undefined) {
                    InProcesssum6 += countone[0].InProsumsix[0].total;
                } else {
                    InProcesssum6 += 0;
                }

                if (countone[0].Disbursedsumone[0] != undefined) {
                    Disbursedsum1 += countone[0].Disbursedsumone[0].total;
                } else {
                    Disbursedsum1 += 0;
                }
                if (countone[0].Disbursedsumtwo[0] != undefined) {
                    Disbursedsum2 += countone[0].Disbursedsumtwo[0].total;
                } else {
                    Disbursedsum2 += 0;
                }
                if (countone[0].Disbursedsumthree[0] != undefined) {
                    Disbursedsum3 += countone[0].Disbursedsumthree[0].total;
                } else {
                    Disbursedsum3 += 0;
                }
                if (countone[0].Disbursedsumfour[0] != undefined) {
                    Disbursedsum4 += countone[0].Disbursedsumfour[0].total;
                } else {
                    Disbursedsum4 += 0;
                }
                if (countone[0].Disbursedsumfive[0] != undefined) {
                    Disbursedsum5 += countone[0].Disbursedsumfive[0].total;
                } else {
                    Disbursedsum5 += 0;
                }
                if (countone[0].Disbursedsumsix[0] != undefined) {
                    Disbursedsum6 += countone[0].Disbursedsumsix[0].total;
                } else {
                    Disbursedsum6 += 0;
                }

                if (countone[0].Repaidsumone[0] != undefined) {
                    Repaidsum1 += countone[0].Repaidsumone[0].total;
                } else {
                    Repaidsum1 += 0;
                }
                if (countone[0].Repaidsumtwo[0] != undefined) {
                    Repaidsum2 += countone[0].Repaidsumtwo[0].total;
                } else {
                    Repaidsum2 += 0;
                }
                if (countone[0].Repaidsumthree[0] != undefined) {
                    Repaidsum3 += countone[0].Repaidsumthree[0].total;
                } else {
                    Repaidsum3 += 0;
                }
                if (countone[0].Repaidsumfour[0] != undefined) {
                    Repaidsum4 += countone[0].Repaidsumfour[0].total;
                } else {
                    Repaidsum4 += 0;
                }
                if (countone[0].Repaidsumfive[0] != undefined) {
                    Repaidsum5 += countone[0].Repaidsumfive[0].total;
                } else {
                    Repaidsum5 += 0;
                }
                if (countone[0].Repaidsumsix[0] != undefined) {
                    Repaidsum6 += countone[0].Repaidsumsix[0].total;
                } else {
                    Repaidsum6 += 0;
                }

                if (countone[0].Rejectedsumone[0] != undefined) {
                    Rejectedsum1 += countone[0].Rejectedsumone[0].total;
                } else {
                    Rejectedsum1 += 0;
                }
                if (countone[0].Rejectedsumtwo[0] != undefined) {
                    Rejectedsum2 += countone[0].Rejectedsumtwo[0].total;
                } else {
                    Rejectedsum2 += 0;
                }
                if (countone[0].Rejectedsumthree[0] != undefined) {
                    Rejectedsum3 += countone[0].Rejectedsumthree[0].total;
                } else {
                    Rejectedsum3 += 0;
                }
                if (countone[0].Rejectedsumfour[0] != undefined) {
                    Rejectedsum4 += countone[0].Rejectedsumfour[0].total;
                } else {
                    Rejectedsum4 += 0;
                }
                if (countone[0].Rejectedsumfive[0] != undefined) {
                    Rejectedsum5 += countone[0].Rejectedsumfive[0].total;
                } else {
                    Rejectedsum5 += 0;
                }
                if (countone[0].Rejectedsumsix[0] != undefined) {
                    Rejectedsum6 += countone[0].Rejectedsumsix[0].total;
                } else {
                    Rejectedsum6 += 0;
                }
            }
            var data = {
                success: true,
                monthsAndYears: [
                    [thismonth, t],
                    [month1, a],
                    [month2, b],
                    [month3, c],
                    [month4, d],
                    [month5, e],
                ],
                All: [sum1, sum2, sum3, sum4, sum5, sum6],
                InProcess: [
                    InProcesssum1,
                    InProcesssum2,
                    InProcesssum3,
                    InProcesssum4,
                    InProcesssum5,
                    InProcesssum6,
                ],
                Disbursed: [
                    Disbursedsum1,
                    Disbursedsum2,
                    Disbursedsum3,
                    Disbursedsum4,
                    Disbursedsum5,
                    Disbursedsum6,
                ],
                Repaid: [
                    Repaidsum1,
                    Repaidsum2,
                    Repaidsum3,
                    Repaidsum4,
                    Repaidsum5,
                    Repaidsum6,
                ],
                Rejected: [
                    Rejectedsum1,
                    Rejectedsum2,
                    Rejectedsum3,
                    Rejectedsum4,
                    Rejectedsum5,
                    Rejectedsum6,
                ],
            }
            return { data };

        } catch (e) {
            this.logger.error(e);
            throw e;
        }
    }
    public async getSecondPieGraphForAggregator(req: Request, res: Response, currentUser: IUser): Promise<{ data: any }> {
        try {
            const userDetails = currentUser;

            var forcalc = new Date();
            var thismonth = forcalc.getMonth() + 1;
            var t = forcalc.getFullYear();
            var this1 = new Date(t, thismonth - 1, 1);

            var month1 = forcalc.getMonth();
            if (month1 < 0) {
                month1 += 12;
                forcalc.setFullYear(forcalc.getFullYear() - 1);
            }
            forcalc.setMonth(month1);
            var a = forcalc.getFullYear();
            var d1m1 = new Date(a, month1 - 1, 1);
            var laster1 = new Date(a, month1, 0);
            laster1.setHours(23, 59, 59, 0);
            if (month1 <= 0) {
                month1 += 12;
                a = a - 1
            }

            var month2 = forcalc.getMonth() - 1;
            if (month2 < 0) {
                month2 += 12;
                forcalc.setFullYear(forcalc.getFullYear() - 1);
            }
            forcalc.setMonth(month2);
            var b = forcalc.getFullYear();
            var d1m2 = new Date(b, month2 - 1, 1);
            var laster2 = new Date(b, month2, 0);
            laster2.setHours(23, 59, 59, 0);
            if (month2 <= 0) {
                month2 += 12;
                b = b - 1
            }

            var month3 = forcalc.getMonth() - 1;
            if (month3 < 0) {
                month3 += 12;
                forcalc.setFullYear(forcalc.getFullYear() - 1);
            }
            forcalc.setMonth(month3);
            var c = forcalc.getFullYear();
            var d1m3 = new Date(c, month3 - 1, 1);
            var laster3 = new Date(c, month3, 0);
            laster3.setHours(23, 59, 59, 0);
            if (month3 <= 0) {
                month3 += 12;
                c = c - 1
            }

            var month4 = forcalc.getMonth() - 1;
            if (month4 < 0) {
                month4 += 12;
                forcalc.setFullYear(forcalc.getFullYear() - 1);
            }
            forcalc.setMonth(month4);
            var d = forcalc.getFullYear();
            var d1m4 = new Date(d, month4 - 1, 1);
            var laster4 = new Date(d, month4, 0);
            laster4.setHours(23, 59, 59, 0);
            if (month4 <= 0) {
                month4 += 12;
                d = d - 1
            }

            var month5 = forcalc.getMonth() - 1;
            if (month5 < 0) {
                month5 += 12;
                forcalc.setFullYear(forcalc.getFullYear() - 1);
            }
            forcalc.setMonth(month5);
            var e = forcalc.getFullYear();
            var d1m5 = new Date(e, month5 - 1, 1);
            var laster5 = new Date(e, month5, 0);
            laster5.setHours(23, 59, 59, 0);
            if (month5 <= 0) {
                month5 += 12;
                e = e - 1
            }

            var todaydate = new Date();

            var countTotal = 0;
            var countFunded = 0;
            var hospitaldata = await this.organizationModel.find({ aggregatorId: userDetails.organizationId });
            if (hospitaldata) {
                var len = hospitaldata.length;

                for (let i = 0; i < len; i++) {
                    var countone = await this.Invoice.aggregate([
                        {
                            $facet: {
                                sumone: [
                                    {
                                        $match: {
                                            $and: [
                                                { hospitalId: hospitaldata[i]._id },
                                                { createdAt: { $gte: d1m5, $lte: todaydate } },
                                            ],
                                        },
                                    },
                                    { $count: "total" },
                                ],
                                sumtwo: [
                                    {
                                        $match: {
                                            $and: [
                                                { hospitalId: hospitaldata[i]._id },
                                                { createdAt: { $gte: d1m5, $lte: todaydate } },
                                                { $or: [{ Status: "Disbursed" }, { Status: "Fully Repaid" }, { Status: "Partially Repaid" }, { Status: "RepaymentConfirmed" }] },
                                            ],
                                        },
                                    },
                                    { $count: "total" },
                                ],
                            },
                        },
                    ]);

                    if (countone[0].sumone[0] != undefined) {
                        countTotal += countone[0].sumone[0].total;
                    } else {
                        countTotal += 0;
                    }
                    if (countone[0].sumtwo[0] != undefined) {
                        countFunded += countone[0].sumtwo[0].total;
                    } else {
                        countFunded += 0;
                    }
                }
            }
            var data = {
                success: true,
                TotalInvoices: countTotal,
                TotalFunded: countFunded,
            }
            return { data }
        } catch (e) {
            this.logger.error(e);
            throw e;
        }
    }
    public async getAllHospitalToAggregator(IFilterDTO: IFilterDTO, currentUser: IUser): Promise<{ data: any }> {
        try {
            //pagination
            var pageNumber = 1;
            var pageSize = 0;
            if (IFilterDTO.pageNumber) {
                var pageNumber = IFilterDTO.pageNumber;
            }
            if (IFilterDTO.pageSize) {
                var pageSize = IFilterDTO.pageSize;
            }
            //search
            // var filters = IFilterDTO.filters || [];
            var searchFilters = [];
            searchFilters.push({ aggregatorId: currentUser.organizationId, isDeleted: false });

            // for (var element of filters) {
            //   searchFilters.push({ [element.searchField]: { $regex: element.searchTerm, $options: 'i' } });
            // }
            var userCount = await this.organizationModel.find({ $and: searchFilters }).countDocuments();
            var numberOfPages = pageSize === 0 ? 1 : Math.ceil(userCount / pageSize);
            var invoices = await this.organizationModel
                .find({ $and: searchFilters })
                .sort({ updatedAt: -1 })
                .skip((pageNumber - 1) * pageSize)
                .limit(pageSize);

            var data = { success: true, count: userCount, message: invoices, numberOfPages };
            return { data }
        } catch (e) {
            this.logger.error(e);
            throw e;
        }
    }
    public async deleteAllHospitalToAggregator(currentUser: IUser, IFilterDTO: IFilterDTO): Promise<{ data: any }> {
        try {
            const id = IFilterDTO._id;
            var invoice = await this.userModel.findOne({ _id: id })
            if (invoice.LStatus != "Pending") {
                return { data: { success: false, message: "Cannot delete All Hospital To Aggregator" } }
            }

            var deleteInvoice = await this.userModel.findByIdAndUpdate({ _id: id }, { $set: { isDeleted: true, updatedBy: currentUser._id } });
            //pending invoice      
            if (deleteInvoice) {
                var data = { success: true, message: "All Hospital deleted Successfully" };
                return { data };
            }

        } catch (e) {
            this.logger.error(e);
            throw e;
        }
    }
    public async splitForAgri(req: Request, currentUser: IUser): Promise<{ data: any }> {
        try {
            // const userDetails = req.currentUser;
            var { HospitalROI, AggregetorLoan, HospitalLoan, AggregeorId, ROIForAggregator } = req.body;

            var agriRoi = 0;
            // if (!userDetails) {
            //   return res.status(400).json({
            //     message: "Not a valid user",
            //   });
            // }
            // const agriData = await this.userModel.findOne({ _id: AggregeorId });

            // if (
            //     agriData.ROIForAggregator != null &&
            //     agriData.ROIForAggregator != undefined &&
            //     agriData.ROIForAggregator > 0
            // ) {
            // } else {
            //     return {
            //         data: {
            //             message:
            //                 "ROI for this aggregator is not found. Please contact admin",
            //         }
            //     };
            // }

            if (HospitalROI > 0 && AggregetorLoan > 0 && HospitalLoan > 0) {
                var hospitalv1 = (HospitalLoan * HospitalROI) / 100;

                var agriv1 = ROIForAggregator - hospitalv1;

                agriRoi = (agriv1 * 100) / AggregetorLoan;
            }

            return { data: { success: true, agriRoi } };
        } catch (e) {
            this.logger.error(e);
            throw e;
        }
    }
    public async addHospitalByAggregator(req: Request, res: Response, currentUser: IUser): Promise<{ data: any }> {
        try {
            const { name } = req.body;

            let {
                email,
                CINNumber,
                contactPerson,
                GSTNumber,
                mobileNumber,
                GSTcertificate,
                AddressProofoftheHospital,
                PANNumber,
                address,
                role,
                password,
                DateOfRegistration,
                HospitalRegistrationCertificate,
                AggregetorLoan,
                HospitalLoan,
                AggregetorROI,
                HospitalROI,
                isSplit,
                PFFees,
                ROIForAggregator
            } = req.body;
            if (isSplit) {
                if (!(AggregetorLoan &&
                    HospitalLoan &&
                    AggregetorROI &&
                    HospitalROI &&
                    ROIForAggregator)) {
                    return {
                        data: {
                            success: false,
                            message: "incomplete split data"
                        }
                    }
                }
            }
            const userDetails = currentUser;

            const findUser = await this.userModel.findOne({ email: email });

            if (findUser && findUser._id && findUser.name) {
                return {
                    data: {
                        success: false,
                        message: "Email is already registered.",
                    }
                };
            }

            const findOrg = await this.organizationModel.findOne({ email: email });

            if (findOrg && findOrg._id && findOrg.nameOfOrganization) {
                return {
                    data: {
                        success: false,
                        message: "Email is already registered.",
                    }
                };
            }

            const orgRecord = await this.organizationModel.create({
                nameOfOrganization: name,
                typeOfOrganization: role,
                dateOfRegistration: DateOfRegistration,
                contactNumber: mobileNumber,
                email: email,
                isActive: true,
                isDeleted: false,
                updatedAt: new Date().toUTCString(),
                createdAt: new Date().toUTCString(),
                PFFees: PFFees,
                CINNumber: CINNumber,
                contactPerson: contactPerson,
                GSTNumber: GSTNumber,
                AddressProofoftheHospital: AddressProofoftheHospital,
                PANNumber: PANNumber,
                address: address,
                HospitalRegistrationCertificate,
                aggregatorId: userDetails.organizationId,
                isSplit: isSplit,
                claimFinancing: true,
                supplierFinancing: false,
                patientFinancing: false,
                merchantFinancing: false,
                employeeManagement: false
            }
            )


            // Convert pass to hash & salt
            const salt = randomBytes(32);
            this.logger.silly('Hashing password');
            const hashedPassword = await argon2.hash(password, { salt });

            const userRecord = await this.userModel.create({
                organizationId: orgRecord._id,
                name: name,
                PFFees: PFFees,
                email: email,
                address: address,
                role: role,
                DateOfRegistration: DateOfRegistration,
                password: hashedPassword,
                salt: salt.toString('hex'),
                isSplit: isSplit,
                isActive: false,
                isDeleted: false,
                createdAt: new Date().toUTCString(),
                passwordUpdatedOn: new Date().toUTCString(),
                updatedBy: userDetails._id,
                claimFinancing: true,
                supplierFinancing: false,
                patientFinancing: false,
                merchantFinancing: false,
                employeeManagement: false
            });
            if (!userRecord || !userRecord.email || userRecord.email !== email) {
                return {
                    data: {
                        success: false,
                        message: "Unable to register user.",
                    }
                };
            }

            if (
                AggregetorLoan &&
                HospitalLoan &&
                AggregetorROI &&
                HospitalROI &&
                userRecord &&
                ROIForAggregator &&
                isSplit
            ) {
                const businessLogicsOBJ = {
                    AggregetorLoan: AggregetorLoan,
                    HospitalLoan: HospitalLoan,
                    AggregetorROI: AggregetorROI,
                    HospitalROI: HospitalROI,
                    hospitalId: userRecord.organizationId,
                    ROIForAggregator: ROIForAggregator,
                    createdAt: Date.now(),
                    updatedBy: userDetails._id,
                };
                const newBusinessLogic = new this.businessLogicsModel(businessLogicsOBJ);
                let saveBusinessLogic = await newBusinessLogic.save();
            } else {
                this.logger.info(
                    "AggregetorLoan:", AggregetorLoan,
                    "HospitalLoan: ", HospitalLoan,
                    "AggregetorROI: ", AggregetorROI,
                    "HospitalROI: ", HospitalROI,
                    "userRecord: ", userRecord,
                    "ROIForAggregator: ", ROIForAggregator,
                    "isSplit: ", isSplit)
            }

            delete userRecord.password;
            delete userRecord.salt;
            delete userRecord._id;

            // this.mailjet.SendWelcomeEmail(userRecord);

            return {
                data: {
                    success: true,
                    message: "success",
                    user: userRecord,
                    newUser: true,
                }
            };
        } catch (e) {
            this.logger.error(e);
            throw e;
        }
    }
    public async getHospitalByIdToAggregator(req: Request, res: Response, currentUser: IUser): Promise<{ data: any }> {
        try {
            const ID = req.query._id;
            const userDetails = currentUser;

            var businessLogicsdata = {};

            const invoices = await this.organizationModel.findOne({ _id: ID });
            const invoice = await this.organizationModel.findOne({ hospitalId: ID });

            if (invoices.isSplit == true) {
                const businessLogics = await this.businessLogicsModel.findOne({
                    hospitalId: invoices._id,
                });
                if (businessLogics) {
                    businessLogicsdata = businessLogics;
                }
            }

            return {
                data: {
                    success: true,
                    message: invoices,
                    ValidatorData: invoice,
                    splitdata: businessLogicsdata,
                }
            };

        } catch (e) {
            this.logger.error(e);
            throw e;
        }
    }
    public async editHospitalProfileByAggregator(req: Request, res: Response, currentUser: IUser): Promise<{ data: any }> {
        try {
            const { _id } = req.query;
            const userDetails = currentUser;
            const {
                name,
                GSTNumber,
                DateOfRegistration,
                PANNumber,
                NoOfClaimProcessedInAYear,
                TotalNoOfClaimProcessed,
                AverageTicketSizeOfTheClaims,
                NoOfTPAsAssociated,
                NoOfDirectInsuranceCompaniesAssociated,
                DoYouHaveAnExistingWorkingCapitalLoan,
                ExistingCreditLimit,
                CINNumber,
                mobileNumber,
                address,
                AccountName,
                AccountNumber,
                NameOfTheBank,
                IFSCcode,
                Branch,
                contactPerson,
                NameOfDirector,
                DirectorPANNumber,
                ContactNumberOfDirector,
                DirectorEmail,
                GSTUrl,
                AddressDocUrl,
                RegCertificateUrl,
                FinancialStUrl,
                NOCextUrl,
                TwoYearBankStUrl,
                TwoyearTTRUrl,
                otherUrl,
                AadharDocUrl,
                AadharNumber,
                conDetailDirUrl,
                KYCDocUrl,
                escrowAccountName,
                escrowBranch,
                escrowIFSCcode,
                escrowNameOfTheBank,
                escrowAccountNumber,
                ParriPassuUrl,
            } = req.body;

            const hosAggUpdate = await this.userModel.findById({ _id: _id });

            if (!hosAggUpdate) {
                return {
                    data: {
                        success: false,
                        message: "Invalid User Id!",
                    }
                };
            }

            let data: any = {};
            if (name) {
                data.name = name;
            }
            if (GSTNumber) {
                data.GSTNumber = GSTNumber;
            }
            if (DateOfRegistration) {
                data.DateOfRegistration = DateOfRegistration;
            }
            if (NoOfClaimProcessedInAYear) {
                data.NoOfClaimProcessedInAYear = NoOfClaimProcessedInAYear;
            }
            if (TotalNoOfClaimProcessed) {
                data.TotalNoOfClaimProcessed = TotalNoOfClaimProcessed;
            }
            if (PANNumber) {
                data.PANNumber = PANNumber;
            }
            if (AverageTicketSizeOfTheClaims) {
                data.AverageTicketSizeOfTheClaims = AverageTicketSizeOfTheClaims;
            }
            if (NoOfDirectInsuranceCompaniesAssociated) {
                data.NoOfDirectInsuranceCompaniesAssociated =
                    NoOfDirectInsuranceCompaniesAssociated;
            }
            if (DoYouHaveAnExistingWorkingCapitalLoan) {
                data.DoYouHaveAnExistingWorkingCapitalLoan =
                    DoYouHaveAnExistingWorkingCapitalLoan;
            }
            if (ExistingCreditLimit) {
                data.ExistingCreditLimit = ExistingCreditLimit;
            }
            if (CINNumber) {
                data.CINNumber = CINNumber;
            }
            if (mobileNumber) {
                data.mobileNumber = mobileNumber;
            }
            if (address) {
                data.address = address;
            }
            if (AccountName) {
                data.AccountName = AccountName;
            }
            if (AccountNumber) {
                data.AccountNumber = AccountNumber;
            }
            if (NameOfTheBank) {
                data.NameOfTheBank = NameOfTheBank;
            }
            if (IFSCcode) {
                data.IFSCcode = IFSCcode;
            }
            if (Branch) {
                data.Branch = Branch;
            }
            if (NameOfDirector) {
                data.NameOfDirector = NameOfDirector;
            }
            if (DirectorPANNumber) {
                data.DirectorPANNumber = DirectorPANNumber;
            }
            if (AadharNumber) {
                data.AadharNumber = AadharNumber;
            }
            if (ContactNumberOfDirector) {
                data.ContactNumberOfDirector = ContactNumberOfDirector;
            }
            if (DirectorEmail) {
                data.DirectorEmail = DirectorEmail;
            }
            if (GSTUrl) {
                data.GSTUrl = GSTUrl;
            }
            if (AddressDocUrl) {
                data.AddressDocUrl = AddressDocUrl;
            }
            if (RegCertificateUrl) {
                data.RegCertificateUrl = RegCertificateUrl;
            }
            if (FinancialStUrl) {
                data.FinancialStUrl = FinancialStUrl;
            }
            if (NOCextUrl) {
                data.NOCextUrl = NOCextUrl;
            }
            if (TwoYearBankStUrl) {
                data.TwoYearBankStUrl = TwoYearBankStUrl;
            }
            if (TwoyearTTRUrl) {
                data.TwoyearTTRUrl = TwoyearTTRUrl;
            }
            if (otherUrl) {
                data.otherUrl = otherUrl;
            }
            if (AadharDocUrl) {
                data.AadharDocUrl = AadharDocUrl;
            }
            if (conDetailDirUrl) {
                data.conDetailDirUrl = conDetailDirUrl;
            }
            if (KYCDocUrl) {
                data.KYCDocUrl = KYCDocUrl;
            }
            if (ParriPassuUrl) {
                data.ParriPassuUrl = ParriPassuUrl;
            }
            if (contactPerson) {
                data.contactPerson = contactPerson;
            }
            if (NoOfTPAsAssociated) {
                data.NoOfTPAsAssociated = NoOfTPAsAssociated;
            }

            if (escrowAccountName) {
                data.escrowAccountName = escrowAccountName;
            }
            if (escrowBranch) {
                data.escrowBranch = escrowBranch;
            }
            if (escrowIFSCcode) {
                data.escrowIFSCcode = escrowIFSCcode;
            }
            if (escrowNameOfTheBank) {
                data.escrowNameOfTheBank = escrowNameOfTheBank;
            }
            if (escrowAccountNumber) {
                data.escrowAccountNumber = escrowAccountNumber;
            }

            const aggHosList = await this.userModel.updateOne({ _id: _id }, { $set: data });

            return {
                data: {
                    success: true,
                    message: "Hospital Updated Successfully By Aggregator",
                    hosAggUpdate,
                }
            };
        } catch (e) {
            this.logger.error(e);
            throw e;
        }
    }
    public async getByIdToAggregator(req: Request, res: Response, currentUser: IUser): Promise<{ data: any }> {
        try {
            const { _id } = req.query;
            const userDetails = currentUser;

            const Eq = userDetails._id;
            if (Eq == _id) {
                const getAggregator = await this.userModel.findOne({ _id });
                return {
                    data: {
                        success: true,
                        message: getAggregator,
                    }
                };
            }
        } catch (e) {
            this.logger.error(e);
            throw e;
        }
    }
    public async editAggregatorProfile(req: Request, res: Response, currentUser: IUser): Promise<{ data: any }> {
        try {
            const userDetails = currentUser;
            const { _id } = req.query;
            const {
                name,
                mobileNumber,
                address,
                TotalNoOfHospital,
                NoOfTPAsAssociated,
                NoOfClaimProcessedInAYear,
                totalValueofClaimsProcessed,
                AverageTicketSizeOfTheClaims,
                NoOfDirectInsuranceCompaniesAssociated,
                AccountName,
                AccountNumber,
                NameOfTheBank,
                IFSCcode,
                Branch,
                PANNumber,
                PANcardUrl,
                AttachedDocUrl,
                CINNumber,
            } = req.body;

            const Dt = userDetails._id;
            if (Dt == _id) {
                const editAgg = await this.userModel.findOne({ _id });
                if (!editAgg) {
                    return {
                        data: {
                            success: false,
                            message: "Invalid Id!",
                            editAgg,
                        }
                    };
                }

                let data: any = {};
                if (name) {
                    data.name = name;
                }
                if (mobileNumber) {
                    data.mobileNumber = mobileNumber;
                }
                if (address) {
                    data.address = address;
                }
                if (TotalNoOfHospital) {
                    data.TotalNoOfHospital = TotalNoOfHospital;
                }
                if (NoOfTPAsAssociated) {
                    data.NoOfTPAsAssociated = NoOfTPAsAssociated;
                }
                if (NoOfClaimProcessedInAYear) {
                    data.NoOfClaimProcessedInAYear = NoOfClaimProcessedInAYear;
                }
                if (totalValueofClaimsProcessed) {
                    data.totalValueofClaimsProcessed = totalValueofClaimsProcessed;
                }
                if (AverageTicketSizeOfTheClaims) {
                    data.AverageTicketSizeOfTheClaims = AverageTicketSizeOfTheClaims;
                }
                if (NoOfDirectInsuranceCompaniesAssociated) {
                    data.NoOfDirectInsuranceCompaniesAssociated =
                        NoOfDirectInsuranceCompaniesAssociated;
                }
                if (address) {
                    data.address = address;
                }
                if (AccountName) {
                    data.AccountName = AccountName;
                }
                if (AccountNumber) {
                    data.AccountNumber = AccountNumber;
                }
                if (NameOfTheBank) {
                    data.NameOfTheBank = NameOfTheBank;
                }
                if (IFSCcode) {
                    data.IFSCcode = IFSCcode;
                }
                if (Branch) {
                    data.Branch = Branch;
                }
                if (PANcardUrl) {
                    data.PANcardUrl = PANcardUrl;
                }
                if (AttachedDocUrl) {
                    data.AttachedDocUrl = AttachedDocUrl;
                }
                if (CINNumber) {
                    data.CINNumber = CINNumber;
                }
                if (PANNumber) {
                    data.PANNumber = PANNumber;
                }

                if (PANNumber) {
                    var users = await this.userModel.find({ PANNumber: PANNumber });

                    for (var doc of users) {
                        if (doc._id !== userDetails._id) {
                            return {
                                data: {
                                    message: " PAN Number already exist",
                                }
                            };
                        }
                    }
                }

                if (AccountNumber) {
                    var users = await this.userModel.find({ AccountNumber: AccountNumber });

                    for (var doc of users) {
                        if (doc._id !== userDetails._id) {
                            return {
                                data: {
                                    message: " Account Number already exist",
                                }
                            };
                        }
                    }
                }

                const updateBL = await this.userModel.updateOne({ _id }, { $set: data });

                return {
                    data: {
                        success: true,
                        message: "Aggregator Profile Updated Successfully",
                    }
                };
            }
        } catch (e) {
            this.logger.error(e);
            throw e;
        }
    }
    public async deleteHospitalByAggregator(req: Request, res: Response): Promise<{ data: any }> {
        try {
            const id = req.query._id;
            await this.userModel.findByIdAndUpdate({ _id: id }, { $set: { isDeleted: true, isActive: false } }, { useFindAndModify: false });
            const data = ({ success: true, message: 'hospital deleted' })
            return { data };
        } catch (e) {
            this.logger.error(e);
            return {
                data: { success: false, error: e },
            }
        }
    }
    public async getInvoiceByAggregatorID(IFilterDTO: IFilterDTO, currentUser: IUser): Promise<{ data: any }> {
        try {

            var pageNumber = 1;
            var pageSize = 0;
            var total: any = {};
            if (IFilterDTO.pageNumber) {
                var pageNumber = parseInt(IFilterDTO.pageNumber.toString());
            }
            if (IFilterDTO.pageSize) {
                var pageSize = parseInt(IFilterDTO.pageSize.toString());
            }

            var searchFilters = [];
            searchFilters.push({ $or: [{ aggregatorId: currentUser._id }, { aggregatorId: currentUser.organizationId }] });
            if (IFilterDTO.Status != undefined || null) {
                searchFilters.push({ Status: IFilterDTO.Status });
            }
            if (IFilterDTO.searchTerm != undefined) {
                searchFilters.push({
                    $or: [
                        { nameOfHospital: { $regex: IFilterDTO.searchTerm, $options: 'i' } },
                        { claimId: { $regex: IFilterDTO.searchTerm, $options: 'i' } },
                        { patientName: { $regex: IFilterDTO.searchTerm, $options: 'i' } },
                        {
                            "$expr": {
                                "$regexMatch": {
                                    "input": { "$toString": "$LoanID" },
                                    "regex": IFilterDTO.searchTerm
                                }
                            }
                        }
                    ]
                })
            }

            var userCount = await this.Invoice.find({ $and: searchFilters }).countDocuments();
            var numberOfPages = pageSize === 0 ? 1 : Math.ceil(userCount / pageSize);

            var aggregatoInvoices = await this.Invoice
                .find({ $and: searchFilters })
                .sort({ updatedAt: -1 })
                .skip((pageNumber - 1) * pageSize)
                .limit(pageSize);;

            var totalAmount = await this.Invoice.aggregate([{ $match: { $and: searchFilters } }, { $group: { _id: '$_v', totalAmount: { $sum: '$LenderApprovalAmount' } } }
            ]);
            if (totalAmount.length != 0) {
                total.count = userCount
                total.totalAmount = totalAmount[0].totalAmount
            } else {
                total.count = 0
                total.totalAmount = 0
            }

            return {
                data: {
                    success: true,
                    message: aggregatoInvoices,
                    numberOfPages,
                    total
                }
            };

        } catch (e) {
            this.logger.error(e);
            throw e;
        }
    }
    public async deleteInvoiceByAggregatorID(currentUser: IUser, IFilterDTO: IFilterDTO): Promise<{ data: any }> {
        try {
            const id = IFilterDTO._id;
            var invoice = await this.Invoice.findOne({ _id: id })
            if (invoice.Status != "Pending") {
                return { data: { success: false, message: "Cannot delete Invoice By AggregatorID" } }
            }

            var deleteInvoice = await this.Invoice.findByIdAndUpdate({ _id: id }, { $set: { isDeleted: true, updatedBy: currentUser._id } });
            //pending invoice      
            if (deleteInvoice) {
                var data = { success: true, message: "Invoice By AggregatorID deleted Successfully" };
                return { data };
            }

        } catch (e) {
            this.logger.error(e);
            throw e;
        }
    }
    public async getInvoiceByIdToAggregator(req: Request, res: Response, currentUser: IUser): Promise<{ data: any }> {
        try {
            const Id = req.query;
            const userDetails = currentUser;

            const invoices = await this.Invoice.findOne({ _id: Id });
            var repaymentData;
            if (invoices) {
                repaymentData = await this.TransactionData.find({ invoiceId: invoices._id })
            }
            return { data: { success: true, message: invoices, repaymentData } };

        } catch (e) {
            this.logger.error(e);
            throw e;
        }
    }
    public async getAllInvoicebyHospitalToAggregator(req: Request, res: Response, currentUser: IUser): Promise<{ data: any }> {
        try {
            const userDetails = currentUser;

            const invoices = await this.Invoice.find({
                $and: [{ aggregatorId: userDetails._id }, { Status: "Fully Repaid" }],
            }).distinct("hospitalId");
            var List;
            var Lists = [];
            if (invoices) {
                for (let i = 0; i < invoices.length; i++) {
                    let id = invoices[i];
                    List = await this.userModel.findOne({ _id: id });
                    Lists = Lists.concat(List);
                }
            }
            if (Lists) {
                var data = Lists.length;
            }
            return { data: { success: true, count: data, message: Lists } };
        } catch (e) {
            this.logger.error(e);
            throw e;
        }
    }
    public async getRepaidInvoiceToAggregator(req: Request, res: Response, currentUser: IUser): Promise<{ data: any }> {
        try {
            const userDetails = currentUser;
            const Repaidinvoices = await this.Invoice.find({
                $and: [{ aggregatorId: userDetails._id }, { Status: "Fully Repaid" }],
            });
            if (Repaidinvoices) {
                var Repaidinvoice = Repaidinvoices.length;

                var TotalRepaidAmount = 0;
                var TotalApprovalAmount = 0;
                for (let i = 0; i < Repaidinvoice; i++) {
                    var repaidamount = Repaidinvoices[i].LenderApprovalAmount;
                    if (repaidamount) {
                        TotalRepaidAmount = TotalRepaidAmount + repaidamount;
                    }
                    var amount = Repaidinvoices[i].AmountDisbursed;
                    if (amount) {
                        TotalApprovalAmount = TotalApprovalAmount + amount;
                    }
                }
            }
            return {
                data: {
                    success: true,
                    count: Repaidinvoice,
                    TotalclaimAmount: TotalRepaidAmount,
                    TotalamountDisbursed: TotalApprovalAmount,
                    message: Repaidinvoices,
                }
            };
        } catch (e) {
            this.logger.error(e);
            throw e;
        }
    }
    public async getFundedInvoiceToAggregatorV1(IFilterDTO: IFilterDTO, currentUser: IUser): Promise<{ data: any }> {
        try {
            //pagination
            var pageNumber = 1;
            var pageSize = 0;
            if (IFilterDTO.pageNumber) {
                var pageNumber = IFilterDTO.pageNumber;
            }
            if (IFilterDTO.pageSize) {
                var pageSize = IFilterDTO.pageSize;
            }

            //search
            var filters = IFilterDTO.filters || [];
            var searchFilters = [];
            searchFilters.push(
                { hospitalId: IFilterDTO._id },
                {
                    $or: [{ Status: "Disbursed" }, { Status: "Partially Repaid" }]
                },
                { RepaidStatus: { $ne: "Fully Repaid" } });
            // for (var element of filters) {
            //   searchFilters.push({ [element.searchField]: { $regex: element.searchTerm, $options: 'i' } });
            // }
            var userCount = await this.Invoice.find({ $and: searchFilters }).countDocuments();
            var numberOfPages = pageSize === 0 ? 1 : Math.ceil(userCount / pageSize);
            var fundedAggregator = await this.Invoice
                .find({ $and: searchFilters })
                .sort({ updatedAt: -1 })
                .skip((pageNumber - 1) * pageSize)
                .limit(pageSize);

            return {
                data: {
                    success: true,
                    count: userCount,
                    message: fundedAggregator,
                    numberOfPages
                }
            };
        } catch (e) {
            this.logger.error(e);
            throw e;
        }
    }
    public async bulkUpdateRepayment(req: Request, res: Response, currentUser: IUser): Promise<{ data: any }> {
        try {
            const { _ids, PaymentReceivedDate, ReceivedNEFT_RTG } = req.body;
            const userDetails = currentUser;
            _ids.forEach(async (_id) => {
                const vendorDetail = await this.Invoice.findOne({ _id: _id._id });
                if (!vendorDetail) {
                    return {
                        data: {
                            message: "Not a valid Vendor ID",
                        }
                    };
                }
                let anchorDetails: any = {};
                anchorDetails.LresponseDate = new Date();
                anchorDetails.Status = "Fully Repaid";
                anchorDetails.RepaidStatus = "Fully Repaid";

                if (_id.AmountReceived) {
                    anchorDetails.AmountReceived = _id.AmountReceived;
                }
                if (PaymentReceivedDate) {
                    var date1 = new Date(PaymentReceivedDate);
                    var finalDate1 = new Date(date1.setDate(date1.getDate()));
                    anchorDetails.PaymentReceivedDate = new Date(finalDate1);
                }
                if (ReceivedNEFT_RTG) {
                    anchorDetails.ReceivedNEFT_RTG = ReceivedNEFT_RTG;
                }

                const hosDetail = await this.organizationModel.findOne({
                    _id: vendorDetail.hospitalId,
                });

                var RemainingAmount = 0;
                anchorDetails.SettleStatus = "FullPaid";

                if (hosDetail.Repayment != undefined) {
                    var repaymentLimit = hosDetail.Repayment;
                }

                var recivedAmount = Math.round(
                    repaymentLimit + vendorDetail.RemainingAmount
                );
                if (hosDetail.Repayment != undefined) {
                    var AvailableLimit =
                        hosDetail.ExistingCreditLimit -
                        hosDetail.UtilizedAmount +
                        recivedAmount;
                }
                anchorDetails.RemainingAmount = RemainingAmount;

                const updtvendor = await this.organizationModel.updateOne(
                    { _id: vendorDetail.hospitalId },
                    {
                        $set: {
                            Repayment: recivedAmount,
                            AvailableLimit: AvailableLimit,
                        },
                    }
                );

                /// transaction log

                const transaction = await this.TransactionData.create({
                    invoiceId: _id,
                    LoanID: vendorDetail.LoanID,
                    hospialId: vendorDetail.hospitalId,
                    aggregatorId: vendorDetail.aggregatorId,
                    lenderId: vendorDetail.LenderId,
                    claimId: vendorDetail.claimId,
                    AmountDisbursed: vendorDetail.AmountDisbursed,
                    transactionDate: PaymentReceivedDate,
                    NEFT_RTG: ReceivedNEFT_RTG,
                    AmountToBePaid: vendorDetail.AmountToBePaid,
                    Interest: vendorDetail.Interest,
                    SettleStatus: anchorDetails.SettleStatus,
                    RemainingAmount: RemainingAmount,
                    AmountReceived: _id.AmountReceived,
                    createdBy: req.currentUser._id
                })
                ///

                const invoices = await this.Invoice.updateOne(
                    { _id: _id },
                    { $set: anchorDetails }
                );

            });
            return { data: { success: true, message: "Succesfully Update" } };
        } catch (e) {
            this.logger.error(e);
            throw e;
        }
    }
    public async updatePassword(req, userInputDTO: IUserInputDTO, currentUser: IUser): Promise<{ data: any }> {
        try {
            const id = currentUser._id;
            const userDetails = await this.userModel.findOne({ _id: id });
            if (!userDetails) {
                return {
                    data: {
                        success: false,
                        message: "user not found"
                    }
                }
            }
            const salt = randomBytes(32);
            this.logger.silly('Hashing password');
            const hashedPassword = await argon2.hash(userInputDTO.password, { salt });

            this.logger.silly('updating password');
            let passwordData: any = {};

            passwordData.updatedAt = new Date().toUTCString();
            passwordData.updatedBy = currentUser._id;
            passwordData.salt = salt.toString('hex');
            passwordData.password = hashedPassword;
            passwordData.passwordUpdateOn = new Date().toUTCString();

            const userRecord = await this.userModel.findByIdAndUpdate(
                { _id: id },
                { $set: passwordData },
                { useFindAndModify: false, new: true });
            if (!userRecord) {
                throw new Error('password cannot be updated');
            }

            const user = userRecord.toObject();
            Reflect.deleteProperty(user, 'password');
            Reflect.deleteProperty(user, 'salt');
            var data = { success: true }
            return { data };
        }
        catch (error) {
            this.logger.error(error);
            return {
                data: { success: false, error: error }
            }
        }
    }

    // get TPA with Insurer
    public async getTPAwithInsurer(req: Request): Promise<{ data: any }> {
        try {
            const Id = req.query.Id;
            const TPA = await this.TPAModel.find({ InsuranceCompanyId: Id });

            var data = {
                success: true,
                message: TPA,
            }
            return { data };
        } catch (e) {
            this.logger.error(e);
            throw e;
        }
    }
    // get insurance
    public async getInsurance(req: Request): Promise<{ data: any }> {
        try {
            const Insurance = await this.InsuranceModel.find();

            var data = {
                success: true,
                message: Insurance,
            }
            return { data };
        } catch (e) {
            this.logger.error(e);
            throw e;
        }
    }
    public async invoiceUploadagv1(req: Request, res: Response, currentUser: IUser): Promise<{ data: any }> {
        try {
            var { claimSubmissionDate, dateOfDischarge, dateOfAdmission } = req.body;

            const {
                nameOfHospital,
                patientName,
                TPAName,
                insurerAprovedAmount,
                InsuranceCompanyName,
                claimId,
                nameOfInsurer,
                finalBillNumber,
                nameOfTPA,
                policyNumber,
                hospitalId,
                TPAId,
                InsuranceCompanyId,
                invoiceId,
                invoiceDocumentUrl,
                insuranceApprovalLetter,
                claimAmount,
                Description,
                otherDocsUrl
            } = req.body;

            const userDetails = currentUser;

            const hospitalData = await this.organizationModel.findOne({ _id: hospitalId });

            const businessLogicsData = await this.businessLogicsModel.findOne({
                hospitalId: hospitalId,
            });

            if (hospitalData.isSplit == true) {
                const claimIdData = await this.Invoice.find({ claimId: claimId });
                for (var e of claimIdData) {
                    if (e && e.Status != "DSPL Rejected" && e.Status != "Hospital Rejected" && e.Status != "Lender Rejected" && e.isDeleted != true) {
                        return {
                            data: {
                                success: false,
                                message: 'claimId Already Exists '
                            }
                        };
                    }
                }
                if (!hospitalData.LenderId) {
                    return {
                        data: {
                            success: false,
                            message:
                                "Hospital not assosciated with any Lender",
                        }
                    };
                }
                if (!hospitalData.LenderLTV) {
                    return {
                        data: {
                            success: false,
                            message: "Hospital not Apporved By Lender",
                        }
                    };
                }

                if (claimAmount >= hospitalData.AvailableLimit) {
                    return {
                        data: {
                            success: false,
                            message:
                                "You don't have sufficience Balance, cross avaliable limit",
                        }
                    };
                }

                var aggriSplitAmount = 0;
                var hospitalSplitAmount = 0;
                var LTVAmount = 0;
                var LTV = 0;
                if (hospitalData.LTV) {
                    var LTV = hospitalData.LTV;
                    var LTVAmount = (insurerAprovedAmount * LTV) / 100;
                }

                const LenderLTV = hospitalData.LenderLTV;
                const LenderTenure = hospitalData.LenderTenure;
                const LenderROI = hospitalData.LenderROI;

                var LenderApprovalAmount = (insurerAprovedAmount * LenderLTV) / 100;

                aggriSplitAmount =
                    (businessLogicsData.AggregetorLoan * LenderApprovalAmount) / 100;
                hospitalSplitAmount =
                    (businessLogicsData.HospitalLoan * LenderApprovalAmount) / 100;

                var date1 = new Date(claimSubmissionDate);
                var finalDate1 = new Date(date1.setDate(date1.getDate()));
                claimSubmissionDate = new Date(finalDate1);

                var date2 = new Date(dateOfDischarge);
                var finalDate2 = new Date(date2.setDate(date2.getDate()));
                dateOfDischarge = new Date(finalDate2);

                var date3 = new Date(dateOfAdmission);
                var finalDate3 = new Date(date3.setDate(date3.getDate()));
                dateOfAdmission = new Date(finalDate3);

                var hospitalInterest = 0;
                hospitalInterest = Math.round(
                    (hospitalSplitAmount *
                        businessLogicsData.HospitalROI *
                        LenderTenure) /
                    (30 * 100)
                );

                var hospitalDisbursmentAmt = hospitalSplitAmount - hospitalInterest;

                var Interest = 0;
                var aggriInterest = 0;
                aggriInterest = Math.round(
                    (aggriSplitAmount *
                        businessLogicsData.AggregetorROI *
                        LenderTenure) /
                    (30 * 100)
                );

                var agriDisbursmentAmt = aggriSplitAmount - aggriInterest;

                Interest = hospitalInterest + aggriInterest;

                var AmountToBePaid = 0;
                AmountToBePaid = agriDisbursmentAmt + hospitalDisbursmentAmt;

                const usrObj = {
                    nameOfHospital,
                    patientName,
                    TPAName,
                    insurerAprovedAmount,
                    InsuranceCompanyName,
                    InsuranceCompanyId,
                    TPAId,
                    claimId,
                    LTV,
                    LTVAmount,
                    nameOfInsurer,
                    finalBillNumber,
                    nameOfTPA,
                    policyNumber,
                    dateOfAdmission,
                    claimSubmissionDate,
                    claimAmount,
                    aggregatorId: userDetails.organizationId,
                    hospitalId,
                    LenderId: hospitalData.LenderId, // validatorId,
                    dateOfDischarge,
                    invoiceDocumentUrl,
                    otherDocsUrl,
                    invoiceId,
                    Status: "Pending",
                    insuranceApprovalLetter,
                    Description,
                    LenderLTV,
                    LenderTenure,
                    LenderROI,
                    LenderApprovalAmount,
                    DresponseDate: Date.now(),
                    // split disbursedamount hospitalamount
                    Interest: Interest,
                    isSplit: true,
                    aggriSplit: businessLogicsData.AggregetorLoan,
                    hospitalSplit: businessLogicsData.HospitalLoan,
                    aggriSplitAmount: aggriSplitAmount,
                    hospitalSplitAmount: hospitalSplitAmount,
                    hospitalROI: businessLogicsData.HospitalROI,
                    aggriROI: businessLogicsData.AggregetorROI,
                    hospitalDisbursmentAmt: hospitalDisbursmentAmt,
                    agriDisbursmentAmt: agriDisbursmentAmt,
                    aggriInterest: aggriInterest,
                    hospitalInterest: hospitalInterest,
                    totalIntrest: aggriInterest + hospitalInterest,
                    AmountToBePaid: AmountToBePaid,
                    AmountDisbursed: AmountToBePaid,
                    isDeleted: false
                };

                const newData = new this.Invoice(usrObj);
                const Invoicedata = await newData.save();
                return { data: { success: true, data: Invoicedata } };
            } else {
                return {
                    data: {
                        success: false,
                        message: "This hospital is not for split disbursment",
                    }
                };
            }

        } catch (e) {
            this.logger.error(e);
            throw e;
        }
    }
    public async getCity(req: Request): Promise<{ data: any }> {
        try {
            const pincode = req.query.Pincode;
            const city = await this.CitiesModel.findOne({ Pincode: pincode });
            return {
                data: {
                    success: true,
                    message: city,
                }
            };

        } catch (e) {
            this.logger.error(e);
            throw e;
        }
    }
    public async repaymentByAggregator(req: Request): Promise<{ data: any }> {
        try {
            const { _id, PaymentReceivedDate, ReceivedNEFT_RTG, AmountReceived } = req.body;

            const invoiceDetails = await this.Invoice.findOne({ _id: _id });
            if (!invoiceDetails) {
                return {
                    data: {
                        message: "Not a valid Invoice ID",
                    }
                };
            }
            let anchorDetails: any = {};

            if (invoiceDetails.AmountReceived) {
                anchorDetails.AmountReceived = invoiceDetails.AmountReceived + AmountReceived
            } else {
                anchorDetails.AmountReceived = AmountReceived
            }

            if (PaymentReceivedDate) {
                var date1 = new Date(PaymentReceivedDate);
                var finalDate1 = new Date(date1.setDate(date1.getDate()));
                anchorDetails.PaymentReceivedDate = new Date(finalDate1);
            }
            if (ReceivedNEFT_RTG) {
                anchorDetails.ReceivedNEFT_RTG = ReceivedNEFT_RTG;
            }

            const hosDetail = await this.organizationModel.findOne({
                _id: invoiceDetails.hospitalId,
            });

            var AmountToBePaid;
            if (invoiceDetails.RemainingAmount) {
                AmountToBePaid = invoiceDetails.RemainingAmount;
            } else {
                AmountToBePaid = invoiceDetails.ApporvedAmount;
            }
            var DueDate = invoiceDetails.DueDate
            var month = '' + (DueDate.getUTCMonth() + 1);
            var day = '' + DueDate.getUTCDate();
            var year = '' + DueDate.getUTCFullYear();

            if (month.length < 2) { month = '0' + month; }
            if (day.length < 2) { day = '0' + day; }

            var DueDateString = [year, month, day].join('-')
            DueDate = new Date(DueDateString)
            if (DueDate >= finalDate1) {
                var AdditionalInterestOld = 0
                if (invoiceDetails.AdditionalInterest) {
                    AdditionalInterestOld = invoiceDetails.AdditionalInterest
                    AmountToBePaid = AmountToBePaid - AdditionalInterestOld
                }
            }

            var RemainingAmount = 0;
            var AdditionalInterest = 0;
            RemainingAmount = Math.round(AmountToBePaid - AmountReceived);
            if (RemainingAmount > 0) {
                anchorDetails.SettleStatus = "Partially Repaid";
                anchorDetails.Status = "Partially Repaid";
                anchorDetails.RepaidStatus = "Partially Repaid";
                anchorDetails.AdditionalInterest = invoiceDetails.AdditionalInterest;
                if (DueDate >= finalDate1) {
                    var ROI = 0;
                    if (hosDetail.AdditionalInterest) { ROI = hosDetail.AdditionalInterest }
                    var date2 = DueDate;
                    var date1 = new Date();

                    var AdditionalDays;
                    AdditionalDays = Math.floor(
                        (date1.getTime() - date2.getTime()) / (1000 * 60 * 60 * 24)
                    );
                    if (AdditionalDays >= 1 && AdditionalDays <= 30) {
                        AdditionalInterest = Math.round((RemainingAmount * ROI) / 100);
                        anchorDetails.AdditionalDays = AdditionalDays;
                        anchorDetails.AdditionalInterest = AdditionalInterest;
                    }
                    else if (AdditionalDays >= 31 && AdditionalDays <= 60) {
                        AdditionalInterest = Math.round((RemainingAmount * 2 * ROI) / 100);
                        anchorDetails.AdditionalDays = AdditionalDays;
                        anchorDetails.AdditionalInterest = AdditionalInterest;
                    }
                }
            } else if (RemainingAmount == 0) {
                anchorDetails.SettleStatus = "Fully Repaid";
                anchorDetails.Status = "Fully Repaid";
                anchorDetails.RepaidStatus = "Fully Repaid";
            } else if (RemainingAmount < 0) {
                anchorDetails.SettleStatus = "Over Paid";
                anchorDetails.Status = "Fully Repaid";
                anchorDetails.RepaidStatus = "Over Paid";
            }
            if (hosDetail.Repayment != undefined) {
                var repaymentLimit = hosDetail.Repayment;
            }

            var recivedAmount = repaymentLimit + AmountReceived
            if (hosDetail.Repayment != undefined) {
                var AvailableLimit = hosDetail.ExistingCreditLimit - hosDetail.UtilizedAmount + recivedAmount
                var UtilizedAmount = hosDetail.UtilizedAmount
                if (DueDate >= finalDate1) {
                    AvailableLimit = AvailableLimit + AdditionalInterestOld - AdditionalInterest
                    UtilizedAmount = UtilizedAmount - AdditionalInterestOld + AdditionalInterest
                }
            }

            anchorDetails.RemainingAmount = RemainingAmount + AdditionalInterest;

            /// transaction log
            const transaction = await this.TransactionData.create({
                invoiceId: _id,
                LoanID: invoiceDetails.LoanID,
                hospialId: invoiceDetails.hospitalId,
                aggregatorId: invoiceDetails.aggregatorId,
                lenderId: invoiceDetails.LenderId,
                claimId: invoiceDetails.claimId,
                AmountDisbursed: invoiceDetails.AmountDisbursed,
                transactionDate: anchorDetails.PaymentReceivedDate,
                NEFT_RTG: ReceivedNEFT_RTG,
                AmountToBePaid: invoiceDetails.AmountToBePaid,
                AdditionalInterest: anchorDetails.AdditionalInterest,
                Interest: invoiceDetails.Interest,
                SettleStatus: anchorDetails.SettleStatus,
                RemainingAmount: anchorDetails.RemainingAmount,
                AmountReceived: AmountReceived,
                createdBy: req.currentUser._id
            })
            ///

            const updtvendor = await this.organizationModel.updateOne(
                { _id: invoiceDetails.hospitalId },
                {
                    $set: {
                        Repayment: recivedAmount,
                        AvailableLimit: AvailableLimit,
                        UtilizedAmount: UtilizedAmount
                    },
                }
            );

            const invoices = await this.Invoice.updateOne(
                { _id: _id },
                { $set: anchorDetails }
            );


            return { data: { success: true, message: "Succesfully Update" } };


        } catch (e) {
            this.logger.error(e);
            throw e;
        }
    }
    public async getCurrentUser(req): Promise<{ currentUser: any }> {
        try {
            if (req.currentOrg && req.currentOrg.LenderId) {
                var lenderDetails = await this.organizationModel.findOne({ _id: req.currentOrg.LenderId }, {lenderType : 0});
            }
            if (lenderDetails && lenderDetails.lenderType) {
                req.currentUser.lenderType = lenderDetails.lenderType
            }
            else { req.currentUser.lenderType = "Online-B" }
            var currentUser = req.currentUser
            return { currentUser };
        } catch (e) {
            this.logger.error(e);
            throw e;
        }
    }
}
