import { Service, Inject } from 'typedi';
import { Request, Response } from 'express';
import { IUser, IFilterDTO, IVendorDTO, ISupplierInvoiceDTO } from '@/interfaces/IUser';
import { Types } from 'mongoose';
import moment from 'moment';
import nodeMailerService from '../loaders/nodemailer';
@Service()
export default class vendorService {
    constructor(
        @Inject('SupplierInvoice') private SupplierInvoice: Models.SupplierInvoiceModel,
        @Inject('HVAssociationModel') private HVAssociationModel: Models.HVAssociationModel,
        @Inject('TransactionDataModel') private TransactionData: Models.TransactionDataModel,
        @Inject('userModel') private UserModel: Models.UserModel,
        @Inject('organizationModel') private organizationModel: Models.organizationModel,
        @Inject('logger') private logger,
        private nodeMailerService: nodeMailerService,
    ) { }
    //dashboard
    public async getDashboardForVendor(currentUser: IUser): Promise<{ data: any }> {
        try {
            var SanctionLimit;
            var AvailableLimit;
            var UtilizedAmount;
            var Repayment;

            var associationDetails = await this.HVAssociationModel.aggregate([{
                $facet: {
                    "SanctionLimit": [
                        { $match: { vendorId: currentUser.organizationId } },
                        { $group: { _id: "_v", total: { $sum: "$creditLimit" } } }
                    ],
                    "AvailableLimit": [
                        { $match: { vendorId: currentUser.organizationId } },
                        { $group: { _id: "_v", total: { $sum: "$AvailableLimit" } } }
                    ],
                    "UtilizedAmount": [
                        { $match: { vendorId: currentUser.organizationId } },
                        { $group: { _id: "_v", total: { $sum: "$UtilizedAmount" } } }
                    ],
                    "Repayment": [
                        { $match: { vendorId: currentUser.organizationId } },
                        { $group: { _id: "_v", total: { $sum: "$Repayment" } } }
                    ]
                }
            }]);
            if (associationDetails[0].SanctionLimit[0] != undefined) { SanctionLimit = associationDetails[0].SanctionLimit[0].total; } else { SanctionLimit = 0; }
            if (associationDetails[0].AvailableLimit[0] != undefined) { AvailableLimit = associationDetails[0].AvailableLimit[0].total; } else { AvailableLimit = 0; }
            if (associationDetails[0].UtilizedAmount[0] != undefined) { UtilizedAmount = associationDetails[0].UtilizedAmount[0].total; } else { UtilizedAmount = 0; }
            if (associationDetails[0].Repayment[0] != undefined) { Repayment = associationDetails[0].Repayment[0].total; } else { Repayment = 0; }


            var Totalinvoices; var TotalInvoicesAmount; var Totalpendinginvoices; var TotalPendingInvoiceAmount;
            var TotalRejectedinvoices; var TotalRejectedInvoiceAmount; var fundedInvoiceLength; var TotalpaidAmount;

            const everyData = await this.SupplierInvoice.aggregate([{
                $facet: {
                    "invoicedataSum": [
                        { $match: { VendorId: currentUser.organizationId } },
                        { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } }
                    ],
                    "invoicedataCount": [{ $match: { VendorId: currentUser.organizationId } }, { $count: "total" }],

                    "penddataSum": [
                        { $match: { $and: [{ VendorId: currentUser.organizationId }, { $or: [{ Status: "Pending" }, { Status: "Hospital Approved" }, { Status: "Lender Approved" }, { Status: "DSPL Approved" }] }] } },
                        { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } }
                    ],
                    "penddataCount": [{ $match: { $and: [{ VendorId: currentUser.organizationId }, { $or: [{ Status: "Pending" }, { Status: "Hospital Approved" }, { Status: "Lender Approved" }, { Status: "DSPL Approved" }] }] } }, { $count: "total" }],
                    "RjectdataSum": [
                        { $match: { $and: [{ VendorId: currentUser.organizationId }, { $or: [{ Status: "Hospital Rejected" }, { Status: "DSPL Rejected" }, { Status: "Lender Rejected" }, { Status: "DSPL Rejected" }] }] } },
                        { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } }
                    ],
                    "RjectdataCount": [{ $match: { $and: [{ VendorId: currentUser.organizationId }, { $or: [{ Status: "Hospital Rejected" }, { Status: "DSPL Rejected" }, { Status: "Lender Rejected" }, { Status: "DSPL Rejected" }] }] } }, { $count: "total" }],
                    "allInvoicesSum": [
                        { $match: { $and: [{ VendorId: currentUser.organizationId }, { $or: [{ Status: "Disbursed" }, { Status: "Fully Repaid" }, { Status: "Hospital Repaid" }, { Status: "Partially Repaid" }] }] } },
                        { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } }
                    ],
                    "allInvoicesCount": [{ $match: { $and: [{ VendorId: currentUser.organizationId }, { $or: [{ Status: "Disbursed" }, { Status: "Fully Repaid" }, { Status: "Hospital Repaid" }, { Status: "Partially Repaid" }] }] } }, { $count: "total" }],
                }
            }])

            if (everyData[0].invoicedataSum[0] != undefined) { TotalInvoicesAmount = everyData[0].invoicedataSum[0].total; } else { TotalInvoicesAmount = 0; }
            if (everyData[0].invoicedataCount[0] != undefined) { Totalinvoices = everyData[0].invoicedataCount[0].total; } else { Totalinvoices = 0; }
            if (everyData[0].penddataSum[0] != undefined) { TotalPendingInvoiceAmount = everyData[0].penddataSum[0].total; } else { TotalPendingInvoiceAmount = 0; }
            if (everyData[0].penddataCount[0] != undefined) { Totalpendinginvoices = everyData[0].penddataCount[0].total; } else { Totalpendinginvoices = 0; }
            if (everyData[0].RjectdataSum[0] != undefined) { TotalRejectedInvoiceAmount = everyData[0].RjectdataSum[0].total; } else { TotalRejectedInvoiceAmount = 0; }
            if (everyData[0].RjectdataCount[0] != undefined) { TotalRejectedinvoices = everyData[0].RjectdataCount[0].total; } else { TotalRejectedinvoices = 0; }
            if (everyData[0].allInvoicesSum[0] != undefined) { TotalpaidAmount = everyData[0].allInvoicesSum[0].total; } else { TotalpaidAmount = 0; }
            if (everyData[0].allInvoicesCount[0] != undefined) { fundedInvoiceLength = everyData[0].allInvoicesCount[0].total; } else { fundedInvoiceLength = 0; }
            return {
                data: {
                    success: true,
                    UtilizedAmount: UtilizedAmount,
                    TotalRepayment: Repayment,
                    SanctionLimit: SanctionLimit,
                    TotalAvailableLimit: AvailableLimit,
                    Totalinvoices: Totalinvoices,
                    TotalInvoicesAmount: TotalInvoicesAmount,
                    Totalpendinginvoices: Totalpendinginvoices,
                    TotalPendingInvoiceAmount: TotalPendingInvoiceAmount,

                    TotalfundedInvoices: fundedInvoiceLength,
                    TotalRejectedinvoices: TotalRejectedinvoices,
                    TotalRejectedInvoiceAmount: TotalRejectedInvoiceAmount,
                    TotalpaidAmount: TotalpaidAmount
                }
            };
        } catch (e) {
            this.logger.error(e);
            throw e;
        }
    }
    public async getDashboardData(req: Request, res: Response, currentUser: IUser): Promise<{ data: any }> {
        try {
            var searchFilters = [];
            searchFilters.push({ isDeleted: false });
            searchFilters.push({ VendorId: currentUser.organizationId });

            if (req.query.dateFrom != undefined || null && req.query.dateTo != undefined || null) {
                searchFilters.push({ createdAt: { $gte: req.query.dateFrom, $lte: req.query.dateTo } });
            }
            var dashboardData = await this.SupplierInvoice.aggregate([
                {
                    $facet: {
                        totalCount: [{ $match: { $and: searchFilters } }, { $count: 'total' }],
                        totalAmount: [
                            { $match: { $and: searchFilters } },
                            { $group: { _id: '$_v', total: { $sum: '$LTVAmount' } } },
                        ],

                        totalInProcessCount: [{
                            $match: {
                                $and: [{ $and: searchFilters }, {
                                    $or: [
                                        { Status: "Pending" },
                                        { Status: "Hospital Approved" },
                                        { Status: "Lender Approved" },
                                        { Status: "DSPL Approved" }
                                    ],
                                },],
                            },
                        },
                        { $count: 'total' },
                        ],

                        totalInProcessAmount: [{
                            $match: {
                                $and: [{ $and: searchFilters }, {
                                    $or: [
                                        { Status: "Pending" },
                                        { Status: "Hospital Approved" },
                                        { Status: "Lender Approved" },
                                        { Status: "DSPL Approved" }
                                    ],
                                },],
                            },
                        },
                        { $group: { _id: '$_v', total: { $sum: '$LTVAmount' } } },
                        ],

                        totalFundedCount: [{
                            $match: {
                                $and: [{ $and: searchFilters }, {
                                    $or: [
                                        { Status: "Disbursed" },
                                        { Status: "Fully Repaid" },
                                        { Status: "Hospital Repaid" },
                                        { Status: "Partially Repaid" }
                                    ],
                                },],
                            }
                        }, { $count: 'total' }],

                        totalFundedAmount: [{
                            $match: {
                                $and: [{ $and: searchFilters }, {
                                    $or: [
                                        { Status: "Disbursed" },
                                        { Status: "Fully Repaid" },
                                        { Status: "Hospital Repaid" },
                                        { Status: "Partially Repaid" }
                                    ],
                                },],
                            }
                        },
                        { $group: { _id: '$_v', total: { $sum: '$LTVAmount' } } },
                        ],

                        totalRepaidCount: [{ $match: { Status: 'Fully Repaid', $and: searchFilters } }, { $count: 'total' }],

                        totalRepaidAmount: [
                            { $match: { Status: 'Fully Repaid', $and: searchFilters } },
                            { $group: { _id: '$_v', total: { $sum: '$LTVAmount' } } },
                        ],

                        totalRejectedCount: [{
                            $match: {
                                $and: [{ $and: searchFilters }, {
                                    $or: [
                                        { Status: "Hospital Rejected" },
                                        { Status: "Lender Rejected" },
                                        { Status: "DSPL Rejected" }
                                    ],
                                },],
                            },
                        }, { $count: 'total' }
                        ],

                        totalRejectedAmount: [{
                            $match: {
                                $and: [{ $and: searchFilters }, {
                                    $or: [
                                        { Status: "Hospital Rejected" },
                                        { Status: "Lender Rejected" },
                                        { Status: "DSPL Rejected" }
                                    ],
                                },],
                            },
                        },
                        { $group: { _id: '$_v', total: { $sum: '$LTVAmount' } } },
                        ]
                    },
                },
            ]);

            var totalCount = 0;
            var totalAmount = 0;
            var totalInProcessCount = 0;
            var totalInProcessAmount = 0;
            var totalRejectedCount = 0;
            var totalRejectedAmount = 0;
            var totalFundedCount = 0;
            var totalFundedAmount = 0;
            var totalRepaidCount = 0;
            var totalRepaidAmount = 0;

            if (dashboardData[0].totalCount[0] != undefined) { totalCount = dashboardData[0].totalCount[0].total; } else { totalCount = 0; }
            if (dashboardData[0].totalAmount[0] != undefined) { totalAmount = dashboardData[0].totalAmount[0].total; } else { totalAmount = 0; }

            if (dashboardData[0].totalInProcessCount[0] != undefined) { totalInProcessCount = dashboardData[0].totalInProcessCount[0].total; } else { totalInProcessCount = 0; }
            if (dashboardData[0].totalInProcessAmount[0] != undefined) { totalInProcessAmount = dashboardData[0].totalInProcessAmount[0].total; } else { totalInProcessAmount = 0; }

            if (dashboardData[0].totalFundedCount[0] != undefined) { totalFundedCount = dashboardData[0].totalFundedCount[0].total; } else { totalFundedCount = 0; }
            if (dashboardData[0].totalFundedAmount[0] != undefined) { totalFundedAmount = dashboardData[0].totalFundedAmount[0].total; } else { totalFundedAmount = 0; }

            if (dashboardData[0].totalRepaidCount[0] != undefined) { totalRepaidCount = dashboardData[0].totalRepaidCount[0].total; } else { totalRepaidCount = 0; }
            if (dashboardData[0].totalRepaidAmount[0] != undefined) { totalRepaidAmount = dashboardData[0].totalRepaidAmount[0].total; } else { totalRepaidAmount = 0; }

            if (dashboardData[0].totalRejectedCount[0] != undefined) { totalRejectedCount = dashboardData[0].totalRejectedCount[0].total; } else { totalRejectedCount = 0; }
            if (dashboardData[0].totalRejectedAmount[0] != undefined) { totalRejectedAmount = dashboardData[0].totalRejectedAmount[0].total; } else { totalRejectedAmount = 0; }

            var data = {
                totalCount: totalCount,
                totalAmount: totalAmount,
                totalInProcessCount: totalInProcessCount,
                totalInProcessAmount: totalInProcessAmount,
                totalFundedCount: totalFundedCount,
                totalFundedAmount: totalFundedAmount,
                totalRepaidCount: totalRepaidCount,
                totalRepaidAmount: totalRepaidAmount,
                totalRejectedCount: totalRejectedCount,
                totalRejectedAmount: totalRejectedAmount
            }
            return { data };
        } catch (e) {
            this.logger.error(e);
            throw e;
        }
    }
    public async getInvoiceGraphToVendor(currentUser: IUser): Promise<{ data: any }> {
        try {
            var sum1 = 0; var sum2 = 0; var sum3 = 0; var sum4 = 0; var sum5 = 0; var sum6 = 0;
            var forcalc = new Date();
            var thismonth = forcalc.getMonth() + 1;
            var t = forcalc.getFullYear();
            var this1 = new Date(t, thismonth - 1, 1);

            var month1 = forcalc.getMonth();
            if (month1 <= 0) {
                month1 += 12;
                forcalc.setFullYear(forcalc.getFullYear() - 1);
            }
            forcalc.setMonth(month1);
            var a = forcalc.getFullYear();
            var d1m1 = new Date(a, month1 - 1, 1);
            var laster1 = new Date(a, month1, 0);
            laster1.setHours(23, 59, 59, 0)
            if (month1 <= 0) {
                month1 += 12;
                a = a - 1
            }

            var month2 = forcalc.getMonth() - 1;
            if (month2 < 0) {
                month2 += 12;
                forcalc.setFullYear(forcalc.getFullYear() - 1);
            }
            forcalc.setMonth(month2);
            var b = forcalc.getFullYear();
            var d1m2 = new Date(b, month2 - 1, 1);
            var laster2 = new Date(b, month2, 0);
            laster2.setHours(23, 59, 59, 0);
            if (month2 <= 0) {
                month2 += 12;
                b = b - 1
            }

            var month3 = forcalc.getMonth() - 1;
            if (month3 < 0) {
                month3 += 12;
                forcalc.setFullYear(forcalc.getFullYear() - 1);
            }
            forcalc.setMonth(month3);
            var c = forcalc.getFullYear();
            var d1m3 = new Date(c, month3 - 1, 1);
            var laster3 = new Date(c, month3, 0);
            laster3.setHours(23, 59, 59, 0)
            if (month3 <= 0) {
                month3 += 12;
                c = c - 1
            }

            var month4 = forcalc.getMonth() - 1;
            if (month4 < 0) {
                month4 += 12;
                forcalc.setFullYear(forcalc.getFullYear() - 1);
            }
            forcalc.setMonth(month4);
            var d = forcalc.getFullYear();
            var d1m4 = new Date(d, month4 - 1, 1);
            var laster4 = new Date(d, month4, 0);
            laster4.setHours(23, 59, 59, 0)
            if (month4 <= 0) {
                month4 += 12;
                d = d - 1
            }

            var month5 = forcalc.getMonth() - 1;
            if (month5 < 0) {
                month5 += 12;
                forcalc.setFullYear(forcalc.getFullYear() - 1);
            }
            forcalc.setMonth(month5);
            var e = forcalc.getFullYear();
            var d1m5 = new Date(e, month5 - 1, 1);
            var laster5 = new Date(e, month5, 0);
            laster5.setHours(23, 59, 59, 0)
            if (month5 <= 0) {
                month5 += 12;
                e = e - 1
            }

            var todaydate = new Date();


            var countser2 = await this.SupplierInvoice.aggregate([{
                $facet: {
                    "sumone": [
                        { $match: { $and: [{ InvoiceDate: { $gte: this1, $lte: todaydate } }, { VendorId: currentUser.organizationId }] } },
                        { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } }
                    ],
                    "sumtwo": [
                        { $match: { $and: [{ InvoiceDate: { $gte: d1m1, $lte: laster1 } }, { VendorId: currentUser.organizationId }] } },
                        { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } }
                    ],
                    "sumthree": [
                        { $match: { $and: [{ InvoiceDate: { $gte: d1m2, $lte: laster2 } }, { VendorId: currentUser.organizationId }] } },
                        { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } }
                    ],
                    "sumfour": [
                        { $match: { $and: [{ InvoiceDate: { $gte: d1m3, $lte: laster3 } }, { VendorId: currentUser.organizationId }] } },
                        { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } }
                    ],
                    "sumfive": [
                        { $match: { $and: [{ InvoiceDate: { $gte: d1m4, $lte: laster4 } }, { VendorId: currentUser.organizationId }] } },
                        { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } }
                    ],
                    "sumsix": [
                        { $match: { $and: [{ InvoiceDate: { $gte: d1m5, $lte: laster5 } }, { VendorId: currentUser.organizationId }] } },
                        { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } }
                    ]
                }
            }])

            if (countser2[0].sumone[0] != undefined) { sum1 = countser2[0].sumone[0].total; } else { sum1 = 0; }
            if (countser2[0].sumtwo[0] != undefined) { sum2 = countser2[0].sumtwo[0].total; } else { sum2 = 0; }
            if (countser2[0].sumthree[0] != undefined) { sum3 = countser2[0].sumthree[0].total; } else { sum3 = 0; }
            if (countser2[0].sumfour[0] != undefined) { sum4 = countser2[0].sumfour[0].total; } else { sum4 = 0; }
            if (countser2[0].sumfive[0] != undefined) { sum5 = countser2[0].sumfive[0].total; } else { sum5 = 0; }
            if (countser2[0].sumsix[0] != undefined) { sum6 = countser2[0].sumsix[0].total; } else { sum6 = 0; }

            return {
                data: {
                    success: true,
                    message: [[sum1, thismonth, t], [sum2, month1, a], [sum3, month2, b], [sum4, month3, c],
                    [sum5, month4, d], [sum6, month5, e]],
                }
            };
        } catch (e) {
            this.logger.error(e);
            throw e;
        }
    }
    public async getLApprovedInvoiceGraphToVendor(currentUser: IUser): Promise<{ data: any }> {
        try {
            var sum1 = 0; var sum2 = 0; var sum3 = 0; var sum4 = 0; var sum5 = 0; var sum6 = 0;
            var forcalc = new Date();
            var thismonth = forcalc.getMonth() + 1;
            var t = forcalc.getFullYear();
            var this1 = new Date(t, thismonth - 1, 1);

            var month1 = forcalc.getMonth();
            if (month1 <= 0) {
                month1 += 12;
                forcalc.setFullYear(forcalc.getFullYear() - 1);
            }
            forcalc.setMonth(month1);
            var a = forcalc.getFullYear();
            var d1m1 = new Date(a, month1 - 1, 1);
            var laster1 = new Date(a, month1, 0);
            laster1.setHours(23, 59, 59, 0)
            if (month1 <= 0) {
                month1 += 12;
                a = a - 1
            } laster1.setHours(23, 59, 59, 0)

            var month2 = forcalc.getMonth() - 1;
            if (month2 < 0) {
                month2 += 12;
                forcalc.setFullYear(forcalc.getFullYear() - 1);
            }
            forcalc.setMonth(month2);
            var b = forcalc.getFullYear();
            var d1m2 = new Date(b, month2 - 1, 1);
            var laster2 = new Date(b, month2, 0);
            laster2.setHours(23, 59, 59, 0);
            if (month2 <= 0) {
                month2 += 12;
                b = b - 1
            }

            var month3 = forcalc.getMonth() - 1;
            if (month3 < 0) {
                month3 += 12;
                forcalc.setFullYear(forcalc.getFullYear() - 1);
            }
            forcalc.setMonth(month3);
            var c = forcalc.getFullYear();
            var d1m3 = new Date(c, month3 - 1, 1);
            var laster3 = new Date(c, month3, 0);
            laster3.setHours(23, 59, 59, 0)
            if (month3 <= 0) {
                month3 += 12;
                c = c - 1
            }

            var month4 = forcalc.getMonth() - 1;
            if (month4 < 0) {
                month4 += 12;
                forcalc.setFullYear(forcalc.getFullYear() - 1);
            }
            forcalc.setMonth(month4);
            var d = forcalc.getFullYear();
            var d1m4 = new Date(d, month4 - 1, 1);
            var laster4 = new Date(d, month4, 0);
            laster4.setHours(23, 59, 59, 0)
            if (month4 <= 0) {
                month4 += 12;
                d = d - 1
            }

            var month5 = forcalc.getMonth() - 1;
            if (month5 < 0) {
                month5 += 12;
                forcalc.setFullYear(forcalc.getFullYear() - 1);
            }
            forcalc.setMonth(month5);
            var e = forcalc.getFullYear();
            var d1m5 = new Date(e, month5 - 1, 1);
            var laster5 = new Date(e, month5, 0);
            laster5.setHours(23, 59, 59, 0)
            if (month5 <= 0) {
                month5 += 12;
                e = e - 1
            }

            var todaydate = new Date();


            var countser2 = await this.SupplierInvoice.aggregate([{
                $facet: {
                    "sumone": [
                        { $match: { $and: [{ VendorId: currentUser.organizationId }, { InvoiceDate: { $gte: this1, $lte: todaydate } }, { $or: [{ Status: "Lender Approved" }, { Status: "Hospital Approved" }, { Status: "Fully Repaid" }, { Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Partially Repaid" }] }] }, },
                        { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } }
                    ],
                    "sumtwo": [
                        { $match: { $and: [{ VendorId: currentUser.organizationId }, { InvoiceDate: { $gte: d1m1, $lte: laster1 } }, { $or: [{ Status: "Lender Approved" }, { Status: "Hospital Approved" }, { Status: "Fully Repaid" }, { Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Partially Repaid" }] }] }, },
                        { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } }
                    ],
                    "sumthree": [
                        { $match: { $and: [{ VendorId: currentUser.organizationId }, { InvoiceDate: { $gte: d1m2, $lte: laster2 } }, { $or: [{ Status: "Lender Approved" }, { Status: "Hospital Approved" }, { Status: "Fully Repaid" }, { Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Partially Repaid" }] }] }, },
                        { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } }
                    ],
                    "sumfour": [
                        { $match: { $and: [{ VendorId: currentUser.organizationId }, { InvoiceDate: { $gte: d1m3, $lte: laster3 } }, { $or: [{ Status: "Lender Approved" }, { Status: "Hospital Approved" }, { Status: "Fully Repaid" }, { Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Partially Repaid" }] }] }, },
                        { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } }
                    ],
                    "sumfive": [
                        { $match: { $and: [{ VendorId: currentUser.organizationId }, { InvoiceDate: { $gte: d1m4, $lte: laster4 } }, { $or: [{ Status: "Lender Approved" }, { Status: "Hospital Approved" }, { Status: "Fully Repaid" }, { Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Partially Repaid" }] }] }, },
                        { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } }
                    ],
                    "sumsix": [
                        { $match: { $and: [{ VendorId: currentUser.organizationId }, { InvoiceDate: { $gte: d1m5, $lte: laster5 } }, { $or: [{ Status: "Lender Approved" }, { Status: "Hospital Approved" }, { Status: "Fully Repaid" }, { Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Partially Repaid" }] }] }, },
                        { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } }
                    ]
                }
            }])

            if (countser2[0].sumone[0] != undefined) { sum1 = countser2[0].sumone[0].total; } else { sum1 = 0; }
            if (countser2[0].sumtwo[0] != undefined) { sum2 = countser2[0].sumtwo[0].total; } else { sum2 = 0; }
            if (countser2[0].sumthree[0] != undefined) { sum3 = countser2[0].sumthree[0].total; } else { sum3 = 0; }
            if (countser2[0].sumfour[0] != undefined) { sum4 = countser2[0].sumfour[0].total; } else { sum4 = 0; }
            if (countser2[0].sumfive[0] != undefined) { sum5 = countser2[0].sumfive[0].total; } else { sum5 = 0; }
            if (countser2[0].sumsix[0] != undefined) { sum6 = countser2[0].sumsix[0].total; } else { sum6 = 0; }

            return {
                data: {
                    success: true,
                    message: [[sum1, thismonth, t], [sum2, month1, a], [sum3, month2, b], [sum4, month3, c],
                    [sum5, month4, d], [sum6, month5, e]],
                }
            };
        } catch (e) {
            this.logger.error(e);
            throw e;
        }
    }
    public async getFundedInvoiceGraphToVendor(currentUser: IUser): Promise<{ data: any }> {
        try {
            var sum1 = 0;
            var sum2 = 0;
            var sum3 = 0;
            var sum4 = 0;
            var sum5 = 0;
            var sum6 = 0;
            var forcalc = new Date();
            var thismonth = forcalc.getMonth() + 1;
            var t = forcalc.getFullYear();
            var this1 = new Date(t, thismonth - 1, 1);

            var month1 = forcalc.getMonth();
            if (month1 <= 0) {
                month1 += 12;
                forcalc.setFullYear(forcalc.getFullYear() - 1);
            }
            forcalc.setMonth(month1);
            var a = forcalc.getFullYear();
            var d1m1 = new Date(a, month1 - 1, 1);
            var laster1 = new Date(a, month1, 0);
            laster1.setHours(23, 59, 59, 0)
            if (month1 <= 0) {
                month1 += 12;
                a = a - 1
            } laster1.setHours(23, 59, 59, 0)

            var month2 = forcalc.getMonth() - 1;
            if (month2 < 0) {
                month2 += 12;
                forcalc.setFullYear(forcalc.getFullYear() - 1);
            }
            forcalc.setMonth(month2);
            var b = forcalc.getFullYear();
            var d1m2 = new Date(b, month2 - 1, 1);
            var laster2 = new Date(b, month2, 0);
            laster2.setHours(23, 59, 59, 0);
            if (month2 <= 0) {
                month2 += 12;
                b = b - 1
            }

            var month3 = forcalc.getMonth() - 1;
            if (month3 < 0) {
                month3 += 12;
                forcalc.setFullYear(forcalc.getFullYear() - 1);
            }
            forcalc.setMonth(month3);
            var c = forcalc.getFullYear();
            var d1m3 = new Date(c, month3 - 1, 1);
            var laster3 = new Date(c, month3, 0);
            laster3.setHours(23, 59, 59, 0)
            if (month3 <= 0) {
                month3 += 12;
                c = c - 1
            }

            var month4 = forcalc.getMonth() - 1;
            if (month4 < 0) {
                month4 += 12;
                forcalc.setFullYear(forcalc.getFullYear() - 1);
            }
            forcalc.setMonth(month4);
            var d = forcalc.getFullYear();
            var d1m4 = new Date(d, month4 - 1, 1);
            var laster4 = new Date(d, month4, 0);
            laster4.setHours(23, 59, 59, 0)
            if (month4 <= 0) {
                month4 += 12;
                d = d - 1
            }

            var month5 = forcalc.getMonth() - 1;
            if (month5 < 0) {
                month5 += 12;
                forcalc.setFullYear(forcalc.getFullYear() - 1);
            }
            forcalc.setMonth(month5);
            var e = forcalc.getFullYear();
            var d1m5 = new Date(e, month5 - 1, 1);
            var laster5 = new Date(e, month5, 0);
            laster5.setHours(23, 59, 59, 0)
            if (month5 <= 0) {
                month5 += 12;
                e = e - 1
            }

            var todaydate = new Date();


            var countser2 = await this.SupplierInvoice.aggregate([{
                $facet: {
                    "sumone": [
                        { $match: { $and: [{ VendorId: currentUser.organizationId }, { PaymentDate: { $gte: this1, $lte: todaydate } }, { $or: [{ Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Fully Repaid" }, { Status: "Partially Repaid" }] }] }, },
                        { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } }
                    ],
                    "sumtwo": [
                        { $match: { $and: [{ VendorId: currentUser.organizationId }, { PaymentDate: { $gte: d1m1, $lte: laster1 } }, { $or: [{ Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Fully Repaid" }, { Status: "Partially Repaid" }] }] }, },
                        { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } }
                    ],
                    "sumthree": [
                        { $match: { $and: [{ VendorId: currentUser.organizationId }, { PaymentDate: { $gte: d1m2, $lte: laster2 } }, { $or: [{ Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Fully Repaid" }, { Status: "Partially Repaid" }] }] }, },
                        { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } }
                    ],
                    "sumfour": [
                        { $match: { $and: [{ VendorId: currentUser.organizationId }, { PaymentDate: { $gte: d1m3, $lte: laster3 } }, { $or: [{ Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Fully Repaid" }, { Status: "Partially Repaid" }] }] }, },
                        { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } }
                    ],
                    "sumfive": [
                        { $match: { $and: [{ VendorId: currentUser.organizationId }, { PaymentDate: { $gte: d1m4, $lte: laster4 } }, { $or: [{ Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Fully Repaid" }, { Status: "Partially Repaid" }] }] }, },
                        { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } }
                    ],
                    "sumsix": [
                        { $match: { $and: [{ VendorId: currentUser.organizationId }, { PaymentDate: { $gte: d1m5, $lte: laster5 } }, { $or: [{ Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Fully Repaid" }, { Status: "Partially Repaid" }] }] }, },
                        { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } }
                    ]
                }
            }])

            if (countser2[0].sumone[0] != undefined) { sum1 = countser2[0].sumone[0].total; } else { sum1 = 0; }
            if (countser2[0].sumtwo[0] != undefined) { sum2 = countser2[0].sumtwo[0].total; } else { sum2 = 0; }
            if (countser2[0].sumthree[0] != undefined) { sum3 = countser2[0].sumthree[0].total; } else { sum3 = 0; }
            if (countser2[0].sumfour[0] != undefined) { sum4 = countser2[0].sumfour[0].total; } else { sum4 = 0; }
            if (countser2[0].sumfive[0] != undefined) { sum5 = countser2[0].sumfive[0].total; } else { sum5 = 0; }
            if (countser2[0].sumsix[0] != undefined) { sum6 = countser2[0].sumsix[0].total; } else { sum6 = 0; }

            return {
                data: {
                    success: true,
                    message: [[sum1, thismonth, t], [sum2, month1, a], [sum3, month2, b], [sum4, month3, c],
                    [sum5, month4, d], [sum6, month5, e]],
                }
            }
        } catch (e) {
            this.logger.error(e);
            throw e;
        }
    }
    public async getVendorGraphOne(currentUser: IUser): Promise<{ data: any }> {
        try {
            var sum1 = 0; var sum2 = 0; var sum3 = 0; var sum4 = 0; var sum5 = 0; var sum6 = 0;

            var InProcesssum1 = 0; var InProcesssum2 = 0; var InProcesssum3 = 0;
            var InProcesssum4 = 0; var InProcesssum5 = 0; var InProcesssum6 = 0;

            var Disbursedsum1 = 0; var Disbursedsum2 = 0; var Disbursedsum3 = 0;
            var Disbursedsum4 = 0; var Disbursedsum5 = 0; var Disbursedsum6 = 0;

            var Repaidsum1 = 0; var Repaidsum2 = 0; var Repaidsum3 = 0;
            var Repaidsum4 = 0; var Repaidsum5 = 0; var Repaidsum6 = 0;

            var Rejectedsum1 = 0; var Rejectedsum2 = 0; var Rejectedsum3 = 0;
            var Rejectedsum4 = 0; var Rejectedsum5 = 0; var Rejectedsum6 = 0;

            var forcalc = new Date();
            var thismonth = forcalc.getMonth() + 1;
            var t = forcalc.getFullYear();
            var this1 = new Date(t, thismonth - 1, 1);

            var month1 = forcalc.getMonth();
            if (month1 <= 0) {
                month1 += 12;
                forcalc.setFullYear(forcalc.getFullYear() - 1);
            }
            forcalc.setMonth(month1);
            var a = forcalc.getFullYear();
            var d1m1 = new Date(a, month1 - 1, 1);
            var laster1 = new Date(a, month1, 0);
            laster1.setHours(23, 59, 59, 0)
            if (month1 <= 0) {
                month1 += 12;
                a = a - 1
            } laster1.setHours(23, 59, 59, 0)

            var month2 = forcalc.getMonth() - 1;
            if (month2 <= 0) {
                month2 += 12;
                forcalc.setFullYear(forcalc.getFullYear() - 1);
            }
            forcalc.setMonth(month2);
            var b = forcalc.getFullYear();
            var d1m2 = new Date(b, month2 - 1, 1);
            var laster2 = new Date(b, month2, 0);
            laster2.setHours(23, 59, 59, 0);
            if (month2 <= 0) {
                month2 += 12;
                b = b - 1
            }

            var month3 = forcalc.getMonth() - 1;
            if (month3 <= 0) {
                month3 += 12;
                forcalc.setFullYear(forcalc.getFullYear() - 1);
            }
            forcalc.setMonth(month3);
            var c = forcalc.getFullYear();
            var d1m3 = new Date(c, month3 - 1, 1);
            var laster3 = new Date(c, month3, 0);
            laster3.setHours(23, 59, 59, 0)
            if (month3 <= 0) {
                month3 += 12;
                c = c - 1
            }

            var month4 = forcalc.getMonth() - 1;
            if (month4 <= 0) {
                month4 += 12;
                forcalc.setFullYear(forcalc.getFullYear() - 1);
            }
            forcalc.setMonth(month4);
            var d = forcalc.getFullYear();
            var d1m4 = new Date(d, month4 - 1, 1);
            var laster4 = new Date(d, month4, 0);
            laster4.setHours(23, 59, 59, 0)
            if (month4 <= 0) {
                month4 += 12;
                d = d - 1
            }

            var month5 = forcalc.getMonth() - 1;
            if (month5 <= 0) {
                month5 += 12;
                forcalc.setFullYear(forcalc.getFullYear() - 1);
            }
            forcalc.setMonth(month5);
            var e = forcalc.getFullYear();
            var d1m5 = new Date(e, month5 - 1, 1);
            var laster5 = new Date(e, month5, 0);
            laster5.setHours(23, 59, 59, 0)
            if (month5 <= 0) {
                month5 += 12;
                e = e - 1
            }

            var todaydate = new Date();


            var countone = await this.SupplierInvoice.aggregate([{
                $facet: {
                    "sumone": [{ $match: { $and: [{ VendorId: currentUser.organizationId }, { InvoiceDate: { $gte: this1, $lte: todaydate } }] } }, { $count: "total" }],
                    "sumtwo": [{ $match: { $and: [{ VendorId: currentUser.organizationId }, { InvoiceDate: { $gte: d1m1, $lte: laster1 } }] } }, { $count: "total" }],
                    "sumthree": [{ $match: { $and: [{ VendorId: currentUser.organizationId }, { InvoiceDate: { $gte: d1m2, $lte: laster2 } }] } }, { $count: "total" }],
                    "sumfour": [{ $match: { $and: [{ VendorId: currentUser.organizationId }, { InvoiceDate: { $gte: d1m3, $lte: laster3 } }] } }, { $count: "total" }],
                    "sumfive": [{ $match: { $and: [{ VendorId: currentUser.organizationId }, { InvoiceDate: { $gte: d1m4, $lte: laster4 } }] } }, { $count: "total" }],
                    "sumsix": [{ $match: { $and: [{ VendorId: currentUser.organizationId }, { InvoiceDate: { $gte: d1m5, $lte: laster5 } }] } }, { $count: "total" }],

                    "InProsumone": [{ $match: { $and: [{ VendorId: currentUser.organizationId }, { InvoiceDate: { $gte: this1, $lte: todaydate } }, { $or: [{ Status: "Pending" }, { Status: "Hospital Approved" }, { Status: "Lender Approved" }, { Status: "DSPL Approved" }] }] } }, { $count: "total" }],
                    "InProsumtwo": [{ $match: { $and: [{ VendorId: currentUser.organizationId }, { InvoiceDate: { $gte: d1m1, $lte: laster1 } }, { $or: [{ Status: "Pending" }, { Status: "Hospital Approved" }, { Status: "Lender Approved" }, { Status: "DSPL Approved" }] }] } }, { $count: "total" }],
                    "InProsumthree": [{ $match: { $and: [{ VendorId: currentUser.organizationId }, { InvoiceDate: { $gte: d1m2, $lte: laster2 } }, { $or: [{ Status: "Pending" }, { Status: "Hospital Approved" }, { Status: "Lender Approved" }, { Status: "DSPL Approved" }] }] } }, { $count: "total" }],
                    "InProsumfour": [{ $match: { $and: [{ VendorId: currentUser.organizationId }, { InvoiceDate: { $gte: d1m3, $lte: laster3 } }, { $or: [{ Status: "Pending" }, { Status: "Hospital Approved" }, { Status: "Lender Approved" }, { Status: "DSPL Approved" }] }] } }, { $count: "total" }],
                    "InProsumfive": [{ $match: { $and: [{ VendorId: currentUser.organizationId }, { InvoiceDate: { $gte: d1m4, $lte: laster4 } }, { $or: [{ Status: "Pending" }, { Status: "Hospital Approved" }, { Status: "Lender Approved" }, { Status: "DSPL Approved" }] }] } }, { $count: "total" }],
                    "InProsumsix": [{ $match: { $and: [{ VendorId: currentUser.organizationId }, { InvoiceDate: { $gte: d1m5, $lte: laster5 } }, { $or: [{ Status: "Pending" }, { Status: "Hospital Approved" }, { Status: "Lender Approved" }, { Status: "DSPL Approved" }] }] } }, { $count: "total" }],

                    "Disbursedsumone": [{ $match: { $and: [{ VendorId: currentUser.organizationId }, { InvoiceDate: { $gte: this1, $lte: todaydate } }, { $or: [{ Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Fully Repaid" }, { Status: "Partially Repaid" }] }] } }, { $count: "total" }],
                    "Disbursedsumtwo": [{ $match: { $and: [{ VendorId: currentUser.organizationId }, { InvoiceDate: { $gte: d1m1, $lte: laster1 } }, { $or: [{ Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Fully Repaid" }, { Status: "Partially Repaid" }] }] } }, { $count: "total" }],
                    "Disbursedsumthree": [{ $match: { $and: [{ VendorId: currentUser.organizationId }, { InvoiceDate: { $gte: d1m2, $lte: laster2 } }, { $or: [{ Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Fully Repaid" }, { Status: "Partially Repaid" }] }] } }, { $count: "total" }],
                    "Disbursedsumfour": [{ $match: { $and: [{ VendorId: currentUser.organizationId }, { InvoiceDate: { $gte: d1m3, $lte: laster3 } }, { $or: [{ Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Fully Repaid" }, { Status: "Partially Repaid" }] }] } }, { $count: "total" }],
                    "Disbursedsumfive": [{ $match: { $and: [{ VendorId: currentUser.organizationId }, { InvoiceDate: { $gte: d1m4, $lte: laster4 } }, { $or: [{ Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Fully Repaid" }, { Status: "Partially Repaid" }] }] } }, { $count: "total" }],
                    "Disbursedsumsix": [{ $match: { $and: [{ VendorId: currentUser.organizationId }, { InvoiceDate: { $gte: d1m5, $lte: laster5 } }, { $or: [{ Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Fully Repaid" }, { Status: "Partially Repaid" }] }] } }, { $count: "total" }],

                    "Repaidsumone": [{ $match: { $and: [{ VendorId: currentUser.organizationId }, { InvoiceDate: { $gte: this1, $lte: todaydate } }, { Status: "Fully Repaid" }] } }, { $count: "total" }],
                    "Repaidsumtwo": [{ $match: { $and: [{ VendorId: currentUser.organizationId }, { InvoiceDate: { $gte: d1m1, $lte: laster1 } }, { Status: "Fully Repaid" }] } }, { $count: "total" }],
                    "Repaidsumthree": [{ $match: { $and: [{ VendorId: currentUser.organizationId }, { InvoiceDate: { $gte: d1m2, $lte: laster2 } }, { Status: "Fully Repaid" }] } }, { $count: "total" }],
                    "Repaidsumfour": [{ $match: { $and: [{ VendorId: currentUser.organizationId }, { InvoiceDate: { $gte: d1m3, $lte: laster3 } }, { Status: "Fully Repaid" }] } }, { $count: "total" }],
                    "Repaidsumfive": [{ $match: { $and: [{ VendorId: currentUser.organizationId }, { InvoiceDate: { $gte: d1m4, $lte: laster4 } }, { Status: "Fully Repaid" }] } }, { $count: "total" }],
                    "Repaidsumsix": [{ $match: { $and: [{ VendorId: currentUser.organizationId }, { InvoiceDate: { $gte: d1m5, $lte: laster5 } }, { Status: "Fully Repaid" }] } }, { $count: "total" }],

                    "Rejectedsumone": [{ $match: { $and: [{ VendorId: currentUser.organizationId }, { InvoiceDate: { $gte: this1, $lte: todaydate } }, { $or: [{ Status: "Hospital Rejected" }, { Status: "Lender Rejected" }, { Status: "DSPL Rejected" }] }] } }, { $count: "total" }],
                    "Rejectedsumtwo": [{ $match: { $and: [{ VendorId: currentUser.organizationId }, { InvoiceDate: { $gte: d1m1, $lte: laster1 } }, { $or: [{ Status: "Hospital Rejected" }, { Status: "Lender Rejected" }, { Status: "DSPL Rejected" }] }] } }, { $count: "total" }],
                    "Rejectedsumthree": [{ $match: { $and: [{ VendorId: currentUser.organizationId }, { InvoiceDate: { $gte: d1m2, $lte: laster2 } }, { $or: [{ Status: "Hospital Rejected" }, { Status: "Lender Rejected" }, { Status: "DSPL Rejected" }] }] } }, { $count: "total" }],
                    "Rejectedsumfour": [{ $match: { $and: [{ VendorId: currentUser.organizationId }, { InvoiceDate: { $gte: d1m3, $lte: laster3 } }, { $or: [{ Status: "Hospital Rejected" }, { Status: "Lender Rejected" }, { Status: "DSPL Rejected" }] }] } }, { $count: "total" }],
                    "Rejectedsumfive": [{ $match: { $and: [{ VendorId: currentUser.organizationId }, { InvoiceDate: { $gte: d1m4, $lte: laster4 } }, { $or: [{ Status: "Hospital Rejected" }, { Status: "Lender Rejected" }, { Status: "DSPL Rejected" }] }] } }, { $count: "total" }],
                    "Rejectedsumsix": [{ $match: { $and: [{ VendorId: currentUser.organizationId }, { InvoiceDate: { $gte: d1m5, $lte: laster5 } }, { $or: [{ Status: "Hospital Rejected" }, { Status: "Lender Rejected" }, { Status: "DSPL Rejected" }] }] } }, { $count: "total" }]
                }
            }])

            if (countone[0].sumone[0] != undefined) { sum1 = countone[0].sumone[0].total; } else { sum1 = 0; }
            if (countone[0].sumtwo[0] != undefined) { sum2 = countone[0].sumtwo[0].total; } else { sum2 = 0; }
            if (countone[0].sumthree[0] != undefined) { sum3 = countone[0].sumthree[0].total; } else { sum3 = 0; }
            if (countone[0].sumfour[0] != undefined) { sum4 = countone[0].sumfour[0].total; } else { sum4 = 0; }
            if (countone[0].sumfive[0] != undefined) { sum5 = countone[0].sumfive[0].total; } else { sum5 = 0; }
            if (countone[0].sumsix[0] != undefined) { sum6 = countone[0].sumsix[0].total; } else { sum6 = 0; }

            if (countone[0].InProsumone[0] != undefined) { InProcesssum1 = countone[0].InProsumone[0].total; } else { InProcesssum1 = 0; }
            if (countone[0].InProsumtwo[0] != undefined) { InProcesssum2 = countone[0].InProsumtwo[0].total; } else { InProcesssum2 = 0; }
            if (countone[0].InProsumthree[0] != undefined) { InProcesssum3 = countone[0].InProsumthree[0].total; } else { InProcesssum3 = 0; }
            if (countone[0].InProsumfour[0] != undefined) { InProcesssum4 = countone[0].InProsumfour[0].total; } else { InProcesssum4 = 0; }
            if (countone[0].InProsumfive[0] != undefined) { InProcesssum5 = countone[0].InProsumfive[0].total; } else { InProcesssum5 = 0; }
            if (countone[0].InProsumsix[0] != undefined) { InProcesssum6 = countone[0].InProsumsix[0].total; } else { InProcesssum6 = 0; }

            if (countone[0].Disbursedsumone[0] != undefined) { Disbursedsum1 = countone[0].Disbursedsumone[0].total; } else { Disbursedsum1 = 0; }
            if (countone[0].Disbursedsumtwo[0] != undefined) { Disbursedsum2 = countone[0].Disbursedsumtwo[0].total; } else { Disbursedsum2 = 0; }
            if (countone[0].Disbursedsumthree[0] != undefined) { Disbursedsum3 = countone[0].Disbursedsumthree[0].total; } else { Disbursedsum3 = 0; }
            if (countone[0].Disbursedsumfour[0] != undefined) { Disbursedsum4 = countone[0].Disbursedsumfour[0].total; } else { Disbursedsum4 = 0; }
            if (countone[0].Disbursedsumfive[0] != undefined) { Disbursedsum5 = countone[0].Disbursedsumfive[0].total; } else { Disbursedsum5 = 0; }
            if (countone[0].Disbursedsumsix[0] != undefined) { Disbursedsum6 = countone[0].Disbursedsumsix[0].total; } else { Disbursedsum6 = 0; }

            if (countone[0].Repaidsumone[0] != undefined) { Repaidsum1 = countone[0].Repaidsumone[0].total; } else { Repaidsum1 = 0; }
            if (countone[0].Repaidsumtwo[0] != undefined) { Repaidsum2 = countone[0].Repaidsumtwo[0].total; } else { Repaidsum2 = 0; }
            if (countone[0].Repaidsumthree[0] != undefined) { Repaidsum3 = countone[0].Repaidsumthree[0].total; } else { Repaidsum3 = 0; }
            if (countone[0].Repaidsumfour[0] != undefined) { Repaidsum4 = countone[0].Repaidsumfour[0].total; } else { Repaidsum4 = 0; }
            if (countone[0].Repaidsumfive[0] != undefined) { Repaidsum5 = countone[0].Repaidsumfive[0].total; } else { Repaidsum5 = 0; }
            if (countone[0].Repaidsumsix[0] != undefined) { Repaidsum6 = countone[0].Repaidsumsix[0].total; } else { Repaidsum6 = 0; }

            if (countone[0].Rejectedsumone[0] != undefined) { Rejectedsum1 = countone[0].Rejectedsumone[0].total; } else { Rejectedsum1 = 0; }
            if (countone[0].Rejectedsumtwo[0] != undefined) { Rejectedsum2 = countone[0].Rejectedsumtwo[0].total; } else { Rejectedsum2 = 0; }
            if (countone[0].Rejectedsumthree[0] != undefined) { Rejectedsum3 = countone[0].Rejectedsumthree[0].total; } else { Rejectedsum3 = 0; }
            if (countone[0].Rejectedsumfour[0] != undefined) { Rejectedsum4 = countone[0].Rejectedsumfour[0].total; } else { Rejectedsum4 = 0; }
            if (countone[0].Rejectedsumfive[0] != undefined) { Rejectedsum5 = countone[0].Rejectedsumfive[0].total; } else { Rejectedsum5 = 0; }
            if (countone[0].Rejectedsumsix[0] != undefined) { Rejectedsum6 = countone[0].Rejectedsumsix[0].total; } else { Rejectedsum6 = 0; }


            return {
                data: {
                    success: true,
                    monthsAndYears: [[thismonth, t], [month1, a], [month2, b], [month3, c], [month4, d], [month5, e]],
                    All: [sum1, sum2, sum3, sum4, sum5, sum6],
                    InProcess: [InProcesssum1, InProcesssum2, InProcesssum3, InProcesssum4, InProcesssum5, InProcesssum6],
                    Disbursed: [Disbursedsum1, Disbursedsum2, Disbursedsum3, Disbursedsum4, Disbursedsum5, Disbursedsum6],
                    Repaid: [Repaidsum1, Repaidsum2, Repaidsum3, Repaidsum4, Repaidsum5, Repaidsum6],
                    Rejected: [Rejectedsum1, Rejectedsum2, Rejectedsum3, Rejectedsum4, Rejectedsum5, Rejectedsum6],
                }
            }
        } catch (e) {
            this.logger.error(e);
            throw e;
        }
    }
    public async getLastPieGraphForVendor(currentUser: IUser): Promise<{ data: any }> {
        try {
            var FundedSum = 0;
            var UnderPaidsum = 0;
            var OverPaidsum = 0;
            var FullPaidsum = 0;

            var forcalc = new Date();
            var thismonth = forcalc.getMonth() + 1;
            var t = forcalc.getFullYear();
            var this1 = new Date(t, thismonth - 1, 1);

            var month1 = forcalc.getMonth();
            if (month1 <= 0) {
                month1 += 12;
                forcalc.setFullYear(forcalc.getFullYear() - 1);
            }
            forcalc.setMonth(month1);
            var a = forcalc.getFullYear();
            var d1m1 = new Date(a, month1 - 1, 1);
            var laster1 = new Date(a, month1, 0);
            laster1.setHours(23, 59, 59, 0)
            if (month1 <= 0) {
                month1 += 12;
                a = a - 1
            } laster1.setHours(23, 59, 59, 0)

            var month2 = forcalc.getMonth() - 1;
            if (month2 <= 0) {
                month2 += 12;
                forcalc.setFullYear(forcalc.getFullYear() - 1);
            }
            forcalc.setMonth(month2);
            var b = forcalc.getFullYear();
            var d1m2 = new Date(b, month2 - 1, 1);
            var laster2 = new Date(b, month2, 0);
            laster2.setHours(23, 59, 59, 0);
            if (month2 <= 0) {
                month2 += 12;
                b = b - 1
            }

            var month3 = forcalc.getMonth() - 1;
            if (month3 <= 0) {
                month3 += 12;
                forcalc.setFullYear(forcalc.getFullYear() - 1);
            }
            forcalc.setMonth(month3);
            var c = forcalc.getFullYear();
            var d1m3 = new Date(c, month3 - 1, 1);
            var laster3 = new Date(c, month3, 0);
            laster3.setHours(23, 59, 59, 0)
            if (month3 <= 0) {
                month3 += 12;
                c = c - 1
            }

            var month4 = forcalc.getMonth() - 1;
            if (month4 <= 0) {
                month4 += 12;
                forcalc.setFullYear(forcalc.getFullYear() - 1);
            }
            forcalc.setMonth(month4);
            var d = forcalc.getFullYear();
            var d1m4 = new Date(d, month4 - 1, 1);
            var laster4 = new Date(d, month4, 0);
            laster4.setHours(23, 59, 59, 0)
            if (month4 <= 0) {
                month4 += 12;
                d = d - 1
            }

            var month5 = forcalc.getMonth() - 1;
            if (month5 <= 0) {
                month5 += 12;
                forcalc.setFullYear(forcalc.getFullYear() - 1);
            }
            forcalc.setMonth(month5);
            var e = forcalc.getFullYear();
            var d1m5 = new Date(e, month5 - 1, 1);
            var laster5 = new Date(e, month5, 0);
            laster5.setHours(23, 59, 59, 0)
            if (month5 <= 0) {
                month5 += 12;
                e = e - 1
            }

            var todaydate = new Date();



            var countone = await this.SupplierInvoice.aggregate([{
                $facet: {
                    "sumone": [{
                        $match: {
                            $and: [{ VendorId: currentUser.organizationId }, { InvoiceDate: { $gte: d1m5, $lte: todaydate } },
                            { $or: [{ Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Fully Repaid" }, { Status: "Partially Repaid" }] }
                            ],
                        }
                    }, { $count: "total" }],
                    "sumtwo": [{
                        $match: {
                            $and: [{ VendorId: currentUser.organizationId }, { InvoiceDate: { $gte: d1m5, $lte: todaydate } },
                            { Status: "Fully Repaid" }, { SettleStatus: "UnderPaid" }
                            ],
                        }
                    }, { $count: "total" }],
                    "sumthree": [{
                        $match: {
                            $and: [{ VendorId: currentUser.organizationId }, { InvoiceDate: { $gte: d1m5, $lte: todaydate } },
                            { Status: "Fully Repaid" }, { SettleStatus: "FullPaid" }
                            ],
                        }
                    }, { $count: "total" }],
                    "sumfour": [{
                        $match: {
                            $and: [{ VendorId: currentUser.organizationId }, { InvoiceDate: { $gte: d1m5, $lte: todaydate } },
                            { Status: "Fully Repaid" }, { SettleStatus: "OverPaid" }
                            ],
                        }
                    }, { $count: "total" }],

                }
            }])

            if (countone[0].sumone[0] != undefined) { FundedSum = countone[0].sumone[0].total; } else { FundedSum = 0; }
            if (countone[0].sumtwo[0] != undefined) { UnderPaidsum = countone[0].sumtwo[0].total; } else { UnderPaidsum = 0; }
            if (countone[0].sumthree[0] != undefined) { FullPaidsum = countone[0].sumthree[0].total; } else { FullPaidsum = 0; }
            if (countone[0].sumfour[0] != undefined) { OverPaidsum = countone[0].sumfour[0].total; } else { OverPaidsum = 0; }

            return {
                data: {
                    success: true,
                    TotalFunded: FundedSum,
                    UnderPaid: UnderPaidsum,
                    OverPaid: OverPaidsum,
                    FullPaid: FullPaidsum
                }
            }
        } catch (e) {
            this.logger.error(e);
            throw e;
        }
    }
    public async getSecondPieGraphForVendor(currentUser: IUser): Promise<{ data: any }> {
        try {
            var forcalc = new Date();
            var thismonth = forcalc.getMonth() + 1;
            var t = forcalc.getFullYear();
            var this1 = new Date(t, thismonth - 1, 1);

            var month1 = forcalc.getMonth();
            if (month1 <= 0) {
                month1 += 12;
                forcalc.setFullYear(forcalc.getFullYear() - 1);
            }
            forcalc.setMonth(month1);
            var a = forcalc.getFullYear();
            var d1m1 = new Date(a, month1 - 1, 1);
            var laster1 = new Date(a, month1, 0);
            laster1.setHours(23, 59, 59, 0)
            if (month1 <= 0) {
                month1 += 12;
                a = a - 1
            } laster1.setHours(23, 59, 59, 0)

            var month2 = forcalc.getMonth() - 1;
            if (month2 <= 0) {
                month2 += 12;
                forcalc.setFullYear(forcalc.getFullYear() - 1);
            }
            forcalc.setMonth(month2);
            var b = forcalc.getFullYear();
            var d1m2 = new Date(b, month2 - 1, 1);
            var laster2 = new Date(b, month2, 0);
            laster2.setHours(23, 59, 59, 0);
            if (month2 <= 0) {
                month2 += 12;
                b = b - 1
            }

            var month3 = forcalc.getMonth() - 1;
            if (month3 <= 0) {
                month3 += 12;
                forcalc.setFullYear(forcalc.getFullYear() - 1);
            }
            forcalc.setMonth(month3);
            var c = forcalc.getFullYear();
            var d1m3 = new Date(c, month3 - 1, 1);
            var laster3 = new Date(c, month3, 0);
            laster3.setHours(23, 59, 59, 0)
            if (month3 <= 0) {
                month3 += 12;
                c = c - 1
            }

            var month4 = forcalc.getMonth() - 1;
            if (month4 <= 0) {
                month4 += 12;
                forcalc.setFullYear(forcalc.getFullYear() - 1);
            }
            forcalc.setMonth(month4);
            var d = forcalc.getFullYear();
            var d1m4 = new Date(d, month4 - 1, 1);
            var laster4 = new Date(d, month4, 0);
            laster4.setHours(23, 59, 59, 0)
            if (month4 <= 0) {
                month4 += 12;
                d = d - 1
            }

            var month5 = forcalc.getMonth() - 1;
            if (month5 <= 0) {
                month5 += 12;
                forcalc.setFullYear(forcalc.getFullYear() - 1);
            }
            forcalc.setMonth(month5);
            var e = forcalc.getFullYear();
            var d1m5 = new Date(e, month5 - 1, 1);
            var laster5 = new Date(e, month5, 0);
            laster5.setHours(23, 59, 59, 0)
            if (month5 <= 0) {
                month5 += 12;
                e = e - 1
            }

            var todaydate = new Date();

            var TotalSum; var Fundedsum;


            var countone = await this.SupplierInvoice.aggregate([{
                $facet: {
                    "sumone": [{
                        $match: { $and: [{ VendorId: currentUser.organizationId }, { InvoiceDate: { $gte: d1m5, $lte: todaydate } }] }
                    }, { $count: "total" }],
                    "sumtwo": [{
                        $match: {
                            $and: [{ VendorId: currentUser.organizationId }, { InvoiceDate: { $gte: d1m5, $lte: todaydate } },
                            { $or: [{ Status: "Disbursed" }, { Status: "Hospital Repaid" }, { Status: "Fully Repaid" }, { Status: "Partially Repaid" }] }
                            ],
                        }
                    }, { $count: "total" }],

                }
            }])

            if (countone[0].sumone[0] != undefined) { TotalSum = countone[0].sumone[0].total; } else { TotalSum = 0; }
            if (countone[0].sumtwo[0] != undefined) { Fundedsum = countone[0].sumtwo[0].total; } else { Fundedsum = 0; }

            return {
                data: {
                    success: true,
                    TotalInvoices: TotalSum,
                    TotalFunded: Fundedsum,

                }
            }
        } catch (e) {
            this.logger.error(e);
            throw e;
        }
    }
    public async getApprovedInvoiceForVendor(currentUser: IUser): Promise<{ data: any }> {
        try {
            var forcalc = new Date();
            var thismonth = forcalc.getMonth() + 1;
            var t = forcalc.getFullYear();
            var this1 = new Date(t, thismonth - 1, 1);

            var month1 = forcalc.getMonth();
            if (month1 <= 0) {
                month1 += 12;
                forcalc.setFullYear(forcalc.getFullYear() - 1);
            }
            forcalc.setMonth(month1);
            var a = forcalc.getFullYear();
            var d1m1 = new Date(a, month1 - 1, 1);
            var laster1 = new Date(a, month1, 0);
            laster1.setHours(23, 59, 59, 0)
            if (month1 <= 0) {
                month1 += 12;
                a = a - 1
            } laster1.setHours(23, 59, 59, 0)

            var month2 = forcalc.getMonth() - 1;
            if (month2 <= 0) {
                month2 += 12;
                forcalc.setFullYear(forcalc.getFullYear() - 1);
            }
            forcalc.setMonth(month2);
            var b = forcalc.getFullYear();
            var d1m2 = new Date(b, month2 - 1, 1);
            var laster2 = new Date(b, month2, 0);
            laster2.setHours(23, 59, 59, 0);
            if (month2 <= 0) {
                month2 += 12;
                b = b - 1
            }

            var month3 = forcalc.getMonth() - 1;
            if (month3 <= 0) {
                month3 += 12;
                forcalc.setFullYear(forcalc.getFullYear() - 1);
            }
            forcalc.setMonth(month3);
            var c = forcalc.getFullYear();
            var d1m3 = new Date(c, month3 - 1, 1);
            var laster3 = new Date(c, month3, 0);
            laster3.setHours(23, 59, 59, 0)
            if (month3 <= 0) {
                month3 += 12;
                c = c - 1
            }

            var month4 = forcalc.getMonth() - 1;
            if (month4 <= 0) {
                month4 += 12;
                forcalc.setFullYear(forcalc.getFullYear() - 1);
            }
            forcalc.setMonth(month4);
            var d = forcalc.getFullYear();
            var d1m4 = new Date(d, month4 - 1, 1);
            var laster4 = new Date(d, month4, 0);
            laster4.setHours(23, 59, 59, 0)
            if (month4 <= 0) {
                month4 += 12;
                d = d - 1
            }

            var month5 = forcalc.getMonth() - 1;
            if (month5 <= 0) {
                month5 += 12;
                forcalc.setFullYear(forcalc.getFullYear() - 1);
            }
            forcalc.setMonth(month5);
            var e = forcalc.getFullYear();
            var d1m5 = new Date(e, month5 - 1, 1);
            var laster5 = new Date(e, month5, 0);
            laster5.setHours(23, 59, 59, 0)
            if (month5 <= 0) {
                month5 += 12;
                e = e - 1
            }

            var todaydate = new Date();
            var sum1 = 0;
            var sum2 = 0;
            var sum3 = 0;
            var sum4 = 0;
            var sum5 = 0;
            var sum6 = 0;
            var TotalapproveInvoiceAmount; var Totalpendinginvoices;

            var countser2 = await this.SupplierInvoice.aggregate([{
                $facet: {
                    "sumone": [
                        { $match: { $and: [{ VendorId: currentUser.organizationId }, { PaymentDate: { $gte: this1, $lte: todaydate } }, { Status: "Hospital Approved" }] }, },
                        { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } }
                    ],
                    "sumtwo": [
                        { $match: { $and: [{ VendorId: currentUser.organizationId }, { PaymentDate: { $gte: d1m1, $lte: laster1 } }, { Status: "Hospital Approved" }] }, },
                        { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } }
                    ],
                    "sumthree": [
                        { $match: { $and: [{ VendorId: currentUser.organizationId }, { PaymentDate: { $gte: d1m2, $lte: laster2 } }, { Status: "Hospital Approved" }] }, },
                        { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } }
                    ],
                    "sumfour": [
                        { $match: { $and: [{ VendorId: currentUser.organizationId }, { PaymentDate: { $gte: d1m3, $lte: laster3 } }, { Status: "Hospital Approved" }] }, },
                        { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } }
                    ],
                    "sumfive": [
                        { $match: { $and: [{ VendorId: currentUser.organizationId }, { PaymentDate: { $gte: d1m4, $lte: laster4 } }, { Status: "Hospital Approved" }] }, },
                        { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } }
                    ],
                    "sumsix": [
                        { $match: { $and: [{ VendorId: currentUser.organizationId }, { PaymentDate: { $gte: d1m5, $lte: laster5 } }, { Status: "Hospital Approved" }] }, },
                        { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } }
                    ]
                }
            }])
            if (countser2[0].sumone[0] != undefined) { sum1 = countser2[0].sumone[0].total; } else { sum1 = 0; }
            if (countser2[0].sumtwo[0] != undefined) { sum2 = countser2[0].sumtwo[0].total; } else { sum2 = 0; }
            if (countser2[0].sumthree[0] != undefined) { sum3 = countser2[0].sumthree[0].total; } else { sum3 = 0; }
            if (countser2[0].sumfour[0] != undefined) { sum4 = countser2[0].sumfour[0].total; } else { sum4 = 0; }
            if (countser2[0].sumfive[0] != undefined) { sum5 = countser2[0].sumfive[0].total; } else { sum5 = 0; }
            if (countser2[0].sumsix[0] != undefined) { sum6 = countser2[0].sumsix[0].total; } else { sum6 = 0; }

            var countone = await this.SupplierInvoice.aggregate([{
                $facet: {
                    "sumone": [
                        { $match: { $and: [{ VendorId: currentUser.organizationId }, { InvoiceDate: { $gte: d1m5, $lte: todaydate } }, { Status: "HApproved" }] } },
                        { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } }
                    ],
                    "sumtwo": [{ $match: { $and: [{ VendorId: currentUser.organizationId }, { InvoiceDate: { $gte: d1m5, $lte: todaydate } }, { Status: "HApproved" }] } }, { $count: "total" }],

                }
            }])
            return {
                data: {
                    success: true,
                    message: [[sum1, thismonth, t], [sum2, month1, a], [sum3, month2, b], [sum4, month3, c],
                    [sum5, month4, d], [sum6, month5, e]],
                }
            }
        } catch (e) {
            this.logger.error(e);
            throw e;
        }
    }
    //get Invoice to Vendor
    public async getInvoicesToVendor(IFilterDTO: IFilterDTO, currentUser: IUser): Promise<{ data: any }> {
        try {
            //pagination
            var pageNumber = 1;
            var pageSize = 0;
            if (IFilterDTO.pageNumber) {
                var pageNumber = parseInt(IFilterDTO.pageNumber.toString());
            }
            if (IFilterDTO.pageSize) {
                var pageSize = parseInt(IFilterDTO.pageSize.toString());
            }
            //filters
            var searchFilters = [];
            // searchFilters.push({ isDeleted: false });
            // searchFilters.push({ VendorId: currentUser._id });
            if (currentUser.accessControl == 0) {
                searchFilters.push({ uploadedBy: currentUser._id });
            }
            else if (currentUser.accessControl == 1) {
                searchFilters.push({ VendorId: currentUser.organizationId });
            }
            else {
                searchFilters.push({ $or: [{ VendorId: currentUser._id }, { VendorId: currentUser.organizationId }] });
            }

            if (IFilterDTO.Status != undefined) {
                searchFilters.push({ Status: IFilterDTO.Status });
            }
            if (IFilterDTO.searchTerm != undefined) {
                searchFilters.push({
                    $or: [
                        { hospitalName: { $regex: IFilterDTO.searchTerm, $options: 'i' } },
                        { vendorName: { $regex: IFilterDTO.searchTerm, $options: 'i' } },
                        {
                            "$expr": {
                                "$regexMatch": {
                                    "input": { "$toString": "$LoanID" },
                                    "regex": IFilterDTO.searchTerm
                                }
                            }
                        }
                    ]
                })
            }
            var totalAmount = 0;
            var totalCount = 0;
            var userCount = await this.SupplierInvoice.find({ $and: searchFilters }).countDocuments();
            var numberOfPages = pageSize === 0 ? 1 : Math.ceil(userCount / pageSize);
            var invoice = await this.SupplierInvoice.aggregate([{
                $facet: {
                    totalAmount: [{ $match: { $and: searchFilters } }, { $group: { _id: '$_v', total: { $sum: '$LTVAmount' } } }],
                    totalCount: [{ $match: { $and: searchFilters } }, { $count: 'total' }]
                }
            }
            ]);
            if (invoice[0].totalAmount[0] != undefined) {
                totalAmount = invoice[0].totalAmount[0].total
            }
            if (invoice[0].totalCount[0] != undefined) {
                totalCount = invoice[0].totalCount[0].total
            }

            var invoices = await this.SupplierInvoice
                .find({ $and: searchFilters })
                .sort({ updatedAt: -1 })
                .skip((pageNumber - 1) * pageSize)
                .limit(pageSize);
            var data = { invoices, numberOfPages, totalAmount, totalCount };
            return { data };
        } catch (e) {
            this.logger.error(e);
            throw e;
        }
    }
    public async getInvoiceByIdToVendor(IFilterDTO: IFilterDTO): Promise<{ data: any }> {
        try {
            const Id = IFilterDTO._id;
            const invoices = await this.SupplierInvoice.findOne({ _id: Id });
            var repaymentData;
            if (invoices) {
                repaymentData = await this.TransactionData.find({ invoiceId: invoices._id })
            }
            return { data: { success: true, message: invoices, repaymentData } };
        } catch (e) {
            this.logger.error(e);
            throw e;
        }
    }
    //edit vendor profile
    public async getVendorProfileToVendor(currentUser: IUser): Promise<{ data: any }> {
        try {
            const Vendor = await this.UserModel.findOne({ _id: currentUser._id });
            return { data: { success: true, message: Vendor } };
        } catch (e) {
            this.logger.error(e);
            throw e;
        }
    }
    public async EditVendorProfileByVendor(currentUser: IUser, IVendorDTO: IVendorDTO): Promise<{ data: any }> {
        try {
            let { name, address, mobileNumber, GSTNumber, PANNumber, email, VendorType,
                bankName, AccountNumber, IFSCcode, authorisedPersonName, contactDetailsForAuthPerson,
                PANNumberForAuthPerson, relationShip, RateOfDeduction, NoOfDaysCreditPeriod, HospitalName, HospitalId,
                KycDocument, Other, ParriPassu, LastTwoYrBank, LastAudFin, LastTwoFin, RegCert, GstCert, AddrProof, companyType, authorizedPerson
            } = IVendorDTO

            let data: any = {};
            if (name) { data.name = name }
            if (VendorType) { data.VendorType = VendorType }
            if (address) { data.address = address }
            if (mobileNumber) { data.mobileNumber = mobileNumber }
            if (email) { data.email = email }
            if (GSTNumber) { data.GSTNumber = GSTNumber }
            if (PANNumber) { data.PANNumber = PANNumber }
            if (bankName) { data.bankName = bankName }
            if (AccountNumber) { data.AccountNumber = AccountNumber }
            if (IFSCcode) { data.IFSCcode = IFSCcode }
            if (authorisedPersonName) { data.authorisedPersonName = authorisedPersonName }
            if (contactDetailsForAuthPerson) { data.contactDetailsForAuthPerson = contactDetailsForAuthPerson }
            if (PANNumberForAuthPerson) { data.PANNumberForAuthPerson = PANNumberForAuthPerson }
            if (relationShip) { data.relationShip = relationShip }
            if (RateOfDeduction) { data.RateOfDeduction = RateOfDeduction }
            if (NoOfDaysCreditPeriod) { data.NoOfDaysCreditPeriod = NoOfDaysCreditPeriod }
            if (HospitalName) { data.HospitalName = HospitalName }
            if (HospitalId) { data.HospitalId = HospitalId }
            if (KycDocument) { data.KycDocument = KycDocument }
            if (Other) { data.Other = Other }
            if (ParriPassu) { data.ParriPassu = ParriPassu }
            if (LastTwoYrBank) { data.LastTwoYrBank = LastTwoYrBank }
            if (LastAudFin) { data.LastAudFin = LastAudFin }
            if (LastTwoFin) { data.LastTwoFin = LastTwoFin }
            if (RegCert) { data.RegCert = RegCert }
            if (GstCert) { data.GstCert = GstCert }
            if (AddrProof) { data.AddrProof = AddrProof }
            if (companyType) { data.companyType = companyType }
            if (authorizedPerson) { data.authorizedPerson = authorizedPerson }

            if (PANNumber) {
                var users = await this.UserModel.find({ PANNumber: PANNumber });
                for (var doc of users) {
                    if (doc._id === currentUser._id) {
                        return {
                            data: {
                                message: " PAN Number already exist",
                            }
                        };
                    }
                }
            }
            if (AccountNumber) {
                var users = await this.UserModel.find({ AccountNumber: AccountNumber });
                for (var doc of users) {
                    if (doc._id !== currentUser._id) {
                        return {
                            data: {
                                message: " Account Number already exist",
                            }
                        };
                    }
                }
            }
            const editValidator = await this.UserModel.updateOne({ _id: currentUser._id }, { $set: data }, { useFindAndModify: false })
            return { data: { success: true, message: "Vendor Edited Successfully" } }
        } catch (e) {
            this.logger.error(e);
            throw e;
        }
    }
    //upload invoice
    public async invoiceUploadToVendorWithDetails(currentUser: IUser, ISupplierInvoiceDTO: ISupplierInvoiceDTO): Promise<{ data: any }> {
        try {
            var { InvoiceDate } = ISupplierInvoiceDTO;
            const { NameOfVendor, InvoiceAmount, InvoiceNumber, venderDocURL, DescriptionArr, HospitalId } = ISupplierInvoiceDTO;

            const invoicenumber = await this.SupplierInvoice.findOne({
                $and: [{ VendorId: currentUser._id }, { InvoiceNumber: InvoiceNumber },
                { $nor: [{ Status: "Lender Rejected" }, { Status: "Hospital Rejected" }, { Status: "DSPL Rejected" }] }]
            });
            if (invoicenumber) {
                return {
                    data: {
                        success: false,
                        message: 'InvoiceNumber already exist'
                    }
                }
            }

            var vendorDetails = await this.organizationModel.findOne({ _id: currentUser.organizationId })

            var hospitalDetails = await this.organizationModel.findOne({ _id: HospitalId })
            if (!hospitalDetails.LenderId) {
                return {
                    data: {
                        success: false,
                        message: "Lender not associated with Hospital"
                    }
                }
            }
            var associationDetails = await this.HVAssociationModel.findOne({ $and: [{ hospitalId: HospitalId }, { vendorId: currentUser.organizationId }] })
            if (!associationDetails) {
                return {
                    data: {
                        success: false,
                        message: "Association not Found"
                    }
                }
            }

            if (associationDetails.Repayment != undefined || associationDetails.UtilizedAmount != undefined) {
                var AvailableLimit = associationDetails.creditLimit - associationDetails.UtilizedAmount + associationDetails.Repayment;
            } else {
                AvailableLimit = associationDetails.AvailableLimit;
            }
            if (!associationDetails.AvailableLimit) {
                return {
                    data: {
                        success: false,
                        message: "Limit not assigned by Hospital"
                    }
                }
            }
            if (InvoiceAmount >= AvailableLimit) {
                return {
                    data: {
                        success: false,
                        message: "You don't have sufficience Balance"
                    }
                }
            }
            const LTV = hospitalDetails.LenderLTV;
            const RateOfDeduction = hospitalDetails.LenderROI;
            const NoOfDaysCreditPeriod = hospitalDetails.LenderTenure;

            const SanctionLimit = associationDetails.AvailableLimit;

            const UtilizedAmount = associationDetails.UtilizedAmount ? associationDetails.UtilizedAmount : 0;
            const Repayment = associationDetails.Repayment ? associationDetails.Repayment : 0;

            var LTVAmount = Math.round((InvoiceAmount * LTV) / 100);

            const upfrontInterest = Math.round((LTVAmount * RateOfDeduction * NoOfDaysCreditPeriod) / (30 * 100));
            const amountToBeDisbursed = (LTVAmount - upfrontInterest)

            var date1 = new Date(InvoiceDate);
            var finalDate1 = new Date(date1.setDate(date1.getDate()));
            InvoiceDate = new Date(finalDate1);

            var date = new Date(InvoiceDate);
            var y = date.setDate(date.getDate() + NoOfDaysCreditPeriod);

            var hDueDate = new Date(y)

            const usrObj = {
                InvoiceAmount,
                NameOfVendor,
                LTV,
                venderDocURL,
                NoOfDaysCreditPeriod,
                hDueDate,
                upfrontInterest,
                RateOfDeduction,
                LTVAmount,
                InvoiceNumber,
                amountToBeDisbursed,
                DescriptionArr,
                Status: "Pending",
                InvoiceDate,
                HospitalId: HospitalId,
                uploadedBy: currentUser._id,
                VendorId: currentUser.organizationId,
                LenderId: hospitalDetails.LenderId,
                vendorName: vendorDetails.nameOfOrganization,
                hospitalName: hospitalDetails.nameOfOrganization
            }
            const newData = new this.SupplierInvoice(usrObj);
            const Invoicedata = await newData.save();
            var supplierLoanId = await this.SupplierInvoice.findOne({ InvoiceNumber: InvoiceNumber })
            this.nodeMailerService.sendemailForNewInvoice(supplierLoanId.LoanID);
            return {
                data: {
                    success: true,
                    UtilizedAmount: UtilizedAmount,
                    Repayment: Repayment,
                    SanctionLimit: SanctionLimit,
                    data: Invoicedata
                }
            };
        } catch (e) {
            this.logger.error(e);
            throw e;
        }
    }
    public async getAllHospitalToVendor(req: Request): Promise<{ data: any }> {
        try {
            var invoices = await this.HVAssociationModel.find({ vendorId: req.currentUser.organizationId });
            if (invoices) {
                var AggregatorInvoices = invoices.length;
            }
            var data = ({ count: AggregatorInvoices, message: invoices })
            return { data };
        } catch (e) {
            this.logger.error(e);
            throw e;
        }
    }
}
