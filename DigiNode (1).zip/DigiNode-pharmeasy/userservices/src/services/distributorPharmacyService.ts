import { Service, Inject } from 'typedi';
import { Request, Response } from 'express';
import { IUser, IFilterDTO, IHospitalSupplierDTO,purchaseFinancingDTO} from '@/interfaces/IUser';
import { Types } from 'mongoose';
import MailJetService from '../loaders/mailjet';
import nodeMailerService from '../loaders/nodemailer';
@Service()
export default class distributorPharmacyService {
  constructor(
    // @Inject('PharmacyModel') private PharmacyModel: Models.SupplierInvoiceModel,
    @Inject('DPAssociationModel') private DPAssociationModel: Models.DPAssociationModel,
    @Inject('PharmacyModel') private PharmacyModel: Models.PharmacyModel,
    @Inject('userModel') private userModel: Models.UserModel,
    @Inject('organizationModel') private organizationModel: Models.organizationModel,
    @Inject('TransactionDataModel') private TransactionData: Models.TransactionDataModel,
    private mailjet: MailJetService,
    private nodeMailerService: nodeMailerService,
    @Inject('logger') private logger,
  ) { }

  //Hospital DashBoard
  public async getDashboardForDistributor(currentUser: any): Promise<{ data: any }> {
    try {
      const userDetails = currentUser;
      var TotalSanctionLimit;
      var TotalAvailableLimit;
      var TotalUtilizedLimit;
      var TotalRepaymentsLimit;
      var AllVendor;

      var TotalinvoicesCount = 0;
      var TotalInvoicesAmount = 0;
      var TotalfundedCount = 0;
      var TotalfundedPaidAmount = 0;
      var TotalPendingCount = 0;
      var TotalPendingAmount = 0;
      var TotalrejctedCount = 0;
      var TotalRejctedAmount = 0;
      var TotalPendingInvoiceAmount = 0;

      var associationDetails = await this.DPAssociationModel.aggregate([{
        $facet: {
          "AllVendor": [
            { $match: { hospitalId: currentUser._id } }, { $count: 'total' }
          ],
          "TotalSanctionLimit": [
            { $match: { hospitalId: currentUser._id } },
            { $group: { _id: "_v", total: { $sum: "$creditLimit" } } }
          ],
          "TotalAvailableLimit": [
            { $match: { hospitalId: currentUser._id } },
            { $group: { _id: "_v", total: { $sum: "$AvailableLimit" } } }
          ],
          "TotalUtilizedLimit": [
            { $match: { hospitalId: currentUser._id } },
            { $group: { _id: "_v", total: { $sum: "$UtilizedAmount" } } }
          ],
          "TotalRepaymentsLimit": [
            { $match: { hospitalId: currentUser._id } },
            { $group: { _id: "_v", total: { $sum: "$Repayment" } } }
          ]
        }
      }]);
      if (associationDetails[0].TotalSanctionLimit[0] != undefined) { TotalSanctionLimit = associationDetails[0].TotalSanctionLimit[0].total; } else { TotalSanctionLimit = 0; }
      if (associationDetails[0].TotalAvailableLimit[0] != undefined) { TotalAvailableLimit = associationDetails[0].TotalAvailableLimit[0].total; } else { TotalAvailableLimit = 0; }
      if (associationDetails[0].TotalUtilizedLimit[0] != undefined) { TotalUtilizedLimit = associationDetails[0].TotalUtilizedLimit[0].total; } else { TotalUtilizedLimit = 0; }
      if (associationDetails[0].TotalRepaymentsLimit[0] != undefined) { TotalRepaymentsLimit = associationDetails[0].TotalRepaymentsLimit[0].total; } else { TotalRepaymentsLimit = 0; }
      if (associationDetails[0].AllVendor[0] != undefined) { AllVendor = associationDetails[0].AllVendor[0].total; } else { AllVendor = 0; }


      const everyDatas = await this.PharmacyModel.aggregate([
        {
          $facet: {
            invoicedataSum: [
              {
                $match: {
                  $and: [
                    { HospitalId: userDetails.organizationId },
                  ],
                },
              },
              {
                $group: { _id: "$_v", total: { $sum: "$LTVAmount" } },
              },
            ],
            invoicedataCount: [
              {
                $match: {
                  $and: [
                    { HospitalId: userDetails.organizationId },
                  ],
                },
              },
              { $count: "total" },
            ],
            penddataSum: [
              {
                $match: {
                  $and: [
                    { HospitalId: userDetails.organizationId },
                    {
                      $or: [
                        { Status: "Disbursed" },
                        { Status: "Fully Repaid" },
                        { Status: "Hospital Repaid" },
                        { Status: "Partially Repaid" }
                      ],
                    },
                  ],
                },
              },
              {
                $group: { _id: "$_v", total: { $sum: "$LTVAmount" } },
              },
            ],
            penddataCount: [
              {
                $match: {
                  $and: [
                    { HospitalId: userDetails.organizationId },
                    {
                      $or: [
                        { Status: "Disbursed" },
                        { Status: "Fully Repaid" },
                        { Status: "Hospital Repaid" },
                        { Status: "Partially Repaid" }
                      ],
                    },
                  ],
                },
              },
              { $count: "total" },
            ],
            RjectdataSum: [
              {
                $match: {
                  $and: [
                    { HospitalId: userDetails.organizationId },
                    {
                      $or: [
                        { Status: "Pending" },
                        { Status: "Hospital Approved" },
                        { Status: "Lender Approved" },
                        { Status: "DSPL Approved" }
                      ],
                    },
                  ],
                },
              },
              {
                $group: { _id: "$_v", total: { $sum: "$LTVAmount" } },
              },
            ],
            RjectdataCount: [
              {
                $match: {
                  $and: [
                    { HospitalId: userDetails.organizationId },
                    {
                      $or: [
                        { Status: "Pending" },
                        { Status: "Hospital Approved" },
                        { Status: "Lender Approved" },
                        { Status: "DSPL Approved" }
                      ],
                    },
                  ],
                },
              },
              { $count: "total" },
            ],
            allInvoicesSum: [
              {
                $match: {
                  $and: [
                    { HospitalId: userDetails.organizationId },
                    {
                      $or: [
                        { Status: "Hospital Rejected" },
                        { Status: "Lender Rejected" },
                        { Status: "DSPL Rejected" }
                      ],
                    },
                  ],
                },
              },
              {
                $group: { _id: "$_v", total: { $sum: "$LTVAmount" } },
              },
            ],
            allInvoicesCount: [
              {
                $match: {
                  $and: [
                    { HospitalId: userDetails.organizationId },
                    {
                      $or: [
                        { Status: "Hospital Rejected" },
                        { Status: "Lender Rejected" },
                        { Status: "DSPL Rejected" }
                      ],
                    },
                  ],
                },
              },
              { $count: "total" },
            ],
          },
        },
      ]);

      if (everyDatas[0].invoicedataSum[0] != undefined) {
        TotalInvoicesAmount += everyDatas[0].invoicedataSum[0].total;
      } else {
        TotalInvoicesAmount += 0;
      }
      if (everyDatas[0].invoicedataCount[0] != undefined) {
        TotalinvoicesCount += everyDatas[0].invoicedataCount[0].total;
      } else {
        TotalinvoicesCount += 0;
      }
      if (everyDatas[0].penddataSum[0] != undefined) {
        TotalfundedPaidAmount += everyDatas[0].penddataSum[0].total;
      } else {
        TotalfundedPaidAmount += 0;
      }
      if (everyDatas[0].penddataCount[0] != undefined) {
        TotalfundedCount += everyDatas[0].penddataCount[0].total;
      } else {
        TotalfundedCount += 0;
      }
      if (everyDatas[0].RjectdataSum[0] != undefined) {
        TotalPendingAmount += everyDatas[0].RjectdataSum[0].total;
      } else {
        TotalPendingAmount += 0;
      }
      if (everyDatas[0].RjectdataCount[0] != undefined) {
        TotalPendingCount += everyDatas[0].RjectdataCount[0].total;
      } else {
        TotalPendingCount += 0;
      }
      if (everyDatas[0].allInvoicesSum[0] != undefined) {
        TotalRejctedAmount += everyDatas[0].allInvoicesSum[0].total;
      } else {
        TotalRejctedAmount += 0;
      }
      if (everyDatas[0].allInvoicesCount[0] != undefined) {
        TotalrejctedCount += everyDatas[0].allInvoicesCount[0].total;
      } else {
        TotalrejctedCount += 0;
      }
      return {
        data: {
          success: true,
          TotalVendor: AllVendor,
          TotalUtilizedLimit: TotalUtilizedLimit,
          TotalRepaymentsLimit: TotalRepaymentsLimit,
          TotalSanctionLimit: TotalSanctionLimit,
          TotalAvailableLimit: TotalAvailableLimit,
          TotalinvoicesCount: TotalinvoicesCount,
          TotalInvoicesAmount: TotalInvoicesAmount,
          TotalPendingCount: TotalPendingCount,
          TotalPendingAmount: TotalPendingAmount,
          TotalfundedCount: TotalfundedCount,
          TotalfundedPaidAmount: TotalfundedPaidAmount,
          TotalrejctedCount: TotalrejctedCount,
          TotalRejctedAmount: TotalRejctedAmount,
        }
      }


    } catch (error) {
      console.log('error:', error);
      return { data: { success: false, error: error } };
    }
  }
  public async getDashboardData(req: Request, res: Response, currentUser: IUser): Promise<{ data: any }> {
    try {
      var searchFilters = [];
      searchFilters.push({ isDeleted: false });
      searchFilters.push({ HospitalId: currentUser._id });

      if (req.query.dateFrom != undefined || null && req.query.dateTo != undefined || null) {
        searchFilters.push({ createdAt: { $gte: req.query.dateFrom, $lte: req.query.dateTo } });
      }
      var dashboardData = await this.PharmacyModel.aggregate([
        {
          $facet: {
            totalCount: [{ $match: { $and: searchFilters } }, { $count: 'total' }],
            totalAmount: [
              { $match: { $and: searchFilters } },
              { $group: { _id: '$_v', total: { $sum: '$LTVAmount' } } },
            ],

            totalInProcessCount: [{
              $match: {
                $and: [{ $and: searchFilters }, {
                  $or: [
                    { Status: "Pending" },
                    { Status: "Hospital Approved" },
                    { Status: "Lender Approved" },
                    { Status: "DSPL Approved" }
                  ],
                },],
              },
            },
            { $count: 'total' },
            ],

            totalInProcessAmount: [{
              $match: {
                $and: [{ $and: searchFilters }, {
                  $or: [
                    { Status: "Pending" },
                    { Status: "Hospital Approved" },
                    { Status: "Lender Approved" },
                    { Status: "DSPL Approved" }
                  ],
                },],
              },
            },
            { $group: { _id: '$_v', total: { $sum: '$LTVAmount' } } },
            ],

            totalFundedCount: [{
              $match: {
                $and: [{ $and: searchFilters }, {
                  $or: [
                    { Status: "Disbursed" },
                    { Status: "Fully Repaid" },
                    { Status: "Hospital Repaid" },
                    { Status: "Partially Repaid" }
                  ],
                },],
              }
            }, { $count: 'total' }],

            totalFundedAmount: [{
              $match: {
                $and: [{ $and: searchFilters }, {
                  $or: [
                    { Status: "Disbursed" },
                    { Status: "Fully Repaid" },
                    { Status: "Hospital Repaid" },
                    { Status: "Partially Repaid" },
                  ],
                },],
              }
            },
            { $group: { _id: '$_v', total: { $sum: '$LTVAmount' } } },
            ],

            totalRepaidCount: [{ $match: { Status: 'Fully Repaid', $and: searchFilters } }, { $count: 'total' }],

            totalRepaidAmount: [
              { $match: { Status: 'Fully Repaid', $and: searchFilters } },
              { $group: { _id: '$_v', total: { $sum: '$LTVAmount' } } },
            ],

            totalRejectedCount: [{
              $match: {
                $and: [{ $and: searchFilters }, {
                  $or: [
                    { Status: "Hospital Rejected" },
                    { Status: "Lender Rejected" },
                    { Status: "DSPL Rejected" }
                  ],
                },],
              },
            }, { $count: 'total' }
            ],

            totalRejectedAmount: [{
              $match: {
                $and: [{ $and: searchFilters }, {
                  $or: [
                    { Status: "Hospital Rejected" },
                    { Status: "Lender Rejected" },
                    { Status: "DSPL Rejected" }
                  ],
                },],
              },
            },
            { $group: { _id: '$_v', total: { $sum: '$LTVAmount' } } },
            ]
          },
        },
      ]);

      var totalCount = 0;
      var totalAmount = 0;
      var totalInProcessCount = 0;
      var totalInProcessAmount = 0;
      var totalRejectedCount = 0;
      var totalRejectedAmount = 0;
      var totalFundedCount = 0;
      var totalFundedAmount = 0;
      var totalRepaidCount = 0;
      var totalRepaidAmount = 0;

      if (dashboardData[0].totalCount[0] != undefined) { totalCount = dashboardData[0].totalCount[0].total; } else { totalCount = 0; }
      if (dashboardData[0].totalAmount[0] != undefined) { totalAmount = dashboardData[0].totalAmount[0].total; } else { totalAmount = 0; }

      if (dashboardData[0].totalInProcessCount[0] != undefined) { totalInProcessCount = dashboardData[0].totalInProcessCount[0].total; } else { totalInProcessCount = 0; }
      if (dashboardData[0].totalInProcessAmount[0] != undefined) { totalInProcessAmount = dashboardData[0].totalInProcessAmount[0].total; } else { totalInProcessAmount = 0; }

      if (dashboardData[0].totalFundedCount[0] != undefined) { totalFundedCount = dashboardData[0].totalFundedCount[0].total; } else { totalFundedCount = 0; }
      if (dashboardData[0].totalFundedAmount[0] != undefined) { totalFundedAmount = dashboardData[0].totalFundedAmount[0].total; } else { totalFundedAmount = 0; }

      if (dashboardData[0].totalRepaidCount[0] != undefined) { totalRepaidCount = dashboardData[0].totalRepaidCount[0].total; } else { totalRepaidCount = 0; }
      if (dashboardData[0].totalRepaidAmount[0] != undefined) { totalRepaidAmount = dashboardData[0].totalRepaidAmount[0].total; } else { totalRepaidAmount = 0; }

      if (dashboardData[0].totalRejectedCount[0] != undefined) { totalRejectedCount = dashboardData[0].totalRejectedCount[0].total; } else { totalRejectedCount = 0; }
      if (dashboardData[0].totalRejectedAmount[0] != undefined) { totalRejectedAmount = dashboardData[0].totalRejectedAmount[0].total; } else { totalRejectedAmount = 0; }

      var data = {
        totalCount: totalCount,
        totalAmount: totalAmount,
        totalInProcessCount: totalInProcessCount,
        totalInProcessAmount: totalInProcessAmount,
        totalFundedCount: totalFundedCount,
        totalFundedAmount: totalFundedAmount,
        totalRepaidCount: totalRepaidCount,
        totalRepaidAmount: totalRepaidAmount,
        totalRejectedCount: totalRejectedCount,
        totalRejectedAmount: totalRejectedAmount
      }
      return { data };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  public async getInvoiceGraphToDistributor(currentUser: IUser): Promise<{ data: any }> {
    try {
      const userDetails = currentUser;
      var sum1 = 0;
      var sum2 = 0;
      var sum3 = 0;
      var sum4 = 0;
      var sum5 = 0;
      var sum6 = 0;
      var forcalc = new Date();
      var thismonth = forcalc.getMonth() + 1;
      var t = forcalc.getFullYear();
      var this1 = new Date(t, thismonth - 1, 1);

      var month1 = forcalc.getMonth();
      if (month1 < 0) {
        month1 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month1);
      var a = forcalc.getFullYear();
      var d1m1 = new Date(a, month1 - 1, 1);
      var laster1 = new Date(a, month1, 0);
      laster1.setHours(23, 59, 59, 0);
      if (month1 <= 0) {
        month1 += 12;
        a = a - 1
      }

      var month2 = forcalc.getMonth() - 1;
      if (month2 < 0) {
        month2 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month2);
      var b = forcalc.getFullYear();
      var d1m2 = new Date(b, month2 - 1, 1);
      var laster2 = new Date(b, month2, 0);
      laster2.setHours(23, 59, 59, 0);
      if (month2 <= 0) {
        month2 += 12;
        b = b - 1
      }

      var month3 = forcalc.getMonth() - 1;
      if (month3 < 0) {
        month3 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month3);
      var c = forcalc.getFullYear();
      var d1m3 = new Date(c, month3 - 1, 1);
      var laster3 = new Date(c, month3, 0);
      laster3.setHours(23, 59, 59, 0);
      if (month3 <= 0) {
        month3 += 12;
        c = c - 1
      }

      var month4 = forcalc.getMonth() - 1;
      if (month4 < 0) {
        month4 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month4);
      var d = forcalc.getFullYear();
      var d1m4 = new Date(d, month4 - 1, 1);
      var laster4 = new Date(d, month4, 0);
      laster4.setHours(23, 59, 59, 0);
      if (month4 <= 0) {
        month4 += 12;
        d = d - 1
      }

      var month5 = forcalc.getMonth() - 1;
      if (month5 < 0) {
        month5 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month5);
      var e = forcalc.getFullYear();
      var d1m5 = new Date(e, month5 - 1, 1);
      var laster5 = new Date(e, month5, 0);
      laster5.setHours(23, 59, 59, 0);

      if (month5 <= 0) {
        month5 += 12;
        e = e - 1
      }
      var todaydate = new Date();

      var countser2 = await this.PharmacyModel.aggregate([
        {
          $facet: {
            sumone: [
              {
                $match: {
                  $and: [
                    { InvoiceDate: { $gte: this1, $lte: todaydate } },
                    { HospitalId: userDetails.organizationId },
                  ],
                },
              },
              { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } },
            ],
            sumtwo: [
              {
                $match: {
                  $and: [
                    { InvoiceDate: { $gte: d1m1, $lte: laster1 } },
                    { HospitalId: userDetails.organizationId },
                  ],
                },
              },
              { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } },
            ],
            sumthree: [
              {
                $match: {
                  $and: [
                    { InvoiceDate: { $gte: d1m2, $lte: laster2 } },
                    { HospitalId: userDetails.organizationId },
                  ],
                },
              },
              { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } },
            ],
            sumfour: [
              {
                $match: {
                  $and: [
                    { InvoiceDate: { $gte: d1m3, $lte: laster3 } },
                    { HospitalId: userDetails.organizationId },
                  ],
                },
              },
              { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } },
            ],
            sumfive: [
              {
                $match: {
                  $and: [
                    { InvoiceDate: { $gte: d1m4, $lte: laster4 } },
                    { HospitalId: userDetails.organizationId },
                  ],
                },
              },
              { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } },
            ],
            sumsix: [
              {
                $match: {
                  $and: [
                    { InvoiceDate: { $gte: d1m5, $lte: laster5 } },
                    { HospitalId: userDetails.organizationId },
                  ],
                },
              },
              { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } },
            ],
          },
        },
      ]);

      if (countser2[0].sumone[0] != undefined) {
        sum1 = countser2[0].sumone[0].total;
      } else {
        sum1 = 0;
      }
      if (countser2[0].sumtwo[0] != undefined) {
        sum2 = countser2[0].sumtwo[0].total;
      } else {
        sum2 = 0;
      }
      if (countser2[0].sumthree[0] != undefined) {
        sum3 = countser2[0].sumthree[0].total;
      } else {
        sum3 = 0;
      }
      if (countser2[0].sumfour[0] != undefined) {
        sum4 = countser2[0].sumfour[0].total;
      } else {
        sum4 = 0;
      }
      if (countser2[0].sumfive[0] != undefined) {
        sum5 = countser2[0].sumfive[0].total;
      } else {
        sum5 = 0;
      }
      if (countser2[0].sumsix[0] != undefined) {
        sum6 = countser2[0].sumsix[0].total;
      } else {
        sum6 = 0;
      }

      return {
        data: {
          success: true,
          message: [
            [sum1, thismonth, t],
            [sum2, month1, a],
            [sum3, month2, b],
            [sum4, month3, c],
            [sum5, month4, d],
            [sum6, month5, e],
          ],
        }
      }
    } catch (error) {
      console.log('error:', error);
      return { data: { success: false, error: error } };
    }
  }
  public async getLApprovedVendorToDistributor(currentUser: IUser): Promise<{ data: any }> {
    try {
      const userDetails = currentUser;

      const Id = userDetails._id.toString();
      const invoices = await this.PharmacyModel.find({
        $and: [{ HospitalId: Id }, { Status: "Lender Approved" }],
      }).distinct("VendorId");
      var List;
      var Lists = [];
      if (invoices) {
        for (let i = 0; i < invoices.length; i++) {
          let id = invoices[i];
          List = await this.userModel.findOne({ _id: id });

          if (List) {
            Lists = Lists.concat(List);
          }
        }
      }
      if (Lists) {
        var data = Lists.length;
      }
      return {
        data:
          { success: true, count: data, message: Lists }
      };
    } catch (error) {
      console.log('error:', error);
      return { data: { success: false, error: error } };
    }
  }
  public async getFundedInvoiceGraphToDistributor(currentUser: IUser): Promise<{ data: any }> {
    try {
      const userDetails = currentUser;
      var sum1 = 0;
      var sum2 = 0;
      var sum3 = 0;
      var sum4 = 0;
      var sum5 = 0;
      var sum6 = 0;
      var forcalc = new Date();
      var thismonth = forcalc.getMonth() + 1;
      var t = forcalc.getFullYear();
      var this1 = new Date(t, thismonth - 1, 1);

      var month1 = forcalc.getMonth();
      if (month1 < 0) {
        month1 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month1);
      var a = forcalc.getFullYear();
      var d1m1 = new Date(a, month1 - 1, 1);
      var laster1 = new Date(a, month1, 0);
      laster1.setHours(23, 59, 59, 0);
      if (month1 <= 0) {
        month1 += 12;
        a = a - 1
      }

      var month2 = forcalc.getMonth() - 1;
      if (month2 < 0) {
        month2 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month2);
      var b = forcalc.getFullYear();
      var d1m2 = new Date(b, month2 - 1, 1);
      var laster2 = new Date(b, month2, 0);
      laster2.setHours(23, 59, 59, 0);
      if (month2 <= 0) {
        month2 += 12;
        b = b - 1
      }

      var month3 = forcalc.getMonth() - 1;
      if (month3 < 0) {
        month3 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month3);
      var c = forcalc.getFullYear();
      var d1m3 = new Date(c, month3 - 1, 1);
      var laster3 = new Date(c, month3, 0);
      laster3.setHours(23, 59, 59, 0);
      if (month3 <= 0) {
        month3 += 12;
        c = c - 1
      }

      var month4 = forcalc.getMonth() - 1;
      if (month4 < 0) {
        month4 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month4);
      var d = forcalc.getFullYear();
      var d1m4 = new Date(d, month4 - 1, 1);
      var laster4 = new Date(d, month4, 0);
      laster4.setHours(23, 59, 59, 0);
      if (month4 <= 0) {
        month4 += 12;
        d = d - 1
      }

      var month5 = forcalc.getMonth() - 1;
      if (month5 < 0) {
        month5 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month5);
      var e = forcalc.getFullYear();
      var d1m5 = new Date(e, month5 - 1, 1);
      var laster5 = new Date(e, month5, 0);
      laster5.setHours(23, 59, 59, 0);

      if (month5 <= 0) {
        month5 += 12;
        e = e - 1
      }
      var todaydate = new Date();

      var countser2 = await this.PharmacyModel.aggregate([
        {
          $facet: {
            sumone: [
              {
                $match: {
                  $and: [
                    { HospitalId: userDetails.organizationId },
                    { PaymentDate: { $gte: this1, $lte: todaydate } },
                    {
                      $or: [
                        { Status: "Disbursed" },
                        { Status: "Hospital Repaid" },
                        { Status: "Fully Repaid" },
                        { Status: "Partially Repaid" }
                      ],
                    },
                  ],
                },
              },
              { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } },
            ],
            sumtwo: [
              {
                $match: {
                  $and: [
                    { HospitalId: userDetails.organizationId },
                    { PaymentDate: { $gte: d1m1, $lte: laster1 } },
                    {
                      $or: [
                        { Status: "Disbursed" },
                        { Status: "Hospital Repaid" },
                        { Status: "Fully Repaid" },
                        { Status: "Partially Repaid" }
                      ],
                    },
                  ],
                },
              },
              { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } },
            ],
            sumthree: [
              {
                $match: {
                  $and: [
                    { HospitalId: userDetails.organizationId },
                    { PaymentDate: { $gte: d1m2, $lte: laster2 } },
                    {
                      $or: [
                        { Status: "Disbursed" },
                        { Status: "Hospital Repaid" },
                        { Status: "Fully Repaid" },
                        { Status: "Partially Repaid" }
                      ],
                    },
                  ],
                },
              },
              { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } },
            ],
            sumfour: [
              {
                $match: {
                  $and: [
                    { HospitalId: userDetails.organizationId },
                    { PaymentDate: { $gte: d1m3, $lte: laster3 } },
                    {
                      $or: [
                        { Status: "Disbursed" },
                        { Status: "Hospital Repaid" },
                        { Status: "Fully Repaid" },
                        { Status: "Partially Repaid" }
                      ],
                    },
                  ],
                },
              },
              { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } },
            ],
            sumfive: [
              {
                $match: {
                  $and: [
                    { HospitalId: userDetails.organizationId },
                    { PaymentDate: { $gte: d1m4, $lte: laster4 } },
                    {
                      $or: [
                        { Status: "Disbursed" },
                        { Status: "Hospital Repaid" },
                        { Status: "Fully Repaid" },
                        { Status: "Partially Repaid" }
                      ],
                    },
                  ],
                },
              },
              { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } },
            ],
            sumsix: [
              {
                $match: {
                  $and: [
                    { HospitalId: userDetails.organizationId },
                    { PaymentDate: { $gte: d1m5, $lte: laster5 } },
                    {
                      $or: [
                        { Status: "Disbursed" },
                        { Status: "Hospital Repaid" },
                        { Status: "Fully Repaid" },
                        { Status: "Partially Repaid" }
                      ],
                    },
                  ],
                },
              },
              { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } },
            ],
          },
        },
      ]);

      if (countser2[0].sumone[0] != undefined) {
        sum1 = countser2[0].sumone[0].total;
      } else {
        sum1 = 0;
      }
      if (countser2[0].sumtwo[0] != undefined) {
        sum2 = countser2[0].sumtwo[0].total;
      } else {
        sum2 = 0;
      }
      if (countser2[0].sumthree[0] != undefined) {
        sum3 = countser2[0].sumthree[0].total;
      } else {
        sum3 = 0;
      }
      if (countser2[0].sumfour[0] != undefined) {
        sum4 = countser2[0].sumfour[0].total;
      } else {
        sum4 = 0;
      }
      if (countser2[0].sumfive[0] != undefined) {
        sum5 = countser2[0].sumfive[0].total;
      } else {
        sum5 = 0;
      }
      if (countser2[0].sumsix[0] != undefined) {
        sum6 = countser2[0].sumsix[0].total;
      } else {
        sum6 = 0;
      }

      return {
        data: {
          success: true,
          message: [
            [sum1, thismonth, t],
            [sum2, month1, a],
            [sum3, month2, b],
            [sum4, month3, c],
            [sum5, month4, d],
            [sum6, month5, e],
          ]
        }
      };

    } catch (error) {
      console.log('error:', error);
      return { data: { success: false, error: error } };
    }
  }
  public async getPendingVendorToDistributor(currentUser: IUser): Promise<{ data: any }> {
    try {
      const userDetails = currentUser;
      const Id = userDetails._id;
      const invoices = await this.PharmacyModel.find({
        $and: [{ HospitalId: Id }, { Status: "Pending" }],
      }).distinct("VendorId");

      var List;
      var Lists = [];

      if (invoices) {
        for (let i = 0; i < invoices.length; i++) {
          let id = invoices[i];
          List = await this.userModel.findOne({ _id: id });

          if (List) {
            Lists = Lists.concat(List);
          }
        }
      }
      if (Lists) {
        var data = Lists.length;
      }
      return {
        data: { success: true, count: data, message: Lists }
      }

    } catch (error) {
      console.log('error:', error);
      return { data: { success: false, error: error } };
    }
  }
  public async getDistributorGraphOne(currentUser: IUser): Promise<{ data: any }> {
    try {
      const userDetails = currentUser;

      var sum1 = 0;
      var sum2 = 0;
      var sum3 = 0;
      var sum4 = 0;
      var sum5 = 0;
      var sum6 = 0;

      var InProcesssum1 = 0;
      var InProcesssum2 = 0;
      var InProcesssum3 = 0;
      var InProcesssum4 = 0;
      var InProcesssum5 = 0;
      var InProcesssum6 = 0;

      var Disbursedsum1 = 0;
      var Disbursedsum2 = 0;
      var Disbursedsum3 = 0;
      var Disbursedsum4 = 0;
      var Disbursedsum5 = 0;
      var Disbursedsum6 = 0;

      var Repaidsum1 = 0;
      var Repaidsum2 = 0;
      var Repaidsum3 = 0;
      var Repaidsum4 = 0;
      var Repaidsum5 = 0;
      var Repaidsum6 = 0;

      var Rejectedsum1 = 0;
      var Rejectedsum2 = 0;
      var Rejectedsum3 = 0;
      var Rejectedsum4 = 0;
      var Rejectedsum5 = 0;
      var Rejectedsum6 = 0;

      var forcalc = new Date();
      var thismonth = forcalc.getMonth() + 1;
      var t = forcalc.getFullYear();
      var this1 = new Date(t, thismonth - 1, 1);

      var month1 = forcalc.getMonth();
      if (month1 < 0) {
        month1 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month1);
      var a = forcalc.getFullYear();
      var d1m1 = new Date(a, month1 - 1, 1);
      var laster1 = new Date(a, month1, 0);
      laster1.setHours(23, 59, 59, 0);
      if (month1 <= 0) {
        month1 += 12;
        a = a - 1
      }

      var month2 = forcalc.getMonth() - 1;
      if (month2 < 0) {
        month2 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month2);
      var b = forcalc.getFullYear();
      var d1m2 = new Date(b, month2 - 1, 1);
      var laster2 = new Date(b, month2, 0);
      laster2.setHours(23, 59, 59, 0);
      if (month2 <= 0) {
        month2 += 12;
        b = b - 1
      }

      var month3 = forcalc.getMonth() - 1;
      if (month3 < 0) {
        month3 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month3);
      var c = forcalc.getFullYear();
      var d1m3 = new Date(c, month3 - 1, 1);
      var laster3 = new Date(c, month3, 0);
      laster3.setHours(23, 59, 59, 0);
      if (month3 <= 0) {
        month3 += 12;
        c = c - 1
      }

      var month4 = forcalc.getMonth() - 1;
      if (month4 < 0) {
        month4 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month4);
      var d = forcalc.getFullYear();
      var d1m4 = new Date(d, month4 - 1, 1);
      var laster4 = new Date(d, month4, 0);
      laster4.setHours(23, 59, 59, 0);
      if (month4 <= 0) {
        month4 += 12;
        d = d - 1
      }

      var month5 = forcalc.getMonth() - 1;
      if (month5 < 0) {
        month5 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month5);
      var e = forcalc.getFullYear();
      var d1m5 = new Date(e, month5 - 1, 1);
      var laster5 = new Date(e, month5, 0);
      laster5.setHours(23, 59, 59, 0);
      if (month5 <= 0) {
        month5 += 12;
        e = e - 1
      }
      var todaydate = new Date();

      var countone = await this.PharmacyModel.aggregate([
        {
          $facet: {
            sumone: [
              {
                $match: {
                  $and: [
                    { HospitalId: userDetails.organizationId },
                    { InvoiceDate: { $gte: this1, $lte: todaydate } },
                  ],
                },
              },
              { $count: "total" },
            ],
            sumtwo: [
              {
                $match: {
                  $and: [
                    { HospitalId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m1, $lte: laster1 } },
                  ],
                },
              },
              { $count: "total" },
            ],
            sumthree: [
              {
                $match: {
                  $and: [
                    { HospitalId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m2, $lte: laster2 } },
                  ],
                },
              },
              { $count: "total" },
            ],
            sumfour: [
              {
                $match: {
                  $and: [
                    { HospitalId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m3, $lte: laster3 } },
                  ],
                },
              },
              { $count: "total" },
            ],
            sumfive: [
              {
                $match: {
                  $and: [
                    { HospitalId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m4, $lte: laster4 } },
                  ],
                },
              },
              { $count: "total" },
            ],
            sumsix: [
              {
                $match: {
                  $and: [
                    { HospitalId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m5, $lte: laster5 } },
                  ],
                },
              },
              { $count: "total" },
            ],

            InProsumone: [
              {
                $match: {
                  $and: [
                    { HospitalId: userDetails.organizationId },
                    { InvoiceDate: { $gte: this1, $lte: todaydate } },
                    {
                      $or: [
                        { Status: "Pending" },
                        { Status: "Hospital Approved" },
                        { Status: "Lender Approved" },
                        { Status: "DSPL Approved" }
                      ],
                    },
                  ],
                },
              },
              { $count: "total" },
            ],
            InProsumtwo: [
              {
                $match: {
                  $and: [
                    { HospitalId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m1, $lte: laster1 } },
                    {
                      $or: [
                        { Status: "Pending" },
                        { Status: "Hospital Approved" },
                        { Status: "Lender Approved" },
                        { Status: "DSPL Approved" }
                      ],
                    },
                  ],
                },
              },
              { $count: "total" },
            ],
            InProsumthree: [
              {
                $match: {
                  $and: [
                    { HospitalId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m2, $lte: laster2 } },
                    {
                      $or: [
                        { Status: "Pending" },
                        { Status: "Hospital Approved" },
                        { Status: "Lender Approved" },
                        { Status: "DSPL Approved" }
                      ],
                    },
                  ],
                },
              },
              { $count: "total" },
            ],
            InProsumfour: [
              {
                $match: {
                  $and: [
                    { HospitalId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m3, $lte: laster3 } },
                    {
                      $or: [
                        { Status: "Pending" },
                        { Status: "Hospital Approved" },
                        { Status: "Lender Approved" },
                        { Status: "DSPL Approved" }
                      ],
                    },
                  ],
                },
              },
              { $count: "total" },
            ],
            InProsumfive: [
              {
                $match: {
                  $and: [
                    { HospitalId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m4, $lte: laster4 } },
                    {
                      $or: [
                        { Status: "Pending" },
                        { Status: "Hospital Approved" },
                        { Status: "Lender Approved" },
                        { Status: "DSPL Approved" }
                      ],
                    },
                  ],
                },
              },
              { $count: "total" },
            ],
            InProsumsix: [
              {
                $match: {
                  $and: [
                    { HospitalId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m5, $lte: laster5 } },
                    {
                      $or: [
                        { Status: "Pending" },
                        { Status: "Hospital Approved" },
                        { Status: "Lender Approved" },
                        { Status: "DSPL Approved" }
                      ],
                    },
                  ],
                },
              },
              { $count: "total" },
            ],

            Disbursedsumone: [
              {
                $match: {
                  $and: [
                    { HospitalId: userDetails.organizationId },
                    { InvoiceDate: { $gte: this1, $lte: todaydate } },
                    {
                      $or: [
                        { Status: "Disbursed" },
                        { Status: "Hospital Repaid" },
                        { Status: "Fully Repaid" },
                        { Status: "Partially Repaid" }
                      ],
                    },
                  ],
                },
              },
              { $count: "total" },
            ],
            Disbursedsumtwo: [
              {
                $match: {
                  $and: [
                    { HospitalId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m1, $lte: laster1 } },
                    {
                      $or: [
                        { Status: "Disbursed" },
                        { Status: "Hospital Repaid" },
                        { Status: "Fully Repaid" },
                        { Status: "Partially Repaid" }
                      ],
                    },
                  ],
                },
              },
              { $count: "total" },
            ],
            Disbursedsumthree: [
              {
                $match: {
                  $and: [
                    { HospitalId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m2, $lte: laster2 } },
                    {
                      $or: [
                        { Status: "Disbursed" },
                        { Status: "Hospital Repaid" },
                        { Status: "Fully Repaid" },
                        { Status: "Partially Repaid" }
                      ],
                    },
                  ],
                },
              },
              { $count: "total" },
            ],
            Disbursedsumfour: [
              {
                $match: {
                  $and: [
                    { HospitalId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m3, $lte: laster3 } },
                    {
                      $or: [
                        { Status: "Disbursed" },
                        { Status: "Hospital Repaid" },
                        { Status: "Fully Repaid" },
                        { Status: "Partially Repaid" }
                      ],
                    },
                  ],
                },
              },
              { $count: "total" },
            ],
            Disbursedsumfive: [
              {
                $match: {
                  $and: [
                    { HospitalId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m4, $lte: laster4 } },
                    {
                      $or: [
                        { Status: "Disbursed" },
                        { Status: "Hospital Repaid" },
                        { Status: "Fully Repaid" },
                        { Status: "Partially Repaid" }
                      ],
                    },
                  ],
                },
              },
              { $count: "total" },
            ],
            Disbursedsumsix: [
              {
                $match: {
                  $and: [
                    { HospitalId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m5, $lte: laster5 } },
                    {
                      $or: [
                        { Status: "Disbursed" },
                        { Status: "Hospital Repaid" },
                        { Status: "Fully Repaid" },
                        { Status: "Partially Repaid" }
                      ],
                    },
                  ],
                },
              },
              { $count: "total" },
            ],

            Repaidsumone: [
              {
                $match: {
                  $and: [
                    { HospitalId: userDetails.organizationId },
                    { InvoiceDate: { $gte: this1, $lte: todaydate } },
                    { Status: "Fully Repaid" },
                  ],
                },
              },
              { $count: "total" },
            ],
            Repaidsumtwo: [
              {
                $match: {
                  $and: [
                    { HospitalId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m1, $lte: laster1 } },
                    { Status: "Fully Repaid" },
                  ],
                },
              },
              { $count: "total" },
            ],
            Repaidsumthree: [
              {
                $match: {
                  $and: [
                    { HospitalId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m2, $lte: laster2 } },
                    { Status: "Fully Repaid" },
                  ],
                },
              },
              { $count: "total" },
            ],
            Repaidsumfour: [
              {
                $match: {
                  $and: [
                    { HospitalId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m3, $lte: laster3 } },
                    { Status: "Fully Repaid" },
                  ],
                },
              },
              { $count: "total" },
            ],
            Repaidsumfive: [
              {
                $match: {
                  $and: [
                    { HospitalId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m4, $lte: laster4 } },
                    { Status: "Fully Repaid" },
                  ],
                },
              },
              { $count: "total" },
            ],
            Repaidsumsix: [
              {
                $match: {
                  $and: [
                    { HospitalId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m5, $lte: laster5 } },
                    { Status: "Fully Repaid" },
                  ],
                },
              },
              { $count: "total" },
            ],

            Rejectedsumone: [
              {
                $match: {
                  $and: [
                    { HospitalId: userDetails.organizationId },
                    { InvoiceDate: { $gte: this1, $lte: todaydate } },
                    {
                      $or: [{ Status: "Hospital Rejected" }, { Status: "Lender Rejected" }, { Status: "DSPL Rejected" }],
                    },
                  ],
                },
              },
              { $count: "total" },
            ],
            Rejectedsumtwo: [
              {
                $match: {
                  $and: [
                    { HospitalId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m1, $lte: laster1 } },
                    {
                      $or: [{ Status: "Hospital Rejected" }, { Status: "Lender Rejected" }, { Status: "DSPL Rejected" }],
                    },
                  ],
                },
              },
              { $count: "total" },
            ],
            Rejectedsumthree: [
              {
                $match: {
                  $and: [
                    { HospitalId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m2, $lte: laster2 } },
                    {
                      $or: [{ Status: "Hospital Rejected" }, { Status: "Lender Rejected" }, { Status: "DSPL Rejected" }],
                    },
                  ],
                },
              },
              { $count: "total" },
            ],
            Rejectedsumfour: [
              {
                $match: {
                  $and: [
                    { HospitalId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m3, $lte: laster3 } },
                    {
                      $or: [{ Status: "Hospital Rejected" }, { Status: "Lender Rejected" }, { Status: "DSPL Rejected" }],
                    },
                  ],
                },
              },
              { $count: "total" },
            ],
            Rejectedsumfive: [
              {
                $match: {
                  $and: [
                    { HospitalId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m4, $lte: laster4 } },
                    {
                      $or: [{ Status: "Hospital Rejected" }, { Status: "Lender Rejected" }, { Status: "DSPL Rejected" }],
                    },
                  ],
                },
              },
              { $count: "total" },
            ],
            Rejectedsumsix: [
              {
                $match: {
                  $and: [
                    { HospitalId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m5, $lte: laster5 } },
                    {
                      $or: [{ Status: "Hospital Rejected" }, { Status: "Lender Rejected" }, { Status: "DSPL Rejected" }],
                    },
                  ],
                },
              },
              { $count: "total" },
            ],
          },
        },
      ]);

      if (countone[0].sumone[0] != undefined) {
        sum1 = countone[0].sumone[0].total;
      } else {
        sum1 = 0;
      }
      if (countone[0].sumtwo[0] != undefined) {
        sum2 = countone[0].sumtwo[0].total;
      } else {
        sum2 = 0;
      }
      if (countone[0].sumthree[0] != undefined) {
        sum3 = countone[0].sumthree[0].total;
      } else {
        sum3 = 0;
      }
      if (countone[0].sumfour[0] != undefined) {
        sum4 = countone[0].sumfour[0].total;
      } else {
        sum4 = 0;
      }
      if (countone[0].sumfive[0] != undefined) {
        sum5 = countone[0].sumfive[0].total;
      } else {
        sum5 = 0;
      }
      if (countone[0].sumsix[0] != undefined) {
        sum6 = countone[0].sumsix[0].total;
      } else {
        sum6 = 0;
      }

      if (countone[0].InProsumone[0] != undefined) {
        InProcesssum1 = countone[0].InProsumone[0].total;
      } else {
        InProcesssum1 = 0;
      }
      if (countone[0].InProsumtwo[0] != undefined) {
        InProcesssum2 = countone[0].InProsumtwo[0].total;
      } else {
        InProcesssum2 = 0;
      }
      if (countone[0].InProsumthree[0] != undefined) {
        InProcesssum3 = countone[0].InProsumthree[0].total;
      } else {
        InProcesssum3 = 0;
      }
      if (countone[0].InProsumfour[0] != undefined) {
        InProcesssum4 = countone[0].InProsumfour[0].total;
      } else {
        InProcesssum4 = 0;
      }
      if (countone[0].InProsumfive[0] != undefined) {
        InProcesssum5 = countone[0].InProsumfive[0].total;
      } else {
        InProcesssum5 = 0;
      }
      if (countone[0].InProsumsix[0] != undefined) {
        InProcesssum6 = countone[0].InProsumsix[0].total;
      } else {
        InProcesssum6 = 0;
      }

      if (countone[0].Disbursedsumone[0] != undefined) {
        Disbursedsum1 = countone[0].Disbursedsumone[0].total;
      } else {
        Disbursedsum1 = 0;
      }
      if (countone[0].Disbursedsumtwo[0] != undefined) {
        Disbursedsum2 = countone[0].Disbursedsumtwo[0].total;
      } else {
        Disbursedsum2 = 0;
      }
      if (countone[0].Disbursedsumthree[0] != undefined) {
        Disbursedsum3 = countone[0].Disbursedsumthree[0].total;
      } else {
        Disbursedsum3 = 0;
      }
      if (countone[0].Disbursedsumfour[0] != undefined) {
        Disbursedsum4 = countone[0].Disbursedsumfour[0].total;
      } else {
        Disbursedsum4 = 0;
      }
      if (countone[0].Disbursedsumfive[0] != undefined) {
        Disbursedsum5 = countone[0].Disbursedsumfive[0].total;
      } else {
        Disbursedsum5 = 0;
      }
      if (countone[0].Disbursedsumsix[0] != undefined) {
        Disbursedsum6 = countone[0].Disbursedsumsix[0].total;
      } else {
        Disbursedsum6 = 0;
      }

      if (countone[0].Repaidsumone[0] != undefined) {
        Repaidsum1 = countone[0].Repaidsumone[0].total;
      } else {
        Repaidsum1 = 0;
      }
      if (countone[0].Repaidsumtwo[0] != undefined) {
        Repaidsum2 = countone[0].Repaidsumtwo[0].total;
      } else {
        Repaidsum2 = 0;
      }
      if (countone[0].Repaidsumthree[0] != undefined) {
        Repaidsum3 = countone[0].Repaidsumthree[0].total;
      } else {
        Repaidsum3 = 0;
      }
      if (countone[0].Repaidsumfour[0] != undefined) {
        Repaidsum4 = countone[0].Repaidsumfour[0].total;
      } else {
        Repaidsum4 = 0;
      }
      if (countone[0].Repaidsumfive[0] != undefined) {
        Repaidsum5 = countone[0].Repaidsumfive[0].total;
      } else {
        Repaidsum5 = 0;
      }
      if (countone[0].Repaidsumsix[0] != undefined) {
        Repaidsum6 = countone[0].Repaidsumsix[0].total;
      } else {
        Repaidsum6 = 0;
      }

      if (countone[0].Rejectedsumone[0] != undefined) {
        Rejectedsum1 = countone[0].Rejectedsumone[0].total;
      } else {
        Rejectedsum1 = 0;
      }
      if (countone[0].Rejectedsumtwo[0] != undefined) {
        Rejectedsum2 = countone[0].Rejectedsumtwo[0].total;
      } else {
        Rejectedsum2 = 0;
      }
      if (countone[0].Rejectedsumthree[0] != undefined) {
        Rejectedsum3 = countone[0].Rejectedsumthree[0].total;
      } else {
        Rejectedsum3 = 0;
      }
      if (countone[0].Rejectedsumfour[0] != undefined) {
        Rejectedsum4 = countone[0].Rejectedsumfour[0].total;
      } else {
        Rejectedsum4 = 0;
      }
      if (countone[0].Rejectedsumfive[0] != undefined) {
        Rejectedsum5 = countone[0].Rejectedsumfive[0].total;
      } else {
        Rejectedsum5 = 0;
      }
      if (countone[0].Rejectedsumsix[0] != undefined) {
        Rejectedsum6 = countone[0].Rejectedsumsix[0].total;
      } else {
        Rejectedsum6 = 0;
      }

      return {
        data: {
          success: true,
          monthsAndYears: [
            [thismonth, t],
            [month1, a],
            [month2, b],
            [month3, c],
            [month4, d],
            [month5, e],
          ],
          All: [sum1, sum2, sum3, sum4, sum5, sum6],
          InProcess: [
            InProcesssum1,
            InProcesssum2,
            InProcesssum3,
            InProcesssum4,
            InProcesssum5,
            InProcesssum6,
          ],
          Disbursed: [
            Disbursedsum1,
            Disbursedsum2,
            Disbursedsum3,
            Disbursedsum4,
            Disbursedsum5,
            Disbursedsum6,
          ],
          Repaid: [
            Repaidsum1,
            Repaidsum2,
            Repaidsum3,
            Repaidsum4,
            Repaidsum5,
            Repaidsum6,
          ],
          Rejected: [
            Rejectedsum1,
            Rejectedsum2,
            Rejectedsum3,
            Rejectedsum4,
            Rejectedsum5,
            Rejectedsum6,
          ],
        }
      }
    } catch (error) {
      console.log('error:', error);
      return { data: { success: false, error: error } };
    }
  }
  public async getLastPieGraphForDistributors(currentUser: IUser): Promise<{ data: any }> {
    try {
      const userDetails = currentUser;

      var FundedSum = 0;

      var UnderPaidsum = 0;
      var OverPaidsum = 0;
      var FullPaidsum = 0;

      var forcalc = new Date();
      var thismonth = forcalc.getMonth() + 1;
      var t = forcalc.getFullYear();
      var this1 = new Date(t, thismonth - 1, 1);

      var month1 = forcalc.getMonth();
      if (month1 < 0) {
        month1 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month1);
      var a = forcalc.getFullYear();
      var d1m1 = new Date(a, month1 - 1, 1);
      var laster1 = new Date(a, month1, 0);
      laster1.setHours(23, 59, 59, 0);
      if (month1 <= 0) {
        month1 += 12;
        a = a - 1
      }

      var month2 = forcalc.getMonth() - 1;
      if (month2 < 0) {
        month2 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month2);
      var b = forcalc.getFullYear();
      var d1m2 = new Date(b, month2 - 1, 1);
      var laster2 = new Date(b, month2, 0);
      laster2.setHours(23, 59, 59, 0);
      if (month2 <= 0) {
        month2 += 12;
        b = b - 1
      }

      var month3 = forcalc.getMonth() - 1;
      if (month3 < 0) {
        month3 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month3);
      var c = forcalc.getFullYear();
      var d1m3 = new Date(c, month3 - 1, 1);
      var laster3 = new Date(c, month3, 0);
      laster3.setHours(23, 59, 59, 0);
      if (month3 <= 0) {
        month3 += 12;
        c = c - 1
      }

      var month4 = forcalc.getMonth() - 1;
      if (month4 < 0) {
        month4 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month4);
      var d = forcalc.getFullYear();
      var d1m4 = new Date(d, month4 - 1, 1);
      var laster4 = new Date(d, month4, 0);
      laster4.setHours(23, 59, 59, 0);
      if (month4 <= 0) {
        month4 += 12;
        d = d - 1
      }

      var month5 = forcalc.getMonth() - 1;
      if (month5 < 0) {
        month5 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month5);
      var e = forcalc.getFullYear();
      var d1m5 = new Date(e, month5 - 1, 1);
      var laster5 = new Date(e, month5, 0);
      laster5.setHours(23, 59, 59, 0);
      if (month5 <= 0) {
        month5 += 12;
        e = e - 1
      }
      var todaydate = new Date();

      var countone = await this.PharmacyModel.aggregate([
        {
          $facet: {
            sumone: [
              {
                $match: {
                  $and: [
                    { HospitalId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m5, $lte: todaydate } },
                    {
                      $or: [
                        { Status: "Disbursed" },
                        { Status: "Hospital Repaid" },
                        { Status: "Fully Repaid" },
                        { Status: "Partially Repaid" }
                      ],
                    },
                  ],
                },
              },
              { $count: "total" },
            ],
            sumtwo: [
              {
                $match: {
                  $and: [
                    { HospitalId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m5, $lte: todaydate } },
                    { Status: "Fully Repaid" },
                    { SettleStatus: "UnderPaid" },
                  ],
                },
              },
              { $count: "total" },
            ],
            sumthree: [
              {
                $match: {
                  $and: [
                    { HospitalId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m5, $lte: todaydate } },
                    { Status: "Fully Repaid" },
                    { SettleStatus: "FullPaid" },
                  ],
                },
              },
              { $count: "total" },
            ],
            sumfour: [
              {
                $match: {
                  $and: [
                    { HospitalId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m5, $lte: todaydate } },
                    { Status: "Fully Repaid" },
                    { SettleStatus: "OverPaid" },
                  ],
                },
              },
              { $count: "total" },
            ],
          },
        },
      ]);

      if (countone[0].sumone[0] != undefined) {
        FundedSum = countone[0].sumone[0].total;
      } else {
        FundedSum = 0;
      }
      if (countone[0].sumtwo[0] != undefined) {
        UnderPaidsum = countone[0].sumtwo[0].total;
      } else {
        UnderPaidsum = 0;
      }
      if (countone[0].sumthree[0] != undefined) {
        FullPaidsum = countone[0].sumthree[0].total;
      } else {
        FullPaidsum = 0;
      }
      if (countone[0].sumfour[0] != undefined) {
        OverPaidsum = countone[0].sumfour[0].total;
      } else {
        OverPaidsum = 0;
      }

      return {
        data: {
          success: true,
          TotalFunded: FundedSum,
          UnderPaid: UnderPaidsum,
          OverPaid: OverPaidsum,
          FullPaid: FullPaidsum,
        }
      }
    } catch (error) {
      console.log('error:', error);
      return { data: { success: false, error: error } };
    }
  }
  public async getSecondPieGraphForHospital(currentUser: IUser): Promise<{ data: any }> {
    try {
      const userDetails = currentUser;
      var forcalc = new Date();
      var thismonth = forcalc.getMonth() + 1;
      var t = forcalc.getFullYear();
      var this1 = new Date(t, thismonth - 1, 1);

      var month1 = forcalc.getMonth();
      if (month1 < 0) {
        month1 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month1);
      var a = forcalc.getFullYear();
      var d1m1 = new Date(a, month1 - 1, 1);
      var laster1 = new Date(a, month1, 0);
      laster1.setHours(23, 59, 59, 0);
      if (month1 <= 0) {
        month1 += 12;
        a = a - 1
      }

      var month2 = forcalc.getMonth() - 1;
      if (month2 < 0) {
        month2 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month2);
      var b = forcalc.getFullYear();
      var d1m2 = new Date(b, month2 - 1, 1);
      var laster2 = new Date(b, month2, 0);
      laster2.setHours(23, 59, 59, 0);
      if (month2 <= 0) {
        month2 += 12;
        b = b - 1
      }

      var month3 = forcalc.getMonth() - 1;
      if (month3 < 0) {
        month3 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month3);
      var c = forcalc.getFullYear();
      var d1m3 = new Date(c, month3 - 1, 1);
      var laster3 = new Date(c, month3, 0);
      laster3.setHours(23, 59, 59, 0);
      if (month3 <= 0) {
        month3 += 12;
        c = c - 1
      }

      var month4 = forcalc.getMonth() - 1;
      if (month4 < 0) {
        month4 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month4);
      var d = forcalc.getFullYear();
      var d1m4 = new Date(d, month4 - 1, 1);
      var laster4 = new Date(d, month4, 0);
      laster4.setHours(23, 59, 59, 0);
      if (month4 <= 0) {
        month4 += 12;
        d = d - 1
      }

      var month5 = forcalc.getMonth() - 1;
      if (month5 < 0) {
        month5 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month5);
      var e = forcalc.getFullYear();
      var d1m5 = new Date(e, month5 - 1, 1);
      var laster5 = new Date(e, month5, 0);
      laster5.setHours(23, 59, 59, 0);

      if (month5 <= 0) {
        month5 += 12;
        e = e - 1
      }
      var todaydate = new Date();

      var TotalSum;
      var Fundedsum;
      var countone = await this.PharmacyModel.aggregate([
        {
          $facet: {
            sumone: [
              {
                $match: {
                  $and: [
                    { HospitalId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m5, $lte: todaydate } },
                  ],
                },
              },
              { $count: "total" },
            ],
            sumtwo: [
              {
                $match: {
                  $and: [
                    { HospitalId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m5, $lte: todaydate } },
                    {
                      $or: [
                        { Status: "Disbursed" },
                        { Status: "Hospital Repaid" },
                        { Status: "Fully Repaid" },
                        { Status: "Partially Repaid" }
                      ],
                    },
                  ],
                },
              },
              { $count: "total" },
            ],
          },
        },
      ]);

      if (countone[0].sumone[0] != undefined) {
        TotalSum = countone[0].sumone[0].total;
      } else {
        TotalSum = 0;
      }
      if (countone[0].sumtwo[0] != undefined) {
        Fundedsum = countone[0].sumtwo[0].total;
      } else {
        Fundedsum = 0;
      }

      return {
        data: {
          success: true,
          TotalInvoices: TotalSum,
          TotalFunded: Fundedsum,
        }
      }
    } catch (error) {
      console.log('error:', error);
      return { data: { success: false, error: error } };
    }
  }
  public async getLApprovedInvoiceGraphToHospital(currentUser: IUser): Promise<{ data: any }> {
    try {
      const userDetails = currentUser;
      var sum1 = 0;
      var sum2 = 0;
      var sum3 = 0;
      var sum4 = 0;
      var sum5 = 0;
      var sum6 = 0;
      var forcalc = new Date();
      var thismonth = forcalc.getMonth() + 1;
      var t = forcalc.getFullYear();
      var this1 = new Date(t, thismonth - 1, 1);

      var month1 = forcalc.getMonth();
      if (month1 < 0) {
        month1 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month1);
      var a = forcalc.getFullYear();
      var d1m1 = new Date(a, month1 - 1, 1);
      var laster1 = new Date(a, month1, 0);
      laster1.setHours(23, 59, 59, 0);
      if (month1 <= 0) {
        month1 += 12;
        a = a - 1
      }

      var month2 = forcalc.getMonth() - 1;
      if (month2 < 0) {
        month2 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month2);
      var b = forcalc.getFullYear();
      var d1m2 = new Date(b, month2 - 1, 1);
      var laster2 = new Date(b, month2, 0);
      laster2.setHours(23, 59, 59, 0);
      if (month2 <= 0) {
        month2 += 12;
        b = b - 1
      }

      var month3 = forcalc.getMonth() - 1;
      if (month3 < 0) {
        month3 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month3);
      var c = forcalc.getFullYear();
      var d1m3 = new Date(c, month3 - 1, 1);
      var laster3 = new Date(c, month3, 0);
      laster3.setHours(23, 59, 59, 0);
      if (month3 <= 0) {
        month3 += 12;
        c = c - 1
      }

      var month4 = forcalc.getMonth() - 1;
      if (month4 < 0) {
        month4 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month4);
      var d = forcalc.getFullYear();
      var d1m4 = new Date(d, month4 - 1, 1);
      var laster4 = new Date(d, month4, 0);
      laster4.setHours(23, 59, 59, 0);
      if (month4 <= 0) {
        month4 += 12;
        d = d - 1
      }

      var month5 = forcalc.getMonth() - 1;
      if (month5 < 0) {
        month5 += 12;
        forcalc.setFullYear(forcalc.getFullYear() - 1);
      }
      forcalc.setMonth(month5);
      var e = forcalc.getFullYear();
      var d1m5 = new Date(e, month5 - 1, 1);
      var laster5 = new Date(e, month5, 0);
      laster5.setHours(23, 59, 59, 0);
      if (month5 <= 0) {
        month5 += 12;
        e = e - 1
      }
      var todaydate = new Date();

      var countser2 = await this.PharmacyModel.aggregate([
        {
          $facet: {
            sumone: [
              {
                $match: {
                  $and: [
                    { HospitalId: userDetails.organizationId },
                    { InvoiceDate: { $gte: this1, $lte: todaydate } },
                    {
                      $or: [
                        { Status: "Lender Approved" },
                        { Status: "Hospital Approved" },
                        { Status: "Fully Repaid" },
                        { Status: "Disbursed" },
                        { Status: "Hospital Repaid" },
                        { Status: "Partially Repaid" }
                      ],
                    },
                  ],
                },
              },
              { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } },
            ],
            sumtwo: [
              {
                $match: {
                  $and: [
                    { HospitalId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m1, $lte: laster1 } },
                    {
                      $or: [
                        { Status: "Lender Approved" },
                        { Status: "Hospital Approved" },
                        { Status: "Fully Repaid" },
                        { Status: "Disbursed" },
                        { Status: "Hospital Repaid" },
                        { Status: "Partially Repaid" }
                      ],
                    },
                  ],
                },
              },
              { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } },
            ],
            sumthree: [
              {
                $match: {
                  $and: [
                    { HospitalId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m2, $lte: laster2 } },
                    {
                      $or: [
                        { Status: "Lender Approved" },
                        { Status: "Hospital Approved" },
                        { Status: "Fully Repaid" },
                        { Status: "Disbursed" },
                        { Status: "Hospital Repaid" },
                        { Status: "Partially Repaid" }
                      ],
                    },
                  ],
                },
              },
              { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } },
            ],
            sumfour: [
              {
                $match: {
                  $and: [
                    { HospitalId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m3, $lte: laster3 } },
                    {
                      $or: [
                        { Status: "Lender Approved" },
                        { Status: "Hospital Approved" },
                        { Status: "Fully Repaid" },
                        { Status: "Disbursed" },
                        { Status: "Hospital Repaid" },
                        { Status: "Partially Repaid" }
                      ],
                    },
                  ],
                },
              },
              { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } },
            ],
            sumfive: [
              {
                $match: {
                  $and: [
                    { HospitalId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m4, $lte: laster4 } },
                    {
                      $or: [
                        { Status: "Lender Approved" },
                        { Status: "Hospital Approved" },
                        { Status: "Fully Repaid" },
                        { Status: "Disbursed" },
                        { Status: "Hospital Repaid" },
                        { Status: "Partially Repaid" }
                      ],
                    },
                  ],
                },
              },
              { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } },
            ],
            sumsix: [
              {
                $match: {
                  $and: [
                    { HospitalId: userDetails.organizationId },
                    { InvoiceDate: { $gte: d1m5, $lte: laster5 } },
                    {
                      $or: [
                        { Status: "Lender Approved" },
                        { Status: "Hospital Approved" },
                        { Status: "Fully Repaid" },
                        { Status: "Disbursed" },
                        { Status: "Hospital Repaid" },
                        { Status: "Partially Repaid" }
                      ],
                    },
                  ],
                },
              },
              { $group: { _id: "$_v", total: { $sum: "$LTVAmount" } } },
            ],
          },
        },
      ]);

      if (countser2[0].sumone[0] != undefined) {
        sum1 = countser2[0].sumone[0].total;
      } else {
        sum1 = 0;
      }
      if (countser2[0].sumtwo[0] != undefined) {
        sum2 = countser2[0].sumtwo[0].total;
      } else {
        sum2 = 0;
      }
      if (countser2[0].sumthree[0] != undefined) {
        sum3 = countser2[0].sumthree[0].total;
      } else {
        sum3 = 0;
      }
      if (countser2[0].sumfour[0] != undefined) {
        sum4 = countser2[0].sumfour[0].total;
      } else {
        sum4 = 0;
      }
      if (countser2[0].sumfive[0] != undefined) {
        sum5 = countser2[0].sumfive[0].total;
      } else {
        sum5 = 0;
      }
      if (countser2[0].sumsix[0] != undefined) {
        sum6 = countser2[0].sumsix[0].total;
      } else {
        sum6 = 0;
      }

      return {
        data: {
          success: true,
          message: [
            [sum1, thismonth, t],
            [sum2, month1, a],
            [sum3, month2, b],
            [sum4, month3, c],
            [sum5, month4, d],
            [sum6, month5, e],
          ],
        }
      }
    } catch (error) {
      console.log('error:', error);
      return { data: { success: false, error: error } };
    }
  }
  public async getHApprovedVendorToHospital(currentUser: IUser): Promise<{ data: any }> {
    try {
      const userDetails = currentUser;
      const Id = userDetails._id.toString();
      const invoices = await this.PharmacyModel.find({
        $and: [{ HospitalId: Id }, { Status: "Hospital Approved" }],
      }).distinct("VendorId");
      var List;
      var Lists = [];

      if (invoices) {
        for (let i = 0; i < invoices.length; i++) {
          let id = invoices[i];
          List = await this.userModel.findOne({ _id: id });

          if (List) {
            Lists = Lists.concat(List);
          }
        }
      }
      if (Lists) {
        var data = Lists.length;
      }
      return { data: { success: true, count: data, message: Lists } }
    } catch (error) {
      console.log('error:', error);
      return { data: { success: false, error: error } };
    }
  }
  public async getHApprovedToHospital(currentUser: IUser): Promise<{ data: any }> {
    try {
      const userDetails = currentUser;
      const Id = userDetails._id.toString();
      const invoices = await this.PharmacyModel.find({
        $and: [{ HospitalId: Id }, { Status: "Hospital Approved" }],
      }).distinct("VendorId");
      var List;
      var Lists = [];

      if (invoices) {
        for (let i = 0; i < invoices.length; i++) {
          let id = invoices[i];
          List = await this.userModel.findOne({ _id: id });

          if (List) {
            Lists = Lists.concat(List);
          }
        }
      }
      if (Lists) {
        var data = Lists.length;
      }
      return { data: { success: true, count: data, message: Lists } }
    } catch (error) {
      console.log('error:', error);
      return { data: { success: false, error: error } };
    }
  }

  //invoices
  public async getInvoicesToDistributor(IFilterDTO: IFilterDTO, currentUser: IUser): Promise<{ data: any }> {
    try {
      //pagination
      var pageNumber = 1;
      var pageSize = 0;
      var total: any = {}
      if (IFilterDTO.pageNumber) {
        var pageNumber = parseInt(IFilterDTO.pageNumber.toString());
      }
      if (IFilterDTO.pageSize) {
        var pageSize = parseInt(IFilterDTO.pageSize.toString());
      }
      //filters
      var searchFilters = [];
      // searchFilters.push({ isDeleted: false });
      // searchFilters.push({ HospitalId: currentUser._id });
      if (currentUser.accessControl == 0) {
        searchFilters.push({ uploadedBy: currentUser._id });
      }
      else if (currentUser.accessControl == 1) {
        searchFilters.push({ HospitalId: currentUser.organizationId });
      }
      else {
        searchFilters.push({ $or: [{ HospitalId: currentUser._id }, { HospitalId: currentUser.organizationId }] });
      }


      if (IFilterDTO.Status != undefined) {
        searchFilters.push({ Status: IFilterDTO.Status });
      }
      if (IFilterDTO.searchTerm != undefined) {
        searchFilters.push({
          $or: [
            { hospitalName: { $regex: IFilterDTO.searchTerm, $options: 'i' } },
            { vendorName: { $regex: IFilterDTO.searchTerm, $options: 'i' } },
            {
              "$expr": {
                "$regexMatch": {
                  "input": { "$toString": "$LoanID" },
                  "regex": IFilterDTO.searchTerm
                }
              }
            }
          ]
        })
      }
      var userCount = await this.PharmacyModel.find({ $and: searchFilters }).countDocuments();
      var totalAmount = await this.PharmacyModel.aggregate([{ $match: { $and: searchFilters } }, { $group: { _id: '$_v', totalAmount: { $sum: '$LTVAmount' } } }
      ]);
      if (totalAmount.length != 0) {
        total.count = userCount
        total.totalAmount = totalAmount[0].totalAmount
      } else {
        total.count = 0
        total.totalAmount = 0
      }
      var numberOfPages = pageSize === 0 ? 1 : Math.ceil(userCount / pageSize);
      var invoices = await this.PharmacyModel
        .find({ $and: searchFilters })
        .sort({ updatedAt: -1 })
        .skip((pageNumber - 1) * pageSize)
        .limit(pageSize);
      var data = { invoices, numberOfPages, total };
      return { data };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  public async deleteInvoicesToDistributor(currentUser: IUser, IFilterDTO: IFilterDTO): Promise<{ data: any }> {
    try {
      const id = IFilterDTO._id;
      var invoice = await this.PharmacyModel.findOne({ _id: id })
      if (invoice.Status != "Pending") {
        return { data: { success: false, message: "Cannot delete Invoice" } }
      }

      var deleteInvoice = await this.PharmacyModel.findByIdAndUpdate({ _id: id }, { $set: { isDeleted: true, updatedBy: currentUser._id } });
      //pending invoice      
      if (deleteInvoice) {
        var data = { success: true, message: "Invoice deleted Successfully" };
        return { data };
      }

    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  // public async getInvoiceByIdToDistributor(IFilterDTO: IFilterDTO): Promise<{ data: any }> {
  //   try {
  //     const Id = IFilterDTO._id;
  //     const invoices = await this.PharmacyModel.findOne({ _id: Id });
  //     var repaymentData;
  //     if (invoices) {
  //       repaymentData = await this.TransactionData.find({ invoiceId: invoices._id })
  //     }

  //     return { data: { success: true, message: invoices, repaymentData } };
  //   } catch (e) {
  //     this.logger.error(e);
  //     throw e;
  //   }
  // }

  public async getHospitalProfileToDistributor(currentUser: IUser): Promise<{ data: any }> {
    try {
      const userDetails = currentUser;
      const hospital = await this.userModel.findOne({ _id: userDetails._id });
      return { data: { success: true, message: hospital } }
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  public async EditHospitalProfileByDistributor(currentUser: IUser, IHospitalDTO: IHospitalSupplierDTO): Promise<{ data: any }> {
    try {
      const userDetails = currentUser;
      let {
        name, address, mobileNumber, GSTNumber, PANNumber, email,
        bankName, AccountNumber, IFSCcode, authorisedPersonName, contactDetailsForAuthPerson,
        PANNumberForAuthPerson, relationShip, Type
      } = IHospitalDTO;

      let data: any = {};
      if (name) { data.name = name; }
      if (address) { data.address = address; }
      if (mobileNumber) { data.mobileNumber = mobileNumber; }
      if (email) { data.email = email; }
      if (GSTNumber) { data.GSTNumber = GSTNumber; }
      if (PANNumber) { data.PANNumber = PANNumber; }
      if (bankName) { data.bankName = bankName; }
      if (AccountNumber) { data.AccountNumber = AccountNumber; }
      if (IFSCcode) { data.IFSCcode = IFSCcode; }
      if (authorisedPersonName) { data.authorisedPersonName = authorisedPersonName; }
      if (contactDetailsForAuthPerson) { data.contactDetailsForAuthPerson = contactDetailsForAuthPerson; }
      if (PANNumberForAuthPerson) { data.PANNumberForAuthPerson = PANNumberForAuthPerson; }
      if (relationShip) { data.relationShip = relationShip; }
      if (Type) { data.Type = Type; }

      if (PANNumber) {
        var users = await this.userModel.find({ PANNumber: PANNumber });
        for (var doc of users) {
          if (doc._id !== currentUser._id) {
            return {
              data: {
                message: " PAN Number already exist",
              }
            };
          }
        }
      }
      if (AccountNumber) {
        var users = await this.userModel.find({ AccountNumber: AccountNumber });
        for (var doc of users) {
          if (doc._id !== currentUser._id) {
            return {
              data: {
                message: " Account Number already exist",
              }
            };
          }
        }
      }
      const hospital = await this.userModel.findByIdAndUpdate({ _id: userDetails._id }, { $set: data }, { useFindAndModify: false });
      return { data: { success: true, message: "Hospital Details updated Successfully" } }
    }
    catch (error) {
      return {
        data: {
          success: false, error
        }
      }
    }
  }
  //approve - reject invoice
  public async editPFInvoiceByDistributor(currentUser: IUser, purchaseFinancingDTO: purchaseFinancingDTO): Promise<{ data: any }> {
    try {
      const id = purchaseFinancingDTO._id;
      const vendorDetail: any = await this.PharmacyModel.findOne({ _id: id });
      
      let invoiceData: any = {};
      
      if (purchaseFinancingDTO.Status == "true") {
        invoiceData.Status = "Distributor Approved";
        invoiceData.distributorComment = purchaseFinancingDTO.distributorComment;
        invoiceData.hDueDate = purchaseFinancingDTO.hDueDate;
        invoiceData.GRNNo = purchaseFinancingDTO.GRNNo;
        invoiceData.GRNValue = purchaseFinancingDTO.GRNValue;
        invoiceData.GRNNotes = purchaseFinancingDTO.GRNNotes;
        invoiceData.GRNDocuments = purchaseFinancingDTO.GRNDocuments
        invoiceData.GRNDate = purchaseFinancingDTO.GRNDate
        var new_NoOfDaysCreditPeriod = vendorDetail.NoOfDaysCreditPeriod

        const upfrontInterest = Math.round(
          (vendorDetail.LTVAmount *
            vendorDetail.RateOfDeduction *
            new_NoOfDaysCreditPeriod) /
          (30 * 100)
        );
        const amountToBeDisbursed = Math.round(
          vendorDetail.LTVAmount - upfrontInterest
        );

        var flag;
        if (new_NoOfDaysCreditPeriod == vendorDetail.NoOfDaysCreditPeriod) {
          flag = "Equal";
        } else if (
          new_NoOfDaysCreditPeriod > vendorDetail.NoOfDaysCreditPeriod
        ) {
          flag = "Greater";
        } else {
          flag = "Lesser";
        }
        if (flag) {
          invoiceData.flag = flag;
        }
        if (amountToBeDisbursed) {
          invoiceData.amountToBeDisbursed = amountToBeDisbursed;
        }
        if (upfrontInterest) {
          invoiceData.upfrontInterest = upfrontInterest;
        }
      } else {
        invoiceData.Status = "Hospital Rejected";
        invoiceData.distributorComment = purchaseFinancingDTO.distributorComment
      }
      invoiceData.updatedAt = new Date().toUTCString();
      invoiceData.HResponseDate = new Date().toUTCString()
      // invoiceData.updatedBy = currentUser._id;


      const invoice = await this.PharmacyModel.findByIdAndUpdate(
        { _id: id },
        { $set: invoiceData },
        { useFindAndModify: false, new: true },
      );
      
      this.nodeMailerService.sendemail(purchaseFinancingDTO.LoanID);
      var data = { success: true, message: "Invoice Updated Successfully" };
      return { data };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  //repayment
  public async postHRepaidToDistributor(currentUser: IUser, purchaseFinancingDTO: purchaseFinancingDTO): Promise<{ data: any }> {
    try {
      let { _id, AmountReceived, ReceivedNEFT_RTG, PaymentReceivedDate } = purchaseFinancingDTO;
      const invoiceDetail = await this.PharmacyModel.findOne({
        $and: [{ _id: _id }, { HospitalId: currentUser._id }],
      });
      var InvoiceDate = invoiceDetail.InvoiceDate.toLocaleDateString();

      var date1 = new Date(PaymentReceivedDate);
      var finalDate1 = new Date(date1.setDate(date1.getDate()));
      PaymentReceivedDate = new Date(finalDate1);

      let anchorDetails: any = {};

      if (PaymentReceivedDate) {
        anchorDetails.PaymentReceivedDate = PaymentReceivedDate;
      }
      anchorDetails.Status = "Hospital Repaid";

      if (AmountReceived) {
        anchorDetails.AmountReceived = AmountReceived;
      }
      if (ReceivedNEFT_RTG) {
        anchorDetails.ReceivedNEFT_RTG = ReceivedNEFT_RTG;
      }

      const invoices = await this.PharmacyModel.updateOne(
        { _id: _id },
        { $set: anchorDetails }
      );
      return {
        data: { success: true, message: "Succesfully Updated" }
      }
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  public async getAllVendorToDistributor(req: Request): Promise<{ data: any }> {
    try {
      const hospitalID = req.currentUser.organizationId;
      var vendor = await this.DPAssociationModel.find({ hospitalId: hospitalID });
      if (vendor) {
        var vendorCount = vendor.length;
      }
      var data = ({ success: true, count: vendorCount, message: vendor })
      return { data };
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  // public async postVendorLimit(req: Request): Promise<{ data: any }> {
  //   try {
  //     const { _id, vendorLimit } = req.body;
  //     const currentUser = req.currentUser;
  //     const currentOrg = await this.organizationModel.findOne({ _id: currentUser.organizationId })

  //     var associationDetails = await this.DPAssociationModel.findOne(
  //       { _id: _id }
  //     );
  //     if (!associationDetails) {
  //       return { data: { success: false, message: "invalid id" } }
  //     }

  //     var existingVendorLimit = associationDetails.creditLimit ? associationDetails.creditLimit : 0
  //     var limitObj: any = {};
  //     var updateUserObj: any = {};

  //     limitObj.creditLimit = vendorLimit;
  //     var UtilizedAmount = associationDetails.UtilizedAmount ? associationDetails.UtilizedAmount : 0;
  //     var Repayment = associationDetails.Repayment ? associationDetails.Repayment : 0;

  //     if (vendorLimit > existingVendorLimit) {
  //       var limitDiff = vendorLimit - existingVendorLimit ;
  //       if (limitDiff > currentOrg.AvailableLimit || !currentOrg.AvailableLimit) {
  //         return {
  //           data: {
  //             success: false,
  //             message: "You don't have sufficient balance"
  //           }
  //         }
  //       }

  //       if (associationDetails.AvailableLimit) {
  //         limitObj.AvailableLimit = associationDetails.AvailableLimit + limitDiff
  //       } else {
  //         limitObj.AvailableLimit = vendorLimit;
  //       }
  //       updateUserObj.AvailableLimit = currentOrg.AvailableLimit - limitDiff
  //       updateUserObj.UtilizedAmount = vendorLimit
  //     }
  //     else {
  //       if (vendorLimit < UtilizedAmount) {
  //         return {
  //           data: {
  //             success: false,
  //             message: "Credit Limit can not be less than utilized amount"
  //           }
  //         }
  //       }
  //       // var limitDiff = existingVendorLimit - vendorLimit
  //       limitObj.AvailableLimit = associationDetails.AvailableLimit - limitDiff
  //       updateUserObj.AvailableLimit = currentOrg.AvailableLimit + limitDiff
  //       updateUserObj.UtilizedAmount = vendorLimit
  //     }
  //     var associationUpdate = await this.DPAssociationModel.findOneAndUpdate(
  //       { _id: req.body._id },
  //       { $set: limitObj }
  //     );

  //     const hospital = await this.organizationModel.updateOne(
  //       { _id: currentOrg._id },
  //       { $set: updateUserObj }
  //     );

  //     var data = ({ success: true, message: "Vendor Limit Updated" })
  //     return { data };
  //   } catch (e) {
  //     this.logger.error(e);
  //     throw e;
  //   }
  // }
  public async repaymentByDistributor(currentUser: IUser, purchaseFinancingDTO: purchaseFinancingDTO): Promise<{ data: any }> {
    try {
      let { _id, AmountReceived, ReceivedNEFT_RTG, PaymentReceivedDate } = purchaseFinancingDTO;
      const invoiceDetail = await this.PharmacyModel.findOne({ _id: _id });
      var InvoiceDate = invoiceDetail.InvoiceDate.toLocaleDateString();

      var date1 = new Date(PaymentReceivedDate);
      var finalDate1 = new Date(date1.setDate(date1.getDate()));
      PaymentReceivedDate = new Date(finalDate1);

      let anchorDetails: any = {};

      if (PaymentReceivedDate) {
        anchorDetails.PaymentReceivedDate = PaymentReceivedDate;
      }

      if (AmountReceived) {
        anchorDetails.AmountReceived = AmountReceived;
      }

      if (AmountReceived >= invoiceDetail.LTVAmount) {
        anchorDetails.Status = "Distributor Repaid";
        anchorDetails.RemainingAmount = 0
      }
      else if (AmountReceived < invoiceDetail.LTVAmount) {

        if (invoiceDetail.RemainingAmount) {
          anchorDetails.RemainingAmount = invoiceDetail.RemainingAmount - AmountReceived;
          if (anchorDetails.RemainingAmount > 0) {
            anchorDetails.Status = "Partially Repaid";
          } else {
            anchorDetails.Status = "Distributor Repaid";
          }
        
        } else {
          anchorDetails.RemainingAmount = invoiceDetail.LTVAmount - AmountReceived;
          anchorDetails.Status = "Partially Repaid";
        }

      }

      if (ReceivedNEFT_RTG) {
        anchorDetails.ReceivedNEFT_RTG = ReceivedNEFT_RTG;
      }

      const invoices = await this.PharmacyModel.updateOne(
        { _id: _id },
        { $set: anchorDetails }
      );
      /// transaction log
      const transaction = await this.TransactionData.create({
        invoiceId: _id,
        LoanID: invoiceDetail.LoanID,
        distributorId: invoiceDetail.distributorId,
        vendorId: invoiceDetail.VendorId,
        lenderId: invoiceDetail.LenderId,
        InvoiceNumber: invoiceDetail.InvoiceNumber,
        AmountDisbursed: invoiceDetail.amountToBeDisbursed,
        transactionDate: PaymentReceivedDate,
        NEFT_RTG: ReceivedNEFT_RTG,
        AmountToBePaid: invoiceDetail.LTVAmount,
        Interest: invoiceDetail.upfrontInterest,
        SettleStatus: anchorDetails.Status,
        // AdditionalDays: AdditionalDays,
        // AdditionalInterest: AdditionalInterest,
        RemainingAmount: anchorDetails.RemainingAmount,
        AmountReceived: AmountReceived,
        createdBy: currentUser._id
      })
      ///

      return {
        data: { success: true, message: "Succesfully Updated" }
      }
    } catch (e) {
      this.logger.error(e);
      throw e;
    }
  }
  public async getAllInvoicesToDistributor(IFilterDTO: IFilterDTO, currentUser: IUser): Promise<{ data: any }> {
    try {
      
        //pagination
        var pageNumber = 1;
        var pageSize = 0;
        var total: any = {};
        if (IFilterDTO.pageNumber) {
            var pageNumber = parseInt(IFilterDTO.pageNumber.toString());
        }
        if (IFilterDTO.pageSize) {
            var pageSize = parseInt(IFilterDTO.pageSize.toString());
        }
        //filters
        var searchFilters = [];
        // searchFilters.push({ isDeleted: false });
        if (currentUser.accessControl == 0) {
            searchFilters.push({ uploadedBy: currentUser._id });
        }
        else if (currentUser.accessControl == 1) {
            searchFilters.push({ distributorId: currentUser.organizationId });
        }
        else {
            searchFilters.push({ $or: [{ distributorId: currentUser._id }, { distributorId: currentUser.organizationId }] });
        }


        if (IFilterDTO.Status != undefined) {
            searchFilters.push({ Status: IFilterDTO.Status });
        }
        if (IFilterDTO.searchTerm != undefined) {
            searchFilters.push({
                $or: [
                    { nameOfHospital: { $regex: IFilterDTO.searchTerm, $options: 'i' } },
                    { claimId: { $regex: IFilterDTO.searchTerm, $options: 'i' } },
                    { patientName: { $regex: IFilterDTO.searchTerm, $options: 'i' } },
                    {
                        "$expr": {
                            "$regexMatch": {
                                "input": { "$toString": "$LoanID" },
                                "regex": IFilterDTO.searchTerm
                            }
                        }
                    }
                ]
            })
        }
        //mongo query
        
        var userCount = await this.PharmacyModel.find({ $and: searchFilters }).countDocuments();
        var numberOfPages = pageSize === 0 ? 1 : Math.ceil(userCount / pageSize);
        var invoices = await this.PharmacyModel
            .find({ $and: searchFilters })
            .sort({ updatedAt: -1 })
            .skip((pageNumber - 1) * pageSize)
            .limit(pageSize);

        var totalAmount = await this.PharmacyModel.aggregate([{ $match: { $and: searchFilters } }, { $group: { _id: '$_v', totalAmount: { $sum: '$LenderApprovalAmount' } } }
        ]);
        
        if (totalAmount.length != 0) {
            total.count = userCount
            total.totalAmount = totalAmount[0].totalAmount
        } else {
            total.count = 0
            total.totalAmount = 0
        }

        var data = { invoices, numberOfPages, total };
        return { data };
    } catch (e) {
        this.logger.error(e);
        throw e;
    }
}
public async getInvoiceByIdToDistributor(req: Request, res: Response, currentUser: IUser): Promise<{ data: any }> {
    try {
        const Id = req.query;
        const userDetails = currentUser;

        const invoices = await this.PharmacyModel.findOne({ _id: Id });
        var repaymentData;
        if (invoices) {
            repaymentData = await this.TransactionData.find({ invoiceId: invoices._id })
        }
        return { data: { success: true, message: invoices, repaymentData } };

    } catch (e) {
        this.logger.error(e);
        throw e;
    }
}
}
