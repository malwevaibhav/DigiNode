const mailjet = require('node-mailjet')
    .connect(process.env.MJ_APIKEY_PUBLIC, process.env.MJ_APIKEY_PRIVATE)

import { Service } from 'typedi';

@Service()
export default class MailJetService {
    constructor(
    ) { }

    public async SendWelcomeEmail(user) {
        const request = mailjet
            .post("send", { 'version': 'v3.1' })
            .request({
                "Messages": [
                    {
                        "From": {
                            "Email": process.env.MJ_FROM_EMAIL,
                            "Name": process.env.MJ_FROM_NAME
                        },
                        "To": [
                            {
                                "Email": user.email,
                                "Name": user.name
                            }
                        ],
                        "Subject": "Welcome To Digisparsh.",
                        "TextPart": "My first Mailjet email",
                        "HTMLPart": `<h3>Dear ${user.name} welcome to <a href="https://uatnewdigi.digisparsh.in/">Digisparsh</a>!</h3><br />
                        May the force be with you!`,
                        "CustomID": "AppGettingStartedTest"
                    }
                ]
            })
        request
            .then((result) => {
                console.log(result.body)
            })
            .catch((err) => {
                console.log(err.statusCode)
            })
    }
}




