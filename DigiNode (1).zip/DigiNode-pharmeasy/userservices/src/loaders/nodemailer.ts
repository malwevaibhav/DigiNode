const nodemailer = require('nodemailer');

export default class nodeMailerService {
  constructor(
  ) { }

public async sendemailforclaim(invoiceData){
    console.log( "invoiceData" ,invoiceData);
    const email = "shivam.gupta@moreyeahs.in"
    const name = "operation"
    var transporter = nodemailer.createTransport({
      service: 'outlook',
      host: 'smtp.office365.com',
      port: 587,
      auth: {
        user: 'connect@digisparsh.in',
        pass: 'Digisparsh@2022'
      }
    });
    console.log(email, 'email')
    var mailOptions = {
      from: 'connect@digisparsh.in',
      to: email,
      subject: `Invoice no  ${invoiceData} : Claim finance alert: Pending Approval New Case`,
      html: `<h4>Dear Ops Team,</h4></br>

 <p>A new Claim finance case Invoice  no <span style="color:#008F99;">${invoiceData}</span> is pending for your approval.</p>
 <p>Kindly login and approve the same.</p>
 <p>Or Pls click the below link for your approval.</p>

 <a href="https://portal.digisparsh.in/Select">https://portal.digisparsh.in/Select</a>

 <h4>Regards</h4>
 <h4>Tech team</h4>`
    };
    transporter.sendMail(mailOptions, function (error, info) {
      if (error) {
        console.log(error);
      } else {
        console.log('Email sent: ' + info.response);
      }
    });
  }

      public async sendemail(invoiceData){
        console.log( "invoiceData" ,invoiceData);
        const email = "shivam.gupta@moreyeahs.in"
        const name = "operation"
            var transporter = nodemailer.createTransport({
              service: 'outlook',
              auth: {
                user: 'connect@digisparsh.in',
                pass: 'Digisparsh@2022'
              }
            });
          console.log(email, 'email')
          var mailOptions = {
            from: 'connect@digisparsh.in',
            to: email,
            subject: `Invoice no  ${invoiceData} : Supplier finance alert: Pending Approval New Case`,
            html: `<h4>Dear Ops Team,</h4></br>
    
     <p>A new supplier finance case Invoice  no <span style="color:#008F99;">${invoiceData}</span> is pending for your approval.</p>
     <p>Kindly login and approve the same.</p>
     <p>Or Pls click the below link for your approval.</p>
    
     <a href="https://portal.digisparsh.in/Select">https://portal.digisparsh.in/Select</a>
    
     <h4>Regards</h4>
     <h4>Tech team</h4>`
          };
          transporter.sendMail(mailOptions, function(error, info){
              if (error) {
                console.log(error);
              } else {
                console.log('Email sent: ' + info.response);
              }
            });
          }  
          
          public async sendemailForNewInvoice(invoiceData){
            console.log( "invoiceData" ,invoiceData);
            const email = "shivam.gupta@moreyeahs.in"
            const name = "operation"
                var transporter = nodemailer.createTransport({
                  service: 'outlook',
                  auth: {
                    user: 'connect@digisparsh.in',
                    pass: 'Digisparsh@2022'
                  }
                });
              console.log(email, 'email')
              var mailOptions = {
                from: 'connect@digisparsh.in',
                to: email,
                subject: `Invoice no  ${invoiceData} : Supplier finance alert: New Case`,
                html: `<h4>Dear Ops Team,</h4>
        
         <p>A new supplier finance case Invoice  no <span style="color:#008F99;">${invoiceData}</span> is generated.</p>
         
         <h4>Regards</h4>
         <h4>Tech team</h4>`
              };
              transporter.sendMail(mailOptions, function(error, info){
                  if (error) {
                    console.log(error);
                  } else {
                    console.log('Email sent: ' + info.response);
                  }
                });
              }   
    
              public async sendemailforPatient(invoiceData){
                console.log( "invoiceData" ,invoiceData);
                const email = "shivam.gupta@moreyeahs.in"
                const name = "operation"
                    var transporter = nodemailer.createTransport({
                      service: 'outlook',
                      host: 'smtp.office365.com',
                      port: 587,
                      auth: {
                        user: 'connect@digisparsh.in',
                        pass: 'Digisparsh@2022'
                      }
                    });
                  console.log(email, 'email')
                  var mailOptions = {
                    from: 'connect@digisparsh.in',
                    to: email,
                    subject: `Invoice no  ${invoiceData} : Patient finance alert: Pending Approval New Case`,
                    html: `<h4>Dear Ops Team,</h4></br>
            
             <p>A new Patient finance case Invoice  no <span style="color:#008F99;">${invoiceData}</span> is pending for your approval.</p>
             <p>Kindly login and approve the same.</p>
             <p>Or Pls click the below link for your approval.</p>
            
             <a href="https://portal.digisparsh.in/Select">https://portal.digisparsh.in/Select</a>
            
             <h4>Regards</h4>
             <h4>Tech team</h4>`
    };
    transporter.sendMail(mailOptions, function (error, info) {
      if (error) {
        console.log(error);
      } else {
        console.log('Email sent: ' + info.response);
      }
    });
  }

}


